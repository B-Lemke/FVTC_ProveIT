﻿Function FindUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	User_In = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$User_In
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------
    #write-debug "input: $User_In"
	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($User_In)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($User_In -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($User_In.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
	# NULL variables (just in case)
	#$User_FullNameArray = @()
    $Original = $null
	$ErrorMsg = $null
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$filtering_Lastname = $false
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
    $SearchingBase = "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
            write-host "Setting User LastName to: $User_LastName..."
	        #write-debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            #write-debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug " First Name: $User_FirstName"
                write-host "Setting User First Name to: $($User_FirstName)..."
                $User_MiddleName = $($User_FullNameArray[1])
	            #write-debug " Middle Name: $User_MiddleName"
                write-host "Setting User Middle Name to: $($User_MiddleName)..."
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                #write-debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
                write-host "Setting User MI to: $($User_MI)..."
	            #write-debug " Middle Initial Part 2 : $User_MI"
                #write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                write-host "Formating First Name for AD search..."
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                write-host "Formating Last Name for AD search..."
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
                        write-host "Comparing list of known non-name words to Last Name..."
	                    #write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
                            write-host "Found non-name Last Name, Setting different Last Name..."
	                        #write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
                                
	                            #write-debug "Index of filtered word is > 0"
                                if($User_MiddleName)
                                {
                                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 1)
                                    {
                                        write-host "Reconfiguring MI..."
                                        #write-debug "Index of filtered word is > 1"
                                        $User_MiddleName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_MiddleName) - 1)])
                                        $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                                        #write-debug "MI set to: $User_MI"
                                        write-host "Setting MI to: $User_MI..."
                                    }
                                    else
                                    {
                                        write-host "Nulling Middle Name do to not found..."
                                        #write-debug "Index of filtered word is NOT > 1"
                                        #write-debug "MI and Middle name set to NULL"
                                        $User_MiddleName = $null
                                        $User_MI = $null
                                    }
                                }
	                            #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                write-host "Setting Last Name to: $User_LastName..."
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            #write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
                                write-host "Last Name wasn't found..."
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
                            write-host "Filtering completed"
	                        #write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                            write-host "Setting Filtered Name to: $User_LastName"
	                        $filtering_Lastname = $false
	                    }
	                }
                    write-host $User_FirstName
                    write-host $User_LastName
                    if($filteredName -eq $false)
                    {
	                    #write-debug "Name not filtered"
                        write-host "Searching by First Name, Last Name, and MI..."
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            write-host "Searching by First Name and Last Name..."
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                write-host "Searching by Last Name and MI..."
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    write-host "Searching by Last Name..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                }        
                            }
                        }
                    }
                    else
                    {
                        #write-debug "Name was filtered"
                        if(!($User_LastName -eq "Last Name not Found"))
                        {
                            #write-debug "Last Name was found"
                            if($User_MI)
                            {
                                #write-debug "Middle Name exists"
                                write-host "Searching by First Name, Last Name, and MI..."
	                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    write-host "Searching by First Name and Last Name..."
                                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        write-host "Searching by Last Name and MI..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                        if(!($AD_User))
                                        {
                                            write-host "Searching by Last Name..."
                                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                        }        
                                    }
                                }
                            }
                            else
                            {
                                #write-debug "Middle Name Doesn't exist"
                                write-host "Searching by First Name and Last Name..."
                                $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                if(!($AD_User))
                                {
                                    write-host "Searching by First Name and Last Name with wildcarded firstname..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        write-host "Searching by Last Name..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }
                            }
                        }
                        else
                        {
                            #write-debug "No AD_User found do to no Last name found"
                            $AD_User = $null
                        }
                    }
                }
	            else
	            {
	                #write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    #write-debug "Last name was null"
	                }
	                else
	                {
	                    #write-debug "First name was null"
	                }
	                #write-debug "AD_User set to null"
	                $AD_User = $null
	            }

	            #write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    #write-debug "Less than 1 user found"                    
                }
            }
            else
            {
	            #write-debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
                    write-host "Filtering out non-name Words..."
	                #write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    #write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
                            write-host "Getting new index of Last Name..."
	                        #write-debug "Index of filtered word is > 0"
	                        #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            write-host "Setting Last Name to $User_LastName..."
                            $filteredName = $true
	                    }
	                    else
	                    {
                            write-host "Last Name wasn't found..."
	                        #write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
                        write-host "Filtering Completed..."
	                    #write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                        write-host "Setting Last Name to $User_LastName..."
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                #write-debug "Last Name was found after filtering"
	                #write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    write-host "Searching by First and Last Name..."
                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                    if(!($AD_User))
                    {
                        write-host "Searching by First and Last Name wildcarded..."
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        if(!($AD_User))
                        {
                            write-host "Searching by Last Name wildcarded..."
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                        }
                    }
	                #write-debug "Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
                    write-host "Last Name not found..."
	                #write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        #write-debug "Input has 1 word"
            #write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            #write-debug "Last Name set to $($User_LastName)"
            write-host "Formating Last Name for AD search..."
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            write-host "Search AD for users by Last Name..."
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                write-host "Seaching AAH users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
            write-host "No Valid input for users name detected..."
	        #write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        #write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
            write-host "Formatting User output..."
	        #write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
                
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);                           
                                'SSO' = $($entry.sAMAccountName);
                                'ID' = $($entry.EmployeeID);
                                'SID' = $($entry.SID)}
                $User_Object = New-Object –TypeName PSObject –Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($lstUsers.Count) -gt 1)
	        {
                write-host "Selecting User..."
	            #write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
                @{Name="ID";Expression = { $_.ID }; Alignment="left" },
	            @{Name="Email";Expression = { $_.Email }; Alignment="left" }
                @{Name="SID";Expression = { $_.SID }; Alignment="left" }|out-null
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results -ge 0)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
write-host "$($ad_user.FirstName)"
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                }
                write-host "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	        elseif ($($lstUsers.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                #write-debug "AD FIRST NAME $($AD_User.Firstname)"
                #write-debug $ad_user.Lastname
                #write-debug $ad_user.Email
	            #write-debug "User count = 1"
                write-host "Formating User's First Name for AD Search..."
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
                write-host "Formating User's Last Name for AD Search..."
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                #write-debug $User_FirstName
                #write-debug $User_LastName
	            write-host "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	    }
	    else
	    {
	        #write-debug "No user found setting variables to null"
	        #write-debug "Searching Corperate Users"
	        $AD_User = (Get-CorpUser -UserIn $original)
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
    }
	else
	{
	    #write-debug "[FAILURE] FindUser - Initial parameter input was null"
	    $ErrorMsg = "FindUser - $Param_ErrorMsg"
	}

    write-host "Formating User output..."
	if($AD_User)
	{
	    $properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	                    'LastName' = $AD_User.LastName;
	                    'MI' = $AD_User.Initials;
	                    'Email' = $AD_User.Email;
	                    'SSO' = $AD_User.SSO;
                        'SID' = $AD_User.SID;
                        'ID' = $AD_User.ID;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	else
	{$errorMsg = "No User Selected"
	    $properties = [ordered]@{'FirstName' = $null;
	                    'LastName' = $null;
	                    'MI' = $null;
	                    'Email' = $null;
	                    'SSO' = $null;
                        'SID' = $null;
                        'ID' = $null;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
    write-host "Returning User output..."
	return $Return_Object
}

Function Get-CorpUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$original = $UserIn
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$filtering_Lastname = $false
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
    $SearchingBase = "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
	        #write-debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            #write-debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug " First Name: $User_FirstName"
                $User_MiddleName = $($User_FullNameArray[1])
	            #write-debug " Middle Name: $User_MiddleName"
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                #write-debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
	            #write-debug " Middle Initial Part 2 : $User_MI"
                
                #write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
	                    #write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
	                        #write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
	                            #write-debug "Index of filtered word is > 0"
	                            #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            #write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
	                        #write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    #write-debug "First and Last name evaluated as not null"
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                    if(!($AD_User))
                                    {
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }        
                            }
                        }
                    }
                    else
                    {
                        $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            }
                        }
                    }
                }
	            else
	            {
	                #write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    #write-debug "Last name was null"
	                }
	                else
	                {
	                    #write-debug "First name was null"
	                }
	                #write-debug "user set to null"
	                $AD_User = $null
	            }

	            #write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    #write-debug "Less than 1 user found"
                    if($filteredName -eq $false)
                    {
                        #write-debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            #write-debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                if(!($AD_User))
                                {
                                    write-host "Seaching Corp users by first name"
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                                }
                            }
                        }
                    }
                    else
                    {
                        #write-debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            #write-debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                write-host "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }

                    
                }
            }
            else
            {
	            #write-debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
	                #write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1-9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    #write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
	                        #write-debug "Index of filtered word is > 0"
	                        #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            $filteredName = $true
	                    }
	                    else
	                    {
	                        #write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
	                    #write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                #write-debug "Last Name was found after filtering"
	                #write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    if($filteredName -eq $true)
                    {
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                write-host "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
                    else
                    {
	                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                write-host "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
	                #write-debug " Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
	                #write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        #write-debug "Input has 1 word"
            #write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            #write-debug "Last Name set to $($User_LastName)"
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                write-host "Seaching Corp users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
	        #write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        #write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
	        #write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);
                                'SSO' = $($entry.sAMAccountName);
                                'SID' = $($entry.SID);
                                'ID' = $($entry.EmployeeID)}
                $User_Object = New-Object –TypeName PSObject –Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($lstUsers.Count) -gt 1)
	        {
	            #write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
                @{Name="SID";Expression = { $_.SID }; Alignment="left" },
                @{Name="ID";Expression = { $_.ID }; Alignment="left" },
	            @{Name="Email";Expression = { $_.Email }; Alignment="left" }|out-null
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                    
                }

	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	        elseif ($($lstUsers.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                #write-debug "AD FIRST NAME $($AD_User.Firstname)"
                #write-debug $ad_user.Lastname
                #write-debug $ad_user.Email
	            #write-debug "User count = 1"
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                #write-debug $User_FirstName
                #write-debug $User_LastName
	
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	    }
	    else
	    {
	        #write-debug "No user found setting variables to null"
	        $AD_User = $null
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
	}
	else
	{
	#write-debug "[FAILURE] FindCorpUser - Initial parameter input was null"
	$ErrorMsg = "FindCorpUser - $Param_ErrorMsg"
	}


	if($AD_User)
	{
	$properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	'LastName' = $AD_User.LastName;
	'MI' = $AD_User.MI;
	'Email' = $AD_User.Email;
	'SSO' = $AD_User.SSO;
    'ID' = $AD_User.ID;
    'SID' = $AD_User.SID;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	else
	{
	$properties = [ordered]@{'FirstName' = $null;
	'LastName' = $null;
	'MI' = $null;
	'Email' = $null;
	'SSO' = $null;
    'ID' = $null;
    'SID' = $null;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	
	return $Return_Object
}

    Function Show-SelectionForm($lstSelections)
    {
 
	    #---------------------------------------------- 
	    #region Import Assemblies 
	    #---------------------------------------------- 
	    [void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	    #endregion Import Assemblies  
 
	    function SelectForm($input1) 
	    { 
	    $Script:SelectionForm_RowIndex = $null
	    <# 
	        .SYNOPSIS 
	    The Main function starts the project application. 
	     
	        .PARAMETER Input1
	    $Input1 contains the complete argument string passed to the script packager executable. 
	     
	        .NOTES 
	    Use this function to initialize your script and to call GUI forms. 
	         
	        .NOTES 
	    To get the console output in the Packager (Forms Engine) use:  
	    $ConsoleOutput (Type: System.Collections.ArrayList) 
	    #> 
	     
	    #-------------------------------------------------------------------------- 
     
	    if((Call-SelectForm_psf($input1)) -eq 'OK') 
	    { 
	    # ADD VALIDATION IF NEEDED
	        } 
	    $global:ExitCode = 0 #Set the exit code for the Packager 
	    } 
 
	    #endregion Source: Startup.pss 
 
	    #region Source: MainForm.psf 
	    function Call-SelectForm_psf($input1) 
	    { 
	    #Datagrid click Function
	        Function dg_Selections_GridClick
	    {
	    #Set $Script:SelectionForm_RowIndex to index of the currently selected row
	    [int]$Script:SelectionForm_RowIndex = $dg_Selections.CurrentRow.Index + 1
	    }
    
	    #Add Data to Datagrid function
	    function Get-ProcessInfo($input1) 
	    {
	    $array = New-Object System.Collections.ArrayList
	    $array.AddRange($input1)
	    $dg_Selections.DataSource = $array
	    $selectform.refresh()
	    $dg_Selections.ClearSelection()
	    }
 
	    #---------------------------------------------- 
	    #region Import the Assemblies 
	    #---------------------------------------------- 
	    [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	    #endregion Import Assemblies 
	 
	    #---------------------------------------------- 
	    #region Generated Form Objects 
	    #---------------------------------------------- 
	    [System.Windows.Forms.Application]::EnableVisualStyles() 
	    $SelectForm = New-Object 'System.Windows.Forms.Form'
	    $ButtonCancel = New-Object 'System.Windows.Forms.Button' 
	    $ButtonSelect = New-Object 'System.Windows.Forms.Button' 
	    $panel1 = New-Object 'System.Windows.Forms.Panel'
	    $panel2 = New-Object 'System.Windows.Forms.Panel'
	    $panel3 = New-Object 'System.Windows.Forms.Panel'
	    $panel4 = New-Object 'System.Windows.Forms.Panel'
	    $dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
	    $InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
	    #endregion Generated Form Objects 
 
	    #---------------------------------------------- 
	    # Form Object Functions
	    #---------------------------------------------- 

	    #Form Load function
	    $SelectForm_Load =
	    { 
	    get-processinfo($input1)         
	    }
	
	    #Select Button clicked function
	    $ButtonSelect_Click = 
	    {     
	    #Checks for input selected before allowing form close from select button click
	    if ($Script:SelectionForm_RowIndex -or $Script:SelectionForm_RowIndex -eq 0)
	    {
	    $SelectForm.Close()
	    }
	    } 

	    #Cancel Button clicked function
	    $ButtonCancel_Click =
	    {
               #TODO: Place custom script here on canceling form
	    $SelectForm.Close() 
	    } 
     
            # --End Form Object Functions-- 
	    #---------------------------------------------- 
	    #region Generated Events 
	    #---------------------------------------------- 
	
	    #Fix Form Load function
	    $Form_StateCorrection_Load = 
	    { 
	            #Correct the initial state of the form to prevent the .Net maximized form issue 
	    $SelectForm.WindowState = $InitialFormWindowState 
	    } 
     
	    #Store Values of form function
	    $Form_StoreValues_Closing = 
	    { 
	    #Store the control values here
	    } 
 
	    $Form_Cleanup_FormClosed = 
	    { 
	            #Remove all event handlers from the controls 
	    try 
	    { 
	                $ButtonCancel.remove_Click($buttonCancel_Click) 
	    $ButtonSelect.remove_Click($ButtonSelect_Click)
	    $SelectForm.remove_Load($SelectForm_Load) 
	    $SelectForm.remove_Load($Form_StateCorrection_Load) 
	    $SelectForm.remove_Closing($Form_StoreValues_Closing) 
	    $SelectForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	    } 
	    catch [Exception] 
	    { } 
	    } 
	    #endregion Generated Events 
 
	    #---------------------------------------------- 
	    #region Form Setup Objects
	    #---------------------------------------------- 
	    #Suspend layouts
	    $SelectForm.SuspendLayout()
	    $panel4.SuspendLayout() 
	    $panel3.SuspendLayout() 
	    $panel2.SuspendLayout() 
	    $panel1.SuspendLayout()
	 
	    # 
	    # SelectForm Attributes
	    # 
	    $SelectForm.Controls.Add($panel1)
	    $SelectForm.Controls.Add($panel2) 
	    $SelectForm.AutoScaleDimensions = '6, 13' 
	    $SelectForm.AutoScaleMode = 'Font' 
	    $SelectForm.BackColor = 'White' 
	    $SelectForm.ClientSize = '373, 329'   
	    $SelectForm.MaximizeBox = $False 
	    $SelectForm.MinimizeBox = $False 
	    $SelectForm.Name = 'SelectForm' 
	    $SelectForm.ShowIcon = $False 
	    $SelectForm.ShowInTaskbar = $False 
	    $SelectForm.StartPosition = 'CenterScreen' 
	    $SelectForm.Text = "Select One:"
	    $formsizex = $SelectForm.ClientSize.Width + 100
	    $formsizey =  $SelectForm.ClientSize.Height + 100
	    $SelectForm.MinimumSize = "$formsizex,$formsizey"
	    $selectform.MaximumSize = "$($formsizex + 600),$formsizey"
	    $SelectForm.TopMost = $True 
	    $SelectForm.add_Load($SelectForm_Load)
	    # 
	    # ButtonCancel Attributes
	    # 
	    $ButtonCancel.Location = '250, 50' 
	    $ButtonCancel.Name = 'ButtonCancel' 
	    $ButtonCancel.Size = '77, 45' 
	    $ButtonCancel.TabIndex = 7 #TODO FIX TABINDEXES
	    $ButtonCancel.Text = 'Cancel' 
	    $ButtonCancel.UseVisualStyleBackColor = $True 
	    $ButtonCancel.add_Click($buttonCancel_Click)
	    $ButtonCancel.Dock = [System.Windows.Forms.DockStyle]::Right
	    # 
	    # ButtonSelect Attributes
	    # 
	    $ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	    $ButtonSelect.ForeColor = 'Blue' 
	    $ButtonSelect.Location = '42, 50' 
	    $ButtonSelect.Name = 'ButtonSelect' 
	    $ButtonSelect.Size = '91, 45' 
	    $ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	    $ButtonSelect.Text = 'Select' 
	    $ButtonSelect.UseVisualStyleBackColor = $True 
	    $ButtonSelect.add_Click($ButtonSelect_Click)
	    $ButtonSelect.MaximumSize.Height = '60' 
	    $ButtonSelect.Dock = [System.Windows.Forms.DockStyle]::Left
	    # 
	    # Panel1 Attributes
	    #  
	    $panel1.Controls.Add($dg_Selections)
	    $panel1.Location = '0, 0' 
	    $panel1.Name = 'panel1' 
	    $panel1.Size = '375, 310' 
	    $panel1.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel1.BackColor = 'LightGray'
	    $panel1.Dock = [System.Windows.Forms.DockStyle]::Top
	    # 
	    # Panel3 Attributes
	    # 
	    $panel3.Controls.Add($ButtonSelect)  
	    $panel3.Location = '188, 310' 
	    $panel3.Name = 'panel2' 
	    $panel3.Size = '188, 80' 
	    $panel3.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel3.Padding = '100,20,0,20' 
	    $panel3.BackColor = 'LightSkyBlue'
	    $panel3.Dock = [System.Windows.Forms.DockStyle]::Left
	    # 
	    # Panel4 Attributes
	    # 
	    $panel4.Controls.Add($ButtonCancel)    
	    #$panel2.Controls.Add($dg_Selections) 
	    #$panel1.BackColor = '0, 114, 198' 
	    $panel4.Location = '0, 310' 
	    $panel4.Name = 'panel2' 
	    $panel4.Size = '188, 80' 
	    $panel4.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel4.Padding = '0,20,100,20' 
	    $panel4.BackColor = 'LightSkyBlue'
	    $panel4.Dock = [System.Windows.Forms.DockStyle]::Right
	    # 
	    # Panel2 Attributes
	    # 
	    $panel2.Controls.Add($panel3)  
	    $panel2.Controls.Add($panel4)  
	    $panel2.Location = '0, 310' 
	    $panel2.Name = 'panel2' 
	    $panel2.Size = '376, 80' 
	    $panel2.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel2.BackColor = 'LightSkyBlue'
	    $panel2.Dock = [System.Windows.Forms.DockStyle]::Bottom
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.Size = '375, 300'
	    $dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	    $dg_Selections.Name = "dg_Selections"
	    $dg_Selections.DataMember = ""
	    #$dg_Selections.TabIndex = 0 #TODO FIX TABINDEXES
	    $dg_Selections.Location = '0,0'
	    $dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	    $dg_Selections.AutoSizeRowsMode = "AllCells"
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	    $dg_Selections.DefaultCellStyle.WrapMode = 'True'
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	    $dg_Selections.Margin = New-Object System.Windows.Forms.Padding(3, 3, 3, 3)
	    $dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	    $dg_Selections.RowHeadersVisible = $false
	    $dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	    #Resume Layouts
	    $panel1.ResumeLayout() 
	    $panel2.ResumeLayout()
	    $panel3.ResumeLayout() 
	    $panel4.ResumeLayout()  
	    $SelectForm.ResumeLayout()
	 
	    #endregion Form Setup Objects
	    #---------------------------------------------- 
	
	    #Save the initial state of the form 
	    $InitialFormWindowState = $SelectForm.WindowState 
	    #Init the OnLoad event to correct the initial state of the form 
	    $SelectForm.add_Load($Form_StateCorrection_Load) 
	    #Clean up the control events 
	    $SelectForm.add_FormClosed($Form_Cleanup_FormClosed) 
	    #Store the control values when form is closing 
	    $SelectForm.add_Closing({
	    #Add Closing code here
	    }) 
	    #Show the Form 
	    return $SelectForm.ShowDialog()

	    #endregion Source: MainForm.psf 
	    $self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	    }
	
	    #Start the application 
	    SelectForm ($lstSelections)
    return $Script:SelectionForm_RowIndex
    }

Function Format-AD-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$Param_ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	#$Name = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","*")
	}
	else
	{
	#write-debug "Could not format null valued name"
	}	
	}
	else
	{
	#write-debug "[FAILURE] Format-AD-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-AD-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}

#TODO GENERAL UPDATING TO GUI
Function Format-String-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","`'`'")
	$Name = $Name.trim() 
	}
	else
	{
	#write-debug "Could not format null valued name"
	}
	}
	else
	{
	#write-debug "[FAILURE] Format-String-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-String-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


$UserList = "PC_List.txt"
$UserList = "$($PSScriptRoot)\$($UserList)"
(gc $UserList) | ? {$_.trim() -ne "" } | set-content $UserList
    write-output "" | Out-File -FilePath "$($UserList)" -Encoding ascii -Append 
    $users = Get-Content $UserList


    write-host -ForegroundColor Yellow "Users in list:"
    write-host -ForegroundColor Cyan "----------------------"
    foreach($line in $users)
{
   if($line -ne "" -and  $line -ne " " -and $line -ne $null)
        {
            write-host $line
        }
        else
        {
            continue
        }
    }
    write-host -ForegroundColor Cyan "----------------------`n"
$arUsers = @()
foreach($line in $users)
{
if($line.trim())
{
$line = $line.trim()
    $psuser = $null
    $psuser = FindUser($line)
    if($psuser)
    {
    write-host "psuser found"
        if($psuser.Errormsg)
        {
            continue
        }
        $trmFirstname = $null
		$trmlastname = $null
		$trmMI = $null
		$firstnameOut = $null
		$lastnameOut = $null
		$MIout = $null

		$firstnameOut = $($psuser.FirstName)
		$trmFirstname = $firstnameOut.trim()

		$lastnameOut = $($psuser.LastName)
		$trmlastname = $lastnameOut.trim()

        if ($($psuser.MI) -eq "" -or $($psuser.MI) -eq " " -or $($psuser.MI) -eq $null)
        {
            $name = $trmFirstname + " " + $trmlastname 
        }
        else
        {
		    $MIout = $($psuser.MI)
		    $trmMI = $MIout.trim()
            $name = $trmFirstname + " " + $trmMI + " " + $trmlastname
        }

        $email = $($psuser.Email)
        $username = $($psuser.SSO)
		$sid = $($psuser.SID)

        $properties = @{'Name' = $Name;
	                    'Email' = $email;
                        'SID' = $sid;
                        'Username' = $username;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
        $arUsers += $Return_Object
    }
    else
    {
        continue
    }
    }
}
if(test-path "C:\Temp\EmailList.txt")
{
Remove-Item "C:\Temp\EmailList.txt" -Force
}
$arEmails = @()
write-output " " | Out-File "C:\Temp\EmailList.txt" -Encoding ascii
write-host "Writing emails to C:\temp\EmailList.txt..." -NoNewline
foreach($u in $arUsers)
{
$arEmails += $($u.Email)
write-output $($u.Email) | Out-File "C:\Temp\EmailList.txt" -Encoding ascii -Append
}
write-host "DONE"
write-host "EMAILS:"
write-host "--------------------------------------"
$arEmails |fl
write-host "--------------------------------------"
read-host "`nPress Enter to exit"



#ArEmails is all emails found Otherwise C:\temp\Emaillist.txt also contains the email list (can be functionalized)

