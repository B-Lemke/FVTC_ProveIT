Param(
[String]$line,
[String]$PCList,
[String]$out_PCLogsFolderPath,
[String]$CompletedList,
[String]$PCLogs,
[String]$ScriptRoot,
[String]$Model,
[switch]$changeADdesc
)

#****************************************
#-------------- Inital Setup ------------

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $Script:NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User = $Script:NonAdmin_User.trim()
            $Script:NonAdmin_User1 = "AFII\$($Script:NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Script:NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}

cls
write-output "------------ Started UpdaterBase Script at $((Get-Date).ToString()) -------------------`n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "------------ Started UpdaterBase Script at $((Get-Date).ToString()) -------------------`n" 

if ($changeADdesc -eq $true)
{
write-host "Will be changing AD Description"
}
else
{
write-host "Won't be changing AD Description"
}




Set-QuickEdit -DisableQuickEdit

$scriptRoot2 = "$PSScriptRoot"
$ParentFullName = (get-item $scriptRoot2).Parent.FullName
$BiosRoot = "C:\Temp\DellBIOSProvider"

$PCRunningScript = hostname
$EUCPCs = @()
$EUCUsers = @()
$EUC = @{bwienk1 = "WILG00MP18YWSB";mjung11 = "WILG00PF0RCUKC"}
foreach ($key in $EUC.Keys)
{
    if ($EUC[$key] -eq $PCRunningScript)
    {

    }
    else
    {
    $EUCPCs += $EUC[$key]
    $EUCUsers += $key
    }
}

import-module ActiveDirectory

$xl3 = New-Object -COM "Excel.Application"
$xl3.Visible = $false
$wb3 = $xl3.Workbooks.Open("$($ScriptRoot)\Bios\$($Model)Bios.xlsx")
$ws3 = $wb3.Sheets.Item(1)

$WorksheetRange3 = $ws3.UsedRange
$RowCount3 = $WorksheetRange3.Rows.Count
$ColumnCount3 = $WorksheetRange3.Columns.Count

$T1 = @()
$T2 = @()
$T3 = @()
for ($t = 1; $t -le $ColumnCount3; $t++){

for ($ir = 2; $ir -le $RowCount3; $ir++){

#get data:
$testB = $ws3.Cells.Item($ir, $t).Text
#write-host "C= $($c) I= $($i)"
#write-host "Test2 = $($test2)"

if ($t -eq 1){$T1 += $testB}
if ($t -eq 2){$T2 += $testB}
if ($t -eq 3){$T3 += $testB}
else{

} 

}

}

$BiosName = $T1[0]
$sourceBios = $T2[0]
$BiosScript = $T3[0]

#clean up

$wb3.Close()
$xl3.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)

#[array]$file = Get-Content $psscriptroot\Set-Lenovo_Bios\BiosSettings.txt


#*************************************************
#---------------BIOS END-----------------------
#*************************************************



#*************************************************
#---------------DRIVERS START-----------------------
#*************************************************
$readdList = 0

$sourceName = @()
$sourceRoot = @()
$sourceCMD = @()
$FileRoots = @()

$xl = New-Object -COM "Excel.Application"
$xl.Visible = $false
$wb = $xl.Workbooks.Open("$($ScriptRoot)\Drivers\$($Model)Drivers.xlsx")
$ws = $wb.Sheets.Item(1)

$WorksheetRange = $ws.UsedRange
$RowCount = $WorksheetRange.Rows.Count
$ColumnCount = $WorksheetRange.Columns.Count

$c1 = @()
$c2 = @()
$c3 = @()
$c4 = @()
$c5 = @()
$c6 = @()
$c7 = @()
$c8 = @()
for ($c = 1; $c -le $ColumnCount; $c++){

for ($i = 2; $i -le $RowCount; $i++){

#get data:
$test2 = $ws.Cells.Item($i, $c).Text

if ($c -eq 1){$c1 += $test2}
if ($c -eq 2){$c2 += $test2}
if ($c -eq 3){$c3 += $test2}
if ($c -eq 4){$c4 += $test2}
if ($c -eq 5){$c5 += $test2}
if ($c -eq 6){$c6 += $test2}
if ($c -eq 7){$c7 += $test2}
if ($c -eq 8){$c8 += $test2} 

}

}

for ($i = 0; $i -le $c1.Length-1; $i++) 
{
$FileRoots += $c2[$i]
if ($c3[$i] -ne "")
{
  #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
 $sourceName += $c1[$i]
 
$sourceRoot += $c2[$i]
$sourceCMD += $c3[$i]
}
  }

#cleanup
$wb.Close()
$xl.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)

write-host "Loaded Drivers"

#Driver installer powershell script locationF
$PSFile1 = "G:\Temp\bwienk\7010\UpdateDrivers.ps1"
$PSFile2 = "G:\Temp\bwienk\7010\dellclient.ps1"

$FileRoots += $PSFile1
$FileRoots += $PSFile2
$FileRoots += $sourceBios
$FileRoots += $BiosRoot



Import-Module $ScriptRoot\Modules\Excel.psm1

Check-Credentials





#-------------- Inital Setup ------------
#****************************************

#-----------------------------------------------------------------------------------------------
#Write-output "********** Automated Driver/Bios update for newly imaged PC's ***********" 
#Write-output "--------------------------Created By Brenton Wienkes---------------------------------" 
#Write-output ""
#-----------------------------------------------------------------------------------------------

#*************************************************

for($i=0;$i-le $FileRoots.Length-1;$i++){

$FileRoots[$i] = Split-Path $FileRoots[$i] -Leaf

}
$computer = $line
$Host.UI.RawUI.WindowTitle = "Running DellUpdaterBatchBase for $computer"
$out_UpdateADConnectList = "$($ScriptRoot)\RecentlyImagedList.txt"
$sourceBios2 = Split-Path $sourceBios -Leaf
#*****************************************************************
#----------------------Installation------------------------------
#Start-Transcript -Path $($PCLogs) -Append
write-host "Starting remote processes on $computer"
$os = Get-WmiObject -Class Win32_BIOS -Computer $computer
$oldbios = $null
$oldbios = "$($os.SMBIOSBIOSVersion)"
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-host "Bios version was: $($os.SMBIOSBIOSVersion)"
Write-output "Bios version was: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
$s2 = New-PSSession -computer $computer
$n = Invoke-Command -Session $s2 -ArgumentList $sourceName,$sourceRoot,$sourceCMD,$BiosName,$sourceBios,$Admin_User1, $strPass, $file -ScriptBlock {

#$powershellArguments2 = "C:\Temp\dellclient.ps1 -Name $args[0] -Root $args[1] -CMD $args[2]" 
#Start-Process "powershell.exe" -verb runas -ArgumentList $powershellArguments2 -Wait
[String[]]$Name = $($args[0])
[String[]]$Root = $($args[1])
[String[]]$CMD = $($args[2])
for($i=0;$i-le $Name.Length-1;$i++){

$Root[$i] = Split-Path $Root[$i] -Leaf


$OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }


	

#NEEDS TO BE SETUP FOR DELL
		# Supend Bitlocker if $OSVolumeEncypted is $true
		if ($OSVolumeEncypted -eq $true) {
			Write-output "Suspending BitLocker protected volume: C:" -Severity 1
            Write-host "Suspending BitLocker protected volume: C:"
			$a = Manage-Bde -Protectors -Disable C:
            write-output $a

		}

$b =Suspend-BitLocker -MountPoint "C:" -RebootCount 1
write-output $b





Try{
    Write-output "Installing $($Name[$i])..."
    Write-Host "Installing $($Name[$i])..."
    #Start-Process -verb runas -filePath "C:\Temp\$($Root[$i])\$($CMD[$i])" -ArgumentList " /S" -wait
    Write-output "running cmd with args /C C:\Temp\$($Root[$i])\$($CMD[$i])"
    $a = Start-Process "powershell.exe" -Verb runas -ArgumentList "/C C:\Temp\$($Root[$i])\$($CMD[$i])" -Wait -WindowStyle Hidden
    write-output $a
  }
  Catch{[Exception]
  Write-Host "Failed: $_"
   Write-Output "Failed: $_"

}
}
Write-Host "Running Standard Driver Update Script..." 
Write-output "Running Standard Driver Update Script..." 
#C:\Temp\dellclient.ps1 -Name $args[0] -Root $args[1] -CMD $args[2] -Bios $args[3] -SourceBios $args[4] -Admin_User $args[5] -strPass $args[6] -NonAdmin_User $args[7] -strPass2 $args[8] -wait
$powershellArguments = "C:\Temp\UpdateDrivers.ps1"
if (test-path "C:\Temp\UpdateDrivers.ps1")
{
$r = Start-Process "powershell.exe" -verb runas -ArgumentList "C:\Temp\UpdateDrivers.ps1" -Wait
write-output $r
}
else
{
write-output "C:\Temp\UpdateDrivers.ps1 was not found"
}

#Lenovo System update uninstall############
#Start-process -filepath "C:\Program Files (x86)\Lenovo\System Update\unins000.exe"-verb runas -argumentlist " /verysilent /norestart" -wait

#C:\Temp\Invoke-DellBios.ps1 -Path "C:\Temp\$($SourceBios)" -Name "$($Bios)" -Admin_User $Admin_User -strPass $strPass -NonAdmin_User $Script:NonAdmin_User -strPass2 $strPass2
}
Remove-PSSession $s2
write-output $n | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
$s = New-PSSession -computerName $computer
$u =Invoke-Command -Session $s -ArgumentList $sourceBios2, $BiosName, $BiosScript -Scriptblock {
$OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }
		
		# Supend Bitlocker if $OSVolumeEncypted is $true
		if ($OSVolumeEncypted -eq $true) {
			Write-output "Suspending BitLocker protected volume: C:" -Severity 1
            Write-host "Suspending BitLocker protected volume: C:"
			$a = Manage-Bde -Protectors -Disable C:
            write-output $a

		}
if(test-path "C:\Temp\Bios")
{
    $biosfile = Get-ChildItem -Path "C:\Temp\Bios" -Filter $($args[2]) -Recurse -ErrorAction SilentlyContinue -Force
    $biospath = $biosfile.fullname
}
write-output "Running $biospath"
write-host "Running $biospath"
$b =Suspend-BitLocker -MountPoint "C:" -RebootCount 1
write-output $b
$c = Start-Process -verb runas -filePath "$biospath" -ArgumentList " /S" -wait
write-output $c
}
Remove-PSSession $s
write-output $u | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

#Stop-Transcript
#----------------------Installation------------------------------
#*****************************************************************

#wait 10 secs to be sure bios updater is ready
Start-Sleep -s 10 
#Restart no.2 timeout after 5 mins
$timedout = $null # reset any previously set timeout
restart-computer $computer -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
if ($timedout)
{
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out, but pc is still responsive"
write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
Start-Sleep -s 120
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out post bios, waited 120 secs and now pc is responsive"
write-output "$($computer) restart timed out waited post bios, 120 secs and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
write-host "$($computer) restart timed out, please check pc"
write-output "$($computer) restart timed out, please check pc $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-Host "adding $($computer) back to list and ending script on this pc"
write-output "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 

$readdList = 1
Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
write-output "#####################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#####################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "#####################################################################"
write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
write-host "#####################################################################" 
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}

<#
foreach ($EUC in $EUCPCs)
{
if (Test-Connection $EUC -Quiet)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {
        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {
    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>
Remove-Item $path -force -recurse
exit
}
}

}
$EncryptionStatus=(manage-bde -status -computername "$computer" C: | where {$_ -match 'Protection Status'})
if ($EncryptionStatus)
{
    $EncryptionStatus=$EncryptionStatus.Split(":")[1].trim()
    if ($EncryptionStatus -like "Protection On")
    {
    Write-host "Bitlocker is on"
    Write-Output "Bitlocker is on" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else
    {
    Write-host "Bitlocker is off"
    Write-Output "Bitlocker is off" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    
        $p = New-PSSession -computerName $computer
        $pt = Invoke-Command -Session $p -Scriptblock {
        #manage-bde -Protectors -Enable C:
        $a1 = manage-bde -on C:
        Write-Output $a1
        $a = manage-bde -status
        write-host "$a"
         write-output $a
        }
        Write-Output $pt | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        Remove-PSSession $p
       
    }
}
               
#Display Bios
$os = Get-WmiObject -Class Win32_BIOS -Computer $computer
$newbios = $null
$newbios = "$($os.SMBIOSBIOSVersion)"
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-host "Bios version is now: $($os.SMBIOSBIOSVersion)"
Write-output "Bios version is now: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "Cleaning up Temp Files"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

#import-module $biosroot\dellbiosprovider.psm1 -verbose

#*****************************************************************
#-------------------------- Cleanup -----------------------------
$t = Invoke-Command -Computer $computer -ArgumentList $FileRoots, $BiosRoot -ScriptBlock {

#Cleanup files pushed
write-host "Setting bios..."
write-output "Setting bios..."
import-module C:\Temp\DellBIOSProvider\dellbiosprovider.psd1 -verbose

$a += set-item -Path DellSmbios:\PowerManagement\wakeonlan "LanOnly" -WarningVariable w -ErrorVariable e -InformationVariable v  -ErrorAction SilentlyContinue|out-string
if ($v)
{
$info = $v |fl|out-string
write-output $info
}
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-host "Successfully set wakeonlan to LanOnly"
    write-output "Successfully set wakeonlan to LanOnly"
    }
     #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null

########### SET AUTO ON to #

$b += Set-Item -Path DellSmbios:\PowerManagement\AutoOn "everyday" -WarningVariable w -ErrorVariable e -InformationVariable v  -ErrorAction SilentlyContinue|out-string
if ($v)
{
$info = $v |fl|out-string
write-output $info
}
#b1 = Set-Item -Path DellSmbios:\PowerManagement\AutoOn "SelectDays"

#$b = Set-Item -Path DellSmbios:\PowerManagement\AutoOnsunday "enabled"
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-host "Successfully set AutoOn to everyday"
    write-output "Successfully set AutoOn to everyday"
    }
     #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null

$c += Set-Item -Path DellSmbios:\PowerManagement\AutoOnHour "17"-WarningVariable w -ErrorVariable e -InformationVariable v   -ErrorAction SilentlyContinue|out-string
if ($v)
{
$info = $v |fl|out-string
write-output $info
}
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-Host "Successfully set AutoOnHour to 17"
    write-output "Successfully set AutoOnHour to 17"
    }
     #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null
    

$c1 += Set-Item -Path DellSmbios:\PowerManagement\AutoOnHr "17" -WarningVariable w -ErrorVariable e -InformationVariable v -ErrorAction SilentlyContinue|out-string
if ($v)
{
$info = $v |fl|out-string
write-output $info
}
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-host "Successfully set AutoOnHr to 17"
    write-output "Successfully set AutoOnHr to 17"
    }
    #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null

$d += Set-Item -Path DellSmbios:\PowerManagement\AutoOnMinute "59" -WarningVariable w -ErrorVariable e -InformationVariable v  -ErrorAction SilentlyContinue |out-string
if ($v)
{
$info = $v |fl|out-string
write-output $info
}
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-host "Successfully set AutoOnMinute to 59"
    write-output "Successfully set AutoOnMinute to 59"
    }
     #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null

$d1 += Set-Item -Path DellSmbios:\PowerManagement\AutoOnMn "59" -WarningVariable w -ErrorVariable e -InformationVariable v  -ErrorAction SilentlyContinue |out-string
if ($v)
{
$info = $v |fl|out-string
#write-host $info
write-output $info
}
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-host "Successfully set AutoOnMn to 59"
    write-output "Successfully set AutoOnMn to 59"
    }
    #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null

$f += set-Item -Path DellSmbios:\PowerManagement\AcPwrRcvry "on" -WarningVariable w -ErrorVariable e -InformationVariable v  -ErrorAction SilentlyContinue |out-string
if ($v)
{
$info = $v |fl|out-string
#write-host $info
write-output $info
}
if ($e)
{
$error1 = $e |fl|out-string
}
if($w)
{
    $warning1 = $w |fl|out-string
}
    if ($error1 -eq $null)
    {
    write-host "Successfully set AcPwrRcvry to on"
    write-output "Successfully set AcPwrRcvry to on"
    }
 #write-output $error1
    #write-output $warning1
    $error1 = $null
    $warning1 = $null
write-host "Finished Setting bios"
write-output "Finished Setting bios"
}
#Write-host $t
write-output $t | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

$U = Invoke-Command -Computer $computer -ArgumentList $FileRoots, $BiosRoot -ScriptBlock {

$pc = hostname
#Files/Folder names that were pushed to C:\Temp
$fileList = @()
for ($i = 0; $i -le ($args).Length-1; $i++){ 
write-host "adding $($args[$i]) to file deletion list"
write-output "adding $($args[$i]) to file deletion list"
$fileList += $args[$i]
}

$filelist += "Bios"


#$fileList = @("t470client.ps1", "Invoke-LenovoBIOSUpdate.ps1", "PMDriver", "ME", "IntelVGA", "n1quj15w")

    #-----------------------Array Loop-----------------------------
foreach ($file in $fileList)
    {
    $newfilepath = "C:\Temp\$($file)"
        #------------Path Test and verify-----------
 if (test-path $newfilepath)
                {
                    Write-Host "$newfilepath file exists"
                    Write-output "$newfilepath file exists"
                    try
                    {
                        #We try to remove...
                        Remove-Item $newfilepath -force -recurse -ErrorAction Stop
                    }
                    catch
                    {
                        #And there will be an error message if it fails
                        Write-Host "Error while deleting $newfilepath on $pc.`n$($Error[0].Exception.Message)"
                        Write-output "Error while deleting $newfilepath on $pc.`n$($Error[0].Exception.Message)"
                        #We skip the rest and go back to the next object in the loop
                        continue
                    }
                    #On sucessful deletion of file...
                    Write-Host  "$newfilepath file deleted"
                    Write-output  "$newfilepath file deleted"
                }
        #------------Path Test and verify-----------

    }
    #-----------------------Array Loop-----------------------------
    }
    write-output $u | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

    
#-------------------------- Cleanup -----------------------------
#*****************************************************************

#Wait for 2 seconds to be sure it's ready
 Start-Sleep -s 2 
#$computer2 = Read-Host -Prompt "Type Full PC name or Serial to begin update"


#Restart no 3 to besure bitlocker is not suspended
$timedout = $null # reset any previously set timeout
restart-computer $computer -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
if ($timedout)
{
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out, but pc is still responsive"
write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
Start-Sleep -s 60
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out post bios, waited 60 secs and now pc is responsive"
write-output "$($computer) restart timed out waited post bios, 60 secs and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
write-host "$($computer) restart timed out, please check pc"
write-output "$($computer) restart timed out, please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-Host "adding $($computer) back to list and ending script on this pc"
write-output "$($computer) is not found in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
write-Host "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 

$readdList = 1
Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
write-host "################################################################" 
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}

<#
foreach ($EUC in $EUCPCs)
{
if (Test-Connection $EUC -Quiet)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {
        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {
    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>
Remove-Item $path -force -recurse
exit
}
}

}


#************************************************************************
#---------------------- Set AD ------------------------------------------
$ADcomputer = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$computer'"
$Desc = "**NEW** Unassigned Desktop $($Model)"
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
if ($changeADdesc -eq $true)
{
     Write-host "Setting $($ADcomputer.Name) Description in Active Directory... `n" 
    Write-output "Setting $($ADcomputer.Name) Description in Active Directory... `n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "Old Description: $($ADcomputer.Description)"  | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "New Description: $($Desc)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-host "Old Description: $($ADcomputer.Description)"
    Write-host "New Description: $($Desc)"
    Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Set-ADComputer $computer -Description $Desc

    write-host -ForegroundColor cyan "Starting Scheduled Windows Update (with autoreboot)..."
Write-output "[START] Invoke-Windows Update for$($computer) $((Get-Date).ToString())"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}
Setup-IP-Invoke($($ADcomputer.Name))
Invoke-WUJob -ComputerName $($ADcomputer.Name) -Script {ipmo PSWindowsUpdate; Get-WindowsUpdate -install -MicrosoftUpdate -AcceptAll -AutoReboot |out-file "C:\temp\PSWindowsUpdate.log" } -Credential $Script:credentials -RunNow -Confirm:$false -Verbose

start-sleep -Seconds 2
if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
{
    write-host -ForegroundColor Cyan "Computer can't be contacted, waiting 3 mins..." -NoNewline
    Start-Sleep -Seconds 180
    write-host "DONE"
    if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
    {
        write-host -ForegroundColor Yellow "Computer STILL can't be contacted, waiting 3 more mins..." -NoNewline
        Start-Sleep -Seconds 180
        write-host "DONE"
        if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
        {
            write-host -ForegroundColor Yellow "Computer STILL can't be contacted, waiting LAST TIME 3 more mins..." -NoNewline
            Start-Sleep -Seconds 180
            write-host "DONE"
            if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
            {
            write-host -ForegroundColor Red "Computer FAILED TO BE CONTACTED!"
            write-host "Computer FAILED TO BE CONTACTED!" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            else
            {
                $StartWU = $true
            }

        }
        else
        {
            $StartWU = $true
        }
    }
    else
    {
    $StartWU = $true
    }
}
else
{
$StartWU = $true
}

if($StartWU -eq $true)
{
start-sleep -Seconds 5
write-host -ForegroundColor Cyan "Checking Windows Update Status $((Get-Date).ToString())"
write-output "Checking Windows Update Status $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Invoke-Command -ComputerName $($ADcomputer.Name) -Credential $Script:credentials -ScriptBlock {
$WUtimeout = $false
$WUfailure = $false
$WUdone = $false
$i = 0
do{
     $failed = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "failed" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName

     $accepted = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "Accepted" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName

     $Downloaded = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "Downloaded" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName

      $Installed = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "Installed" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName
 
    if($accepted -eq $null)
    {
         if($failed -eq $null)
         {

         }
         else
         {
            write-host -ForegroundColor Red "FAILED to ACCEPT UPDATES"
            write-host $failed
            $WUfailure = $true
            break
         }
    }
    else
    {
        if($Downloaded -eq $null)
        {
            write-host -ForegroundColor Cyan "Waiting for download"
            if($failed -eq $null)
            {
            
            }
            else
            {
                write-host -ForegroundColor Red "FAILED to DOWNLOAD UPDATES"
                write-host $failed
                $WUfailure = $true
                break
            }
        }
        else
        {
            if($Installed -eq $null)
            {
                write-host -ForegroundColor Cyan "Installing..."
            }
            else
            {
                if($installed.count -lt $accepted.count)
                {
                    write-host  -ForegroundColor Cyan "Installing..."
                }
                else
                {
                    write-host -ForegroundColor Cyan "Windows Update Completed!"
                    write-host $Installed
                    $WUdone = $true
                    break
                }
            }
        }
     }
     if($i -ge 120)
     {
         $WUTimeout = $true
         break
     }
     else
     {
         write-host -ForegroundColor Cyan "Waiting 1 min..." -NoNewline
         Start-Sleep -Seconds 60
         write-host "DONE"
     }
     $i++

 }until($WUtimeout -eq $true -or $WUfailure -eq $true -or $WUdone -eq $true)
 }

 $log = Get-Content "\\$($ADcomputer.Name)\C$\temp\PSWindowsUpdate.log" -Raw
 $inlogs = Get-content $PCLogs -Raw
 write-output ($inlogs + $log) |-FilePath "$($PCLogs)" -Encoding ascii
 write-host -ForegroundColor Cyan "Windows Update" -NoNewline
 write-host -ForegroundColor Green " Completed" -NoNewline
 write-host -ForegroundColor Cyan "$((Get-Date).ToString())"
 write-output "Windows Update Complete! $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
 }
 else
 {
    write-host -ForegroundColor RED "WINDOWS UPDATE COULD NOT BE DONE! $((Get-Date).ToString())"
    write-output "WINDOWS UPDATE COULD NOT BE DONE! $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
 }
}
else
{
    Write-host "Description: $($ADcomputer.Description)" 
    Write-output "Description: $($ADcomputer.Description)"  | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}

#Write-output ""| Out-File -FilePath $CompletedList -Encoding ascii -Append
Write-output "$($computer) Completed $((Get-Date).ToString())"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "$($computer) Completed $((Get-Date).ToString())"| Out-File -FilePath $CompletedList -Encoding ascii -Append
Write-output "$($computer)"| Out-File -FilePath $out_UpdateADConnectList -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
write-host "################################################################" 

$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii
}

<#
foreach ($EUC in $EUCPCs)
{

if (Test-Connection $EUC -Quiet -Count 1)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {

        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {

    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>
Remove-Item $path -force -recurse





<#
$logstopush = gc "$PSScriptroot\NeedtoPushlogs.txt"
$readdlogs = New-Object System.Collections.ArrayList

foreach ($log in $logstopush)
{
if ($log)
{
if($log.trim())
{
$log = $log.trim()
if (Test-Path "$log")
    {

foreach ($EUC in $EUCPCs)
{

if (Test-Connection $EUC -Quiet -Count 1)
{

$index = $EUCPCs.IndexOf($EUC)

    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {

        Copy-Item -Path $log -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
        {
            $readdlogs.Add("$log") > $null
        }
        

}

}

}

}

}

}
#
write-output $readdlogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii


write-output "" | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs2.txt" -Encoding ascii
$hash = @{}                 # Define an empty hashtable
gc "$PSScriptroot\NeedtoPushlogs.txt" |        # Send the content of the file into the pipeline...
% {                             # For each object in the pipeline...
                                      # note '%' is an alias of 'foreach-object'          
if ($hash.$_ -eq $null) {    # if that line is not a key in our hashtable...
                                      # note -eq means 'equals'
                                      # note $_ means 'the data we got from the pipe'
                                     # note $null means NULL
         $_                       # ... send that line further along the pipe
     };
     $hash.$_ = 1                 # Add that line to the hash (so we won't send it again)
                                      # note that the value isn't important here,
                                      # only the key. ;-)
  } > "$PSScriptroot\NeedtoPushlogs2.txt"              # finally... redirect the pipe into a new file.
  gc "$PSScriptroot\NeedtoPushlogs2.txt" -Raw | Set-Content -Path "$PSScriptroot\NeedtoPushlogs.txt"
  Remove-Item "$PSScriptroot\NeedtoPushlogs2.txt" -force -recurse > $null
  #>

exit
#---------------------- Set AD ------------------------------------------
#************************************************************************
#}

