﻿param
(
[Parameter(Mandatory=$false)] $computer
)

#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------

    $scriptPath = "$($PSScriptRoot)"
    $Root = (get-item $scriptPath).Parent.Parent.FullName

    ####################################################
    #-------------------LOG SETUP----------------------#
    ####################################################

    $LogRoot = $Root
    $ParentLogContainingFolderName = "VDIs"
    $LogContainingFolderName = "Assign Empty VDI Logs"
    $logpath = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"
    if(!(test-path "$LogRoot\Logs"))
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$LogRoot\Logs")
    }

    if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName"))
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName")
    }

    if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName"))
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName")
    }
    ####################################################
    #-------------------LOG SETUP----------------------#
    ####################################################

    ##################################### FUNCTION START
    #


    ####################################################
    #--------------START GET USERS PC------------------#
    ####################################################
    <#
    Function get-UsersPC($IN_User)
    {
        $in_user = $in_user.Trim()
        $computer = $null
        if(!($in_user) -or $in_user -eq "")
        {

        }
        else
        {
            $fullnamearray = $in_user.Split(" ")
            $firstname = $fullnamearray[0]
            $lastname = $fullnamearray[$fullnamearray.count - 1]
            $firstname = $firstname.replace("`'","*")
            $lastname = $lastname.replace("`'","*")
            $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$firstname*$lastname*'")
            if(!($computer) -or $computer.count -lt 1)
            {
            $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$firstname* $lastname*'")
            if(!($computer) -or $computer.count -lt 1)
            {
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$firstname *$lastname*'")
                if(!($computer) -or $computer.count -lt 1)
                {
                    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$firstname*$lastname*'")
                }
            }
            $firstname = $firstname.replace("*","`'")
            $lastname = $lastname.replace("*","`'")
        
            $lstPCs = @() 
            foreach ($entry in $computer)
            {
                $properties = @{'Selection'= $($computer.Indexof($entry));
                                'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
                $object = New-Object –TypeName PSObject –Prop $properties
                $lstPCs += $object
                #write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
            }
        }

        if($computer -ne $null)
        {
            return $lstPCs
        }
        else
        {
            return $null
        }
    }
    #>
    
Function Show-SelectionForm($lstSelections)
{
	#---------------------------------------------- 
	#region Import Assemblies 
	#---------------------------------------------- 
	[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
    [void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	#endregion Import Assemblies  
 
	function SelectForm($input1) 
	{ 
    	$Script:SelectionForm_RowIndex = $null
	    <# 
        	.SYNOPSIS 
    	The Main function starts the project application. 
        	     
	        .PARAMETER Input1
	    $Input1 contains the complete argument string passed to the script packager executable. 
        	     
	        .NOTES 
	    Use this function to initialize your script and to call GUI forms. 
        	         
	        .NOTES 
	    To get the console output in the Packager (Forms Engine) use:  
	    $ConsoleOutput (Type: System.Collections.ArrayList) 
	    #> 
	     
    	#-------------------------------------------------------------------------- 
        $SLFResult = (Call-SelectForm_psf($input1))
        return $SLFResult
        <#
	    if((Call-SelectForm_psf($input1)) -eq 'OK') 
    	{ 
	        # ADD VALIDATION IF NEEDED
	    } 
    	$global:ExitCode = 0 #Set the exit code for the Packager
        #> 
    } 
 
	#endregion Source: Startup.pss 
     
    #region Source: MainForm.psf 
    function Call-SelectForm_psf($input1) 
    { 
        #Datagrid click Function
    	Function dg_Selections_GridClick
        {
	        #Set $Script:SelectionForm_RowIndex to index of the currently selected row
	        $Script:SelectionForm_RowIndex = ($dg_Selections.CurrentRow.Index + 1)
	    }
    
        #Add Data to Datagrid function
	    function Get-ProcessInfo($input1) 
	    {
	        $array = New-Object System.Collections.ArrayList
	        $array.AddRange($input1)
	        $dg_Selections.DataSource = $array
            $dg_Selections.Refresh()
	        $dg_Selections.ClearSelection()
	    }
 
	    #---------------------------------------------- 
	    #region Import the Assemblies 
	    #---------------------------------------------- 
	    [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	    #endregion Import Assemblies 
	 
	    #---------------------------------------------- 
	    #region Generated Form Objects 
	    #---------------------------------------------- 
	    [System.Windows.Forms.Application]::EnableVisualStyles() 
	    $SelectForm = New-Object 'System.Windows.Forms.Form'
	    $ButtonCancel = New-Object 'System.Windows.Forms.Button' 
	    $ButtonSelect = New-Object 'System.Windows.Forms.Button' 
	    $panel1 = New-Object 'System.Windows.Forms.Panel'
	    $panel2 = New-Object 'System.Windows.Forms.Panel'
        $splitcontainer1 = New-Object 'System.windows.forms.splitcontainer'
        $splitcontainer2 = New-Object 'System.windows.forms.splitcontainer'
	    $panel3 = New-Object 'System.Windows.Forms.Panel'
	    $panel4 = New-Object 'System.Windows.Forms.Panel'
	    $dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
	    $InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
	    #endregion Generated Form Objects 
 
	    #---------------------------------------------- 
	    # Form Object Functions
	    #---------------------------------------------- 
        
	    #Form Load function
        $SelectForm_Resize=
	    {   
            $splitcontainer1.SplitterDistance = ($Selectform.Height - 90)
        }

	    $SelectForm_Load =
	    { 
	        get-processinfo($input1)    
            $dgwidth = 0
            $dgheight = 0
            foreach ($col in $dg_Selections.Columns)
            {
                $dgwidth += $col.Width
            }

            foreach ($row in $dg_Selections.Rows)
            {
                $dgheight += $row.Height
            }
            if ($dg_Selections.RowCount -gt 8)
            {
                $Scrollbaractive = $true
                $dgwidth += 20
            }
            $Selectform.Width = $dgwidth + 20
            $Selectform.MinimumSize = "$($dgwidth + 20),$($Selectform.Height)"
            $Selectform.MaximumSize = "$($dgwidth + 20),$($dgheight + 130)"
            $selectform.Refresh()
            $dg_Selections.Refresh()
            $dg_Selections.Width = $dgwidth
            $dg_Selections.Height = $dgheight
            $splitcontainer1.SplitterDistance = ($Selectform.Height - 90)
            $splitcontainer1.Refresh()
            $splitcontainer2.SplitterDistance = ($splitcontainer1.size.width / 2)
            if($($ButtonSelect.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5)))) -lt 91)
            {
                $ButtonSelect.Size = "91, $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonSelect.Location = "$([math]::Round(($splitcontainer2.Size.Width / 4) - ($ButtonSelect.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            }
            else
            {
                $ButtonSelect.Size = "$($ButtonSelect.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonSelect.Location = "$([math]::Round((($splitcontainer2.Size.Width - 91) / 4) - ($ButtonSelect.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            }

            if($($ButtonCancel.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5)))) -lt 91)
            {
                $ButtonCancel.Size = "91, $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonCancel.Location = "$([math]::Round(($splitcontainer2.Size.Width / 4) - ($ButtonCancel.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            }
            else
            {
                $ButtonCancel.Size = "$($ButtonCancel.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonCancel.Location = "$([math]::Round((($splitcontainer2.Size.Width - 91) / 4) - ($ButtonCancel.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            } 
	    }
	
	    #Select Button clicked function
	    $ButtonSelect_Click = 
	    {     
	        #Checks for input selected before allowing form close from select button click
	        if ($Script:SelectionForm_RowIndex)
	        {
                $Script:SelectForm_return = $Script:SelectionForm_RowIndex
	            $SelectForm.Close()
	        }
            else
            {
                $Script:SelectForm_return = $null
            }
	    } 

	    #Cancel Button clicked function
	    $ButtonCancel_Click =
	    {
            $Script:SelectionForm_RowIndex = $null
	        $SelectForm.Close() 
	    } 
     
        # --End Form Object Functions-- 
	    #---------------------------------------------- 
	    #region Generated Events 
	    #---------------------------------------------- 
	
	    #Fix Form Load function
	    $Form_StateCorrection_Load = 
	    { 
            if($Script:InitialFixesLocation)
            {
                if(test-path "$Script:InitialFixesLocation\Files\FormIcon.ico")
                {
                    $Icon = New-Object System.Drawing.icon("$Script:InitialFixesLocation\Files\FormIcon.ico")
                    $MainForm.Icon = $icon
                }
            }
                
    	    #Correct the initial state of the form to prevent the .Net maximized form issue 
            $SelectForm.WindowState = $InitialFormWindowState 
	    } 
     
	    #Store Values of form function
	    $Form_StoreValues_Closing = 
	    { 
	        #Store the control values here
	    } 
 
	    $Form_Cleanup_FormClosed = 
	    { 
    	    #Remove all event handlers from the controls 
        	try 
	        { 
    	        $ButtonCancel.remove_Click($buttonCancel_Click) 
	            $ButtonSelect.remove_Click($ButtonSelect_Click)
	            $SelectForm.remove_Load($SelectForm_Load) 
	            $SelectForm.remove_Load($Form_StateCorrection_Load) 
	            $SelectForm.remove_Closing($Form_StoreValues_Closing) 
	            $SelectForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	        } 
	        catch [Exception] 
	        { } 
	    } 
	    #endregion Generated Events 
 
	    #---------------------------------------------- 
	    #region Form Setup Objects
	    #---------------------------------------------- 
	    #Suspend layouts
	    $SelectForm.SuspendLayout()
	    $panel4.SuspendLayout() 
	    $panel3.SuspendLayout() 
	    $panel2.SuspendLayout() 
	    $panel1.SuspendLayout()
        $splitcontainer1.SuspendLayout()
        $splitcontainer2.SuspendLayout()
	    # 
	    # SelectForm Attributes
	    # 
	    $SelectForm.Controls.Add($splitcontainer1)
	    $SelectForm.BackColor = 'White'   
	    $SelectForm.MaximizeBox = $False 
	    $SelectForm.MinimizeBox = $False 
	    $SelectForm.Name = 'SelectForm' 
	    $SelectForm.ShowIcon = $False 
	    $SelectForm.ShowInTaskbar = $False 
	    $SelectForm.StartPosition = 'CenterScreen' 
	    $SelectForm.Text = 'Select One'
	    $SelectForm.TopMost = $True 
	    $SelectForm.add_Load($SelectForm_Load)
        $SelectForm.Add_Resize($SelectForm_Resize)
	    # 
	    # ButtonCancel Attributes
	    # 
	    $ButtonCancel.Name = 'ButtonCancel' 
	    $ButtonCancel.TabIndex = 7 #TODO FIX TABINDEXES
	    $ButtonCancel.Text = 'Cancel' 
	    $ButtonCancel.UseVisualStyleBackColor = $True 
	    $ButtonCancel.add_Click($ButtonCancel_Click)
        $ButtonCancel.MaximumSize.Height = '60' 
        $ButtonCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	    # 
	    # ButtonSelect Attributes
	    # 
	    $ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	    $ButtonSelect.ForeColor = 'Blue' 
	    $ButtonSelect.Name = 'ButtonSelect' 
	    $ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	    $ButtonSelect.Text = 'Select' 
	    $ButtonSelect.UseVisualStyleBackColor = $True 
	    $ButtonSelect.add_Click($ButtonSelect_Click)
	    $ButtonSelect.MaximumSize.Height = '60' 
        $ButtonSelect.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	    # 
	    # Panel1 Attributes
	    #  
	    $panel1.Controls.Add($dg_Selections)
	    $panel1.Location = '0, 0' 
	    $panel1.Name = 'panel1' 
	    $panel1.Size = '375, 310'
	    $panel1.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel1.BackColor = 'LightGray'
	    $panel1.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # splitcontainer1 Attributes
	    # 
        $splitcontainer1.Panel1.size = '300, 745'
        $splitcontainer1.Location = '0, 0' 
        $splitcontainer1.Name = 'splitcontainer1'
        $splitcontainer1.Orientation = [System.Windows.Forms.Orientation]::Horizontal
        $splitcontainer1.SplitterDistance = '310'
        $splitcontainer1.IsSplitterFixed = $true
        $splitcontainer1.SplitterWidth = '1'
        $splitcontainer1.Panel2.Controls.Add($splitcontainer2)
        $splitcontainer1.Panel1.Controls.Add($panel1)
        $splitcontainer1.Dock = [System.Windows.Forms.DockStyle]::Fill
        # 
	    # Panel3 Attributes
	    # 
	    $panel3.Controls.Add($ButtonSelect)  
	    $panel3.Location = '0, 0' 
	    $panel3.Name = 'panel2' 
	    $panel3.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel3.BackColor = 'LightSkyBlue'
	    $panel3.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # Panel4 Attributes
	    # 
	    $panel4.Controls.Add($ButtonCancel)
	    $panel4.Location = '0, 0' 
	    $panel4.Name = 'panel2'
	    $panel4.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel4.BackColor = 'LightSkyBlue'
	    $panel4.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # splitcontainer2 Attributes
	    # 
	    $splitcontainer2.Panel1.Controls.Add($panel3)  
	    $splitcontainer2.Panel2.Controls.Add($panel4)
	    $splitcontainer2.Location = '0, 310'
        $splitcontainer2.SplitterDistance = $splitcontainer2.Size.Width / 2
        $splitcontainer2.IsSplitterFixed = $true
        $splitcontainer2.SplitterWidth = '1' 
	    $splitcontainer2.Name = 'splitcontainer2' 
	    $splitcontainer2.TabIndex = 8 #TODO FIX TABINDEXES
	    $splitcontainer2.BackColor = 'LightSkyBlue'
	    $splitcontainer2.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	    $dg_Selections.Name = "dg_Selections"
	    $dg_Selections.DataMember = ""
	    $dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	    $dg_Selections.AutoSizeRowsMode = "AllCells"
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	    $dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::AllCells
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	    $dg_Selections.RowHeadersVisible = $false
        $dg_Selections.MultiSelect = $false
	    $dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	    #Resume Layouts
	    $panel1.ResumeLayout() 
	    $panel2.ResumeLayout()
	    $panel3.ResumeLayout() 
	    $panel4.ResumeLayout()  
        $splitcontainer1.ResumeLayout()
        $splitcontainer2.ResumeLayout()
	    $SelectForm.ResumeLayout()
	 
	    #endregion Form Setup Objects
	    #---------------------------------------------- 
        	
    	#Save the initial state of the form 
    	$InitialFormWindowState = $SelectForm.WindowState 
    	#Init the OnLoad event to correct the initial state of the form 
    	$SelectForm.add_Load($Form_StateCorrection_Load) 
    	#Clean up the control events 
    	$SelectForm.add_FormClosed($Form_Cleanup_FormClosed) 
    	#Store the control values when form is closing 
    	$SelectForm.add_Closing({
            #Add Closing code here
    	}) 

	    #Show the Form 
        $SelectFormResult = $SelectForm.ShowDialog()
        $return = $Script:SelectForm_return
        $Script:SelectForm_return = $null
        $Script:SelectionForm_RowIndex = $null
        return $return

	    #endregion Source: MainForm.psf 
	    $self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	}
	
	#Start the application 
	$Finalresult = SelectForm ($lstSelections)
        
    return $Finalresult
} #FUNCTION END ----------------------------------

#TODO GENERAL UPDATING TO GUI
Function Format-AD-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$Param_ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	#$Name = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","*")
	}
	else
	{
	#write-debug "Could not format null valued name"
	}	
	}
	else
	{
	#write-debug "[FAILURE] Format-AD-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-AD-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}

#TODO GENERAL UPDATING TO GUI
Function Format-String-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","`'`'")
	$Name = $Name.trim() 
	}
	else
	{
	#write-debug "Could not format null valued name"
	}
	}
	else
	{
	#write-debug "[FAILURE] Format-String-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-String-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}

Function FindUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	User_In = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$User_In
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------
    #write-debug "input: $User_In"
	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($User_In)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($User_In -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($User_In.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
	# NULL variables (just in case)
	#$User_FullNameArray = @()
    $Original = $null
	$ErrorMsg = $null
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$filtering_Lastname = $false
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
    $SearchingBase = "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
            write-host "Setting User LastName to: $User_LastName..."
	        #write-debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            #write-debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug " First Name: $User_FirstName"
                write-host "Setting User First Name to: $($User_FirstName)..."
                $User_MiddleName = $($User_FullNameArray[1])
	            #write-debug " Middle Name: $User_MiddleName"
                write-host "Setting User Middle Name to: $($User_MiddleName)..."
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                #write-debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
                write-host "Setting User MI to: $($User_MI)..."
	            #write-debug " Middle Initial Part 2 : $User_MI"
                #write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                write-host "Formating First Name for AD search..."
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                write-host "Formating Last Name for AD search..."
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
                        write-host "Comparing list of known non-name words to Last Name..."
	                    #write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
                            write-host "Found non-name Last Name, Setting different Last Name..."
	                        #write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
                                
	                            #write-debug "Index of filtered word is > 0"
                                if($User_MiddleName)
                                {
                                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 1)
                                    {
                                        write-host "Reconfiguring MI..."
                                        #write-debug "Index of filtered word is > 1"
                                        $User_MiddleName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_MiddleName) - 1)])
                                        $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                                        #write-debug "MI set to: $User_MI"
                                        write-host "Setting MI to: $User_MI..."
                                    }
                                    else
                                    {
                                        write-host "Nulling Middle Name do to not found..."
                                        #write-debug "Index of filtered word is NOT > 1"
                                        #write-debug "MI and Middle name set to NULL"
                                        $User_MiddleName = $null
                                        $User_MI = $null
                                    }
                                }
	                            #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                write-host "Setting Last Name to: $User_LastName..."
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            #write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
                                write-host "Last Name wasn't found..."
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
                            write-host "Filtering completed"
	                        #write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                            write-host "Setting Filtered Name to: $User_LastName"
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    #write-debug "Name not filtered"
                        write-host "Searching by First Name, Last Name, and MI..."
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            write-host "Searching by First Name and Last Name..."
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                write-host "Searching by Last Name and MI..."
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    write-host "Searching by Last Name..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                }        
                            }
                        }
                    }
                    else
                    {
                        #write-debug "Name was filtered"
                        if(!($User_LastName -eq "Last Name not Found"))
                        {
                            #write-debug "Last Name was found"
                            if($User_MI)
                            {
                                #write-debug "Middle Name exists"
                                write-host "Searching by First Name, Last Name, and MI..."
	                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    write-host "Searching by First Name and Last Name..."
                                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        write-host "Searching by Last Name and MI..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                        if(!($AD_User))
                                        {
                                            write-host "Searching by Last Name..."
                                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                        }        
                                    }
                                }
                            }
                            else
                            {
                                #write-debug "Middle Name Doesn't exist"
                                write-host "Searching by First Name and Last Name..."
                                $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                if(!($AD_User))
                                {
                                    write-host "Searching by First Name and Last Name with wildcarded firstname..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        write-host "Searching by Last Name..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }
                            }
                        }
                        else
                        {
                            #write-debug "No AD_User found do to no Last name found"
                            $AD_User = $null
                        }
                    }
                }
	            else
	            {
	                #write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    #write-debug "Last name was null"
	                }
	                else
	                {
	                    #write-debug "First name was null"
	                }
	                #write-debug "AD_User set to null"
	                $AD_User = $null
	            }

	            #write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    #write-debug "Less than 1 user found"                    
                }
            }
            else
            {
	            #write-debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
                    write-host "Filtering out non-name Words..."
	                #write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    #write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
                            write-host "Getting new index of Last Name..."
	                        #write-debug "Index of filtered word is > 0"
	                        #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            write-host "Setting Last Name to $User_LastName..."
                            $filteredName = $true
	                    }
	                    else
	                    {
                            write-host "Last Name wasn't found..."
	                        #write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
                        write-host "Filtering Completed..."
	                    #write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                        write-host "Setting Last Name to $User_LastName..."
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                #write-debug "Last Name was found after filtering"
	                #write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    write-host "Searching by First and Last Name..."
                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                    if(!($AD_User))
                    {
                        write-host "Searching by First and Last Name wildcarded..."
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        if(!($AD_User))
                        {
                            write-host "Searching by Last Name wildcarded..."
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                        }
                    }
	                #write-debug "Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
                    write-host "Last Name not found..."
	                #write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        #write-debug "Input has 1 word"
            #write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            #write-debug "Last Name set to $($User_LastName)"
            write-host "Formating Last Name for AD search..."
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            write-host "Search AD for users by Last Name..."
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                write-host "Seaching AAH users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
            write-host "No Valid input for users name detected..."
	        #write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        #write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
            write-host "Formatting User output..."
	        #write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
                
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);                           
                                'SSO' = $($entry.sAMAccountName);
                                'ID' = $($entry.EmployeeID);
                                'SID' = $($entry.SID)}
                $User_Object = New-Object –TypeName PSObject –Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($AD_User.Count) -gt 1)
	        {
                write-host "Selecting User..."
	            #write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
                @{Name="ID";Expression = { $_.ID }; Alignment="left" },
	            @{Name="Email";Expression = { $_.Email }; Alignment="left" }
                @{Name="SID";Expression = { $_.SID }; Alignment="left" }|out-null
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                }
                write-host "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	        elseif ($($AD_User.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                #write-debug "AD FIRST NAME $($AD_User.Firstname)"
                #write-debug $ad_user.Lastname
                #write-debug $ad_user.Email
	            #write-debug "User count = 1"
                write-host "Formating User's First Name for AD Search..."
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
                write-host "Formating User's Last Name for AD Search..."
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                #write-debug $User_FirstName
                #write-debug $User_LastName
	            write-host "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	    }
	    else
	    {
	        #write-debug "No user found setting variables to null"
	        #write-debug "Searching Corperate Users"
	        $AD_User = (Get-CorpUser -UserIn $original)
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
    }
	else
	{
	    #write-debug "[FAILURE] FindUser - Initial parameter input was null"
	    $ErrorMsg = "FindUser - $Param_ErrorMsg"
	}

    write-host "Formating User output..."
	if($AD_User)
	{
	    $properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	                    'LastName' = $AD_User.LastName;
	                    'MI' = $AD_User.Initials;
	                    'Email' = $AD_User.Email;
	                    'SSO' = $AD_User.SSO;
                        'SID' = $AD_User.SID;
                        'ID' = $AD_User.ID;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	else
	{$errorMsg = "No User Selected"
	    $properties = [ordered]@{'FirstName' = $null;
	                    'LastName' = $null;
	                    'MI' = $null;
	                    'Email' = $null;
	                    'SSO' = $null;
                        'SID' = $null;
                        'ID' = $null;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
    write-host "Returning User output..."
	return $Return_Object
}

#TODO  GENERAL UPDATING TO GUI
Function Get-CorpUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$original = $UserIn
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$filtering_Lastname = $false
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
    $SearchingBase = "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
	        #write-debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            #write-debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug " First Name: $User_FirstName"
                $User_MiddleName = $($User_FullNameArray[1])
	            #write-debug " Middle Name: $User_MiddleName"
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                #write-debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
	            #write-debug " Middle Initial Part 2 : $User_MI"
                
                #write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
	                    #write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
	                        #write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
	                            #write-debug "Index of filtered word is > 0"
	                            #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            #write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
	                        #write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    #write-debug "First and Last name evaluated as not null"
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                    if(!($AD_User))
                                    {
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }        
                            }
                        }
                    }
                    else
                    {
                        $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            }
                        }
                    }
                }
	            else
	            {
	                #write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    #write-debug "Last name was null"
	                }
	                else
	                {
	                    #write-debug "First name was null"
	                }
	                #write-debug "user set to null"
	                $AD_User = $null
	            }

	            #write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    #write-debug "Less than 1 user found"
                    if($filteredName -eq $false)
                    {
                        #write-debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            #write-debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                if(!($AD_User))
                                {
                                    write-host "Seaching Corp users by first name"
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                                }
                            }
                        }
                    }
                    else
                    {
                        #write-debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            #write-debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                write-host "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }

                    
                }
            }
            else
            {
	            #write-debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
	                #write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1-9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    #write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
	                        #write-debug "Index of filtered word is > 0"
	                        #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            $filteredName = $true
	                    }
	                    else
	                    {
	                        #write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
	                    #write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                #write-debug "Last Name was found after filtering"
	                #write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    if($filteredName -eq $true)
                    {
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                write-host "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
                    else
                    {
	                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                write-host "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
	                #write-debug " Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
	                #write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        #write-debug "Input has 1 word"
            #write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            #write-debug "Last Name set to $($User_LastName)"
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                write-host "Seaching Corp users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
	        #write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        #write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
	        #write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);
                                'SSO' = $($entry.sAMAccountName);
                                'SID' = $($entry.SID);
                                'ID' = $($entry.EmployeeID)}
                $User_Object = New-Object –TypeName PSObject –Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($AD_User.Count) -gt 1)
	        {
	            #write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
                @{Name="SID";Expression = { $_.SID }; Alignment="left" },
                @{Name="ID";Expression = { $_.ID }; Alignment="left" },
	            @{Name="Email";Expression = { $_.Email }; Alignment="left" }|out-null
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                    
                }

	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	        elseif ($($AD_User.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                #write-debug "AD FIRST NAME $($AD_User.Firstname)"
                #write-debug $ad_user.Lastname
                #write-debug $ad_user.Email
	            #write-debug "User count = 1"
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                #write-debug $User_FirstName
                #write-debug $User_LastName
	
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
                $User_SID = $($AD_User.SID)
	        }
	    }
	    else
	    {
	        #write-debug "No user found setting variables to null"
	        $AD_User = $null
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
	}
	else
	{
	#write-debug "[FAILURE] FindCorpUser - Initial parameter input was null"
	$ErrorMsg = "FindCorpUser - $Param_ErrorMsg"
	}


	if($AD_User)
	{
	$properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	'LastName' = $AD_User.LastName;
	'MI' = $AD_User.MI;
	'Email' = $AD_User.Email;
	'SSO' = $AD_User.SSO;
    'ID' = $AD_User.ID;
    'SID' = $AD_User.SID;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	else
	{
	$properties = [ordered]@{'FirstName' = $null;
	'LastName' = $null;
	'MI' = $null;
	'Email' = $null;
	'SSO' = $null;
    'ID' = $null;
    'SID' = $null;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	
	return $Return_Object
}

function Get-usersPC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$Param_ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
    $User_FromConnectedPC = $false
    $descfailed = $false
    $nousers = $false
    $filtering_Lastname = $false
    if(!($Param_ErrorMsg))
	{
        $UserIn = $UserIn.Trim()
        $PSUser = (FindUser -User_In $UserIn)
        if($PSUser)
        {
            #FINDUSER FUNCTION RETURNED NOT NULL
	        $User_FirstName = ((Format-Ad-User-Name -name $($PSUser.Firstname)).output)
	        $User_LastName = ((Format-Ad-User-Name -name $($PSUser.LastName)).output)
            if($User_LastName -and $User_FirstName)
            {
                #USER_LASTNAME AND USER_FIRSTNAME NOT NULL

                #START LASTNAME FILTER SUFFIXES------------------------
                $filterArrysuffix = @("III", "II", "I", "jr", "jr.", "sr", "sr.")
                foreach ($suffix in $filterArrysuffix)
                {
                    if($User_LastName -like "* $suffix")
                    {
                        #USER_LASTNAME IS LIKE A SUFFIX IN ARRAY
                        $User_LastName = $User_Lastname -replace (" $suffix")
                    } 
                }
                #END LASTNAME FILTER SUFFIXES------------------------
                
                $searchbyDesc = $false

                #START FIRST SEARCH AD BY DESCRIPTION FIRST AND LAST NAME---------------------------------------
                write-host 'Getting PC from user first and last name in description from AD...'
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_FirstName*$User_LastName'")
                if(!($computer))
                {
                    #DESCRIPTION LIKE "*FIRSTNAME*LASTNAME"
                    write-host 'Expanding Search to find users Lastname in description of PC...'
                    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName'")
                    if(!($computer))
                    {
                        #DESCRIPTION LIKE "*LASTNAME"
                        write-host 'Expanding Search to find users Lastname anywhere in description of PC...'
                        $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName*'")
                        if(!($computer))
                        {
                            #DESCRIPTION LIKE "*FIRSTNAME"
                            write-host 'Expanding Search to find users Firstname anywhere in description of PC...'
                            $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_FirstName*'")
                        }
                    }
                }
                #END FIRST SEARCH AD BY DESCRIPTION FILTER FIRST AND LAST NAME---------------------------------------
            }
            elseif ($User_LastName)
            {
                #USER_FIRSTNAME IS NULL

                #START LASTNAME FILTER SUFFIXES------------------------
                $filterArrysuffix = @("III", "II", "I", "jr", "jr.", "sr", "sr.")
                foreach ($suffix in $filterArrysuffix)
                {
                    if($User_LastName -like "* $suffix")
                    {
                        $User_LastName = $User_Lastname -replace (" $suffix")
                    } 
                }
                #END LASTNAME FILTER SUFFIXES------------------------

                $User_FirstName = $null

                #START FIRST SEARCH AD BY DESCRIPTION FILTER LASTNAME ONLY---------------------------------------
                write-host 'Expanding Search to find users Lastname in description of PC...'
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName'")
                if(!($computer))
                {
                    write-host 'Expanding Search to find users Lastname anywhere in description of PC...'
                    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName*'")
                }
                #END FIRST SEARCH AD BY DESCRIPTION FILTER LASTNAME ONLY---------------------------------------
            }
            elseif ($User_FirstName)
            {
                #USER_LASTNAME IS NULL

                $User_LastName = $null

                #START FIRST SEARCH AD BY DESCRIPTION FILTER FIRSTNAME ONLY---------------------------------------
                write-host 'Expanding Search to find users Firstname anywhere in description of PC...'
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_FirstName*'")
                #END FIRST SEARCH AD BY DESCRIPTION FILTER FIRSTNAME ONLY---------------------------------------
            }
            else
            {
                #FIRST AND LAST NAME ARE NULL
                write-warning "User Not Found"
                $User_FirstName = $null
                $User_LastName = $null
                $computer = $null
            }
            
            #------------- AD COMPUTER DONE PROCESSING HERE ---------------------------
        
            write-host 'Setting Variable User Firstname...'
            $User_FirstName = $PSUser.Firstname
            if($PSUser.MI)
            {
                #MIDDLE INITIAL PRESENT
                $User_MI = $PSUser.MI
            }
            write-host 'Setting Variable User Lastname...'
	        $User_LastName = $PSUser.LastName
            
            #------------------- USER FIRST, MI, LAST NAME DONE PROCESSING HERE ----------------------------
	    }
        else
        {
            #FINDUSER FUNCTION RETURNED NULL
            write-warning "User Not Found"
            $User_FirstName = $null
            $User_LastName = $null
            $computer = $null
        }
	    
	    if($computer -ne $null)
	    {
            #COMPUTER FOUND IN AD
	        $lstPCs = @() 
	        foreach ($entry in $computer)
	        {
	            $properties = [ordered]@{'Selection'= $($computer.Indexof($entry) + 1);
	                                        'Name'=$($entry.Name);
                                            'Description'= $($entry.Description)}
	            $object = New-Object –TypeName PSObject –Prop $properties
	            $lstPCs += $object
	        }

	        if($($computer.Count) -ge 1)
	        {
                return $lstPCs
	        }
	        else 
	        {
                #NO PC FOUND
                
                $lstPCs = $null
	        }
	    }
	    else
	    {   
	        #NO COMPUTER FOUND IN AD
            write-warning "Computer Not Found"
	        $computer = $null
            $lstPCs = $null
	    }

        return $lstPCs
}
	else
	{
        write-warning $Param_ErrorMsg
        return $null
	}
}

    ####################################################
    #--------------END GET USERS PC------------------#
    ####################################################

    ##################################### FUNCTION END


    import-module Citrix.xendesktop.admin
    add-pssnapin Citrix.*

    $ServersPath = (get-item $PSscriptroot).Parent.FullName
    $vSphereServerPath = "$ServersPath\ServerFiles\vSphereServerAddress.txt"
    $CitrixServerPath = "$ServersPath\ServerFiles\CitrixServerAddress.txt"
    if(test-path $vSphereServerPath)
    {
        $vSphereServer = Get-Content -Path $vSphereServerPath
    }
    else
    {
        write-host -ForegroundColor Yellow "vSphere Server file not found, defaulting to hardcoded"
        #default to hardcode
        $vSphereServer = 'grbaahvlpxdvc02.i.ameriprise.com'
    }

    if(test-path $CitrixServerPath)
    {
        $AdminAddress = Get-Content -Path $CitrixServerPath
    }
    else
    {
        #default to hardcode
        write-host -ForegroundColor Yellow "Citrix Server file not found, defaulting to hardcoded"
        $AdminAddress = "GRBAAHVWPXDDC03.i.ameriprise.com:80"
    }
    #$AdminAddress = "grbaahvwpxddc01.aah.local:80"
    $continue = $true
    while ($continue -eq $true)
    {
        $LogDir = "$Root\Logs\VDIs\Assign Empty VDI Logs"
        $computer = $null
        $computer1 = $null
        $emptyVM = $null
        $emptyVMNames = $null

        $VMs = $null
        $citrix_e = $null
        $VMs = Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`")" -MaxRecordCount 1000 -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            write-host -ForegroundColor Cyan "Search in citrix $strE`n"
        }

        $emptyVM = $VMs |where-object{$_.AssociatedUserNames.count -lt 1}
        $emptyVMNames = $emptyVM |%{(($_.DNSName).Substring(0,14))}
        write-host -ForegroundColor Cyan "Empty VDI's in Citrix:"
        write-host -ForegroundColor Yellow "----------------------------------------"
        foreach ($evm in $emptyVMNames)
        {
            write-host $evm
        }

        write-host -ForegroundColor Yellow "----------------------------------------`n"

        if($emptyVMNames)
        {
            if($emptyVMNames.count -lt 12)
            {
                write-host -ForegroundColor Yellow "WARNING: Only $($emptyVMNames.count) Avaliable VDIs Left in Citrix!"
                write-host -ForegroundColor Yellow "Please Make Sure Ops Has Been Contacted To Create More VDIs!`n"
                read-host "Press enter to continue"
                write-host " "
            }
        }

        import-module ActiveDirectory
        #$computer2 = $computer1.trim()
        $pcfound = $false

        :emtpyvdicheck foreach ($emptyVDI in $emptyVMNames)
        {
            if ($emptyVDI -ne $null -or $emptyVMNames[0] -ne "")
            {
                Write-host -ForegroundColor Yellow "-----------------------------------"
                Write-host -ForegroundColor Cyan "Checking AD for: " -NoNewline
                write-host "$($emptyVDI)"
                $ADcomputer2 = $null
                $computer2 = $null
                $computer2 = $emptyVDI.trim()
                $ADcomputer2 = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$($computer2)'"
                Write-host -ForegroundColor Cyan "Description in AD: " -NoNewline
                write-host "$($ADcomputer2.Description)"
                if($ADcomputer2.Description -like "*NEW*" -or $ADcomputer2.Description -like "**NEW**")
                {
                    Write-host "$computer2" -NoNewline
                    Write-Host -ForegroundColor Green " is unassigned in AD"
                    $pcfound = $true
                    $computer = $computer2
                    Write-host -ForegroundColor Yellow "-----------------------------------`n"
                    Break
                }
                elseif ($ADcomputer2.Description -like "" -or $ADComputer2.Description -eq $null)
                {
                    Write-host "$computer2" -NoNewline
                    Write-Host -ForegroundColor Green " is unassigned in AD"
                    $pcfound = $true
                    $computer = $computer2
                    Write-host -ForegroundColor Yellow "-----------------------------------`n"
                    Break
                }
                else
                {
                    Write-host "$computer2" -NoNewline
                    Write-host -ForegroundColor Yellow " is already assigned in AD"
                    $pcfound = $false
                }
            }
            Write-host -ForegroundColor Yellow "-----------------------------------`n"
        }

        if($pcfound -eq $false)
        {
            write-host -ForegroundColor Red "`nNo Empty VDI was found in citrix and Active directory!`n"

            $exit = read-host "Press enter to exit"
            exit
        }
        Write-Host -ForegroundColor Yellow "--------------------------------------------------------------------"
        write-host -ForegroundColor Cyan "Using VDI: " -NoNewline
        write-host -ForegroundColor Green "$computer`n"


        ################### Assign VDI #######################################################################################################################
        #import-module Citrix.xendesktop.admin
        #add-pssnapin Citrix.*

        $userIn = $null
        $userIn1 = $null
        $userDept = $null
        $userDept1 = $null

        $userIn1 = read-host "Enter employee name"
        $userIn = $userIn1.trim()

        if($userIn)
        {
            if($userIn -eq "" -or $userIn -eq " ")
            {
                write-host -ForegroundColor Red "`nNo Employee name Given`n"
                $userIn = $null
                $userIn1 = $null
                $userDept = $null
                $userDept1 = $null
                $exit = Read-Host "Press enter to return to start"
                continue
            }
            else
            {
                $titlecase = $null
                $titlecase = (Get-Culture).TextInfo
                $userIn = $titlecase.ToTitleCase($userIn)
            }
        }

        $userDept = $Null
        while(!($userDept))
        {
            $deptcorrect = $false
            $userDept1 = $null
            $userDept1 = read-host "Enter user Department [Used to set AD Description] (enter q to quit)"
            $userDept = $userDept1.trim()
            $titlecase = $null
            $titlecase = (Get-Culture).TextInfo
            $userDept = $titlecase.ToTitleCase($userDept)
            if($userDept)
            {
                if($userDept -like "q")
                {
                    read-host "Press enter to exit"
                    exit
                }
                elseif($userDept -eq "" -or $userDept -eq " ")
                {
                    write-host -ForegroundColor Red "`nNo Department Given`n"
                    $userDept = $null
                    continue
                }
                else
                {
                    if($userdept -like "*PHS*")
                    {
                        write-host -ForegroundColor Yellow "PHS is not a department allowed!"
                        $userdept = $null
                        continue
                    }
                    elseif($userdept -like "CS")
                    {
                        write-host -ForegroundColor Cyan "Changing Department: " -NoNewline
                        write-host $deptdesc -NoNewline
                        write-host -ForegroundColor Cyan " to: " -NoNewline
                        write-host "Client Service"
                        $userdept = "Client Service"
                    }
                    elseif($userdept -like "Client Services")
                    {
                        write-host -ForegroundColor Cyan "Changing Department: " -NoNewline
                        write-host $deptdesc -NoNewline
                        write-host -ForegroundColor Cyan " to: " -NoNewline
                        write-host "Client Service"
                        $userdept = "Client Service"
                    }
                    elseif($userdept -like "Customer Service")
                    {
                        write-host -ForegroundColor Cyan "Changing Department: " -NoNewline
                        write-host $deptdesc -NoNewline
                        write-host -ForegroundColor Cyan " to: " -NoNewline
                        write-host "Client Service"
                        $userdept = "Client Service"
                    }
                    elseif($userdept -like "Customer Services")
                    {
                        write-host -ForegroundColor Cyan "Changing Department: " -NoNewline
                        write-host $deptdesc -NoNewline
                        write-host -ForegroundColor Cyan " to: " -NoNewline
                        write-host "Client Service"
                        $userdept = "Client Service"
                    }

                    if($userdept -like "It")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "IT"
                        $userdept = "IT"
                    }
                    elseif($userdept -like "Administrative Assistant")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Admin Assistant"
                        $userdept = "Admin Assistant"
                    }
                    elseif($userdept -like "Admin Support")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Administrative Support"
                        $userdept = "Administrative Support"
                    }
                    elseif($userdept -like "Actuarial")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Actuary"
                        $userdept = "Actuary"
                    }
                    elseif($userdept -like "*Claims")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Claims"
                        $userdept = "Claims"
                    }
                }
            }
        }

	        ############################ Find SamAccount name ###########################

        




        <#
        $fullnamearray = $null
        $lastName = $null
        $MiddleName = $null
        $user = $null
        $selection = $null
        $email = $null
        $username = $null
        $sid = $null

	        $fullnamearray = $userIn.Split(" ")

                if ($fullnamearray.count -gt 1)
                {
                    if ($fullnamearray.count -eq 3)
                    {
                        #write-host "fullname has 3 words"
                        $firstName = $fullnamearray[0]
                        write-host -ForegroundColor Cyan "`nFirst Name: " -NoNewline
                        write-host "$firstName"
                        $MiddleName = $fullnamearray[1]
                        #write-host $MiddleName
                        write-host -ForegroundColor Cyan "Middle Name: " -NoNewline
                        write-host "$MiddleName"
                        $MI = $MiddleName.ToCharArray() | %{[string][char]$_}
                
                        $MI = $MI[0]
                        write-host -ForegroundColor Cyan "Middle Initial: " -NoNewline
                        write-host "$MI"
                        $lastName = $fullnamearray[$fullnamearray.count -1]
                        write-host -ForegroundColor Cyan "Last Name: " -NoNewline
                        write-host "$lastName"
                        $user = @(Get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "Surname -like '*$lastName' -and GivenName -like '$firstName*' -and Initials -like '$MI*'")
                        write-host "$($user.count)" -NoNewline
                        write-host -ForegroundColor Cyan " Users Found from searching by First, Middle, and Last Name"
                        if($($user.count) -lt 1)
                        {
                            $user = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "Surname -like '*$lastName' -and GivenName -like '$firstName*'")
                        }
                    }
                    else
                    {
                        #write-host "fullname has more than 1 word but not 3 words"
                        $firstName = $fullnamearray[0]
                        write-host -ForegroundColor Cyan "`nFirst Name: " -NoNewline
                        write-host "$firstName"
                
                        if ($lastName -eq "BCP")
                        {
                            $lastName = $fullnamearray[$fullnamearray.count -2]
                        }
                        else
                        {
                            $lastName = $fullnamearray[$fullnamearray.count -1]
                        }
                        write-host -ForegroundColor Cyan "Last Name: " -NoNewline
                        write-host "$lastName"
                        $user = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Surname -like '*$lastName' -and GivenName -like '$firstName*'")
                        write-host "$($user.count)" -NoNewline
                        write-host -ForegroundColor Cyan " Users Found from searching by First and Last Name"
                    }
                }
                elseif ($fullnamearray.count -eq 1)
                {
                    $lastName = $fullnamearray[0]
                    $user = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Surname -like '*$lastName' -and GivenName -like '*'")
                }
                else
                {
                    #write-host "skipped"
                    write-host -ForegroundColor "`nNo users avaliable, exiting`n"
                    $exit = read-host "Press any key to exit"
		        exit
                }

                if($($user.count) -gt 1)
                {
                    Write-Host -ForegroundColor Yellow "Too many Users"
                    $name = "Too many results returned"

                    foreach ($entry in $user)
                    {
                        write-host -ForegroundColor Yellow "$($user.Indexof($entry))" -NoNewline
                        write-host " = $($entry.GivenName) $($entry.Initials) $($entry.SurName) EMAIL = $($entry.UserPrincipalName))"
                    }
                    write-host -ForegroundColor Yellow "none" -NoNewline
                    write-host " = None of these"
                    $inputToFilter = Read-host -prompt "Enter Number of selection that should be used for $($fullname)"
                    if ($inputToFilter -like "none")
                    {
                        #$name = "Too many results returned"
		                Write-Host -ForegroundColor Red "`nNo users avaliable, exiting`n"
                        $exit = read-host "Press any key to exit"
		                exit
                    }
                    else
                    {
                        try
                        {
                            $selection = [int]$inputToFilter
                            $user = $user[$selection]

		                    $trmFirstname = $null
		                    $trmlastname = $null
		                    $trmMI = $null
		                    $firstnameOut = $null
		                    $lastnameOut = $null
		                    $MIout = $null

		                    $firstnameOut = $($user.GivenName)
		                    $trmFirstname = $firstnameOut.trim()

		                    $lastnameOut = $($user.SurName)
		                    $trmlastname = $lastnameOut.trim()

                            if ($($user.Initials) -eq "" -or $($user.Initials) -like " ")
                            {
                                $name = $trmFirstname + " " + $trmlastname
                            }
                            else
                            {
                                $name = $trmFirstname + " " + $trmMI + " " + $trmlastname
                            }
			                $email = $($user.UserPrincipalName)
            		        $username = $($user.sAMAccountName)
			                $sid = $($user.SID)
                        }
                        catch
                        {
                            write-host $_
                        }
                        write-host -ForegroundColor Cyan "Users Fullname: " -NoNewline
                        write-host "$name"
                    }

                }
                elseif($($user.count) -lt 1)
                {
                    Write-host -ForegroundColor Yellow "No Users found In AAH`n Searching Corp..."

                    ################### CORP SEARCH #################################
                    if ($fullnamearray.count -gt 1)
                    {
                        if ($fullnamearray.count -eq 3)
                        {
                            #write-host "fullname has 3 words"
                            $firstName = $fullnamearray[0]
                            write-host -ForegroundColor Cyan "`nFirst Name: " -NoNewline
                            write-host "$firstName"
                            $MiddleName = $fullnamearray[1]
                            write-host -ForegroundColor Cyan "Middle Name: " -NoNewline
                            write-host "$MiddleName"
                            #write-host $MiddleName
                            $MI = $MiddleName.ToCharArray() | %{[string][char]$_}
                            $MI = $MI[0]                   
                            write-host -ForegroundColor Cyan "Middle Initial: " -NoNewline
                            write-host "$MI"
                            $lastName = $fullnamearray[$fullnamearray.count -1]
                            write-host -ForegroundColor Cyan "Last Name: " -NoNewline
                            write-host "$lastName"
                            write-host "$($user.count)" -NoNewline
                            write-host -ForegroundColor Cyan " Users Found from searching by First, Middle, and Last Name"
                            if($($user.count) -lt 1)
                            {
                                $user = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com" -Properties * -filter "Surname -like '*$lastName' -and GivenName -like '$firstName*'")
                            }
                        }
                        else
                        {
                            #write-host "fullname has more than 1 word but not 3 words"
                            $firstName = $fullnamearray[0]
                            write-host -ForegroundColor Cyan "`nFirst Name: " -NoNewline
                            write-host "$firstName"
                    
                            if ($lastName -eq "BCP")
                            {
                                $lastName = $fullnamearray[$fullnamearray.count -2]
                            }
                            else
                            {
                                $lastName = $fullnamearray[$fullnamearray.count -1]
                            }
                            write-host -ForegroundColor Cyan "Last Name: " -NoNewline
                            write-host "$lastName"
                            $user = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Surname -like '*$lastName' -and GivenName -like '$firstName*'")
                            write-host "$($user.count)" -NoNewline
                            write-host -ForegroundColor Cyan " Users Found from searching by First and Last Name"
                        }
                    }
                    elseif ($fullnamearray.count -eq 1)
                    {
                        $lastName = $fullnamearray[0]
                        $user = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Surname -like '*$lastName' -and GivenName -like '*'")
                
                    }
                    else
                    {
                        #write-host "skipped"
                        write-host -ForegroundColor Red "`nNo users avaliable, exiting`n"
                        $exit = read-host "Press any key to exit"
		            exit
                    }
    
                    if($($user.count) -gt 1)
                    {
                        Write-Host -ForegroundColor Yellow "Too many Users"
                        $name = "Too many results returned"
    
                        foreach ($entry in $user)
                        {
                            write-host -ForegroundColor Yellow "$($user.Indexof($entry))" -NoNewline
                            write-host " = $($entry.GivenName) $($entry.Initials) $($entry.SurName)" -NoNewline
                            write-host -ForegroundColor Cyan " EMAIL" -NoNewline
                            write-host " = $($entry.UserPrincipalName))"
                        }
                        write-host -ForegroundColor Yellow "none" -NoNewline
                        write-host " = None of these"
                        $inputToFilter = Read-host -prompt "Enter Number of selection that should be used for $($fullname)"
                        if ($inputToFilter -like "none")
                        {
                            #$name = "Too many results returned"
		                    write-host -ForegroundColor Red "No users avaliable, exiting"
                            $exit = read-host "Press any key to exit"
    		                exit
                        }
                        else
                        {
                            try
                            {
                                $selection = [int]$inputToFilter
                                $user = $user[$selection]
    
		                        $trmFirstname = $null
		                        $trmlastname = $null
		                        $trmMI = $null
		                        $firstnameOut = $null
		                        $lastnameOut = $null
		                        $MIout = $null
                                $email = $null
                        
		                        $firstnameOut = $($user.GivenName)
		                        $trmFirstname = $firstnameOut.trim()
    
		                        $lastnameOut = $($user.SurName)
		                        $trmlastname = $lastnameOut.trim()
    
                                if ($($user.Initials) -eq "" -or $($user.Initials) -like " ")
                                {
                                    $name = $trmFirstname + " " + $trmlastname
                                }
                                else
                                {
                                    $name = $trmFirstname + " " + $trmMI + " " + $trmlastname
                                }
			                    $email = $($user.UserPrincipalName)
            		            $username = $($user.sAMAccountName)
			                    $sid = $($user.SID)
                            }
                            catch
                            {
                                write-host $_
                            }
                            write-host -ForegroundColor Cyan "Users Full Name: " -NoNewline
                            write-host $name
                        }
                    }
                    elseif($($user.count) -lt 1)
                    {
                        Write-host -ForegroundColor Red "No Users Found"
                        $name = "No Users returned"
                        $email = "no results returned"
                        $oldpcname = "no Users"
                        $oldpcdesc = "no Users"
                        $exit = read-host "Press any key to exit"
		                exit
                        #$name = "no results returned"
                    }
                    elseif($($user.count) -eq 1)
                    {
		                $trmFirstname = $null
		                $trmlastname = $null
		                $trmMI = $null
		                $firstnameOut = $null
		                $lastnameOut = $null
		                $MIout = $null
    
		                $firstnameOut = $($user.GivenName)
		                $trmFirstname = $firstnameOut.trim()
    
		                $lastnameOut = $($user.SurName)
		                $trmlastname = $lastnameOut.trim()
    
                        if ($($user.Initials) -eq "" -or $($user.Initials) -eq " " -or $($user.Initials) -eq $null)
                        {
                            $name = $trmFirstname + " " + $trmlastname 
                        }
                        else
                        {
		                    $MIout = $($user.Initials)
		                    $trmMI = $MIout.trim()
                            $name = $trmFirstname + " " + $trmMI + " " + $trmlastname
                        }

                        $email = $($user.UserPrincipalName)
                        $username = $($user.sAMAccountName)
		                $sid = $($user.SID)
                    }


                ################### CORP SEARCH #################################    

                }
                elseif($($user.count) -eq 1)
                {
		            $trmFirstname = $null
		            $trmlastname = $null
		            $trmMI = $null
		            $firstnameOut = $null
		            $lastnameOut = $null
		            $MIout = $null

		            $firstnameOut = $($user.GivenName)
		            $trmFirstname = $firstnameOut.trim()

		            $lastnameOut = $($user.SurName)
		            $trmlastname = $lastnameOut.trim()

                    if ($($user.Initials) -eq "" -or $($user.Initials) -eq " " -or $($user.Initials) -eq $null)
                    {
                        $name = $trmFirstname + " " + $trmlastname 
                    }
                    else
                    {
		                $MIout = $($user.Initials)
		                $trmMI = $MIout.trim()
                        $name = $trmFirstname + " " + $trmMI + " " + $trmlastname
                    }

                    $email = $($user.UserPrincipalName)
                    $username = $($user.sAMAccountName)
		            $sid = $($user.SID)
                }
                #>
                $psuser = FindUser($userin)
                if($psuser)
                {
                if($psuser.Errormsg)
                {
                Write-Warning $psuser.Errormsg
                read-host "Press enter to exit"
                exit
                }
                $trmFirstname = $null
		        $trmlastname = $null
		        $trmMI = $null
		        $firstnameOut = $null
		        $lastnameOut = $null
		        $MIout = $null

		        $firstnameOut = $($psuser.FirstName)
		        $trmFirstname = $firstnameOut.trim()

		        $lastnameOut = $($psuser.LastName)
		        $trmlastname = $lastnameOut.trim()

                if ($($psuser.MI) -eq "" -or $($psuser.MI) -eq " " -or $($psuser.MI) -eq $null)
                {
                    $name = $trmFirstname + " " + $trmlastname 
                }
                else
                {
		            $MIout = $($psuser.MI)
		            $trmMI = $MIout.trim()
                    $name = $trmFirstname + " " + $trmMI + " " + $trmlastname
                }

                $email = $($psuser.Email)
                $username = $($psuser.SSO)
		        $sid = $($psuser.SID)
                }
                else
                {
                Write-Warning "No user selected"
                read-host "Press enter to exit"
                exit
                }
                

	        ############################ Find SamAccount name ############################

        write-host -ForegroundColor Cyan "`nName = " -NoNewline
        write-host $name
        write-host -ForegroundColor Cyan "`Username = " -NoNewline
        write-host $username
        write-host -ForegroundColor Cyan "Email = " -NoNewline
        write-host "$email`n" 
        write-host -ForegroundColor Cyan "SID = " -NoNewline
        write-host "$SID"
        Write-Host -ForegroundColor Yellow "--------------------------------------------------------------------`n"
        $VM = $null
        $citrix_e = $null
        $VM = Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
        $VM_out = $($VM.HostedMachineName)

        write-output "`nName = $name" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        write-output "Username = $username" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        write-output "SID = $SID`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append

        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            write-host -ForegroundColor Cyan "Search for " -NoNewline
            write-host "$($VM.HostedMachineName)" -NoNewline
            write-host -ForegroundColor Cyan " in citrix $strE"
            write-output "Search for $($VM.HostedMachineName) in citrix $strE" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        }

        if ($VM.count -gt 1)
        {
            #TODO ADD SELECTION PROCESS ON MULTIPLE VDIs
            write-host -ForegroundColor Yellow "Too many VDI's Returned"
            write-output "Too many VDI's Returned" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        }

        if ($VM.count -lt 1)
        {
            write-host -ForegroundColor Red "VDI not found"
            write-output "VDI not found" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $exit = read-host "Press any key to exit"
            exit
        }

        if ($username -eq $null -or $username -eq "")
        {
            write-host -ForegroundColor Red "Username is empty, exiting"
            write-output "Username is empty, exiting" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $exit = read-host "Press any key to exit"
            exit
        }

        $VMU = $null
        $citrix_e = $null
        $VMU = @(Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and AssociatedUserName -eq `"AFII\$username`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue)
        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            write-host -ForegroundColor Cyan "Search for " -NoNewline
            write-host "AFII\$username" -NoNewline
            write-host -ForegroundColor Cyan " assiocated to VDIs in citrix $strE"
            write-output "Search for AFII\$username assiocated to VDIs in citrix $strE" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        }

        $assignanywaysVDI = $false
        $ExistingVDI = $null
        if ($VMU.count -gt 0)
        {
            write-host -ForegroundColor Yellow "`nUser is currently already assigned in Citrix to these VDI's:"
            write-output "`nUser is currently already assigned to these VDI's:" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            foreach ($uVM in $VMU)
            {
                write-host "$($uVM.HostedMachineName)"
                write-output "$($uVM.HostedMachineName)" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }
            write-host "`n"
            write-output "`n"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            write-output "[INPUT] ASSIGN ANYWAYS (Y/N):" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $conAssign = read-host "Assign Anyways (y/n)?"
            if ($conAssign -like "y")
            {
                $assignanywaysVDI = $true
                if ($($VMU.count) -eq 1)
                {
                    $ExistingVDI = $VMU[0].HostedMachineName
                }
                write-output "[RESPONSE] continue script and assign anyways`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                #continue anyways
            }
            else
            {
                write-output "[RESPONSE] Do NOT assign and exit script" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                $exit = read-host "Press any key to exit"
                exit
            }
        }

        $existingLaptop = $null
        $existingLaptop = (get-UsersPC($name))
        $skipassign2 = $false
        if($existingLaptop -ne $null)
        {
            Write-Host -ForegroundColor Yellow "`n PCs Currently Assigned in AD to User:`n"
            write-output "`n Existing Computers currently assigned to $($name):`n "| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $existingLaptop | Format-Table @{Label ="Computer Name";Expression = { $_.Name }; Alignment="left" }, @{Label ="AD Description";Expression = { $_.Description }; Alignment="left" } -Autosize
            # @{Name="Number";Expression = { $_.Selection }; Alignment="left" },
        
            foreach($EL in $existingLaptop)
            {
                write-output "$EL"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }
            write-output " " | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            if($($existingLaptop.count) -eq 1)
            {
                if ($($existingLaptop[0].Name) -eq $ExistingVDI -and $assignanywaysVDI -eq $true)
                {
                    $skipassign2 = $true
                }
            }
            if ($skipassign2 -eq $false)
            {
                write-output "[INPUT] ASSIGN ANYWAYS (Y/N):" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                $conAssign = read-host "Assign Anyways (y/n)?"
                if ($conAssign -like "y")
                {
                    write-output "[RESPONSE] continue script and assign anyways`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                    #continue anyways
                }
                else
                {
                    write-output "[RESPONSE] Do NOT assign and exit script" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                    $exit = read-host "Press any key to exit"
                    exit
                }
            }
            else
            {
                write-output "[INFO] ONLY 1 VDI WAS THE SAME AS THE ONLY PC ASSIGNED IN AD. USER ALREADY SELECTED TO ASSIGN ANYWAYS. 2ND 'ASSIGN ANYWAYS (Y/N)' PROMPT WAS SKIPPED" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }
        }

        $user = get-BrokerUser -AdminAddress $AdminAddress -Filter "(Fullname -eq `"$username`")"
        if ($user.count -gt 1)
        {
            #TODO ADD SELECTION PROCESS ON MULTIPLE USERS
            write-host -ForegroundColor Yellow "Too many UserNames Returned"
            write-output "Too many UserNames Returned" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        }
        # NEWWWW
        elseif ($user.count -eq 1)
        {

        }
        # NEWWWW
        elseif ($user.count -lt 1)
        {
            write-host -ForegroundColor Cyan "User Not found in citrix, Creating New Broker User"
            write-output "User Not found in citrix, Creating New Broker User" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append

	        ############# Start Adding New BrokerUser to citrix ###################
        Add-BrokerUser -Name "AFII\$username" -machine $VM -AdminAddress $AdminAddress

        #New-BrokerUser -AdminAddress $AdminAddress -Fullname $username -Name "AFII\$username" -UPN $email -SID $sid
        start-sleep -s 3
        $userTest = $null
        $userTest = get-BrokerUser -AdminAddress $AdminAddress -Filter "(SID -eq `"$sid`")"
        if($userTest)
        {
            write-host -ForegroundColor Green "`nSUCCESSFULLY " -NoNewline
            write-host -ForegroundColor cyan "created New Broker User in citrix, Refreshing " -NoNewline
            write-host "$($VM.HostedMachineName)" -NoNewline
            write-host -ForegroundColor Cyan " information"
            write-output "SUCCESFULLY created New Broker User in citrix, Refreshing $($VM.HostedMachineName) information`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append

            $VM = $null
            $citrix_e = $null
            $VM = Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
            
            if($citrix_e)
            {
                $strE = $citrix_e[0].ToString()|out-string
                write-host -ForegroundColor Cyan "Search for " -NoNewline
                write-host "$($VM.HostedMachineName)" -nonewline
                write-host -ForegroundColor Cyan " in citrix " -NoNewline
                write-host "$strE" 
                write-output "Search for $($VM.HostedMachineName) in citrix $strE" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }

        }
        else
        {
            write-host -ForegroundColor red "`nFAILED " -NoNewline
            write-host -ForegroundColor Cyan "to create New Broker User in citrix, will not be able to assign User to VDI" 
            write-output "FAILED to create New Broker User in citrix, will not be able to assign User to VDI" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $exit = read-host "`nPress any key to exit"
            exit
        }
	        ############# End Adding New BrokerUser to citrix ###################

        }

        $trmDept = $null
        $trmName = $null
        $currentusers = $null
        $isUserAssigned = $false

        write-host -ForegroundColor Cyan "Checking Current Assigned Users for " -NoNewline
        write-host "$($VM.HostedMachineName)"
        write-output "Checking Current Assigned Users for $($VM.HostedMachineName)" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        $currentusers = $VM.AssociatedUserNames |%{get-BrokerUser -AdminAddress $AdminAddress -Filter "(name -eq `"$_`")"} 
        foreach ($u in $($currentusers.FullName))
        {
            if ($username -eq $u)
            {
                write-host "$username" -NoNewline
                write-host -ForegroundColor Cyan " is ALREADY assigned to " -NoNewline
                write-host "$($VM.HostedMachineName)`n"
                write-output "$username is ALREADY assigned to $($VM.HostedMachineName)`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                $isUserAssigned = $true
            }
        }
        
        if (!($isUserAssigned))
        {
            write-host -ForegroundColor Cyan "Adding " -NoNewline
            write-host "$username" -NoNewline
            write-host -ForegroundColor Cyan " to " -NoNewline
            write-host "$($VM.HostedMachineName)"
            write-output "Adding $username to $($VM.HostedMachineName)" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            add-BrokerUser -InputObject $user -machine $VM -AdminAddress $AdminAddress
        }

        $VM = $null
        $citrix_e = $null
        $VM = Get-BrokerMachine -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            write-host -ForegroundColor Cyan "Search for " -NoNewline
            write-host "$($VM.HostedMachineName)" -NoNewline
            write-host -ForegroundColor Cyan " in citrix " -NoNewline
            write-host "$strE"
            write-output "Search for $($VM.HostedMachineName) in citrix $strE" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        }

        $users = $VM.AssociatedUserNames |%{get-BrokerUser -AdminAddress $AdminAddress -Filter "(name -eq `"$_`")"}

        if($isUserAssigned)
        {
            write-host -ForegroundColor Green "`nSUCCESSFULLY " -NoNewline
            write-host -ForegroundColor Cyan "confirmed " -NoNewline
            write-host "$username" -NoNewline
            write-host -ForegroundColor Cyan " assigned to " -NoNewline
            write-host "$($VM.HostedMachineName)" -NoNewline
            write-host -ForegroundColor Cyan " in Citrix`n"
            write-output "SUCCESSFULLY confirmed $username is assigned to $($VM.HostedMachineName) in Citrix" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $citrixsuccess = $true
        }
        else
        {
            foreach ($u in $($users.FullName))
            {
                if ($username -eq $u)
                {
                    write-host -ForegroundColor Green "`nSUCCESSFULLY " -NoNewline
                    write-host -ForegroundColor Cyan "confirmed " -NoNewline
                    write-host "$username" -NoNewline
                    write-host -ForegroundColor Cyan " assigned to " -NoNewline
                    write-host "$($VM.HostedMachineName)" -NoNewline
                    write-host -ForegroundColor Cyan " in Citrix`n"
                    write-output "SUCCESSFULLY confirmed $username assigned to $($VM.HostedMachineName) in Citrix" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
                    $citrixsuccess = $true
                    $isUserAssigned = $true
                }
            }
        }

        if(!($isUserAssigned))
        {
            write-host -ForegroundColor Red "`nFAILED " -NoNewline
            write-host -ForegroundColor Cyan "to assign " -NoNewline
            write-host "$username" -NoNewline
            write-host " to " -NoNewline
            write-host "$($VM.HostedMachineName)`n"
            write-output "FAILED to assign $username to $($VM.HostedMachineName)" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $citrixsuccess = $false
            $exit = read-host "Press any key to exit"
            exit
        }
        write-host -ForegroundColor Yellow "----------------------------------------------------------"
        write-host -ForegroundColor Cyan "Users currently assigned to " -NoNewline
        write-host "$($VM.HostedMachineName):`n"
        write-output "Users currently assigned to $($VM.HostedMachineName):`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        $users | %{write-host "$($users.fullname)"; write-output "$($users.fullname)"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append}
        write-host ""
        write-host -ForegroundColor Yellow "----------------------------------------------------------`n"
        write-host -ForegroundColor Cyan "Setting Description in AD to:"
        write-output "Setting Description in AD to:" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        $trmDept = $userDept.trim()
        $trmName = $name.trim()
        $desc = "$trmDept - $trmName"
        write-host "$desc"
        write-output "$desc`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        $ADcomputer1 = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$($VM.HostedMachineName)'"
        Set-ADComputer $ADcomputer1 -Description $desc
        write-host -ForegroundColor Cyan "`nVerifying Desc Set..."
        write-output "Verifying Desc Set..." | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
        $ADcomputer1 = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$($VM.HostedMachineName)'"
        write-host -ForegroundColor Cyan "Description in AD for " -NoNewline
        write-host "$($VM.HostedMachineName)" -NoNewline
        write-host -ForegroundColor cyan " is now: "-NoNewline
        write-host "$($ADcomputer1.description)"
        write-output "Description in AD for $($VM.HostedMachineName) is now:`n$($ADcomputer1.description)`n" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append

        if ($desc -eq $($ADcomputer1.description))
        {
            write-host -ForegroundColor Green "`nSUCCESSFULLY " -NoNewline
            write-host -ForegroundColor Cyan "set " -NoNewline
            write-host "$($ADcomputer1.name)" -NoNewline
            write-host -ForegroundColor Cyan " Description to: " -NoNewline
            write-host "$desc`n"
            write-output "SUCCESSFULLY set $($ADcomputer1.name) Description to $desc" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $adsuccess = $true
        }
        else
        {
            write-host -ForegroundColor Red "`nFAILED " -NoNewline
            write-host -ForegroundColor Cyan "to set " -nonewline
            write-host "$($ADcomputer1.name)" -NoNewline
            write-host -ForegroundColor Cyan " Description to: " -nonewline
            write-host "$desc`n"
            write-output "FAILED to set $($ADcomputer1.name) Description to $desc" | Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            $adsuccess = $false
            $exit = read-host "Press any key to exit"
            exit
        }
        write-host -ForegroundColor Cyan "`n   RESULTS:"
        write-host -ForegroundColor Cyan "----------------------------------------------------------"
        write-host "Assigned User to VDI in Citrix... " -NoNewline
        if ($citrixsuccess -eq $true){write-host -ForegroundColor Green "SUCCESS"}
        else{write-host -ForegroundColor red "FAILED"}
        write-host "Active Directory Description Set... " -NoNewline
        if ($adsuccess -eq $true){write-host -ForegroundColor Green "SUCCESS"}
        else{write-host -ForegroundColor red "FAILED"}
        #write-host "Webpage should open to record in service-now..." -NoNewline
        #write-host -foregroundcolor Yellow "MUST UPDATE SERVICE-NOW MANUALLY STILL!"
        write-host -ForegroundColor Cyan "----------------------------------------------------------"

		        ############## SN webpage open to assign ################
        if ($($ADcomputer1.name))
        {
            write-output "`n"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            if ($adsuccess -eq $true)
            {
                write-output "SUCCESSFULLY set Active Directory"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }
            else
            {
                write-output "FAILED to set Active Directory"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }
            if ($citrixsuccess -eq $true)
            {
                write-output "SUCCESSFULLY assigned user in Citrix"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }
            else
            {
                write-output "FAILED assigning user in Citrix"| Out-File -FilePath "$LogDir\$VM_Out - $name.txt" -Encoding ascii -Append
            }

            if(test-path 'C:\Program Files (x86)\Python37-32\python.exe')
            {
                #python installed
                if(test-path "$root\Python\Assign VDI.ps1")
                {
                    #retire VDI in Service now script found
                    write-host "Starting Update of Service-Now records"
                    $pslogpath = "$LogDir\$VM_Out - $name.txt"
                    write-host "-------------------------------------------------------"
                    Start-Process Powershell -ArgumentList ("& `'$root\Python\Assign VDI.ps1`' -computer '$($ADcomputer1.name)' -UserEmail $email -PSLogPath '$($pslogpath)'")
                    write-host "-------------------------------------------------------"
                }
                else
                {
                    write-host -ForegroundColor Cyan "Opening Up VDI in Service Now" -NoNewline
                    write-host -ForegroundColor Yellow " SERVICE-NOW NEEDS TO BE UPDATED MANUALLY!"
                    write-output "Opening Browser to VDI record in Service Now" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                    $url = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware_list.do%3Fsysparm_first_row%3D1%26sysparm_query%3DGOTOci.nameLIKE$($ADcomputer1.name)%26sysparm_query_encoded%3DGOTOci.nameLIKE$($ADcomputer1.name)%26sysparm_view%3D"
                    Start-Process "chrome.exe" $url
                }
            }
            else
            {
                write-host -ForegroundColor Cyan "Opening Up VDI in Service Now" -NoNewline
                write-host -ForegroundColor Yellow " SERVICE-NOW NEEDS TO BE UPDATED MANUALLY!"
                write-output "Opening Browser to VDI record in Service Now" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                $url = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware_list.do%3Fsysparm_first_row%3D1%26sysparm_query%3DGOTOci.nameLIKE$($ADcomputer1.name)%26sysparm_query_encoded%3DGOTOci.nameLIKE$($ADcomputer1.name)%26sysparm_view%3D"
                Start-Process "chrome.exe" $url
            }
        }

		        ############## SN webpage open to assign ################

        $exit = read-host "`n Do another one? (y/n)"
        if ($exit -like "y")
        {
            $continue = $true
            continue
        }
        else
        {
            $continue = $false
            exit
        }
    }
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}


################### Assign VDI ###########################################################################################################################################