﻿Get-ChildItem "C:\Temp\Drivers" -Recurse -Filter "*.inf" | 
ForEach-Object { 
write-host "Installing $($_.FullName)"
Try{
PNPUtil.exe /add-driver $_.FullName /install

}
catch
{
write-host "$($_)"
continue
}
write-host "Successfully installed $($_.FullName)"
 }