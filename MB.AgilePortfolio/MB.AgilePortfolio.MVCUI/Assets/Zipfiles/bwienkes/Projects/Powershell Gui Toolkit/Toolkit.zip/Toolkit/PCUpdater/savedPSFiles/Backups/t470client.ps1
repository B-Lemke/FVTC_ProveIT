﻿Param(

#(name),(remoteroot),(cmd command)

[String[]]$Name,
[String[]]$Root,
[String[]]$CMD,
[String]$Bios,
[String]$BiosName


)




write-output " "
<#
for($i=0;$i-le $Name.Length-1;$i++)
{
    $Root[$i] = Split-Path $Root[$i] -Leaf
    write-host "Name = $($Name[$i])"
    write-host "Root = C:\Temp\$($Root[$i])"
    write-host "CMD = $($CMD[$i])"
    Write-host -ForegroundColor Cyan "Installing $($Name[$i])..." -NoNewline
    
    if($CMD[$i] -like "*.msi")
    {
    write-host "Skipping Thunderbolt on client (already installed)..." -NoNewline
        #start-process msiexec "/i C:\Temp\$($Root[$i])\$($CMD[$i]) /qn" -wait | Out-Host
    }
    else
    {
            Start-Process -FilePath "C:\Windows\System32\CMD.EXE" -ArgumentList "/C C:\Temp\$($Root[$i])\$($CMD[$i])" -Wait -WindowStyle Hidden | Out-Host

    }
    write-host "Done"

}
#>

    Write-output "Updating to Bios $($BiosName)..." 
#Write-host "Updating to Bios $($Bios)..." 


            write-output "Checking Battery..."
            $batteries = (Get-WmiObject win32_battery)
            $lowbats = $false
            if($batteries.count)
            {
                foreach($bat in $batteries)
                {
                    if (((Get-WmiObject win32_battery).EstimatedChargeRemaining) -lt 30)
                    {
                        $lowbats = $true
                    }
                }
            }
            else
            {
                if (((Get-WmiObject win32_battery).EstimatedChargeRemaining) -lt 30)
                {
                    $lowbats = $true
                }
            }
            if ($lowbats -eq $true)
            {
                write-host -ForegroundColor Red "`nBATTERY HAS LESS THAN 30% CHARGE BIOS MAY NOT WORK!"
                
            }
            else
            {
                write-host -ForegroundColor Green "Battery has 30% or more charge"
            }

(&"C:\Temp\Invoke-LenovoBIOSUpdate.ps1" -Path "C:\Temp\Bios") |out-host
write-host "waiting 5 mins to allow bios"
start-sleep -Seconds 300






    

