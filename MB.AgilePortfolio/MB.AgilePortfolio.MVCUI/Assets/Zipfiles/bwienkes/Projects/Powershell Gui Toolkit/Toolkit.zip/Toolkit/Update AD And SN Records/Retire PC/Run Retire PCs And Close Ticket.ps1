﻿

#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************
cls
# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;


function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User1 = $NonAdmin_User.trim()
            $NonAdmin_User1 = "AFII\$($Script:NonAdmin_User1)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}


function Call-Reassignment($Desc)
{

    $i = 0
    $strpcs = ""
    foreach($pc in $Desc)
    {
    $pc = $pc.trim()
    if(!($pc))
    {
        continue
    }
    write-host "Entry: $pc"
    $pc2 = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "Name -like '*$pc'"
    $baseroot = (((get-item "$Psscriptroot").Parent).Parent).FullName
    if($PC2.name)
    {
    
    
    $name = $PC2.name
    $logpath = "$baseroot\logs\Retire PCs\$name.txt"
    write-output "Computer: $($PC2.name)" | Out-File $logpath -Encoding ascii
    write-output "Date: $(get-date)" | Out-File $logpath -Encoding ascii -Append
    write-host $name -NoNewline
    write-host -ForegroundColor Yellow " was found in AD"
    write-output "PC was in AD..." | Out-File $logpath -Encoding ascii -Append
    $deleteInAd = read-host "would you like to Delete $name from AD?(y/n)"
    if($deleteInAd -like "y")
    {
        write-output "User choose to remove the PC from AD" | Out-File $logpath -Encoding ascii -Append
        write-host "Removing $name..." -NoNewline
        Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$name'" | Remove-ADObject -Recursive -Confirm:0
        $ADcomputer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$name'") 
        if ($ADcomputer.count -lt 1)
        {
            write-output "[SUCCESS] Removing PC from AD" | Out-File $logpath -Encoding ascii -Append
            write-Host -ForegroundColor Green "SUCCESS"
        }
        else
        {
            write-output "[FAILED] Removing PC from AD" | Out-File $logpath -Encoding ascii -Append
            write-Host -ForegroundColor Red "FAILED"
        }
    }
    
        if($i -eq 0)
        {
            
            if ($name -like ",*")
            {
                $name.Replace(',')
            }
            $strpcs += "`"$name`""
        $i++
        }
        else
        {
            $strpcs += ",`"$name`""
        $i++
        }
    }
    else
    {
        $logpath = "$baseroot\logs\Retire PCs\$pc.txt"
        write-output "Computer: $($PC2.name)" | Out-File $logpath -Encoding ascii
        write-output "Date: $(get-date)" | Out-File $logpath -Encoding ascii -Append
        write-host "$PC is not in AD"
        write-output "$PC is not in AD" | Out-File $logpath -Encoding ascii -Append
        if($i -eq 0)
        {
            $name = $PC.toUpper()
            if ($name -like ",*")
            {
                $name.Replace(',')
            }
            $strpcs += "`"$name`""
        $i++
        }
        else
        {
            $strpcs += ",`"$($PC.toUpper())`""
        $i++
        }
    }
    write-host " "
    }
    write-host "PC String:"
    write-host "--------------------------------------------"
    write-host $strpcs
    write-host "--------------------------------------------"
    write-host -ForegroundColor Yellow "This script will update ITAM, and open a ticket, assign ticket to you, and close ticket."
    write-host -ForegroundColor Yellow "`nScript assumes you have:"
    write-host -ForegroundColor Yellow "------------------------------"
    write-host -ForegroundColor Yellow "- Chosen to remove PC from AD if it was present"
    write-host -ForegroundColor Yellow "- Checked there is no bios password on computer"
    write-host -ForegroundColor Yellow "- Already DBANed computer"
    write-host -ForegroundColor Yellow "------------------------------"
    $continuescriptcaution = read-host "`n Do you want to continue with running this script? (y/n)"
    if ($continuescriptcaution -like "y")
    {

    }
    else
    {
        read-host "`n Press enter to exit"
        exit
    }
    $scriptPath = "$($PSScriptRoot)"
    $LogRoot = (get-item $scriptPath).Parent.Parent.FullName
    $Python_Script = "$LogRoot\Python\Retire PCs And Close Ticket.py"

    $i= 0
    if(Test-Path "$Python_Script")
    {

        #$Python_Script = "C:\Users\bwienk1\Desktop\Script Fixes\Python\Check PCs.py"
        $i= 0
        $content = $null
        $content = (get-content "$Python_Script")

        if($strpcs)
        {
            $i= 0
            $content2 = ($content | Where-Object {$_ -like 'OldComputerFullname = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
            if($content2.count -gt 1)
            {
                #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
            }
            else
            {
                $content[$index] = "OldComputerFullname = [$strpcs]"
            }
        }
        else
        {
            $i= 0
            $content2 = ($content | Where-Object {$_ -like 'OldComputerFullname = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
            if($content2.count -gt 1)
            {
                #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
            }
            else
            {
                $content[$index] = "OldComputerFullname = []"
            }

        }

        $content |Set-Content "$Python_Script"
        Start-Sleep -Milliseconds 500
            
        write-host -ForegroundColor Cyan "Getting Info from Service-Now Records..."
        write-output "Computers Ran  = [$strpcs]"
        & "C:\Program Files (x86)\Python37-32\python.exe" "$Python_Script" "$Script:NonAdmin_User1" "$Script:Password"
        write-host -ForegroundColor Cyan "Completed Getting Info from Service-Now Records!"
        $exit = read-host " Press enter to exit"
        exit

    }
    else
    {
        #write-debug "location fixes is not valid path"
    }
}

Check-Credentials
#$loginPassword = $Script:Password
#$loginUsername = $Script:NonAdmin_User1
$desc = gc -Path "$PSScriptRoot\pc_list.txt"
While(!($Desc))
{
$desc = read-host "Search Service-now for PC like (wildcards supported, IE: *)"
}
clear-content "$PSScriptRoot\pc_list.txt"
While(!($Script:NonAdmin_User1))
{
   $Script:NonAdmin_User1 = read-host "Enter Your Non Admin Username (enter q to exit)"
   if ($Script:NonAdmin_User1 -eq "q"){exit}
}
if(!($Script:Password))
{
    while(!($Script:Password))
    {
        $Script:Password = read-host "Enter Your Non Admin Password (enter q to exit)"
        if ($Script:Password -eq "q"){exit}
    }
}
    Call-Reassignment -Desc $Desc
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------
    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}


