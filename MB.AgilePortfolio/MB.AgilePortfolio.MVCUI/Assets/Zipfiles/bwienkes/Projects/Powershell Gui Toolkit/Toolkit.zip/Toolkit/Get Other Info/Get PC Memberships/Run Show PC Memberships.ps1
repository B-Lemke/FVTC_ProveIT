﻿param
(
    [Parameter(Mandatory=$false)]$computer            
)
#HIDE CONSOLE IMPORTS---------------------------------------------------------------------------------------------------------
#---------------------------------------------- 
#region Import Assemblies 
#---------------------------------------------- 
[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'
function Hide-Console
{
    $Script:ShowConsole = $false
    $consolePtr = [Console.Window]::GetConsoleWindow()
    #0 hide
    [Console.Window]::ShowWindow($consolePtr, 0)
}
Hide-Console
if(!($computer)){$Param_ErrorMsg = "No value entered for: computer"}
elseif(!($computer -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: computer"}
elseif(!($computer.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: computer"}
if(!($Param_ErrorMsg))
{
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;

    Function Show-DGForm($lstSelections)
{
 
	#---------------------------------------------- 
	#region Import Assemblies 
	#---------------------------------------------- 
	[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	#endregion Import Assemblies  
 
	function DGForm($input1) 
	{ 
	    $Script:DGForm_RowIndex = $null
	    <# 
    	    .SYNOPSIS 
    	The Main function starts the project application. 
    	     
	        .PARAMETER Input1
	    $Input1 contains the complete argument string passed to the script packager executable. 
    	     
	        .NOTES 
	    Use this function to initialize your script and to call GUI forms. 
    	         
	        .NOTES 
	    To get the console output in the Packager (Forms Engine) use:  
	    $ConsoleOutput (Type: System.Collections.ArrayList) 
	    #> 
	     
	    #-------------------------------------------------------------------------- 
     
	    if((Call-DGForm_psf($input1)) -eq 'OK') 
	    { 
	        # ADD VALIDATION IF NEEDED
	    } 
	    $global:ExitCode = 0 #Set the exit code for the Packager 
	} 
 
	#endregion Source: Startup.pss 
 
	#region Source: MainForm.psf 
	function Call-DGForm_psf($input1) 
	{ 
    	#Datagrid click Function
	    Function dg_Selections_GridClick
	    {
	        #Set $Script:SelectionForm_RowIndex to index of the currently selected row
	        $Script:DGForm_RowIndex = $dg_Selections.CurrentRow.Index
	    }
    
	    #Add Data to Datagrid function
	    function Get-ProcessInfo($input1) 
	    {
	        $array = New-Object System.Collections.ArrayList
	        $array.AddRange($input1)
	        $dg_Selections.DataSource = $array
	        $DGform.refresh()
	        $dg_Selections.ClearSelection()
	    }
 
	    #---------------------------------------------- 
	    #region Import the Assemblies 
	    #---------------------------------------------- 
	    [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	    #endregion Import Assemblies 
    	 
    	#---------------------------------------------- 
    	#region Generated Form Objects 
    	#---------------------------------------------- 
    	[System.Windows.Forms.Application]::EnableVisualStyles() 
    	$DGForm = New-Object 'System.Windows.Forms.Form'
    	#$ButtonCancel = New-Object 'System.Windows.Forms.Button' 
    	$ButtonSelect = New-Object 'System.Windows.Forms.Button' 
    	$panel1 = New-Object 'System.Windows.Forms.Panel'
    	$panel2 = New-Object 'System.Windows.Forms.Panel'
    	$panel3 = New-Object 'System.Windows.Forms.Panel'
    	$panel4 = New-Object 'System.Windows.Forms.Panel'
    	$dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
    	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
    	#endregion Generated Form Objects 
 
	    #---------------------------------------------- 
	    # Form Object Functions
	    #---------------------------------------------- 
    
    	#Form Load function
    	$DGForm_Load =
    	{ 
        	get-processinfo($input1)         
	    }
    	
    	#Select Button clicked function
    	$ButtonSelect_Click = 
    	{     
        	$DGForm.Close()
	    } 

           <#        
	    #Cancel Button clicked function
	    $ButtonCancel_Click =
	    {
            #TODO: Place custom script here on canceling form
	        $DGForm.Close() 
	    }
        #>
        
     
            # --End Form Object Functions-- 
	    #---------------------------------------------- 
	    #region Generated Events 
	    #---------------------------------------------- 
	
	    #Fix Form Load function
	    $Form_StateCorrection_Load = 
	    { 
	        #Correct the initial state of the form to prevent the .Net maximized form issue 
	        $DGForm.WindowState = $InitialFormWindowState 
	    } 
     
	    #Store Values of form function
	    $Form_StoreValues_Closing = 
	    { 
	        #Store the control values here
	    } 
 
	    $Form_Cleanup_FormClosed = 
	    { 
	        #Remove all event handlers from the controls 
	        try 
	        { 
    	        #$ButtonCancel.remove_Click($buttonCancel_Click) 
	            $ButtonSelect.remove_Click($ButtonSelect_Click)
	            $DGForm.remove_Load($DGForm_Load) 
	            $DGForm.remove_Load($Form_StateCorrection_Load) 
	            $DGForm.remove_Closing($Form_StoreValues_Closing) 
	            $DGForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	        } 
	        catch [Exception] 
	        { } 
	    } 
	    #endregion Generated Events 
 
	    #---------------------------------------------- 
	    #region Form Setup Objects
	    #---------------------------------------------- 
	    #Suspend layouts
	    $DGForm.SuspendLayout()
	    #$panel4.SuspendLayout() 
	    $panel3.SuspendLayout() 
	    $panel2.SuspendLayout() 
	    $panel1.SuspendLayout()
    	 
    	# 
    	# SelectForm Attributes
    	# 
    	$DGForm.Controls.Add($panel1)
    	$DGForm.Controls.Add($panel2) 
    	$DGForm.AutoScaleDimensions = '6, 13' 
    	$DGForm.AutoScaleMode = 'Font' 
    	$DGForm.BackColor = 'White' 
    	$DGForm.ClientSize = '373, 329'   
    	$DGForm.MaximizeBox = $False 
    	$DGForm.MinimizeBox = $False 
    	$DGForm.Name = 'SelectForm' 
    	$DGForm.ShowIcon = $False 
    	$DGForm.ShowInTaskbar = $False 
    	$DGForm.StartPosition = 'CenterScreen' 
    	$DGForm.Text = 'PC Memberships'
    	$formsizex = $DGForm.ClientSize.Width + 100
    	$formsizey =  $DGForm.ClientSize.Height + 100
    	$DGForm.MinimumSize = "$formsizex,$formsizey"
    	$DGForm.MaximumSize = "$($formsizex + 600),$formsizey"
    	$DGForm.TopMost = $True 
    	$DGForm.add_Load($DGForm_Load)
        # 
	    # ButtonSelect Attributes
	    # 
	    $ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	    $ButtonSelect.ForeColor = 'Blue' 
	    $ButtonSelect.Location = '42, 50' 
	    $ButtonSelect.Name = 'ButtonSelect' 
	    $ButtonSelect.Size = '91, 45' 
	    $ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	    $ButtonSelect.Text = 'OK' 
	    $ButtonSelect.UseVisualStyleBackColor = $True 
	    $ButtonSelect.add_Click($ButtonSelect_Click)
	    $ButtonSelect.MaximumSize.Height = '60' 
	    $ButtonSelect.Dock = [System.Windows.Forms.DockStyle]::Left
	    # 
	    # Panel1 Attributes
	    #  
	    $panel1.Controls.Add($dg_Selections)
	    $panel1.Location = '0, 0' 
	    $panel1.Name = 'panel1' 
	    $panel1.Size = '375, 310' 
	    $panel1.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel1.BackColor = 'LightGray'
	    $panel1.Dock = [System.Windows.Forms.DockStyle]::Top
	    # 
	    # Panel3 Attributes
	    # 
	    $panel3.Controls.Add($ButtonSelect)  
	    $panel3.Location = '188, 310' 
	    $panel3.Name = 'panel2' 
	    $panel3.Size = '300, 80' 
	    $panel3.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel3.Padding = '180,20,0,20' 
	    $panel3.BackColor = 'LightSkyBlue'
	    $panel3.Dock = [System.Windows.Forms.DockStyle]::Left
	    # 
	    # Panel2 Attributes
	    # 
	    $panel2.Controls.Add($panel3)  
	    #$panel2.Controls.Add($panel4)  
	    $panel2.Location = '0, 310' 
	    $panel2.Name = 'panel2' 
	    $panel2.Size = '376, 80' 
	    $panel2.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel2.BackColor = 'LightSkyBlue'
	    $panel2.Dock = [System.Windows.Forms.DockStyle]::Bottom
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.Size = '375, 300'
	    $dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	    $dg_Selections.Name = "dg_Selections"
	    $dg_Selections.DataMember = ""
	    #$dg_Selections.TabIndex = 0 #TODO FIX TABINDEXES
	    $dg_Selections.Location = '0,0'
	    $dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	    $dg_Selections.AutoSizeRowsMode = "AllCells"
        #$dg_Selections.AutoSizeColumnsMode = 
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	    $dg_Selections.DefaultCellStyle.WrapMode = 'True'
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	    $dg_Selections.Margin = New-Object System.Windows.Forms.Padding(3, 3, 3, 3)
	    $dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	    $dg_Selections.RowHeadersVisible = $false
        $dg_Selections.ColumnHeadersVisible = $false
	    $dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	    #Resume Layouts
	    $panel1.ResumeLayout() 
	    $panel2.ResumeLayout()
	    $panel3.ResumeLayout() 
	    $panel4.ResumeLayout()  
	    $DGForm.ResumeLayout()
    	 
    	#endregion Form Setup Objects
    	#---------------------------------------------- 
    	
    	#Save the initial state of the form 
    	$InitialFormWindowState = $DGForm.WindowState 
    	#Init the OnLoad event to correct the initial state of the form 
    	$DGForm.add_Load($Form_StateCorrection_Load) 
    	#Clean up the control events 
    	$DGForm.add_FormClosed($Form_Cleanup_FormClosed) 
    	#Store the control values when form is closing 
    	$DGForm.add_Closing({
    	    #Add Closing code here
	    }) 

	    #Show the Form
        #$result = $DGForm.ShowDialog()
	    return $DGForm.ShowDialog()

	    #endregion Source: MainForm.psf 
	    $self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	}
	
	#Start the application
    $Finalresult = DGForm ($lstSelections)
    return $Script:DGForm_RowIndex
}


#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
             
    $AD_Computer = $null
    $AD_Computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "name -like '$computer'")
    if($AD_Computer)
    {
        $sccmGroups = @()
        $Group = $AD_Computer | Select -ExpandProperty MemberOf |% {$_.Split(",")[0].TrimStart("CN=")}
        if ($Group.count -lt 1)
        {
            #no memberships
            $properties = @{'Membership' = "No Memberships";}
            $obj = New-Object –TypeName PSObject –Prop $properties
            $sccmGroups += $obj
        }
        else
        {
            foreach ($member in $Group)
            {
                if ($member -like "SCCM*")
                {
                    #$sccmGroups += $member
                }
                $properties = @{'Membership' = $member;}
                $obj = New-Object –TypeName PSObject –Prop $properties
                $sccmGroups += $obj
            }
        }
            $selectedMembership = Show-DGForm($sccmGroups)
    }
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}
}
else
{
write-host "Show PC Memberships: $Param_ErrorMsg"
Read-Host "`nPress Enter to exit"
exit
}