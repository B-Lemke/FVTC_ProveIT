﻿param
(
[Parameter(Mandatory=$false)] $computer
)

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

Function Check-If-IP
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$isIP = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if ($Computername -like "*.*.*.*")
	{
	# Is an IP Address
	$isIP =  $true
	}
	else
	{
	# NOT an IP Address
	$isIP = $false
	}
	}
	else
	{
	Write-Debug "[FAILURE] Check-If-IP - Initial parameter input was null"
	$ErrorMsg = "Check-If-IP - $Param_ErrorMsg"
	
	}
	$properties = @{'Output' = $isIP;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


Function Filter-PC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$PC = $null
	$ErrorMsg = $null
	$Return_Object = $null
    
	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	    $Computername = $Computername.trim()
	    $PC = $Computername
	    If ($PC -like "WILG000*")
	    {
	        #WI laptop Dell
	        $PC = $PC -replace "WILG000"
	    }
	    elseif ($PC -like "WILG00*")
	    {
	        #WI laptop Lenovo
	        $PC = $PC -replace "WILG00"
	    }
	    elseif ($PC -like "WIDG000*")
	    {
	        #WI Desktop Dell
	        $PC = $PC -replace "WIDG000"
	    }
	    elseif ($PC -like "WIDG00*")
	    {
	        #WI Desktop Lenovo?
	        $PC = $PC -replace "WIDG00"
	    }
	    elseif ($PC -like "AZLG000*")
	    {
	        #AZ laptop dell
	        $PC = $PC -replace "AZLG000"
	    }
	    elseif ($PC -like "AZLG00*")
	    {
	        #AZ laptop lenovo
	        $PC = $PC -replace "AZLG00"
	    }
	    elseif ($PC -like "AZDG000*")
	    {
	        #AZ Desktop dell
	        $PC = $PC -replace "AZDG000"
	    }
	    elseif ($PC -like "AZDG00*")
	    {
	        #AZ Desktop lenovo?
	        $PC = $PC -replace "AZDG00"
	    }
	    elseif ($PC -like "NVLG000*")
	    {
	        #LV laptop dell
	        $PC = $PC -replace "NVLG000"
	    }
	    elseif ($PC -like "NVLG00*")
	    {
	        #LV laptop lenovo
	        $PC = $PC -replace "NVLG00"
	    }
	    elseif ($PC -like "NVDG000*")
	    {
	        #LV Desktop dell
	        $PC = $PC -replace "NVDG000"
	    }
	    elseif ($PC -like "NVDG00*")
	    {
	        #LV Desktop lenovo?
	        $PC = $PC -replace "NVDG00"
	    }
	    elseif ($PC -like "WIVGP*")
	    {
	        #VDI's To be added
	    }
	    elseif ($PC -like "*.*.*.*")
    	{
        	$script:IPaddress = $true
	    }
	    else
	    {
	        #BAD ENTRY CODE HERE
	        $ErrorMsg = "Filter-PC - Not a valid input"
	    }
	}
	else
	{
	    Write-Debug "[FAILURE] Filter-PC - Initial parameter input was null"
	    $ErrorMsg = "Filter-PC - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $PC;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}

function Teardown-IP-Invoke
{
		#Post Reset Trustedhosts back
		if ($Script:TrustedHosts)
		{
			Set-Item WSMan:\localhost\Client\TrustedHosts -Value $Script:TrustedHosts -Force
		}
}

Function Show-SelectionForm($lstSelections)
{
 
	#---------------------------------------------- 
	#region Import Assemblies 
	#---------------------------------------------- 
	[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	#endregion Import Assemblies  
 
	function SelectForm($input1) 
	{ 
	$Script:SelectionForm_RowIndex = $null
	<# 
	    .SYNOPSIS 
	The Main function starts the project application. 
	     
	    .PARAMETER Input1
	$Input1 contains the complete argument string passed to the script packager executable. 
	     
	    .NOTES 
	Use this function to initialize your script and to call GUI forms. 
	         
	    .NOTES 
	To get the console output in the Packager (Forms Engine) use:  
	$ConsoleOutput (Type: System.Collections.ArrayList) 
	#> 
	     
	#-------------------------------------------------------------------------- 
     
	if((Call-SelectForm_psf($input1)) -eq 'OK') 
	{ 
	# ADD VALIDATION IF NEEDED
	    } 
	$global:ExitCode = 0 #Set the exit code for the Packager 
	} 
 
	#endregion Source: Startup.pss 
 
	#region Source: MainForm.psf 
	function Call-SelectForm_psf($input1) 
	{ 
	#Datagrid click Function
	    Function dg_Selections_GridClick
	{
	#Set $Script:SelectionForm_RowIndex to index of the currently selected row
	[int]$Script:SelectionForm_RowIndex = $dg_Selections.CurrentRow.Index
	}
    
	#Add Data to Datagrid function
	function Get-ProcessInfo($input1) 
	{
	$array = New-Object System.Collections.ArrayList
	$array.AddRange($input1)
	$dg_Selections.DataSource = $array
	$selectform.refresh()
	$dg_Selections.ClearSelection()
	}
 
	#---------------------------------------------- 
	#region Import the Assemblies 
	#---------------------------------------------- 
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	#endregion Import Assemblies 
	 
	#---------------------------------------------- 
	#region Generated Form Objects 
	#---------------------------------------------- 
	[System.Windows.Forms.Application]::EnableVisualStyles() 
	$SelectForm = New-Object 'System.Windows.Forms.Form'
	$ButtonCancel = New-Object 'System.Windows.Forms.Button' 
	$ButtonSelect = New-Object 'System.Windows.Forms.Button' 
	$panel1 = New-Object 'System.Windows.Forms.Panel'
	$panel2 = New-Object 'System.Windows.Forms.Panel'
	$panel3 = New-Object 'System.Windows.Forms.Panel'
	$panel4 = New-Object 'System.Windows.Forms.Panel'
	$dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
	#endregion Generated Form Objects 
 
	#---------------------------------------------- 
	# Form Object Functions
	#---------------------------------------------- 

	#Form Load function
	$SelectForm_Load =
	{ 
	get-processinfo($input1)         
	}
	
	#Select Button clicked function
	$ButtonSelect_Click = 
	{     
	#Checks for input selected before allowing form close from select button click
	if ($Script:SelectionForm_RowIndex -or $Script:SelectionForm_RowIndex -eq 0)
	{
	$SelectForm.Close()
	}
	} 

	#Cancel Button clicked function
	$ButtonCancel_Click =
	{
           #TODO: Place custom script here on canceling form
	$SelectForm.Close() 
	} 
     
        # --End Form Object Functions-- 
	#---------------------------------------------- 
	#region Generated Events 
	#---------------------------------------------- 
	
	#Fix Form Load function
	$Form_StateCorrection_Load = 
	{ 
	        #Correct the initial state of the form to prevent the .Net maximized form issue 
	$SelectForm.WindowState = $InitialFormWindowState 
	} 
     
	#Store Values of form function
	$Form_StoreValues_Closing = 
	{ 
	#Store the control values here
	} 
 
	$Form_Cleanup_FormClosed = 
	{ 
	        #Remove all event handlers from the controls 
	try 
	{ 
	            $ButtonCancel.remove_Click($buttonCancel_Click) 
	$ButtonSelect.remove_Click($ButtonSelect_Click)
	$SelectForm.remove_Load($SelectForm_Load) 
	$SelectForm.remove_Load($Form_StateCorrection_Load) 
	$SelectForm.remove_Closing($Form_StoreValues_Closing) 
	$SelectForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	} 
	catch [Exception] 
	{ } 
	} 
	#endregion Generated Events 
 
	#---------------------------------------------- 
	#region Form Setup Objects
	#---------------------------------------------- 
	#Suspend layouts
	$SelectForm.SuspendLayout()
	$panel4.SuspendLayout() 
	$panel3.SuspendLayout() 
	$panel2.SuspendLayout() 
	$panel1.SuspendLayout()
	 
	# 
	# SelectForm Attributes
	# 
	$SelectForm.Controls.Add($panel1)
	$SelectForm.Controls.Add($panel2) 
	$SelectForm.AutoScaleDimensions = '6, 13' 
	$SelectForm.AutoScaleMode = 'Font' 
	$SelectForm.BackColor = 'White' 
	$SelectForm.ClientSize = '373, 329'   
	$SelectForm.MaximizeBox = $False 
	$SelectForm.MinimizeBox = $False 
	$SelectForm.Name = 'SelectForm' 
	$SelectForm.ShowIcon = $False 
	$SelectForm.ShowInTaskbar = $False 
	$SelectForm.StartPosition = 'CenterScreen' 
	$SelectForm.Text = 'Select One'
	$formsizex = $SelectForm.ClientSize.Width + 100
	$formsizey =  $SelectForm.ClientSize.Height + 100
	$SelectForm.MinimumSize = "$formsizex,$formsizey"
	$selectform.MaximumSize = "$($formsizex + 600),$formsizey"
	$SelectForm.TopMost = $True 
	$SelectForm.add_Load($SelectForm_Load)
	# 
	# ButtonCancel Attributes
	# 
	$ButtonCancel.Location = '250, 50' 
	$ButtonCancel.Name = 'ButtonCancel' 
	$ButtonCancel.Size = '77, 45' 
	$ButtonCancel.TabIndex = 7 #TODO FIX TABINDEXES
	$ButtonCancel.Text = 'Cancel' 
	$ButtonCancel.UseVisualStyleBackColor = $True 
	$ButtonCancel.add_Click($buttonCancel_Click)
	$ButtonCancel.Dock = [System.Windows.Forms.DockStyle]::Right
	# 
	# ButtonSelect Attributes
	# 
	$ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	$ButtonSelect.ForeColor = 'Blue' 
	$ButtonSelect.Location = '42, 50' 
	$ButtonSelect.Name = 'ButtonSelect' 
	$ButtonSelect.Size = '91, 45' 
	$ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	$ButtonSelect.Text = 'Select' 
	$ButtonSelect.UseVisualStyleBackColor = $True 
	$ButtonSelect.add_Click($ButtonSelect_Click)
	$ButtonSelect.MaximumSize.Height = '60' 
	$ButtonSelect.Dock = [System.Windows.Forms.DockStyle]::Left
	# 
	# Panel1 Attributes
	#  
	$panel1.Controls.Add($dg_Selections)
	$panel1.Location = '0, 0' 
	$panel1.Name = 'panel1' 
	$panel1.Size = '375, 310' 
	$panel1.TabIndex = 8 #TODO FIX TABINDEXES
	$panel1.BackColor = 'LightGray'
	$panel1.Dock = [System.Windows.Forms.DockStyle]::Top
	# 
	# Panel3 Attributes
	# 
	$panel3.Controls.Add($ButtonSelect)  
	$panel3.Location = '188, 310' 
	$panel3.Name = 'panel2' 
	$panel3.Size = '188, 80' 
	$panel3.TabIndex = 8 #TODO FIX TABINDEXES
	$panel3.Padding = '100,20,0,20' 
	$panel3.BackColor = 'LightSkyBlue'
	$panel3.Dock = [System.Windows.Forms.DockStyle]::Left
	# 
	# Panel4 Attributes
	# 
	$panel4.Controls.Add($ButtonCancel)    
	#$panel2.Controls.Add($dg_Selections) 
	#$panel1.BackColor = '0, 114, 198' 
	$panel4.Location = '0, 310' 
	$panel4.Name = 'panel2' 
	$panel4.Size = '188, 80' 
	$panel4.TabIndex = 8 #TODO FIX TABINDEXES
	$panel4.Padding = '0,20,100,20' 
	$panel4.BackColor = 'LightSkyBlue'
	$panel4.Dock = [System.Windows.Forms.DockStyle]::Right
	# 
	# Panel2 Attributes
	# 
	$panel2.Controls.Add($panel3)  
	$panel2.Controls.Add($panel4)  
	$panel2.Location = '0, 310' 
	$panel2.Name = 'panel2' 
	    $panel2.Size = '376, 80' 
	    $panel2.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel2.BackColor = 'LightSkyBlue'
	    $panel2.Dock = [System.Windows.Forms.DockStyle]::Bottom
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.Size = '375, 300'
	$dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	$dg_Selections.Name = "dg_Selections"
	$dg_Selections.DataMember = ""
	#$dg_Selections.TabIndex = 0 #TODO FIX TABINDEXES
	$dg_Selections.Location = '0,0'
	$dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	$dg_Selections.AutoSizeRowsMode = "AllCells"
	$dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	$dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	$dg_Selections.DefaultCellStyle.WrapMode = 'True'
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	$dg_Selections.Margin = New-Object System.Windows.Forms.Padding(3, 3, 3, 3)
	$dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
	$dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	$dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	$dg_Selections.RowHeadersVisible = $false
	$dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	#Resume Layouts
	$panel1.ResumeLayout() 
	$panel2.ResumeLayout()
	$panel3.ResumeLayout() 
	$panel4.ResumeLayout()  
	$SelectForm.ResumeLayout()
	 
	#endregion Form Setup Objects
	#---------------------------------------------- 
	
	#Save the initial state of the form 
	$InitialFormWindowState = $SelectForm.WindowState 
	#Init the OnLoad event to correct the initial state of the form 
	$SelectForm.add_Load($Form_StateCorrection_Load) 
	#Clean up the control events 
	$SelectForm.add_FormClosed($Form_Cleanup_FormClosed) 
	#Store the control values when form is closing 
	$SelectForm.add_Closing({
	#Add Closing code here
	}) 
	#Show the Form 
	return $SelectForm.ShowDialog()

	#endregion Source: MainForm.psf 
	$self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	}
	
	#Start the application 
	SelectForm ($lstSelections)
return $Script:SelectionForm_RowIndex
}


Function Get-PC-By_PCName($PC)
{
    $Filter_pc = $null
	if($PC -ne "" -and $PC -ne $null)
	{
	if (((Check-If-IP -computername $PC).output) -eq $false)
	{
	$Filter_pc = ((Filter-PC -computername $PC).output)
	$computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$Filter_pc'")
	if($computer -ne $null)
	{
	$lstPCs = @() 
	foreach ($entry in $computer)
	{
	$properties = @{'Selection'= $($computer.Indexof($entry));
	'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
	$object = New-Object –TypeName PSObject –Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	}
	if($($computer.Count) -gt 1)
	{
        $Script:SelectForm_RowIndex = $null
	    Show-SelectionForm($lstPCs)
	if ($Script:SelectForm_RowIndex -or $Script:SelectForm_RowIndex -eq 0)
	{
	    #Computer returned from selection
	    $computer = $lstPCs[$Script:SelectForm_RowIndex]
	    $Script:SelectForm_RowIndex = $null
	    return $computer
	}
	else
	{
	#No Computer returned from selection
	    return $null
	}
	  
	<#	
	# OLD CONSOLE OUTPUT

	$lstPcs| Format-Table -Autosize `
	@{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	@{Name="Computer Name";Expression = { $_.Name }; Alignment="left" },
	@{Name="AD Description";Expression = { $_.Description }; Alignment="left" }|out-host
	$select = read-host "`n Enter a Selection"
	$computer = ($lstPCs|Where-Object -Property Selection -eq -Value $select |Select-Object *)
	return $computer
	#>
	}
	elseif ($($computer.Count) -eq 1)
	{
	$computer = $lstPCs[0]
	return $computer
	}
	}
	else
	{   
	#No Computer returned from AD
	return $null
	}
	}
	else
	{
    Setup-IP-Invoke($PC)
	#RETURN IP
	#	IP can get buggy
	$lstPCs = @() 
	#foreach ($entry in $PC)
	#{
	    $properties = @{'Selection'= 0;
	    'Name'= $PC;
        'Description'= "No Description for IP Address"}
	$object = New-Object –TypeName PSObject –Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	#}
	$computer = $lstPCs
	return $computer
	}
	}
	else
	{
	#Input was null or empty
	return $null
	}
}


function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $NonAdmin_User1 = $NonAdmin_User.trim()
            $NonAdmin_User1 = "AFII\$($NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
        if($Script:CredentialsLoaded -eq $false)
        {
            $Script:Credentials = $null
            $Script:Credentials = Get-Credential -Credential $env:USERDOMAIN/$Env:USERNAME
            if(!($Script:Credentials))
            {
                write-host -ForegroundColor red "Admin Credentials are required to run script and none were stored or Entered!"
                read-host "Press enter to exit"
                exit
            }
        }
    }
}


cls



Set-QuickEdit -DisableQuickEdit
Add-PSSnapin VMware.VimAutomation.Core
Import-Module -Name VMware.PowerCLI -ErrorAction SilentlyContinue

$ServersPath = (get-item $PSScriptroot).Parent.FullName
$vSphereServerPath = "$ServersPath\ServerFiles\vSphereServerAddress.txt"
$CitrixServerPath = "$ServersPath\ServerFiles\CitrixServerAddress.txt"
if(test-path $vSphereServerPath)
{
$vSphereServer = Get-Content -Path $vSphereServerPath
}
else
{
write-host -ForegroundColor Yellow "vSphere Server file not found, defaulting to hardcoded"
#default to hardcode
$vSphereServer = 'grbaahvlpxdvc02.i.ameriprise.com'
}

$scriptPath = "$($PSScriptRoot)"
#$LoginRoot = (get-item $scriptPath).FullName
$LoginRoot = (get-item $scriptPath).Parent.Parent.FullName

#####################################################################
#$host.ui.RawUI.WindowTitle = "$ProgramName Install"

#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
Set-Location "C:\"
write-host $e
$scriptPath = "$($PSScriptRoot)"
$Root = (get-item $scriptPath).Parent.Parent.FullName
$continue = $true
if ($computer)
{
$AdapterComputer = $computer
}
 $LogDir = "$Root\Logs\VDIs\Expand VDI HDD"
    $computer = $null
    $computer1 = $null
    $vdigone = $false
    if (!($AdapterComputer))
    {
        $VDIEntry = $true
        while($VDIEntry)
        {
            $computer1 = read-host "Enter full VDI name to Expand HDD"
            if($computer1 -like "WIVGP*")
            {
                $VDIEntry = $false
            }
            else
            {
                cls
                write-host -ForegroundColor Yellow "VDI Name is Incorrect`n"
            }
        }
    }
    else
    {
        $computer1 = $AdapterComputer
        $AdapterComputer = $null
    }

$computer = $computer1.trim()
$computer = $computer.ToUpper()

if(!(test-path "$LogDir\$computer.txt"))
{
Write-Output "---------------------- Started $((Get-Date).ToString()) -------------------------" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii
}
else
{
Write-Output "---------------------- Started $((Get-Date).ToString()) -------------------------" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
}



#***************************************************************************************
#---------------------------------OPTIONAL CHANGES START-------------------------------
#***************************************************************************************

# This is H:\ Drive path DO NOT NEED TO CHANGE UNLESS YOUR H:\ can't be accessed by your nonadmin account
#$RootInstallLocation = "$($HDrivePath)"

#**************************************************************
#-------Import-----------
import-module ActiveDirectory
#-------Import-----------


#name of text file that will have the list of pcs to update Located in the t470BatchUpdater folder on the desktop (each one is a new line and can accept serial number or full name)
$PCList = "pc_list.txt"
$CompletedList = "CompletedList.txt"

    #---------------------DEFAULT-------------
    #$txtFileCompletedPCs = "pc_list.txt"
    #---------------------DEFAULT-------------



#Name of the folder on your desktop  where you want individual PC logs to be stored (C:\USERS\YOUR NONADMIN ACCOUNT\DESKTOP\THIS VALUE)
$PCLogsFolderName = "CompletedLogs"


    #---------------------DEFAULT-------------
    #$PCLogsFolderName = "Completed470Logs"
    #---------------------DEFAULT-------------

#***************************************************************************************
#---------------------------------OPTIONAL CHANGES END-------------------------------
#***************************************************************************************
if (!(test-Path "$($LogDir)"))
{
$fso = new-object -ComObject scripting.filesystemobject
$fso.CreateFolder("$($LogDir)")
}

if (!(test-Path "$($LogDir)\$($PCLogsFolderName)"))
{
$fso = new-object -ComObject scripting.filesystemobject
$fso.CreateFolder("$($LogDir)\$($PCLogsFolderName)")
}

if (!(test-Path "$($LogDir)\$($PCLogsFolderName)\Temp"))
{
$fso = new-object -ComObject scripting.filesystemobject
$fso.CreateFolder("$($LogDir)\$($PCLogsFolderName)\Temp")
}

if (!(test-Path "$($LogDir)\$CompletedList"))
{
write-output "" | out-file "$($LogDir)\$CompletedList" -Encoding ascii
}

if (test-Path "$($PSScriptRoot)\$($PCList)")
{
write-host "Found PC list text file"
}
else
{
write-host "PC list text file not found"
write-host "make sure this file is located in the in the same folder this script was run from"
}


#***************************************************************
#-------------------------Directories---------------------------
#**************************************************************
$PCList = "$($PSScriptRoot)\$($PCList)"
$out_PCList = $PCList
$Dir = "$($PSScriptRoot)\savedPSFiles"
$out_PCLogsFolderPath = "$($LogDir)\$($PCLogsFolderName)"

#***************************************************************
#-------------------------Directories---------------------------
#**************************************************************


Check-Credentials


    if(!($computer))
    {
        if($Computer -like "WIVGP*")
                {
                write-host -ForegroundColor red "$computer is not a VDI!"
                read-host "Press enter to exit"
                exit
                }
        write-host "Using PC list..."
        $computers = Get-Content $PCList
        if($Computers)
        {
            if(!($computers.Trim()))
            {
                $computers = $null
                write-host -ForegroundColor Red "`nNo Computers found in PC List located at: " -NoNewline
                write-host (Get-Item("$PCList")).fullname
                Read-Host "`nPress Enter to exit"
                exit
            }
        }
        else
        {
            $computers = $null
            write-host -ForegroundColor Red "`nNo Computers found in PC List located at: " -NoNewline
            write-host (Get-Item("$PCList")).fullname
            Read-Host "`nPress Enter to exit"
            exit
        }
    }
    else
    {
    $computers = Get-Content $PCList
        if($Computers)
        {
            if(!($computers.Trim()))
            {
                write-host "Not using PC List..."
                write-host -ForegroundColor Cyan "Running for " -NoNewline
                
                write-host "$computer" -NoNewline
                write-host -ForegroundColor Cyan " only`n"
                write-output $computer | out-file $PCList -Encoding ascii
            }
            else
            {
             write-host "Using PC list..."
            }
        }
        else
        {
            write-host "Not using PC List..."
            write-host -ForegroundColor Cyan "Running for " -NoNewline
            write-host "$computer" -NoNewline
            write-host -ForegroundColor Cyan " only`n"
            write-output $computer | out-file $PCList -Encoding ascii
        }
    }


(gc $PCList) | ? {$_.trim() -ne "" } | set-content $PCList
write-output "" | Out-File -FilePath "$($PCList)" -Encoding ascii -Append 
$computers = gc $PCList
write-host -ForegroundColor Cyan "Running for the following Computers:"
write-host -ForegroundColor Cyan "------------------------------------"
write-host $computers
write-host -ForegroundColor Cyan "------------------------------------`n"
write-host -ForegroundColor Yellow "This script expand hard drive in Vsphere, then expand hard drive by invoking disk management on the computer"
    write-host -ForegroundColor Yellow "`nScript assumes you have:"
    write-host -ForegroundColor Yellow "------------------------------"
    write-host -ForegroundColor Yellow "- There is enough free space on the computer to create your remote profile on it (will give errors if not enough space)"
    write-host -ForegroundColor Yellow "------------------------------"
    $continuescriptcaution = read-host "`n Do you want to continue with running this script? (y/n)"
    if ($continuescriptcaution -like "y")
    {

    }
    else
    {
        read-host "`n Press enter to exit"
        exit
    }
#*************************************************
#---------------For Each PC in List Start----------
#*************************************************
$readdList = @()
$pccount = 0

foreach ($line in $computers){
Get-Content $PCList | where { $_ -ne "$($line)" } | out-file $PCList
$line = $line.Trim()

 #---------variable adapter--------
 $PC = $line
 #---------variable adapter--------

$script:IPaddress = $false
$computer = (Get-PC-By_PCName($PC)).name
#****************************************************
#------ Filter and Modify Adapter END---------------
#****************************************************

if($PC -eq "")
{
continue
}
$PCLogs = "$($out_PCLogsFolderPath)\Temp\$($PC).txt"
if (test-path $($PCLogs))
{
Clear-Content $($PCLogs)
}
#****************************************************
#-------------------Obtain AD Record START-----------
#****************************************************

if($scipt:IPaddress -eq $false)
{
    if($computer)
    {
    if($($computer).count -gt 1)
    {
        write-Host "$($PC) Brought back too many matches in AD"
        write-Host "readding $($PC) back to list and moving to next pc"
        write-output "$($PC) Brought back too many matches in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
        $readdList += $($PC)
        Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
        Write-output "$($PC) Failed due to too many results returned from AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append

        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-host "################################################################"
        write-host "#---------------------------- END -----------------------------#"
        write-host "################################################################" 

        $path = $PCLogs
        $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
        if (test-path $PCLogs)
        {
            (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
        }
        else
        {
            (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        }
        Remove-Item $path -force -recurse
        continue
    }
    $computer = $computer.Name
    }
    else
    {
    write-host -ForegroundColor red "No PC Found!"
    read-host "Press enter to exit"
    continue
    }
}
else
{
    if($PC)
    {
        $computer = $pc
        Setup-IP-Invoke($computer)
    }
}


if ($computer) {
if (test-connection $computer -Quiet)
{
    #Connection is good
}
else
{
    write-output "Read from file: $($PC)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "Read from Active Directory: $($computer)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "$($computer) unreachable currently" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-host "adding $($PC) back to PC text file" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
    $readdList += $($PC)
    Write-output "$($PC) Failed due to unreachable $((Get-Date).ToString())"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
    write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-host "################################################################"
    write-host "#---------------------------- END -----------------------------#"
    write-host "################################################################" 
    $path = $PCLogs
    $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
    if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
Remove-Item $path -force -recurse
continue
}
write-host -ForegroundColor Cyan "Computer set to: " -NoNewline
write-host $computer
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
connect-VIServer $vSphereServer
$vm = get-vm $computer
$hdd = Get-HardDisk -VM $computer
$changeCap = $null
$cap = $hdd.CapacityGB

if ($cap -lt 60)
{
    Write-host "Hard Drive is less than 60 GB"
    write-output "Hard Drive is less than 60 GB" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    $difference = 60 -$cap
    if($difference -lt 10)
    {
        $changeCap = $cap + 10
        Write-host "Changing Capacity from $cap GB to $changeCap GB" 
        Write-output "Changing Capacity from $cap GB to $changeCap GB" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else
    {
        
        $changeCap = 60
        Write-host "Changing Capacity from $cap GB to $changeCap GB" 
        Write-output "Changing Capacity from $cap GB to $changeCap GB" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
}
elseif ($cap -gt 60 -or $cap -eq 60)
{
write-output "Hard Drive is 60 GB or more"
    if ($cap -eq 100 -or ($cap -gt 100 -and $cap -lt 110))
    {
    
    $changeCap = 110
    Write-host "Changing Capacity from $cap GB to Maximum limit $changeCap GB" 
    Write-output "Changing Capacity from $cap GB to Maximum limit $changeCap GB" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else
    {
        $changeCap = $cap + 10
        Write-host "Changing Capacity from $cap to $changeCap GB" 
        Write-output "Changing Capacity from $cap to $changeCap GB" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    
}
if ($changeCap -eq $null)
{
write-host "No capacity set to change to, setting to default 60 GB"
write-output "No capacity set to change to, setting to default 60 GB" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
$changeCap = 60
}


Get-HardDisk -VM $computer | where {$_.Name -eq "Hard disk 1"} | Set-HardDisk -CapacityGB $changeCap -Confirm:$false
Invoke-VMScript -vm $computer -ScriptText "echo rescan > c:\diskpart.txt && echo select vol c >> c:\diskpart.txt && echo extend >> c:\diskpart.txt && diskpart.exe /s c:\diskpart.txt" -ScriptType BAT |out-host

write-host "Hard Drive of $computer is now: "
write-output "Hard Drive of $computer is now: " | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Get-HardDisk -VM $computer | fl CapacityGB,Name
Get-HardDisk -VM $computer | fl CapacityGB,Name | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append



#-------------SESSION REMOVE FILES---------
###########################################


write-output "Entered PC: $PC" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "Found PC: $computer" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append  


#**********************************************
#------------------ Xfer --------------------
#Write-output "$($computer) completed $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
Write-output "Extending VDI hard drive Complete $((Get-Date).ToString())`n"
Write-output "Extending VDI hard drive Complete $((Get-Date).ToString())`n"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END -----------------------------#"
write-host "################################################################" 
$path = $PCLogs
if (test-path "$($out_PCLogsFolderPath)\$($computer).txt")
{

}
else
{
Write-Output "" | Out-File -FilePath "$($out_PCLogsFolderPath)\$($computer).txt" -Encoding ascii -Append
}
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
Remove-Item $path -force -recurse
}
else 
{ 
    $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
    write-Host "$($PC) is not found in AD"
    write-output "$($PC) is not found in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
    Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
    $readdList += $($PC)
    Write-output "$($PC) Failed due to not found in AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
    write-host "adding $($PC) back to PC text file" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    write-host "################################################################"
    write-host "#---------------------------- END -----------------------------#"
    write-host "################################################################" 
    $path = $PCLogs
    $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
    if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
Remove-Item $path -force -recurse
continue
}


}
#*************************************************
#---------------For Each PC in List End----------
#*************************************************



foreach ($failedpc in $readdList)
{
Write-output "$($failedpc)"| Out-File -FilePath $PCList -Encoding ascii -Append
}

Teardown-IP-Invoke

$computer2 = Read-Host -Prompt "press enter to exit"
Disconnect-VIServer -Server $vSphereServer -Force -Confirm:$false
exit
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}
