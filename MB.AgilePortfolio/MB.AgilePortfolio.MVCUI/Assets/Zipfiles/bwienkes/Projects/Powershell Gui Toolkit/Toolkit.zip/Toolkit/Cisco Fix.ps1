﻿param
(
[Parameter(Mandatory=$false)] $computer
)
if(!($computer)){$Param_ErrorMsg = "No value entered for: computer"}
elseif(!($computer -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: computer"}
elseif(!($computer.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: computer"}
if(!($Param_ErrorMsg))
	{
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        #Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

function Filter-PC($PC1){
$PC1 = $PC1.trim()
$PC = $PC1
#****************************************************
$script:IPaddress = $false
If ($PC -like "WILG000*")
{
#WI laptop Dell
$PC = $PC -replace "WILG000"
}
elseif ($PC -like "WILG00*")
{
#WI laptop Lenovo
$PC = $PC -replace "WILG00"
}
elseif ($PC -like "WIDG000*")
{
#WI Desktop Dell
$PC = $PC -replace "WIDG000"
}
elseif ($PC -like "WIDG00*")
{
#WI Desktop Lenovo?
$PC = $PC -replace "WIDG00"
}
elseif ($PC -like "AZLG000*")
{
#AZ laptop dell
$PC = $PC -replace "AZLG000"
}
elseif ($PC -like "AZLG00*")
{
#AZ laptop lenovo
$PC = $PC -replace "AZLG00"
}
elseif ($PC -like "AZDG000*")
{
#AZ Desktop dell
$PC = $PC -replace "AZDG000"
}
elseif ($PC -like "AZDG00*")
{
#AZ Desktop lenovo?
$PC = $PC -replace "AZDG00"
}
elseif ($PC -like "NVLG000*")
{
#LV laptop dell
$PC = $PC -replace "NVLG000"
}
elseif ($PC -like "NVLG00*")
{
#LV laptop lenovo
$PC = $PC -replace "NVLG00"
}
elseif ($PC -like "NVDG000*")
{
#LV Desktop dell
$PC = $PC -replace "NVDG000"
}
elseif ($PC -like "NVDG00*")
{
#LV Desktop lenovo?
$PC = $PC -replace "NVDG00"
}
elseif ($PC -like "WIVGP*")
{
#VDI's To be added
}
elseif($PC -like "*.*.*.*")
{
    $script:IPaddress = $true
}
return $PC
}

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $NonAdmin_User = $NonAdmin_User.trim()
            $NonAdmin_User1 = "AFII\$($NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
        if($Script:CredentialsLoaded -eq $false)
        {
            $Script:Credentials = $null
            $Script:Credentials = Get-Credential -Credential $env:USERDOMAIN/$Env:USERNAME
            if(!($Script:Credentials))
            {
                write-host -ForegroundColor red "Admin Credentials are required to run script and none were stored or Entered!"
                read-host "Press enter to exit"
                exit
            }
        }
    }
}

function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}

function Teardown-IP-Invoke
{
		#Post Reset Trustedhosts back
		if ($Script:TrustedHosts)
		{
			Set-Item WSMan:\localhost\Client\TrustedHosts -Value $Script:TrustedHosts -Force
		}
}

cls
if(!($computer))
{
    ################################################################
    Set-QuickEdit
    $computer = Read-Host -Prompt " Enter one of the following:`n`n - PC Serial Number`n - Full PC Name`n - IP address (IP address may show errors)`n`n Input"
    ################################################################
    }
    	Set-QuickEdit -DisableQuickEdit

$pc = Filter-PC($computer)
if ($pc -ne "" -and $pc -ne $null)
{
    if ($script:IPaddress -eq $false)
    {
        $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$PC'")
        if($($computer.Count) -gt 1)
        {
        cls
            Write-Host -ForegroundColor Yellow "`n Multiple PCs Found`n"
            foreach ($entry in $computer)
            {
                write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
            }
            write-host " none = None of these"
            Set-QuickEdit
            $inputToFilter = Read-host -prompt "`n Enter Number of selection that should be used for $($PC)"
            Set-QuickEdit -DisableQuickEdit
            if ($inputToFilter -like "none")
            {
                Write-Host -ForegroundColor Yellow " $($PC) had to many results return and none were choosen"
                Set-QuickEdit
                        write-host "`n Press Enter to exit"
                        exit 
            }    
            else
            {
                try
                {
                    $selection = [int]$inputToFilter
                    $computer = $computer[$selection]
                    if ($computer.Name -eq $null)
                    {
                        Write-Host -ForegroundColor red " $($PC) not found in AD selection (null computer name)"
                        Set-QuickEdit
                        write-host "`n Press Enter to exit"
                        exit 
                    }
                    else
                    {
                    $description = $computer.description
                    $computer = $computer.Name
                        
                    }
                }
                catch
                {
                    write-warning $_
                }
            }
        }
        elseif ($computer.Count -lt 1)
        {
            Write-Host -ForegroundColor Red " $($PC) not found in AD (no matches found)"

                Set-QuickEdit
                        write-host "`n Press Enter to exit"
                        exit 
        }
        elseif ($computer.Count -eq 1)
        {
            if ($computer.Name -eq $null)
            {
                Write-Host -ForegroundColor Red " $($PC) not found in AD (null computer name)"
                Set-QuickEdit
                        write-host "`n Press Enter to exit"
                        exit 
            }
            else
            {
                $description = $computer.description
                $computer = $computer.Name
            }
        }
    }
    else
    {
        $computer = $pc
        
        $IP_ComputerName = $null
        If ((Test-Connection -ComputerName $computer -count 1 -Quiet) -eq 'True')
        {
            $HN1 = wmic /node: $computer computersystem get name
            $IP_ComputerName = $HN1[2].tostring()
            #write-host $HN.name
        }
        if ($IP_ComputerName -ne $null -and $IP_ComputerName -ne "")
        {
            #$computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$HN'")
            #$description = $computer.description
        }
    }


    if (Test-Connection $computer -Quiet -count 1)
    {
        cls
        if ($script:IPaddress -eq $false)
        {
            write-host "Contacting $computer..."
            Invoke-Command -Computer $computer -ScriptBlock {
                $failed = $false
                New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
                Get-ItemProperty "HKCR:\Installer\Products\*" | Where {$_.ProductName -Like "Cisco Anyconnect*"} | Select-Object @{Name="PID"; Expression={$_.PSChildName}}, @{Name="ProductName";Expression={"$($_.ProductName)"}}|%{$CiscoID = $_.PID}
                if ($CiscoID)
                {
                    write-host "Found Cisco registry key: HKCR:\Installer\Products\$CiscoID"
                    Write-host "Attempting to remove HKCR:\Installer\Products\$CiscoID..."
                    Remove-Item -Path "HKCR:\Installer\Products\$CiscoID" -Recurse -ErrorVariable ev
                    if($ev)
                    {
                        $strE = $ev[0].ToString()|out-string
                        write-host -ForegroundColor Red "Error deleting Registry key for Cisco Anyconnect:"
                        write-host "$strE"
                        $failed = $true
                        $ev = $null
                    }
                    else
                    {
                        write-host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                        write-host " removed Cisco AnyConnect from HKCR registry"
                    }
                }
                else
                {
                    write-host "Could not find Cisco AnyConnect registry entry in HKCR:\Installer\Products"
                }
                Get-ItemProperty "HKLM:\SOFTWARE\Classes\Installer\Products\*" | Where {$_.ProductName -Like "Cisco Anyconnect*"} | Select-Object @{Name="PID"; Expression={$_.PSChildName}}, @{Name="ProductName";Expression={"$($_.ProductName)"}}|%{$CiscoID2 = $_.PID}
                if ($CiscoID2)
                {
                    write-host "Found Cisco registry key: HKLM:\SOFTWARE\Classes\Installer\Products\$CiscoID2"
                    Write-host "Attempting to remove HKLM:\SOFTWARE\Classes\Installer\Products\$CiscoID2..."
                    Remove-Item -Path "HKLM:\SOFTWARE\Classes\Installer\Products\$CiscoID2" -Recurse -ErrorVariable ev
                    if($ev)
                    {
                        $strE = $ev[0].ToString()|out-string
                        write-host -ForegroundColor Red "Error deleting Registry key for Cisco Anyconnect:"
                        write-host "$strE"
                        $failed = $true
                        $ev = $null
                    }
                    else
                    {
                        write-host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                        write-host " removed Cisco AnyConnect from HKLM registry"
                    }
                }
                else
                {
                    write-host "Could not find Cisco AnyConnect registry entry in HKLM:\SOFTWARE\Classes\Installer\Products"
                }
            }
        }
        else
        {
            Setup-IP-Invoke($computer)
            write-host "Contacting IP address... $computer"
            write-host "IP Address relayed computername: $IP_ComputerName"
            Check-Credentials
            if(!($script:Credentials))
            {
            $script:Credentials = "$env:USERDOMAIN\$env:USERNAME"
            }
            Invoke-Command -ComputerName $computer -Credential $script:Credentials -ScriptBlock {
                $failed = $false
                New-PSDrive -Name HKCR -PSProvider Registry -Root HKEY_CLASSES_ROOT
                Get-ItemProperty "HKCR:\Installer\Products\*" | Where {$_.ProductName -Like "Cisco Anyconnect*"} | Select-Object @{Name="PID"; Expression={$_.PSChildName}}, @{Name="ProductName";Expression={"$($_.ProductName)"}}|%{$CiscoID = $_.PID}
                if ($CiscoID)
                {
                    write-host "Found Cisco registry key: HKCR:\Installer\Products\$CiscoID"
                    Write-host "Attempting to remove HKCR:\Installer\Products\$CiscoID..."
                    Remove-Item -Path "HKCR:\Installer\Products\$CiscoID" -Recurse -ErrorVariable ev
                    if($ev)
                    {
                        $strE = $ev[0].ToString()|out-string
                        write-host -ForegroundColor Red "Error deleting Registry key for Cisco Anyconnect:"
                        write-host "$strE"
                        $failed = $true
                        $ev = $null
                    }
                    else
                    {
                        write-host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                        write-host " removed Cisco AnyConnect from HKCR registry"
                    }
                }
                else
                {
                    write-host "Could not find Cisco AnyConnect registry entry in HKCR:\Installer\Products"
                }
                Get-ItemProperty "HKLM:\SOFTWARE\Classes\Installer\Products\*" | Where {$_.ProductName -Like "Cisco Anyconnect*"} | Select-Object @{Name="PID"; Expression={$_.PSChildName}}, @{Name="ProductName";Expression={"$($_.ProductName)"}}|%{$CiscoID2 = $_.PID}
                if ($CiscoID2)
                {
                    write-host "Found Cisco registry key: HKLM:\SOFTWARE\Classes\Installer\Products\$CiscoID2"
                    Write-host "Attempting to remove HKLM:\SOFTWARE\Classes\Installer\Products\$CiscoID2..."
                    Remove-Item -Path "HKLM:\SOFTWARE\Classes\Installer\Products\$CiscoID2" -Recurse -ErrorVariable ev
                    if($ev)
                    {
                        $strE = $ev[0].ToString()|out-string
                        write-host -ForegroundColor Red "Error deleting Registry key for Cisco Anyconnect:"
                        write-host "$strE"
                        $failed = $true
                        $ev = $null
                    }
                    else
                    {
                        write-host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                        write-host " removed Cisco AnyConnect from HKLM registry"
                    }
                }
                else
                {
                    write-host "Could not find Cisco AnyConnect registry entry in HKLM:\SOFTWARE\Classes\Installer\Products"
                }
            }

            Teardown-IP-Invoke
        }
        write-host "Cisco AnyConnect should be able to install now"
    }
    else
    {
        write-host -ForegroundColor Red "FAILED "
        write-host "to contact $computer"
    }
    read-host "Press Enter to exit"
    exit
    }
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}
}
else
{
write-host "Cisco Fix: $Param_ErrorMsg"
Read-Host "`nPress Enter to exit"
exit
}
