﻿    param
    (
    [string]$Computername,
    [string]$Userfullname
    )
    


    Function Format-AD-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$Param_ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	#$Name = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","*")
	}
	else
	{
	Write-Debug "Could not format null valued name"
	}	
	}
	else
	{
	Write-Debug "[FAILURE] Format-AD-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-AD-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


Function Show-SelectionForm($lstSelections)
{
	    #---------------------------------------------- 
	    #region Import Assemblies 
	    #---------------------------------------------- 
	    [void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
    	[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	    #endregion Import Assemblies  
 
	    function SelectForm($input1) 
	    { 
    	    $Script:SelectionForm_RowIndex = $null
	        <# 
        	    .SYNOPSIS 
    	    The Main function starts the project application. 
        	     
	            .PARAMETER Input1
	        $Input1 contains the complete argument string passed to the script packager executable. 
        	     
	            .NOTES 
	        Use this function to initialize your script and to call GUI forms. 
        	         
	            .NOTES 
	        To get the console output in the Packager (Forms Engine) use:  
	        $ConsoleOutput (Type: System.Collections.ArrayList) 
	        #> 
	     
    	    #-------------------------------------------------------------------------- 
            $SLFResult = (Call-SelectForm_psf($input1))
            return $SLFResult
            <#
	        if((Call-SelectForm_psf($input1)) -eq 'OK') 
    	    { 
	            # ADD VALIDATION IF NEEDED
	        } 
    	    $global:ExitCode = 0 #Set the exit code for the Packager
            #> 
    	} 
 
	    #endregion Source: Startup.pss 
     
    	#region Source: MainForm.psf 
    	function Call-SelectForm_psf($input1) 
    	{ 
        	#Datagrid click Function
    	    Function dg_Selections_GridClick
        	{
	                #Set $Script:SelectionForm_RowIndex to index of the currently selected row
	                $Script:SelectionForm_RowIndex = ($dg_Selections.CurrentRow.Index + 1)

	        }
    
        	#Add Data to Datagrid function
	        function Get-ProcessInfo($input1) 
	        {
	            $array = New-Object System.Collections.ArrayList
	            $array.AddRange($input1)
	            $dg_Selections.DataSource = $array
                #$dg_Selections.Columns |ForEach-Object{$_.AutoSizeMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::AllCells}
                $dg_Selections.Refresh()
                $panel1.size = $dg_Selections.Size
                $panel1.Refresh()
                $splitcontainer1.size.width = $panel1.size.Width
                $splitcontainer1.refresh()
                $splitcontainer2.size.width = $panel1.size.Width
                $splitcontainer2.refresh()
                $splitcontainer2.SplitterDistance = ($splitcontainer2.size.width / 2)
                $Selectform.clientsize.width = $panel1.Size.Width
	            $selectform.refresh()

	            $dg_Selections.ClearSelection()
	        }
 
	        #---------------------------------------------- 
	        #region Import the Assemblies 
	        #---------------------------------------------- 
	        [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	        [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	        [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	        #endregion Import Assemblies 
	 
	        #---------------------------------------------- 
	        #region Generated Form Objects 
	        #---------------------------------------------- 
	        [System.Windows.Forms.Application]::EnableVisualStyles() 
	        $SelectForm = New-Object 'System.Windows.Forms.Form'
	        $ButtonCancel = New-Object 'System.Windows.Forms.Button' 
	        $ButtonSelect = New-Object 'System.Windows.Forms.Button' 
	        $panel1 = New-Object 'System.Windows.Forms.Panel'
	        $panel2 = New-Object 'System.Windows.Forms.Panel'
            $splitcontainer1 = New-Object 'System.windows.forms.splitcontainer'
            $splitcontainer2 = New-Object 'System.windows.forms.splitcontainer'
	        $panel3 = New-Object 'System.Windows.Forms.Panel'
	        $panel4 = New-Object 'System.Windows.Forms.Panel'
	        $dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
	        $InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
	        #endregion Generated Form Objects 
 
	        #---------------------------------------------- 
	        # Form Object Functions
	        #---------------------------------------------- 
        
	        #Form Load function
	        $SelectForm_Load =
	        { 
	            get-processinfo($input1)         
	        }
	
	        #Select Button clicked function
	        $ButtonSelect_Click = 
	        {     
	            #Checks for input selected before allowing form close from select button click
	            if ($Script:SelectionForm_RowIndex)
	            {
	                $SelectForm.Close()
	            }
	        } 

	        #Cancel Button clicked function
	        $ButtonCancel_Click =
	        {
                $Script:SelectionForm_RowIndex = $null
                #TODO: Place custom script here on canceling form
	            $SelectForm.Close() 
	        } 
     
            # --End Form Object Functions-- 
	        #---------------------------------------------- 
	        #region Generated Events 
	        #---------------------------------------------- 
	
	        #Fix Form Load function
	        $Form_StateCorrection_Load = 
	        { 
    	        #Correct the initial state of the form to prevent the .Net maximized form issue 
            	$SelectForm.WindowState = $InitialFormWindowState 
	        } 
     
	        #Store Values of form function
	        $Form_StoreValues_Closing = 
	        { 
	            #Store the control values here
	        } 
 
	        $Form_Cleanup_FormClosed = 
	        { 
    	        #Remove all event handlers from the controls 
        	    try 
	            { 
    	            $ButtonCancel.remove_Click($buttonCancel_Click) 
	                $ButtonSelect.remove_Click($ButtonSelect_Click)
	                $SelectForm.remove_Load($SelectForm_Load) 
	                $SelectForm.remove_Load($Form_StateCorrection_Load) 
	                $SelectForm.remove_Closing($Form_StoreValues_Closing) 
	                $SelectForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	            } 
	            catch [Exception] 
	            { } 
	        } 
	        #endregion Generated Events 
 
	        #---------------------------------------------- 
	        #region Form Setup Objects
	        #---------------------------------------------- 
	        #Suspend layouts
	        $SelectForm.SuspendLayout()
	        $panel4.SuspendLayout() 
	        $panel3.SuspendLayout() 
	        $panel2.SuspendLayout() 
	        $panel1.SuspendLayout()
            $splitcontainer1.SuspendLayout()
            $splitcontainer2.SuspendLayout()
	 
	        # 
	        # SelectForm Attributes
	        # 
	        $SelectForm.Controls.Add($splitcontainer1)
	        #$SelectForm.Controls.Add($panel2) 
	        $SelectForm.AutoScaleDimensions = '6, 13' 
	        $SelectForm.AutoScaleMode = 'Font' 
            $SelectForm.AutoSize = $true
            $SelectForm.AutoSizeMode = 'GrowOnly'
	        $SelectForm.BackColor = 'White' 
	        #$SelectForm.ClientSize = '473, 329'   
	        $SelectForm.MaximizeBox = $False 
	        $SelectForm.MinimizeBox = $False 
	        $SelectForm.Name = 'SelectForm' 
	        $SelectForm.ShowIcon = $False 
	        $SelectForm.ShowInTaskbar = $False 
	        $SelectForm.StartPosition = 'CenterScreen' 
	        $SelectForm.Text = 'Select One'
	        #$formsizex = $SelectForm.ClientSize.Width + 100
	        #$formsizey =  $SelectForm.ClientSize.Height + 100
	        #$SelectForm.MinimumSize = "$formsizex,$formsizey"
	        #$selectform.MaximumSize = "$($formsizex + 600),$formsizey"
	        $SelectForm.TopMost = $True 
	        $SelectForm.add_Load($SelectForm_Load)
	        # 
	        # ButtonCancel Attributes
	        # 
	        #$ButtonCancel.Location = '250, 50' 
	        $ButtonCancel.Name = 'ButtonCancel' 
	        #$ButtonCancel.Size = '77, 45' 
	        $ButtonCancel.TabIndex = 7 #TODO FIX TABINDEXES
	        $ButtonCancel.Text = 'Cancel' 
	        $ButtonCancel.UseVisualStyleBackColor = $True 
	        $ButtonCancel.add_Click($buttonCancel_Click)
	        $ButtonCancel.Dock = [System.Windows.Forms.DockStyle]::Right
	        # 
	        # ButtonSelect Attributes
	        # 
	        $ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	        $ButtonSelect.ForeColor = 'Blue' 
	        #$ButtonSelect.Location = '42, 50' 
	        $ButtonSelect.Name = 'ButtonSelect' 
	        #$ButtonSelect.Size = '91, 45' 
	        $ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	        $ButtonSelect.Text = 'Select' 
	        $ButtonSelect.UseVisualStyleBackColor = $True 
	        $ButtonSelect.add_Click($ButtonSelect_Click)
	        $ButtonSelect.MaximumSize.Height = '60' 
	        $ButtonSelect.Dock = [System.Windows.Forms.DockStyle]::Left
	        # 
	        # Panel1 Attributes
	        #  
	        $panel1.Controls.Add($dg_Selections)
            $panel1.AutoSize = $true
            $panel1.AutoSizeMode = 'GrowAndShrink'
	        #$panel1.Location = '0, 0' 
	        $panel1.Name = 'panel1' 
	        #$panel1.Size = '375, 310' 
	        $panel1.TabIndex = 8 #TODO FIX TABINDEXES
	        $panel1.BackColor = 'LightGray'
	        $panel1.Dock = [System.Windows.Forms.DockStyle]::Fill
            #$pane1.anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	        # 
	        # Panel3 Attributes
	        # 

            #$splitcontainer1.Panel1.size = '300, 745'
            #$splitcontainer1.Location = '0, 0' 
            $splitcontainer1.AutoSize = $true
            $splitcontainer1.Name = 'splitcontainer1'
            $splitcontainer1.Orientation = [System.Windows.Forms.Orientation]::Horizontal
            $splitcontainer1.SplitterDistance = '310'
            #$splitcontainer1.Panel2.Location =  '375, 0'
            $splitcontainer1.Panel2.Controls.Add($splitcontainer2)
            $splitcontainer1.Panel1.Controls.Add($panel1)
            $splitcontainer1.Panel1.AutoSize = $true
            $splitcontainer1.Panel1.AutoSizeMode = 'GrowAndShrink'
            $splitcontainer1.Panel2.AutoSize = $true
            $splitcontainer1.Panel2.AutoSizeMode = 'GrowAndShrink'
            $splitcontainer1.Dock = [System.Windows.Forms.DockStyle]::Fill
	        $panel3.Controls.Add($ButtonSelect)  
	        #$panel3.Location = '188, 310' 
	        $panel3.Name = 'panel2' 
	        #$panel3.Size = '188, 80' 
	        $panel3.TabIndex = 8 #TODO FIX TABINDEXES
	        $panel3.Padding = '20,20,0,20' 
	        $panel3.BackColor = 'LightSkyBlue'
	        $panel3.Dock = [System.Windows.Forms.DockStyle]::Fill
	        # 
	        # Panel4 Attributes
	        # 
	        $panel4.Controls.Add($ButtonCancel)    
	        #$panel2.Controls.Add($dg_Selections) 
	        #$panel1.BackColor = '0, 114, 198' 
	        #$panel4.Location = '0, 310' 
	        $panel4.Name = 'panel2' 
	        #$panel4.Size = '188, 80' 
	        $panel4.TabIndex = 8 #TODO FIX TABINDEXES
	        $panel4.Padding = '0,20,20,20' 
	        $panel4.BackColor = 'LightSkyBlue'
	        $panel4.Dock = [System.Windows.Forms.DockStyle]::Fill
	        # 
	        # Panel2 Attributes
	        # 
	        $splitcontainer2.Panel1.Controls.Add($panel3)  
	        $splitcontainer2.Panel2.Controls.Add($panel4)
            $splitcontainer2.AutoSize = $true  
	        #$splitcontainer2.Location = '0, 310'
            $splitcontainer1.SplitterDistance = $splitcontainer2.Size.Width / 2 
	        $splitcontainer2.Name = 'splitcontainer2' 
	        #$splitcontainer2.Size = '376, 80' 
	        $splitcontainer2.TabIndex = 8 #TODO FIX TABINDEXES
	        $splitcontainer2.BackColor = 'LightSkyBlue'
	        $splitcontainer2.Dock = [System.Windows.Forms.DockStyle]::Fill
	        # 
	        # Datagrid Attributes
	        # 
	        #$dg_Selections.Size = '375, 300'
	        $dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	        $dg_Selections.Name = "dg_Selections"
	        $dg_Selections.DataMember = ""
            $dg_Selections.AutoSize = $true
	        #$dg_Selections.TabIndex = 0 #TODO FIX TABINDEXES
	        #$dg_Selections.Location = '0,0'
	        $dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	        $dg_Selections.AutoSizeRowsMode = "AllCells"
	        $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	        $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	        $dg_Selections.DefaultCellStyle.WrapMode = 'True'
	        $dg_Selections.SelectionMode = 'FullRowSelect'
	        $dg_Selections.ReadOnly = $true
	        #$dg_Selections.Margin = New-Object System.Windows.Forms.Padding(3, 3, 3, 3)
	        $dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::DisplayedCells
	        $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	        $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	        $dg_Selections.RowHeadersVisible = $false
	        $dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	        #Resume Layouts
            
	        $panel1.ResumeLayout() 
	        $panel2.ResumeLayout()
	        $panel3.ResumeLayout() 
	        $panel4.ResumeLayout()  
            $splitcontainer1.ResumeLayout()
            $splitcontainer2.ResumeLayout()
	        $SelectForm.ResumeLayout()
	 
	        #endregion Form Setup Objects
	        #---------------------------------------------- 
        	
    	    #Save the initial state of the form 
    	    $InitialFormWindowState = $SelectForm.WindowState 
    	    #Init the OnLoad event to correct the initial state of the form 
    	    $SelectForm.add_Load($Form_StateCorrection_Load) 
    	    #Clean up the control events 
    	    $SelectForm.add_FormClosed($Form_Cleanup_FormClosed) 
    	    #Store the control values when form is closing 
    	    $SelectForm.add_Closing({
            	#Add Closing code here
    	    }) 
	        #Show the Form 
	        #return $SelectForm.ShowDialog()
            $SelectFormResult = $SelectForm.ShowDialog()

            return $Script:SelectionForm_RowIndex

	        #endregion Source: MainForm.psf 
	        $self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	    }
	
	    #Start the application 
	    $Finalresult = SelectForm ($lstSelections)
        
        return $Finalresult
    } #FUNCTION END ----------------------------------

#TODO GENERAL UPDATING TO GUI
Function Format-String-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","`'`'")
	$Name = $Name.trim() 
	}
	else
	{
	Write-Debug "Could not format null valued name"
	}
	}
	else
	{
	Write-Debug "[FAILURE] Format-String-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-String-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}

    Function Filter-PC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$PC = $null
	$ErrorMsg = $null
	$Return_Object = $null
    
	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	    $Computername = $Computername.trim()
	    $PC = $Computername
	    If ($PC -like "WILG000*")
	    {
	        #WI laptop Dell
	        $PC = $PC -replace "WILG000"
	    }
	    elseif ($PC -like "WILG00*")
	    {
	        #WI laptop Lenovo
	        $PC = $PC -replace "WILG00"
	    }
	    elseif ($PC -like "WIDG000*")
	    {
	        #WI Desktop Dell
	        $PC = $PC -replace "WIDG000"
	    }
	    elseif ($PC -like "WIDG00*")
	    {
	        #WI Desktop Lenovo?
	        $PC = $PC -replace "WIDG00"
	    }
	    elseif ($PC -like "AZLG000*")
	    {
	        #AZ laptop dell
	        $PC = $PC -replace "AZLG000"
	    }
	    elseif ($PC -like "AZLG00*")
	    {
	        #AZ laptop lenovo
	        $PC = $PC -replace "AZLG00"
	    }
	    elseif ($PC -like "AZDG000*")
	    {
	        #AZ Desktop dell
	        $PC = $PC -replace "AZDG000"
	    }
	    elseif ($PC -like "AZDG00*")
	    {
	        #AZ Desktop lenovo?
	        $PC = $PC -replace "AZDG00"
	    }
	    elseif ($PC -like "NVLG000*")
	    {
	        #LV laptop dell
	        $PC = $PC -replace "NVLG000"
	    }
	    elseif ($PC -like "NVLG00*")
	    {
	        #LV laptop lenovo
	        $PC = $PC -replace "NVLG00"
	    }
	    elseif ($PC -like "NVDG000*")
	    {
	        #LV Desktop dell
	        $PC = $PC -replace "NVDG000"
	    }
	    elseif ($PC -like "NVDG00*")
	    {
	        #LV Desktop lenovo?
	        $PC = $PC -replace "NVDG00"
	    }
	    elseif ($PC -like "WIVGP*")
	    {
	        #VDI's To be added
	    }
	    elseif ($PC -like "*.*.*.*")
    	{
        	#IP ADDRESS SLIPPED THROUGH!
	    }
	    else
	    {
	        #BAD ENTRY CODE HERE
	        $ErrorMsg = "Filter-PC - Not a valid input"
	    }
	}
	else
	{
	    Write-Debug "[FAILURE] Filter-PC - Initial parameter input was null"
	    $ErrorMsg = "Filter-PC - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $PC;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


    Function Test-IsOnline
{
	[CmdletBinding()]
	param(
	[Parameter(ValueFromPipeline = $True,ValueFromPipelineByPropertyName = $True)]
	[ValidateNotNullOrEmpty()]
	[Alias('Computers', 'CN')]

	[string[]] $ComputerName,

	[int] $Threads = $env:NUMBER_OF_PROCESSORS,
	[switch] $ShowProgress = $True,
	[switch] $ShowTime = $false,
	[int] $Timeout = 120,
	[int]$RetryCount = 1,
	[int]$RetryWaitTime = 10,
	[switch] $DNSLookup
	)

	Begin
	{

	Function Get-Result
	{
	[CmdletBinding()]
	Param(
	[switch] $Wait
	)
	Do
	{
	$More = $false
	foreach ($Runspace in $Runspaces) 
	{
	$StartTime = $RunspaceTimers[$Runspace.ID]
	if ($Runspace.Handle.IsCompleted)
	{
	$Runspace.PowerShell.EndInvoke($Runspace.Handle)
	$Runspace.PowerShell.Dispose()
	$Runspace.PowerShell = $Null
	$Runspace.Handle = $Null
	}
	elseif ($Runspace.Handle -ne $Null)
	{
	$More = $True
	}
	if ($Timeout -and $StartTime)
	{
	if ((New-TimeSpan -Start $StartTime).TotalSeconds -ge $Timeout -and $Runspace.PowerShell) 
	{
	Write-Warning -Message ('Timeout {0}' -f $Runspace.IObject)
	$Runspace.PowerShell.Dispose()
	$Runspace.PowerShell = $Null
	$Runspace.Handle = $Null
	}
	}
	}

	if ($More -and $PSBoundParameters['Wait'])
	{
	Start-Sleep -Milliseconds 100
	}

	foreach ($Thread in $Runspaces.Clone())
	{
	if (-not $Thread.Handle) 
	{
	Write-Verbose -Message ('Removing [{0}] from runspaces' -f $Thread.IObject)
	$Runspaces.Remove($Thread)
	}
	}

	if ($ShowProgress)
	{
	$ProgressSplatting = @{
	Activity        = 'Checking hosts'
	Status          = 'Processing: {0} of {1} total hosts' -f ($RunspaceCounter - $Runspaces.Count), $RunspaceCounter
	PercentComplete = ($RunspaceCounter - $Runspaces.Count) / $RunspaceCounter * 100
	}
	Write-Progress @ProgressSplatting
	}
	}
	while ($More -and $PSBoundParameters['Wait'])
	}


	if($ComputerName.Count -gt 1) {
	Write-Verbose -Message "Processing [$($ComputerName.Count)] hosts"
	}

	$CachedErrorActionPreference = 'Stop'
	$ErrorActionPreference = $CachedErrorActionPreference

	#$Script:VerbosePreference = 'Continue'

	$StartTime = Get-Date

	$RunspaceTimers = [HashTable]::Synchronized(@{})
	$Output = [HashTable]::Synchronized(@{})
	$Runspaces = New-Object -TypeName System.Collections.ArrayList
	$RunspaceCounter = 0

	Write-Verbose -Message 'Creating initial session state'

	$ISS = [initialsessionstate]::CreateDefault()
	$ISS.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'RunspaceTimers', $RunspaceTimers, ''))
	$ISS.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'Output', $Output, ''))

	Write-Verbose -Message 'Creating runspace factory'

	$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $Threads, $ISS, $Host)
	$RunspacePool.ApartmentState = 'STA'
	$RunspacePool.Open()


	$PsExecScriptBlock = {
	[CmdletBinding()]
	param(
	[int] $ID,
	[string] $ComputerName,
	[int]$RetryCount,
	[int]$RetryWaitTime,
	[switch] $DNSLookup
	)

	$RunspaceTimers.$ID = Get-Date
	if (-not $Output.ContainsKey($ComputerName))
	{
	$Output[$ComputerName] = New-Object -TypeName PSObject -Property @{
	ComputerName = $ComputerName
	}
	}
	if ($DNSLookup)
	{
	Write-Verbose -Message "[${ComputerName}] Performing DNS lookup."
	$ErrorActionPreference = 'SilentlyContinue'
	$HostEntry = [Net.Dns]::GetHostEntry($ComputerName)
	$Result = $?
	$ErrorActionPreference = $CachedErrorActionPreference

	if ($Result)
	{
	if ($HostEntry.HostName.Split('.')[0] -ieq $ComputerName.Split('.')[0])
	{
	$IPDns = @($HostEntry |
	Select-Object -ExpandProperty AddressList |
	Select-Object -ExpandProperty IPAddressToString)
	}
	else
	{
	$IPDns = @(@($HostEntry.HostName) + @($HostEntry.Aliases))
	}
	$Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name 'IP' -Value $IPDns
	}
	else
	{
	$Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name 'IP' -Value $Null
	}
	}

	Write-Verbose -Message "Pinging host [${ComputerName}]"

	$Online = $false

	1..$RetryCount | ForEach-Object -Process {
	$Param = @{
	ComputerName = $ComputerName
	BufferSize   = 1
	Count        = 1
	Quiet        = $True
	}

	$Online = Test-Connection @Param
	}
	    if($Online) 
            {
                $Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name Online -Value $True
            } else 
            {
                $Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name Online -Value $false
            }
	}

	}
	process
	{
	foreach ($Computer in $ComputerName)
	{
	Write-Verbose -Message "Processing [${Computer}]"
	++$RunspaceCounter
	$psCMD = [powershell]::Create().AddScript($PsExecScriptBlock)
	[void] $psCMD.AddParameter('ID', $RunspaceCounter)
	[void] $psCMD.AddParameter('ComputerName', $Computer)
	[void] $psCMD.AddParameter('RetryCount', $RetryCount)
	[void] $psCMD.AddParameter('RetryWaitTime', $RetryWaitTime)
	[void] $psCMD.AddParameter('DNSLookup', $DNSLookup)
	[void] $psCMD.AddParameter('Verbose', $VerbosePreference)
	$psCMD.RunspacePool = $RunspacePool

	[void]$Runspaces.Add(@{
	Handle     = $psCMD.BeginInvoke()
	PowerShell = $psCMD
	IObject    = $Computer
	ID         = $RunspaceCounter
	})

	Get-Result
	}
	}

	End 
	{
	Get-Result -Wait
	if ($ShowProgress)
	{
	Write-Progress -Activity 'Checking if host is online' -Status 'Done' -Completed
	}
	Write-Verbose -Message 'Closing runspace pool.'
	$RunspacePool.Close()
	Write-Verbose -Message 'Disposing runspace pool.'
	$RunspacePool.Dispose()

	[hashtable[]] $Properties = @{
	Name       = 'ComputerName'
	Expression = {
	$_.Name
	}
	}
	if ($DNSLookup)
	{
	$Properties += @{
	Name       = 'IP'
	Expression = {
	$_.Value.'IP' 
	}
	}
	}
	$Properties += @{
	Name       = 'Online'
	Expression = {
	$_.Value.Online
	}
	}

	$Output.GetEnumerator() | Select-Object -Property $Properties | Sort-Object Online

	if ($ShowTime)
	{
	    Write-Host -ForegroundColor Green ('Start time: ' + $StartTime)
	    Write-Host -ForegroundColor Green ('End time:   ' + (Get-Date))
	}

	}
}

function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}


    Function Get-PC-By_PCName($PC)
{
    $Filter_pc = $null
	if($PC -ne "" -and $PC -ne $null)
	{
	    $Filter_pc = ((Filter-PC -computername $PC).output)
	    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$Filter_pc'")
	    if($computer -ne $null)
	    {
	        $lstPCs = @() 
	        foreach ($entry in $computer)
	        {
	            $properties = [ordered]@{'Selection'= $($computer.Indexof($entry) + 1);
	                                    'Name'=$($entry.Name);
                                        'Description'= $($entry.Description)}
	            $object = New-Object –TypeName PSObject –Prop $properties
	            $lstPCs += $object
	            #write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	        }
	        if($($computer.Count) -gt 1)
	        {
	            $result = Show-SelectionForm($lstPCs)
	            if ($result)
	            {
                    $result = $result - 1
	                #Computer returned from selection
	                $computer = $lstPCs[$result]
                    $result = $null
	                $Script:SelectForm_RowIndex = $null
	                return $computer
	            }
	            else
	            {
	                #No Computer returned from selection
	                return $null
	            }
	        }
	        elseif ($($computer.Count) -eq 1)
	        {
	            $computer = $lstPCs[0]
	            return $computer
	        }
	    }
	    else
	    {   
	        #No Computer returned from AD
            if($pc -like "*.*.*.*")
            {
                if(Test-Connection -ComputerName $pc -Count 1 -Quiet -ErrorAction SilentlyContinue)
                {
                    return $PC
                }
            }
            else
            {
    	        return $null
            }
	    }
    }
	else
	{
	    #Input was null or empty
	    return $null
	}
}


    Function FindUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	User_In = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$User_In
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------
    Write-Debug "input: $User_In"
	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($User_In)){$Param_ErrorMsg = "No value entered for: UserIn"}
	elseif(!($User_In -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($User_In.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
	# NULL variables (just in case)
	#$User_FullNameArray = @()
<#
    $Original = $null
	$ErrorMsg = $null
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
#>
    $filtering_Lastname = $false
    $SearchingBase = "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
            #$MainForm.Text = "Setting User LastName to: $User_LastName..."
	        Write-Debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            Write-Debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                write-debug " First Name: $User_FirstName"
                #$MainForm.Text = "Setting User First Name to: $($User_FirstName)..."
                $User_MiddleName = $($User_FullNameArray[1])
	            Write-Debug " Middle Name: $User_MiddleName"
                #$MainForm.Text = "Setting User Middle Name to: $($User_MiddleName)..."
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                Write-Debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
                #$MainForm.Text = "Setting User MI to: $($User_MI)..."
	            Write-Debug " Middle Initial Part 2 : $User_MI"
               # write-debug " Last Name (input index = "$($User_FullNameArray.count -1)"): $User_LastName"
                #$MainForm.Text = "Formating First Name for AD search..."
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                #$MainForm.Text = "Formating Last Name for AD search..."
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
                        #$MainForm.Text = "Comparing list of known non-name words to Last Name..."
	                    write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
                            #$MainForm.Text = "Found non-name Last Name, Setting different Last Name..."
	                        write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
                                
	                            write-debug "Index of filtered word is > 0"
                                if($User_MiddleName)
                                {
                                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 1)
                                    {
                                        #$MainForm.Text = "Reconfiguring MI..."
                                        write-debug "Index of filtered word is > 1"
                                        $User_MiddleName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_MiddleName) - 1)])
                                        $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                                        write-debug "MI set to: $User_MI"
                                        #$MainForm.Text = "Setting MI to: $User_MI..."
                                    }
                                    else
                                    {
                                        #$MainForm.Text = "Nulling Middle Name do to not found..."
                                        write-debug "Index of filtered word is NOT > 1"
                                        write-debug "MI and Middle name set to NULL"
                                        $User_MiddleName = $null
                                        $User_MI = $null
                                    }
                                }
	                            write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                #$MainForm.Text = "Setting Last Name to: $User_LastName..."
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
                                #$MainForm.Text = "Last Name wasn't found..."
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
                            #$MainForm.Text = "Filtering completed"
	                        write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                            #$MainForm.Text = "Setting Filtered Name to: $User_LastName"
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    write-debug "Name not filtered"
                        #$MainForm.Text = "Searching by First Name, Last Name, and MI..."
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            #$MainForm.Text = "Searching by First Name and Last Name..."
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                #$MainForm.Text = "Searching by Last Name and MI..."
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    #$MainForm.Text = "Searching by Last Name..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                }        
                            }
                        }
                    }
                    else
                    {
                        write-debug "Name was filtered"
                        if(!($User_LastName -eq "Last Name not Found"))
                        {
                            write-debug "Last Name was found"
                            if($User_MI)
                            {
                                write-debug "Middle Name exists"
                                #$MainForm.Text = "Searching by First Name, Last Name, and MI..."
	                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    #$MainForm.Text = "Searching by First Name and Last Name..."
                                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        #$MainForm.Text = "Searching by Last Name and MI..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                        if(!($AD_User))
                                        {
                                            #$MainForm.Text = "Searching by Last Name..."
                                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                        }        
                                    }
                                }
                            }
                            else
                            {
                                write-debug "Middle Name Doesn't exist"
                                #$MainForm.Text = "Searching by First Name and Last Name..."
                                $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                if(!($AD_User))
                                {
                                    #$MainForm.Text = "Searching by First Name and Last Name with wildcarded firstname..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        #$MainForm.Text = "Searching by Last Name..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }
                            }
                        }
                        else
                        {
                            write-debug "No AD_User found do to no Last name found"
                            $AD_User = $null
                        }
                    }
                }
	            else
	            {
	                write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    write-debug "Last name was null"
	                }
	                else
	                {
	                    write-debug "First name was null"
	                }
	                Write-Debug "AD_User set to null"
	                $AD_User = $null
	            }

	            write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    Write-Debug "Less than 1 user found"  
                }
            }
            else
            {
	            Write-Debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
                    #$MainForm.Text = "Filtering out non-name Words..."
	                write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
                            ##$MainForm.Text = "Getting new index of Last Name..."
	                        write-debug "Index of filtered word is > 0"
	                        write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            ##$MainForm.Text = "Setting Last Name to $User_LastName..."
                            $filteredName = $true
	                    }
	                    else
	                    {
                            #$MainForm.Text = "Last Name wasn't found..."
	                        write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
                        #$MainForm.Text = "Filtering Completed..."
	                    write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                        ##$MainForm.Text = "Setting Last Name to $User_LastName..."
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                write-debug "Last Name was found after filtering"
	                write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    ##$MainForm.Text = "Searching by First and Last Name..."
                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                    if(!($AD_User))
                    {
                        ##$MainForm.Text = "Searching by First and Last Name wildcarded..."
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        if(!($AD_User))
                        {
                            ##$MainForm.Text = "Searching by Last Name wildcarded..."
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                        }
                    }
	                write-debug "Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
                    ##$MainForm.Text = "Last Name not found..."
	                write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        write-debug "Input has 1 word"
            write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            write-debug "Last Name set to $($User_LastName)"
            ##$MainForm.Text = "Formating Last Name for AD search..."
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            ##$MainForm.Text = "Search AD for users by Last Name..."
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                #$MainForm.Text = "Seaching AAH users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
            #$MainForm.Text = "No Valid input for users name detected..."
	        write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
            #$MainForm.Text = "Formatting User output..."
	        write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);
                                'SSO' = $($entry.sAMAccountName)}
                $User_Object = New-Object –TypeName PSObject –Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($AD_User.Count) -gt 1)
	        {
                #$MainForm.Text = "Selecting User..."
	            write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
	            @{Name="E-mail";Expression = { $_.Email }; Alignment="left" }|out-host
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                }
                #$MainForm.Text = "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                Write-Debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                Write-Debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
	        }
	        elseif ($($AD_User.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                write-debug "AD FIRST NAME $($AD_User.Firstname)"
                write-debug $ad_user.Lastname
                write-debug $ad_user.Email
	            Write-Debug "User count = 1"
                #$MainForm.Text = "Formating User's First Name for AD Search..."
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
                #$MainForm.Text = "Formating User's Last Name for AD Search..."
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                Write-Debug $User_FirstName
                Write-Debug $User_LastName
	            #$MainForm.Text = "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                Write-Debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                Write-Debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
	        }
	    }
	    else
	    {
	        Write-Debug "No user found setting variables to null"
	        Write-Debug "Searching Corperate Users"
	        $AD_User = (Get-CorpUser -UserIn $original)
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
    }
	else
	{
	    Write-Debug "[FAILURE] FindUser - Initial parameter input was null"
	    $ErrorMsg = "FindUser - $Param_ErrorMsg"
	}

    #$MainForm.Text = "Formating User output..."
	if($AD_User)
	{
	    $properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	                    'LastName' = $AD_User.LastName;
	                    'MI' = $AD_User.Initials;
	                    'Email' = $AD_User.Email;
	                    'SSO' = $AD_User.SSO;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	else
	{
	    $properties = [ordered]@{'FirstName' = $null;
	                    'LastName' = $null;
	                    'MI' = $null;
	                    'Email' = $null;
	                    'SSO' = $null;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
    #$MainForm.Text = "Returning User output..."
	return $Return_Object
}

#TODO  GENERAL UPDATING TO GUI
Function Get-CorpUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
<#
	$original = $UserIn
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
#>
    $filtering_Lastname = $false
    $SearchingBase = "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
	        Write-Debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            Write-Debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                write-debug " First Name: $User_FirstName"
                $User_MiddleName = $($User_FullNameArray[1])
	            Write-Debug " Middle Name: $User_MiddleName"
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                Write-Debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
	            Write-Debug " Middle Initial Part 2 : $User_MI"
                
                write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
	                    write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
	                        write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
	                            write-debug "Index of filtered word is > 0"
	                            write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
	                        write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    write-debug "First and Last name evaluated as not null"
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                    if(!($AD_User))
                                    {
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }        
                            }
                        }
                    }
                    else
                    {
                        $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            }
                        }
                    }
                }
	            else
	            {
	                write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    write-debug "Last name was null"
	                }
	                else
	                {
	                    write-debug "First name was null"
	                }
	                Write-Debug "user set to null"
	                $AD_User = $null
	            }

	            write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    Write-Debug "Less than 1 user found"
                    if($filteredName -eq $false)
                    {
                        Write-Debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            Write-Debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                if(!($AD_User))
                                {
                                    #$MainForm.Text = "Seaching Corp users by first name"
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                                }
                            }
                        }
                    }
                    else
                    {
                        Write-Debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            Write-Debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                #$MainForm.Text = "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }

                    
                }
            }
            else
            {
	            Write-Debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
	                write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1-9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
	                        write-debug "Index of filtered word is > 0"
	                        write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            $filteredName = $true
	                    }
	                    else
	                    {
	                        write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
	                    write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                write-debug "Last Name was found after filtering"
	                write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    if($filteredName -eq $true)
                    {
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                #$MainForm.Text = "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
                    else
                    {
	                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                #$MainForm.Text = "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
	                write-debug " Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
	                write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        write-debug "Input has 1 word"
            write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            write-debug "Last Name set to $($User_LastName)"
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                #$MainForm.Text = "Seaching Corp users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
	        write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
	        write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);
                                'SSO' = $($entry.sAMAccountName)}
                $User_Object = New-Object –TypeName PSObject –Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($AD_User.Count) -gt 1)
	        {
	            write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
	            @{Name="E-mail";Expression = { $_.Email }; Alignment="left" }|out-host
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                }

	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                Write-Debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                Write-Debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
	        }
	        elseif ($($AD_User.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                write-debug "AD FIRST NAME $($AD_User.Firstname)"
                write-debug $ad_user.Lastname
                write-debug $ad_user.Email
	            Write-Debug "User count = 1"
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                Write-Debug $User_FirstName
                Write-Debug $User_LastName
	
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                Write-Debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                Write-Debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
	        }
	    }
	    else
	    {
	        Write-Debug "No user found setting variables to null"
	        $AD_User = $null
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
	}
	else
	{
	    Write-Debug "[FAILURE] FindCorpUser - Initial parameter input was null"
	    $ErrorMsg = "FindCorpUser - $Param_ErrorMsg"
	}


	if($AD_User)
	{
	    $properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	                    'LastName' = $AD_User.LastName;
	                    'MI' = $AD_User.MI;
	                    'Email' = $AD_User.Email;
	                    'SSO' = $AD_User.SSO;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	else
	{
	    $properties = [ordered]@{'FirstName' = $null;
	                    'LastName' = $null;
	                    'MI' = $null;
	                    'Email' = $null;
	                    'SSO' = $null;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object –TypeName PSObject –Prop $properties
	}
	
	return $Return_Object
}


    write-host "Parameter input for User: $Userfullname"
    $PSUser = FindUser -User_In $Userfullname
    if($PSUser)
    {
        if($PSUser.SSO)
        {
         $username = $PSUser.SSO
        }
        else
        {
            write-host $PSUser.Errormsg
        }
    }


    if(!($username))
    {
        write-host "no user was found"
        read-host "press enter to exit"
        exit
    }
    else
    {
        write-host "Users Username set to: $username"
    }

    if(!($Computername))
    {
        write-host "Old PC was not found"
        read-host "press enter to exit"
        exit
    }
    else
    {
        $OldPC = (Get-PC-By_PCName($Computername)).Name
    }

    if(!($OldPC))
    {
        write-host "Old PC was not found"
        read-host "press enter to exit"
        exit
    }

    $PC = read-host "Enter New PC Serial, Fullname, or IP Address"
    if($PC)
    {
        $PC = $PC.Trim()
        if($PC)
        {
            $NewPC = (Get-PC-By_PCName($PC))
            if($NewPC)
            {
                
                if($NewPC.name)
                {
                    $NewPC = $NewPC.Name
                }
                else
                {
                    if($NewPC -like "*.*.*.*")
                    {
                     #ip address
                     Setup-IP-Invoke
                    }
                    else
                    {
                    write-host "New PC was not found"
                    read-host "press enter to exit"
                    exit
                    }
                }
            }
            else
            {
                write-host "New PC was not found"
                read-host "press enter to exit"
                exit
            }
        }
    }

    $Savefrom = "\\$oldpc\C$\Users\$username"
    $Saveto = "\\$newpc\C$\Users\$username"
    $NewPCReady = $false
    $OldPConline = $false
    $NewPConline = $false
    $timeout = 0 #5secs pulls for 20 mins
    while($OldPConline -eq $false -or $NewPConline -eq $false)
    {
        write-host -ForegroundColor Cyan "Old PC is: " -nonewline
        if(Test-Connection $oldpc -Count 1 -Quiet -ErrorAction SilentlyContinue)
        {
            write-host -ForegroundColor Green "Online"
            $OldPConline = $true
        }
        else
        {
            write-host -ForegroundColor Red "Offline"
            $OldPConline = $false
        }

        write-host -ForegroundColor Cyan "New PC is: " -nonewline
        if(Test-Connection $newpc -Count 1 -Quiet -ErrorAction SilentlyContinue)
        {
            write-host -ForegroundColor Green "Online"
            $NewPConline = $true
            if(test-path -path "\\$newpc\C$\Users\$username")
            {
                write-host -ForegroundColor Yellow "New PC User Documents found (User has Logged into pc!)"
                $NewPCReady = $true
                $NewPConline = $true
            }
            else
            {
                 write-host -ForegroundColor Yellow "New PC User Documents found (User has Logged into pc!)"
                $NewPCReady = $false
                $NewPConline = $false
            }
        }
        else
        {
            write-host -ForegroundColor Red "Offline"
            $NewPConline = $false
        }

        if($timeout -ge 240)
        {
            if($NewPConline -eq $false)
            {
                write-host -ForegroundColor Red "`nNew PC timed out waiting for it be come online after 20 mins"
            }
            else
            {
                if($NewPConline -eq $true)
                {
                    write-host -ForegroundColor Yellow "New PC User Documents found (User has Logged into pc!)"
                }
                else
                {
                    write-host -ForegroundColor Yellow "New PC User Documents NOT found (User has NOT Logged into pc!)"
                }
            }

            if($OldPConline -eq $false)
            {
                write-host -ForegroundColor Red "`nOld PC timed out waiting for it be come online after 20 mins"
            }
            
            if($NewPConline -eq $false -or $OldPConline -eq $false)
            {
                read-host "`n Press enter to exit"
                exit
            }
        }
        else
        {
            $timeout++
            write-host "Waiting 5 secs..."
            Start-Sleep -Seconds 5
        } 
    }

    
    # See if bookmarks exist from backup location
IF (Test-Path -Path "$Savefrom\AppData\Local\Google\Chrome\Bookmarks") 
{
    # See if bookmarks exist on local restore location
    IF(Test-path -Path "$Saveto\AppData\Local\Google\Chrome\User Data\Default\Bookmarks") 
    {
        # Remove Current local Bookmarks for validation they successfully copied from backup
        Remove-Item -Path "$Saveto\AppData\Local\Google\Chrome\User Data\Default\Bookmarks" -Force 
    }
    # Check for Folder Chrome uses for bookmarks to determine if Chrome is installed
    IF(!(Test-path -Path "$Saveto\AppData\Local\Google\Chrome\User Data\Default"))
    {
        # THEN CHROME NOT INSTALLED
        write-host "Detected Google Chrome is not installed on New Computer"
        # Check for secondary folder to save chrome bookmarks to

        robocopy "$Savefrom\AppData\Local\Google\Chrome\Bookmarks" "$Saveto\Documents\ChromeBookmarks" /e /is /it > $null
        #Copy-Item -Path "$Savefrom\AppData\Local\Google\Chrome\Bookmarks" -Destination "$Saveto\Documents\ChromeBookmarks" -Force -Recurse
        Write-host "`n Google Chrome bookmarks saved to:"
        write-host " $Saveto\Documents\ChromeBookmarks`n"            
        write-host " After Google Chrome is installed either:"
        write-host " --Re-run Restore from AAHUtilities-- OR --Import bookmarks into Google Chrome--`n"

        IF (Test-Path -path "$Saveto\Documents\ChromeBookmarks\Bookmarks")
        {
             # BOOKMARKS COPIED SUCCESSFULLY
            Write-host "`n Google Chrome bookmarks saved to:"
            write-host " $Saveto\Documents\ChromeBookmarks`n"
            write-host " After Google Chrome is installed either:"
            write-host " --Re-run Restore from AAHUtilities-- OR --Import bookmarks into Google Chrome--`n"
       }
        
    }
    ELSE
    {
        # THEN CHROME IS INSTALLED

        # Copy to local restore folder
        Copy-Item -Path "$Savefrom\AppData\Local\Google\Chrome\Bookmarks" -Destination "$Saveto\AppData\Local\Google\Chrome\User Data\Default" -Force -Recurse
        # Verify Bookmarks Copied
        IF (Test-Path -path "$Saveto\AppData\Local\Google\Chrome\User Data\Default\Bookmarks")
        {
            # BOOKMARKS COPIED SUCCESSFULLY

            Write-host " Google Chrome bookmarks restored"
        }
    }
}
#----------------------------------------------------#
############# GOOGLE CHROME FAVORITES ################


############# STICKY NOTES ################
#-----------------------------------------#

#|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||#
# NOTE: Robocopy is not used because these files should be replaced each time #
#|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||#

    # Test if Sticky notes file exist on backup location
    IF (Test-Path "$Savefrom\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe" -ErrorAction SilentlyContinue)
    {
        IF (Test-Path "$Savefrom\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite" -ErrorAction SilentlyContinue)
        {
            # FILE EXISTS ON BACKUP LOCATION
            # Test if Sticky notes file exist on local restore location
            if (Test-path -Path "$Saveto\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe" -ErrorAction SilentlyContinue)
            {
                IF(Test-path -Path "$Saveto\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite" -ErrorAction SilentlyContinue)
                {
                    # FILE EXISTS ON LOCAL RESTORE LOCATION
        
                    # Remove local file for copy from backup success verification
                    try
                    {
                        Remove-Item -Path "$Saveto\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite" -Force -ErrorAction SilentlyContinue
                    }
                    catch
                    {
                        cls
                        write-host -ForegroundColor Yellow " Could not remove Sticky Notes file."
                        write-warning " Make sure Sticky Notes is closed before continuing"
                        read-host "`n Press enter to continue"
                        cls
                    }
                }
                # Copy file from backup location to local restore location
                write-host -ForegroundColor Cyan "Copying Sticky notes..."
                Copy-Item -Path "$Savefrom\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite" -Destination "$Saveto\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState" -Force -Recurse
                write-host "Done"
                # Test for Copy file success
                IF (Test-Path -path "$Saveto\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite")
                {
                    # FILE COPIED SUCCESSFULLY
                    write-host -ForegroundColor Green "SUCCESSFULLY" -NoNewline
                    Write-host " copied Sticky Notes"
                }
                else
                {
                    write-host -ForegroundColor Red "FAILED" -NoNewline
                    Write-host " to copy Sticky Notes"
                }
            }
            else
            {
                write-host -ForegroundColor Yellow "Sticky Notes not installed on New PC, Saving Sticky Notes to Documents"
                if(!(test-path "$Saveto\Documents\Sticky Notes" -ErrorAction SilentlyContinue))
                {
                    write-host -ForegroundColor Cyan "Creating Sticky Notes Folder in Documents..."
                     New-Item -Path $Saveto\Documents -Name "Sticky Notes" -ItemType Container -Force > $NULL
                     write-host "Done"
                     write-host -ForegroundColor Cyan "Copying Sticky notes to documents..."
                     Copy-Item -Path "$Savefrom\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite" -Destination "$Saveto\Documents\Sticky Notes" -Force -Recurse
                     IF (Test-Path -path "$Saveto\Documents\Sticky Notes\plum.sqlite" -ErrorAction SilentlyContinue)
                     {
                        # FILE COPIED SUCCESSFULLY
                        write-host -ForegroundColor Green "SUCCESSFULLY" -NoNewline
                        Write-host " copied Sticky Notes"
                     }
                     else
                     {
                        write-host -ForegroundColor Red "FAILED" -NoNewline
                        Write-host " to copy Sticky Notes"
                     }
                }
                else
                {
                    #Sticky notes folder already exists in documents
                    write-host -ForegroundColor Cyan "Copying Sticky notes to documents..."
                    Copy-Item -Path "$Savefrom\AppData\Local\Packages\Microsoft.MicrosoftStickyNotes_8wekyb3d8bbwe\LocalState\plum.sqlite" -Destination "$Saveto\Documents\Sticky Notes" -Force -Recurse
                    IF (Test-Path -path "$Saveto\Documents\Sticky Notes\plum.sqlite" -ErrorAction SilentlyContinue)
                    {
                        # FILE COPIED SUCCESSFULLY
                        write-host -ForegroundColor Green "SUCCESSFULLY" -NoNewline
                        Write-host " copied Sticky Notes"
                    }
                    else
                    {
                        write-host -ForegroundColor Red "FAILED" -NoNewline
                        Write-host " to copy Sticky Notes"
                    }
                }
            }
        }
        else
        {
            write-host -ForegroundColor Yellow "`nSticky Notes not installed on Old PC, Skipping Sticky Notes`n"
        }
    }
    else
    {
        write-host -ForegroundColor Yellow "`nSticky Notes not installed on Old PC, Skipping Sticky Notes`n"
    }
$LocalRoot = "\\$newPC\C$\Users\$username"
$RemoteRoot = "\\$oldpc\C$\Users\$username"
write-host -ForegroundColor Cyan "Copying Favorites in Favorites folder (Excluding Favorites Bar)..." -NoNewline
robocopy "$RemoteRoot\Favorites" "$LocalRoot\Favorites" /XD "$RemoteRoot\Favorites\Favorites Bar" /e /is /it > $null
write-host "Done"
#Copy-Item -Path "$RemoteRoot\Favorites\*" -Exclude ("$RemoteRoot\Favorites\Links","$RemoteRoot\Favorites\Links\*","$RemoteRoot\Favorites\Favorites Bar","$RemoteRoot\Favorites\Favorites Bar\*") -Destination "$LocalRoot\Favorites" -Force -Recurse -Container
if (Test-Path "$LocalRoot\Favorites\Links")
    {
    if (!(Test-Path "$RemoteRoot\Favorites\Links"))
    {
    write-host -ForegroundColor Cyan "Copying Favorites Bar..." -NoNewline
    Copy-Item -Path "$RemoteRoot\Favorites\Favorites Bar\*" -Destination "$LocalRoot\Favorites\Links"
    write-host "Done"
    }
    else
    {
    write-host -ForegroundColor Cyan "Copying Favorites Bar..." -NoNewline
    Copy-Item -Path "$RemoteRoot\Favorites\Links\*" -Destination "$LocalRoot\Favorites\Links"
    write-host "Done"
    } 
}
else
{
#TODO: add Favorites bar logic
write-host "couldn't find new pc favorites\links folder"
}

        
    
#############################################################################################################




###############################################################################
#----------------------------Outlook signature--------------------------------#
###############################################################################
$src = "\\$OldPC\C$\users\$username\AppData\Roaming\Microsoft\Signatures"
$dst = "\\$NewPC\C$\users\$username\AppData\Roaming\Microsoft\Signatures"
if(test-path "$src")
{
    write-host -ForegroundColor Cyan "Copying Outlook Signatures..." -NoNewline
    robocopy $src $dst /is /it /e > $null
    write-host "Done"
}
else
{
    write-host -ForegroundColor Cyan "Skipped Outlook Signatures (no signatures found on old pc)"
}

###############################################################################
#----------------------------Onenote notebooks in documents-------------------#
###############################################################################
$src = "\\$OldPC\C$\users\$username\Documents\OneNote Notebooks"
$dst = "\\$NewPC\C$\users\$username\Documents\OneNote Notebooks"
if(test-path "$src")
{
    write-host -ForegroundColor Cyan "Copying OneNote Notebooks..." -NoNewline
    robocopy $src $dst /is /it /e > $null
    write-host "Done"
}
else
{
    write-host -ForegroundColor Cyan "Skipped OneNote Notebooks (no notebooks found on old pc)"
}

$src = "\\$OldPC\C$\users\$username\Documents"
$dst = "\\$NewPC\C$\users\$username\Documents"
if(test-path "$src")
{
    write-host -ForegroundColor Cyan "Copying Documents..." -NoNewline
    robocopy $src $dst /xf "OneNote Notebooks"  /is /it /e > $null
    write-host "Done"
}
else
{
    write-host -ForegroundColor Yellow "Can't find Documents folder...Skipped Documents"
}

$src = "\\$OldPC\C$\users\$username\Desktop"
$dst = "\\$NewPC\C$\users\$username\Desktop"
if(test-path "$src")
{
    write-host -ForegroundColor Cyan "Copying Desktop..." -NoNewline
    if(!(test-path "$dst\dataToAuthorityOverTunnel.dat" -ErrorAction SilentlyContinue))
    {
        Get-ChildItem "$src" |
                Where-Object {!($_.Name -like "*.exe" -or $_.Name -like "desktop.ini") } |
                %{write-host -ForegroundColor Cyan "Copying: " -NoNewline; write-host "$($_.Name)"; copy-item -path $_.Fullname -Destination "$dst" -Force -Recurse}
        write-host "Done"
    }
    else
    {
        Get-ChildItem "$src" |
                Where-Object {!($_.Name -like "*.exe" -or $_.Name -like "desktop.ini" -or $_.Name -like "dataToAuthorityOverTunnel.dat") } |
                %{write-host -ForegroundColor Cyan "Copying: " -NoNewline; write-host "$($_.Name)"; copy-item -path $_.Fullname -Destination "$dst" -Force -Recurse}
        write-host "Done"
    }
}
else
{
    write-host -ForegroundColor Yellow "Can't find Desktop folder...Skipped Documents"
}

write-host "`n Transfer complete."
read-host "Press Enter to Exit"
exit

