﻿


[array]$file = Get-Content $psscriptroot\biostest.txt



#####################################################################


#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
Set-Location "C:\"

$scriptPath = "$($PSScriptRoot)"
$Root = (get-item $scriptPath).Parent.Parent.FullName
$ExcelLoginFilePath = "$($Root)\CHANGE-THIS.xlsx"

$xl20 = New-Object -COM "Excel.Application"
$xl20.Visible = $false
$wb20 = $xl20.Workbooks.Open("$($Root)\CHANGE-THIS.xlsx")
$ws20 = $wb20.Sheets.Item(1)
$xlFixedFormat20 = [Microsoft.Office.Interop.Excel.XlFileFormat]::xlWorkbookDefault

$WorksheetRange20 = $ws20.UsedRange
$RowCount20 = $WorksheetRange20.Rows.Count
$ColumnCount20 = $WorksheetRange20.Columns.Count
write-host "Loading Accounts from $($Root)\CHANGE-THIS.xlsx..."
for ($i20 = 2; $i20 -le $RowCount20; $i20++){
for ($cl0 = 1; $cl0 -le $ColumnCount20; $cl0++){



#get data:
$cell = $ws20.Cells.Item($i20, $cl0).Text
if ($i20 -eq 2){
if ($cl0 -eq 1){
write-host "Admin account username Loaded"
$Admin_User = "$($cell)"
}
if ($cl0 -eq 2){
write-host "Current account username Loaded"
$NonAdmin_User = "$($cell)"
}
if ($cl0 -eq 3){
write-host "H:\ Loaded"
$HDrivePath = "$($cell)"
}
else{

}
}
}
}
$wb20.Close()
$xl20.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl20)

#***************************************************************************************
#---------------------------------OPTIONAL CHANGES START-------------------------------
#***************************************************************************************

# This is H:\ Drive path DO NOT NEED TO CHANGE UNLESS YOUR H:\ can't be accessed by your nonadmin account
$RootInstallLocation = "$($HDrivePath)"

#**************************************************************
#-------Import-----------
import-module ActiveDirectory
#-------Import-----------


#name of text file that will have the list of pcs to update Located in the t470BatchUpdater folder on the desktop (each one is a new line and can accept serial number or full name)
$PCList = "pc_list.txt"
$CompletedList = "CompletedList.txt"

    #---------------------DEFAULT-------------
    #$txtFileCompletedPCs = "pc_list.txt"
    #---------------------DEFAULT-------------



#Name of the folder on your desktop  where you want individual PC logs to be stored (C:\USERS\YOUR NONADMIN ACCOUNT\DESKTOP\THIS VALUE)
$PCLogsFolderName = "CompletedLogs"


    #---------------------DEFAULT-------------
    #$PCLogsFolderName = "Completed470Logs"
    #---------------------DEFAULT-------------

#***************************************************************************************
#---------------------------------OPTIONAL CHANGES END-------------------------------
#***************************************************************************************

if (test-Path "$($PSScriptRoot)\$($PCLogsFolderName)")
{

}
else
{
$fso = new-object -ComObject scripting.filesystemobject
$fso.CreateFolder("$($PSScriptRoot)\$($PCLogsFolderName)")
}

if (test-Path "$($PSScriptRoot)\$($PCList)")
{
write-host "Found PC list text file"
}
else
{
write-host "PC list text file not found"
write-host "make sure this file is located in the in the same folder this script was run from"
}


#***************************************************************
#-------------------------Directories---------------------------
#**************************************************************
$PCList = "$($PSScriptRoot)\$($PCList)"
$out_PCList = $PCList
$Dir = "$($PSScriptRoot)\savedPSFiles"
$out_PCLogsFolderPath = "$($PSScriptRoot)\$($PCLogsFolderName)"

#***************************************************************
#-------------------------Directories---------------------------
#**************************************************************



#***************************************************************
#-------------------------Credentials---------------------------
#**************************************************************
$Admin_User1 = "AFII\$($Admin_User)"
$NonAdmin_User1 = "AFII\$($NonAdmin_User)"
$ACreds = Get-Content C:\Temp\ACreds.txt
    foreach ($line in $ACreds)
{
$strPass = $line
}
    $Creds = Get-Content C:\Temp\Creds.txt
foreach ($line in $Creds)
{
$strPass2 = $line
}
$password = convertto-securestring $strPass -AsPlainText -Force
$password2 = convertto-securestring $strPass2 -AsPlainText -Force
$credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",$password
$credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",$password2
#***************************************************************
#-------------------------Credentials---------------------------
#**************************************************************

#*************************************************
#---------------For Each PC in List End----------
#*************************************************

#*************************************************
#---------------Cred Cleanup----------
#*************************************************
if (test-Path "C:\Temp\ACreds.txt")
{
Remove-Item C:\Temp\ACreds.txt -force -recurse -ErrorAction Stop
}
else
{
#already removed
}
if (test-Path "C:\Temp\Creds.txt")
{
Remove-Item C:\Temp\Creds.txt -force -recurse -ErrorAction Stop
}
else
{
#already removed
}
#*************************************************
#---------------Cred Cleanup----------
#*************************************************

#***************************************************************
#------------------------Mapping Drive---------------------------
#**************************************************************
#############NOT NEEDED FOR THIS#########################
<#
Try{
#New-PSDrive -Name "Y" -PSProvider FileSystem -Root "\\wgpsm008.aah.local\appmediaprimary" -Credential $credentials
}
Catch [System.UnauthorizedAccessException]
{
write-host "Problem with mapping G Drive with NonAdmin Credentials, attempting to map with Admin Credentials"
    Try{
    #New-PSDrive -Name "G" -PSProvider FileSystem -Root "\\wgpsm008.aah.local\appmediaprimary" -Credential $credentials
    }
    Catch
    {
    write-host "Problem with mapping G Drive with either credentials"
    write-host "Error:"
    write-host $_
    $exit = Read-Host -Prompt "press enter to exit"
    exit
    }
}
#>
#############NOT NEEDED FOR THIS#########################
#***************************************************************
#------------------------Mapping Drive---------------------------
#**************************************************************




$line = Read-host -Prompt "enter pc serial or fullname"

$line = $line.Trim()

 #---------variable adapter--------
 $PC = $line
 #---------variable adapter--------

#****************************************************
#------ Filter and Modify Adapter START---------------
#****************************************************

If ($PC -like "WILG000*")
{
#WI laptop Dell
$PC = $PC -replace "WILG000"
}
elseif ($PC -like "WILG00*")
{
#WI laptop Lenovo
$PC = $PC -replace "WILG00"
}
elseif ($PC -like "WIDG000*")
{
#WI Desktop Dell
$PC = $PC -replace "WIDG000"
}
elseif ($PC -like "WIDG00*")
{
#WI Desktop Lenovo?
$PC = $PC -replace "WIDG00"
}
elseif ($PC -like "AZLG000*")
{
#AZ laptop dell
$PC = $PC -replace "AZLG000"
}
elseif ($PC -like "AZLG00*")
{
#AZ laptop lenovo
$PC = $PC -replace "AZLG00"
}
elseif ($PC -like "AZDG000*")
{
#AZ Desktop dell
$PC = $PC -replace "AZDG000"
}
elseif ($PC -like "AZDG00*")
{
#AZ Desktop lenovo?
$PC = $PC -replace "AZDG00"
}
elseif ($PC -like "NVLG000*")
{
#LV laptop dell
$PC = $PC -replace "NVLG000"
}
elseif ($PC -like "NVLG00*")
{
#LV laptop lenovo
$PC = $PC -replace "NVLG00"
}
elseif ($PC -like "NVDG000*")
{
#LV Desktop dell
$PC = $PC -replace "NVDG000"
}
elseif ($PC -like "NVDG00*")
{
#LV Desktop lenovo?
$PC = $PC -replace "NVDG00"
}
elseif ($PC -like "WIVGP*")
{
#VDI's To be added
}
#****************************************************
#------ Filter and Modify Adapter END---------------
#****************************************************

$PCLogs = "$($out_PCLogsFolderPath)\Temp\$($PC).txt"
if (test-path $($PCLogs))
{
Clear-Content $($PCLogs)
}
#****************************************************
#-------------------Obtain AD Record START-----------
#****************************************************

$ADcomputer = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$PC'"
#Logs Setup
$out_CompletedList = "$($PSScriptRoot)\$($CompletedList)"
$out_PCList = "$($PCList)"
$out_UpdateADConnectList = "$($PSScriptRoot)\RecentlyImagedList.txt"

if($($ADcomputer).count -gt 1)
{
write-Host "$($PC) Brought back too many matches in AD"
write-Host "readding $($PC) back to list and moving to next pc"
write-output "$($PC) Brought back too many matches in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
$readdList += $($PC)
Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
Write-output "$($PC) Failed due to too many results returned from AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append

write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END -----------------------------#"
write-host "################################################################" 

$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
Remove-Item $path -force -recurse
continue
}
$computer = $ADcomputer.Name




if ($computer) {





$s = New-PSSession -computerName $computer -credential $credentials
$n = Invoke-Command -Session $s -ArgumentList $file, $Admin_User1, $strPass,$PSScriptRoot -ScriptBlock {

#########################################################################################################
$OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }
		
		# Supend Bitlocker if $OSVolumeEncypted is $true
		if ($OSVolumeEncypted -eq $true) {
			Write-output "Suspending BitLocker protected volume: C:" -Severity 1
            Write-host "Suspending BitLocker protected volume: C:"
			$a = Manage-Bde -Protectors -Disable C:
            write-output $a

		}

$b =Suspend-BitLocker -MountPoint "C:" -RebootCount 1
write-output $b

write-host "Setting bios..."
write-output "Setting bios..."
$password = convertto-securestring $($args[2]) -AsPlainText -Force

$credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$($args[1])",$password


foreach($setting in $($args[0]))
{
write-host "Setting $setting..."
write-output "Setting $setting..."
    $run = "$setting"
    #$run = "$setting,$password,ascii,us"
    $Response = (gwmi -class Lenovo_SetBiosSetting -namespace root\wmi).SetBiosSetting("$run").return
    write-output ("$setting`n$Response")
    $Response = (gwmi -class Lenovo_SaveBiosSettings -namespace root\wmi).SaveBiosSettings("").return
    write-output ("$setting`n$Response")
}

#############################################################################################################

}
Remove-PSSession $s
write-host $n
write-output $n | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

}





#*************************************************
#---------------Cred Cleanup----------
#*************************************************
if (test-Path "C:\Temp\ACreds.txt")
{
Remove-Item C:\Temp\ACreds.txt -force -recurse -ErrorAction Stop
}
else
{
#already removed
}

if (test-Path "C:\Temp\Creds.txt")
{
Remove-Item C:\Temp\Creds.txt -force -recurse -ErrorAction Stop
}
else
{
#already removed
}
#*************************************************
#---------------Cred Cleanup----------
#*************************************************

$computer2 = Read-Host -Prompt "press enter to exit"
exit
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}