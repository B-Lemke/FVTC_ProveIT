﻿

#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************
cls
# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;


function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User1 = $NonAdmin_User.trim()
            $NonAdmin_User1 = "AFII\$($Script:NonAdmin_User1)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}


function Call-Reassignment
{
    param(
    $Desc,
    $StockRoom,
    $logRoot
    )
    $i = 0
    $strpcs = ""
    foreach($pc in $Desc)
    {
        
        $pc = $pc.trim()
        if(!($pc))
        {
            continue
        }
        $ParentLogContainingFolderName = "Python"
        $LogContainingFolderName = "Seperate PC"
        $logfilename = "$($pc.trim()).txt"
        $logpath = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"
        $logpathout = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName"
        if(!(test-path "$LogRoot\Logs"))
        {
            $fso = new-object -ComObject scripting.filesystemobject
            $fso.CreateFolder("$LogRoot\Logs")
        }
        if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName"))
        {
            $fso = new-object -ComObject scripting.filesystemobject
            $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName")
        }
        if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName"))
        {
            $fso = new-object -ComObject scripting.filesystemobject
            $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName")
        }

        if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"))
        {
            write-output "$((Get-Date).ToString())" |Out-File -FilePath $logpath
        }


        write-output "Started: $(get-date)" |Out-File -FilePath "$logpath" -Encoding ascii
        write-output "Entry: $pc" |Out-File -FilePath "$logpath" -Encoding ascii -Append
        write-output "Stockroom set to: $StockRoomValue" |Out-File -FilePath "$logpath" -Encoding ascii -Append
        write-host "Entry: $pc"
        $pc2 = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "Name -like '*$pc'"
        if($PC2.name)
        {
            $name = $PC2.name
            write-host $name -NoNewline
            write-host -ForegroundColor Yellow " was found in AD"
            write-output "$name was found in AD" |Out-File -FilePath "$logpath" -Encoding ascii -Append
            
            $deleteInAd = read-host "would you like to Delete $name from AD?(y/n)"
            if($deleteInAd -like "y")
            {
                write-output "would you like to Delete $name from AD?(y/n): Y" |Out-File -FilePath "$logpath" -Encoding ascii -Append
                write-host "Removing $name..." -NoNewline
                Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$name'" | Remove-ADObject -Recursive -Confirm:0
                $ADcomputer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$name'") 
                if ($ADcomputer.count -lt 1)
                {
                    write-output "[SUCCESS] Deleting from AD" |Out-File -FilePath "$logpath" -Encoding ascii -Append
                    write-Host -ForegroundColor Green "SUCCESS"
                }
                else
                {
                    write-output "[FAILED] Deleting from AD" |Out-File -FilePath "$logpath" -Encoding ascii -Append
                    write-Host -ForegroundColor Red "FAILED"
                }
            }
    
            if($i -eq 0)
            {
            
                if ($name -like ",*")
                {
                    $name.Replace(',')
                }
                $strpcs += "`"$($PC.toUpper())`""
            $i++
            }
            else
            {
                $strpcs += ",`"$($PC.toUpper())`""
                $i++
            }
        }
        else
        {
             write-output "$PC is not in AD" |Out-File -FilePath "$logpath" -Encoding ascii -Append
            write-host "$PC is not in AD"
            if($i -eq 0)
            {
                $name = $PC.toUpper()
                if ($name -like ",*")
                {
                    $name.Replace(',')
                }
                $strpcs += "`"$name`""
                $i++
            }
            else
            {
                $strpcs += ",`"$($PC.toUpper())`""
                $i++
            }
        }
        write-host " "
    }
    write-host "PC String:"
    write-host "--------------------------------------------"
    write-host $strpcs
    write-host "--------------------------------------------"
    $scriptPath = "$($PSScriptRoot)"
    $LogRoot = (get-item $scriptPath).Parent.Parent.FullName
    $Python_Script = "$LogRoot\Python\Seperate PC.py"

    $i= 0
    if(Test-Path "$Python_Script")
    {

        #$Python_Script = "C:\Users\bwienk1\Desktop\Script Fixes\Python\Check PCs.py"
        $i= 0
        $content = $null
        $content = (get-content "$Python_Script")

        if($strpcs)
        {
            $i= 0
            $content2 = ($content | Where-Object {$_ -like 'OldComputerFullname = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
            if($content2.count -gt 1)
            {
                #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
            }
            else
            {
                $content[$index] = "OldComputerFullname = [$strpcs]"
            }
        }
        else
        {
            $i= 0
            $content2 = ($content | Where-Object {$_ -like 'OldComputerFullname = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
            if($content2.count -gt 1)
            {
                #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
            }
            else
            {
                $content[$index] = "OldComputerFullname = []"
            }

        }

        $content |Set-Content "$Python_Script"
        Start-Sleep -Milliseconds 500
            $firstlogs = gc $logpath -Raw
        write-host -ForegroundColor Cyan "Getting Info from Service-Now Records..."
        $pythonlogpath = $logpathout.replace('\','/')
        & "C:\Program Files (x86)\Python37-32\python.exe" "$Python_Script" "$Script:NonAdmin_User1" "$Script:Password" "$StockRoomValue", "$pythonlogpath"
        write-host -ForegroundColor Cyan "Completed Getting Info from Service-Now Records!"
        foreach($pc in $Desc)
        {

        $scriptPath = "$($PSScriptRoot)"
        $ParentLogContainingFolderName = "Python"
        $LogContainingFolderName = "Seperate PC"
        $logfilename = "$($pc.trim()).txt"
        $logpath = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"

                $logs = gc $logpath
                $splitlogs = $logs.split("|")
               $splitlogs | Out-File $logpath
               $rawlog = gc $logpath -Raw
               ($firstlogs) + ($rawlog) | Set-Content $logpath
        }
                write-Host -ForegroundColor Cyan "Log Formatting complete!"
        $exit = read-host " Press enter to exit"
        exit

    }
    else
    {
        #write-debug "location fixes is not valid path"
    }
}

Check-Credentials
#$loginPassword = $Script:Password
#$loginUsername = $Script:NonAdmin_User1
$desc = gc -Path "$PSScriptRoot\pc_list.txt"
While(!($Desc))
{
$desc = read-host "Search Service-now for PC like (wildcards supported, IE: *)"
}
Clear-Content "$PSScriptRoot\pc_list.txt"

While(!($Script:NonAdmin_User1))
{
   $Script:NonAdmin_User1 = read-host "Enter Your Non Admin Username (enter q to exit)"
   if ($Script:NonAdmin_User1 -eq "q"){exit}
}
if(!($Script:Password))
{
    while(!($Script:Password))
    {
        $Script:Password = read-host "Enter Your Non Admin Password (enter q to exit)"
        if ($Script:Password -eq "q"){exit}
    }
}
$Stockroomin = $Null
$StockRoomValueGB = "AAH Green Bay"
$StockRoomValueLV = 'AAH LV Site'
$StockRoomValuePHX = 'AAH PHX'
While(!($StockroomLocation))
{
    $Stockroomin = $Null
    $Stockroomin = read-host "Enter Stockroom Old PC will be located IE:(LV, GB, AZ)"
    $StockroomLocation = ($Stockroomin.ToUpper()).Trim()

    if ($StockroomLocation -eq "GB"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "GREEN BAY"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "GREENBAY"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "WI"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "WISCONSIN"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "DEPERE"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "DE PERE"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "PACKERLAND"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "q"){exit}
    else
    {
        if ($StockroomLocation -eq "LV"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "LASVEGAS"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "LAS VEGAS"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "PILOTRD"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "PILOT RD"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "PILOT"){$StockRoomValue = $StockRoomValueLV}
        else
        {
            if ($StockroomLocation -eq "AZ"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "DUNLAP"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "BC"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHOENIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHEONIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHENIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHONIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHX"){$StockRoomValue = $StockRoomValuePHX}
            else
            {
                write-host -ForegroundColor Red "Stockroom invalid!"
                $StockRoomValue = $Null
                read-host "`nPress enter to continue`n"
            }  
        }
    }
    if(!($StockRoomValue))
    {
        $StockroomLocation = $Null
    }
}
$scriptPath = "$($PSScriptRoot)"
$LogRoot = (get-item $scriptPath).Parent.Parent.FullName
write-host -ForegroundColor Cyan "Stockroom set to: " -nonewline
write-host $StockRoomValue



    Call-Reassignment -Desc $Desc -stockroom $StockRoomValue -logroot $logRoot
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------
    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}


