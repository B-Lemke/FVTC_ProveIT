Param(
[String]$line,
[String]$PCList,
[String]$out_PCLogsFolderPath,
[String]$CompletedList,
[String]$PCLogs,
[String]$ScriptRoot,
[String]$Model,
[switch]$changeADdesc
)

#****************************************
#-------------- Inital Setup ------------
$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp



function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}



Set-QuickEdit -DisableQuickEdit

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $Script:NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User = $Script:NonAdmin_User.trim()
            $Script:NonAdmin_User1 = "AFII\$($Script:NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Script:NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}
Set-Location "C:\"
$PCRunningScript = hostname
$EUCPCs = @()
$EUCUsers = @()
$EUC = @{bwienk1 = "WILG00MP18YWSB";mjung11 = "WILG00PF0RCUKC"}
foreach ($key in $EUC.Keys)
{
    if ($EUC[$key] -eq $PCRunningScript)
    {

    }
    else
    {
    $EUCPCs += $EUC[$key]
    $EUCUsers += $key
    }
}

#bios installer powershell script location
$PSFile1 = "G:\Temp\bwienk\T470\Invoke-LenovoBIOSUpdate.ps1"

#bios file location


$xl3 = New-Object -COM "Excel.Application"
$xl3.Visible = $false
$wb3 = $xl3.Workbooks.Open("$($ScriptRoot)\Bios\$($Model)Bios.xlsx")
$ws3 = $wb3.Sheets.Item(1)

$WorksheetRange3 = $ws3.UsedRange
$RowCount3 = $WorksheetRange3.Rows.Count
$ColumnCount3 = $WorksheetRange3.Columns.Count

#$wb | Get-Member
#$ws | Get-Member
#Looking up a value in one column and assigning the corresponding value from another column to a variable could be done like this:
$T1 = @()
$T2 = @()
$T3 = @()
for ($t = 1; $t -le $ColumnCount3; $t++){

for ($ir = 2; $ir -le $RowCount3; $ir++){

#get data:
$testB = $ws3.Cells.Item($ir, $t).Text
#write-host "C= $($c) I= $($i)"
#write-host "Test2 = $($test2)"

if ($t -eq 1){$T1 += $testB}
if ($t -eq 2){$T2 += $testB}
if ($t -eq 3){$T3 += $testB}
else{

} 
#set data:
#ws.Cells.Item($i, 1) = "Test"

}

}



###############
#FOR LOOP for each $i count
$BiosName = $T1[0]
$sourceBios = $T2[0]
$BiosScript = $T3[0]



#clean up

$wb3.Close()
$xl3.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)


[array]$file = Get-Content $psscriptroot\Set-Lenovo_Bios\BiosSettings.txt
#*************************************************
#---------------BIOS END-----------------------
#*************************************************



#*************************************************
#---------------DRIVERS START-----------------------
#*************************************************
$sourceName = @()
$sourceRoot = @()
$sourceCMD = @()
$FileRoots = @()

$xl = New-Object -COM "Excel.Application"
$xl.Visible = $false
$wb = $xl.Workbooks.Open("$($ScriptRoot)\Drivers\$($Model)Drivers.xlsx")
$ws = $wb.Sheets.Item(1)

$WorksheetRange = $ws.UsedRange
$RowCount = $WorksheetRange.Rows.Count
$ColumnCount = $WorksheetRange.Columns.Count

#$wb | Get-Member
#$ws | Get-Member
#Looking up a value in one column and assigning the corresponding value from another column to a variable could be done like this:
$ct1 = @()
$ct2 = @()
$ct3 = @()
$ct4 = @()
$ct5 = @()
$ct6 = @()
$ct7 = @()
$ct8 = @()
for ($cy = 1; $cy -le $ColumnCount; $cy++){

for ($i = 2; $i -le $RowCount; $i++){

#get data:
$test2 = $ws.Cells.Item($i, $cy).Text
#write-host "C= $($c) I= $($i)"
#write-host "Test2 = $($test2)"

if ($cy -eq 1){$ct1 += $test2}
if ($cy -eq 2){$ct2 += $test2}
if ($cy -eq 3){$ct3 += $test2}
if ($cy -eq 4){$ct4 += $test2}
if ($cy -eq 5){$ct5 += $test2}
if ($cy -eq 6){$ct6 += $test2}
if ($cy -eq 7){$ct7 += $test2}
if ($cy -eq 8){$ct8 += $test2} 
#set data:
#ws.Cells.Item($i, 1) = "Test"

}

}



###############
#FOR LOOP for each $i count



for ($i = 0; $i -le $ct1.Length-1; $i++) 
{
  #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
 $sourceName += $ct1[$i]
 $FileRoots += $ct2[$i]
$sourceRoot += $ct2[$i]
$sourceCMD += $ct3[$i]


  }

#cleanup
$wb.Close()
$xl.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)

#Driver installer powershell script location
$PSFile2 = "G:\Temp\bwienk\T470\t470client.ps1"

$FileRoots += $PSFile1
$FileRoots += $PSFile2
$FileRoots += $sourceBios


#$ExcelLoginFilePath = "$($ScriptRoot)\CHANGE-THIS.xlsx"
Import-Module $ScriptRoot\Modules\Excel.psm1
# creates global dynamic array vars: c(the ColumnsNeeded #'s)[(rowsneeded #'s - rowstartsat)] viewed as c1[0] for col 1 row 1 if rowstartat is 1

    # RowsNeeded default is @("2")
    # ColumnsNeeded default is @(1,2,3)
    # RowStartsAt default is 1

Check-Credentials
#**************************************************************


#initialization of arrays

#-------------- Inital Setup ------------
#****************************************

#-----------------------------------------------------------------------------------------------
#Write-output "********** Automated Lenovo T470 Driver/Bios update for newly imaged PC's ***********" 
#Write-output "--------------------------Created By Brenton Wienkes---------------------------------" 
#Write-output ""
#-----------------------------------------------------------------------------------------------


#*************************************************
#------------- Mapping Drives Start---------------
#*************************************************

#DEFAULTLY THIS WILL BE USED TO PULL ALL FILES FROM G:\Temp\bwienk\

#New-PSDrive -Name "G" -PSProvider FileSystem -Root "\\aah.local\aah\Public" -Credential $Script:credentials2
#*************************************************
#------------- Mapping Drives End---------------
#*************************************************

for($i=0;$i-le $FileRoots.Length-1;$i++){

$FileRoots[$i] = Split-Path $FileRoots[$i] -Leaf

}
$computer = $line
$Host.UI.RawUI.WindowTitle = "Running LenovoUpdaterBatchBase for $computer"
$out_UpdateADConnectList = "$($ScriptRoot)\RecentlyImagedList.txt"
#*****************************************************************
#----------------------Installation------------------------------
#Start-Transcript -Path $($PCLogs) -Append
cls
write-output "------------ Started UpdaterBase Script at $((Get-Date).ToString()) -------------------`n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "------------ Started UpdaterBase Script at $((Get-Date).ToString()) -------------------`n" 


#computer restart start
$timedout = $null # reset any previously set timeout
if (Test-Connection $computer -ErrorAction SilentlyContinue)
{
    #connection good
}
else
{
    write-host -ForegroundColor Cyan "Waiting 2 mins for pc to come back online..." -NoNewline
    Start-Sleep -Seconds 120
    write-host "Done"
}
write-host -ForegroundColor Cyan "Restarting computer started at: " -nonewline
write-host $(get-date)
restart-computer $computer -credential $Script:credentials -force -wait -for PowerShell -Timeout 1000 -Delay 2 -ev timedout
if ($timedout)
{
    write-host "Waiting 2 mins due to timed out restart..." -NoNewline
    write-output "Waiting 2 mins due to timed out restart" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    start-sleep -Seconds 120
    write-host "Done"
    if (test-connection $computer -Quiet)
    {
    #Connection is good
    write-Host "$($computer) restart timed out, but pc is still responsive"
    write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else{
    write-host "Waiting 5 mins due to timed out and not responsive after restart..." -NoNewline
    Start-Sleep -Seconds 300
    write-host "Done"
    if (test-connection $computer -Quiet)
    {
    #Connection is good
    write-Host "$($computer) restart timed out Pre bios, waited 5 mins and now pc is responsive"
    write-output "$($computer) restart timed out waited Pre bios, 5 mins and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else
    {
        write-host -ForegroundColor Yellow "$($computer) restart timed out, please check pc"
        write-output "$($computer) restart timed out, please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-Host "adding $($computer) back to list and ending script on this pc"
        write-Host "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
        Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
        Write-output "$($computer) Failed due restart timedout Pre bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-host "################################################################"
        write-host "#---------------------------- END -----------------------------#"
        write-host "################################################################" 
        $path = $PCLogs
        $PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
        if (test-path $PCLogs)
        {
        (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
        }
        else
        {
        (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        }
        <#
        foreach ($EUC in $EUCPCs)
        {
        if (Test-Connection $EUC -Quiet)
        {
        $index = $EUCPCs.IndexOf($EUC)
            If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
            {
                Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
            }
            else
            {
            write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
            }

        }
        }
        Remove-Item $path -force -recurse
        exit
        }
        }
        }
        #>
        }
    }
}
#computer restart end



$os = Get-WmiObject -Class Win32_BIOS -Computer $computer
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
$oldbios = $null
$oldbios = "$($os.SMBIOSBIOSVersion)"
Write-output "Bios version was: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-host ""
Write-host "Bios version was: $($os.SMBIOSBIOSVersion)"
Write-host ""
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
$Bios_OUT = $sourceBios
$Bios_OUT = Split-Path $Bios_OUT -Leaf 
$n = Invoke-Command -Computer $computer -Credential $Script:credentials -ArgumentList $sourceName,$sourceRoot,$sourceCMD,$BiosName,$Bios_OUT -ScriptBlock {

$OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }
		
		# Supend Bitlocker if $OSVolumeEncypted is $true
		if ($OSVolumeEncypted -eq $true) {
			Write-output "Suspending BitLocker protected volume: C:" -Severity 1
            Write-host "Suspending BitLocker protected volume: C:"
			#Manage-Bde -Protectors -Disable C:

		}
Suspend-BitLocker -MountPoint "C:" -RebootCount 1

write-host "Installing thunderbolt software..." -NoNewline
start-process msiexec "/i C:\Temp\Thunderbolt\setup.msi /qn" -wait
write-host "DONE"
for($i=0;$i-le $($args[0]).Length-1;$i++)
{
$folder = Split-Path $($args[1])[$i] -Leaf

write-host "`nInstall Args: C:\Temp\$folder\$($($args[2])[$i])"
Write-host -ForegroundColor Cyan "Installing $(($args[0])[$i])..." -NoNewline

    if($($args[2])[$i] -like "*.msi")
    {
        #start-process msiexec "/i C:\Temp\$($Root[$i])\$($CMD[$i]) /qn" -wait | Out-Host
    }
    else
    {
            Start-Process -FilePath "C:\Windows\System32\CMD.EXE" -ArgumentList "/C cd C:\Temp\$folder & C:\Temp\$folder\$($($args[2])[$i])" -Wait | Out-Host

    }
    write-host "Done"

}
$b = &"C:\Temp\t470client.ps1" -Name $args[0] -Root $args[1] -CMD $args[2] -Biosname $args[3] -Bios $args[4] | Out-Host

#write-host $b
write-output $b
}

#Stop-Transcript
#----------------------Installation------------------------------
#*****************************************************************
write-output $n | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

#wait 10 secs to be sure bios updater is ready
Start-Sleep -s 40 
#Restart no.2 timeout after 5 mins
$timedout = $null # reset any previously set timeout
if (Test-Connection $computer -ErrorAction SilentlyContinue)
{
    #connection good
}
else
{
    write-host -ForegroundColor Cyan "Waiting 2 mins for pc to come back online..." -NoNewline
    Start-Sleep -Seconds 120
    write-host "Done"
}
write-host -ForegroundColor Cyan "Restarting computer started at: " -nonewline
write-host $(get-date)
restart-computer $computer -credential $Script:credentials -force -wait -for PowerShell -Timeout 1000 -Delay 2 -ev timedout -ErrorAction SilentlyContinue
if ($timedout)
{
    write-host "Waiting 2 mins due to timed out restart..." -NoNewline
    write-output "Waiting 2 mins due to timed out restart" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    start-sleep -Seconds 120
    write-host "Done"
    if (test-connection $computer -Quiet)
    {
    #Connection is good
    write-Host "$($computer) restart timed out, but pc is still responsive"
    write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else{
    write-host "Waiting 5 mins due to timed out and not responsive after restart..." -NoNewline
    Start-Sleep -Seconds 300
    write-host "Done"
    if (test-connection $computer -Quiet)
    {
    #Connection is good
    write-Host "$($computer) restart timed out post bios, waited 5 mins and now pc is responsive"
    write-output "$($computer) restart timed out waited post bios, 5 mins and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else
    {
        write-host -ForegroundColor Yellow "$($computer) restart timed out, please check pc"
        write-output "$($computer) restart timed out, please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-Host "adding $($computer) back to list and ending script on this pc"
        write-Host "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
        Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
        Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        write-host "################################################################"
        write-host "#---------------------------- END -----------------------------#"
        write-host "################################################################" 
        $path = $PCLogs
        $PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
        if (test-path $PCLogs)
        {
        (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
        }
        else
        {
        (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        }
        <#
        foreach ($EUC in $EUCPCs)
        {
        if (Test-Connection $EUC -Quiet)
        {
        $index = $EUCPCs.IndexOf($EUC)
            If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
            {
                Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
            }
            else
            {
            write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
            }

        }
        }
        Remove-Item $path -force -recurse
        exit
        }
        }
        }
        #>
        }
    }
}
               
#Display Bios
$os = $null
$os = Get-WmiObject -Class Win32_BIOS -Computer $computer
$afterBios = $null
$afterBios = "$($os.SMBIOSBIOSVersion)"
write-host "Bios Pushed: $Biosname"
if ($afterBios -like "*$BiosName*")
{
    Write-output "Bios matched the version pushed to the pc SUCCESSFULLY" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "Bios version is now: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-host "Bios matched the version pushed to the pc " -NoNewline
    Write-host -ForegroundColor Green "SUCCESSFULLY"
    #Write-host "Bios version is now: $($os.SMBIOSBIOSVersion)"
    Write-host ""
    Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else
{
    if ($oldbios -eq $afterBios)
    {
        Write-Output "Bios version did not change, checking again..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        Write-host "Bios version did not change, checking again..."
        Start-Sleep -s 5
        $os = $null
        $os = Get-WmiObject -Class Win32_BIOS -Computer $computer
        $afterBios = $null
        $afterBios = "$($os.SMBIOSBIOSVersion)"
        if ($oldbios -eq $afterBios)
        {
            write-host -ForegroundColor Cyan "Checking Battery..."
            write-output "Checking Battery..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            $batteries = (Get-WmiObject win32_battery -ComputerName $computer)
            $lowbats = $false
            if($batteries.count)
            {
                foreach($bat in $batteries)
                {
                    if (((Get-WmiObject win32_battery -ComputerName $computer).EstimatedChargeRemaining) -lt 30)
                    {
                        $lowbats = $true
                    }
                }
            }
            else
            {
                if (((Get-WmiObject win32_battery -ComputerName $computer).EstimatedChargeRemaining) -lt 30)
                {
                    $lowbats = $true
                }
            }
            if ($lowbats -eq $true)
            {
                write-host -ForegroundColor Red "`nBATTERY HAS LESS THAN 50% CHARGE BIOS MAY NOT WORK!"
                write-output "[ERROR] BATTERY HAS LESS THAN 30% CHARGE BIOS MAY NOT WORK!" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            else
            {
                write-host -ForegroundColor Green "Battery has 30% or more charge"
                write-output "[SUCCESS] Battery has 30% or more charge" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            Write-Output "Bios version STILL did not change, trying to run bios update again..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            Write-host "Bios version STILL did not change, trying to run bios update again..."
            invoke-command -ComputerName $computer -Credential $Script:credentials -ScriptBlock{
                Write-output "Updating to Bios $($BiosName)..." 
                #Write-host "Updating to Bios $($Bios)..." 
                $OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }
		
		        # Supend Bitlocker if $OSVolumeEncypted is $true
		        if ($OSVolumeEncypted -eq $true) 
                {
			        Write-output "Suspending BitLocker protected volume: C:" -Severity 1
                    Write-host "Suspending BitLocker protected volume: C:"
			        #Manage-Bde -Protectors -Disable C:
		        }
                Suspend-BitLocker -MountPoint "C:" -RebootCount 1
                (&"C:\Temp\Invoke-LenovoBIOSUpdate.ps1" -Path "C:\Temp\Bios") |out-host
                }
            write-host -ForegroundColor Cyan "Waiting 60 secs before restart..." -NoNewline
            start-sleep -Seconds 60
            write-host "Done" -NoNewline
            $timedout = $null # reset any previously set timeout
            write-host -ForegroundColor Cyan "Restarting computer started at: " -nonewline
            write-host $(get-date)
            restart-computer $computer -credential $Script:credentials -force -wait -for PowerShell -Timeout 1000 -Delay 2 -ev timedout -ErrorAction SilentlyContinue
            if ($timedout)
            {
                write-host "Waiting 2 mins due to timed out restart..." -NoNewline
                write-output "Waiting 2 mins due to timed out restart" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                start-sleep -Seconds 120
                write-host "Done"
                if (test-connection $computer -Quiet)
                {
                    #Connection is good
                    write-Host "$($computer) restart timed out, but pc is still responsive"
                    write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                }
                else
                {
                    write-host "Waiting 5 mins due to timed out and not responsive after restart..." -NoNewline
                    Start-Sleep -Seconds 300
                    write-host "Done"
                    if (test-connection $computer -Quiet)
                    {
                        #Connection is good
                        write-Host "$($computer) restart timed out post bios, waited 5 mins and now pc is responsive"
                        write-output "$($computer) restart timed out waited post bios, 5 mins and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    }
                    else
                    {
                        write-host -ForegroundColor Yellow "$($computer) restart timed out, please check pc"
                        write-output "$($computer) restart timed out, please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-Host "adding $($computer) back to list and ending script on this pc"
                        write-Host "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
                        Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
                        Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
                        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-host "################################################################"
                        write-host "#---------------------------- END -----------------------------#"
                        write-host "################################################################" 
                        $path = $PCLogs
                        $PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
                        if (test-path $PCLogs)
                        {
                            (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                        }
                        else
                        {
                            (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        }

                        <#
                        foreach ($EUC in $EUCPCs)
                        {
                        if (Test-Connection $EUC -Quiet)
                        {
                        $index = $EUCPCs.IndexOf($EUC)
                            If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
                            {
                                Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
                            }
                            else
                            {
                            write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
                            }

                        }
                        }
                        Remove-Item $path -force -recurse
                        exit
                        }
                        }
                        }
                        #>
                         Remove-Item $path -force -recurse
                         read-host "Press Enter to Exit"
                        exit

                    }
                }

                Start-Sleep -s 5
                $os = $null
                $os = Get-WmiObject -Class Win32_BIOS -Computer $computer
                $afterBios = $null
                $afterBios = "$($os.SMBIOSBIOSVersion)"
                if ($afterBios -like "*$BiosName*")
                {

                }
                else
                {
                    if ($oldbios -eq $afterBios)
                    {
                        Write-Output "Bios version still did not change and didnt match the bios pushed please verify the bios is up to date on $computer" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        Write-host -ForegroundColor Red "Bios version still did not change and didnt match the bios pushed please verify the bios is up to date on " -nonewline
                        write-host "$computer"
                        read-host "Press Enter to continue"
                    }
                }
            }
            else
            {
                Start-Sleep -s 5
                $os = $null
                $os = Get-WmiObject -Class Win32_BIOS -Computer $computer
                $afterBios = $null
                $afterBios = "$($os.SMBIOSBIOSVersion)"
                if ($afterBios -like "*$BiosName*")
                {
                    Write-output "Bios matched the version pushed to the pc SUCCESSFULLY" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-output "Bios version is now: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-host "Bios matched the version pushed to the pc " -NoNewline
                    Write-host -ForegroundColor Green "SUCCESSFULLY"
                    #Write-host "Bios version is now: $($os.SMBIOSBIOSVersion)"
                    Write-host ""
                    Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

                }
                else
                {
                if ($oldbios -eq $afterBios)
                {
                    Write-Output "Bios version still did not change please verify the bios is up to date on $computer" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-output "Bios version is now: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                     Write-host "Bios version is currently: $($os.SMBIOSBIOSVersion)"
                    Write-host -ForegroundColor Red "Bios version still did not change please verify the bios is up to date on " -nonewline
                    write-host "$computer"
write-output "$($computer) BIOS DID NOT CHANGE (bios ver: $afterBios), please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-Host "adding $($computer) back to list and ending script on this pc"
write-output "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
Write-output "$($computer) BIOS DID NOT CHANGE (bios ver: $afterBios) $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END -----------------------------#"
write-host "################################################################" 
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii
}
<#
foreach ($EUC in $EUCPCs)
{
if (Test-Connection $EUC -Quiet)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {
        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {
    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>

Remove-Item $path -force -recurse
read-host "Press Enter to exit script"
exit

                }
                else
                {
                    Write-output "Bios Changed but didnt match bios pushed" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-output "Bios version is now: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-host "Bios Changed but didnt match bios pushed"
                    #Write-host "Bios version is now: $($os.SMBIOSBIOSVersion)"
                    Write-host ""
                    Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                }
                }

            }
        }
    }
}

Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "Bios version is now: $($os.SMBIOSBIOSVersion)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-host ""
Write-host "Bios version is now: $($os.SMBIOSBIOSVersion)"
Write-host ""
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "Cleaning up Temp Files"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append


#*****************************************************************
#-------------------------- Cleanup -----------------------------
#Start-Transcript -Path $PCLogs -Append

$t = Invoke-Command -Computer $computer -Credential $Script:credentials -ArgumentList $FileRoots, $file -ScriptBlock {


######### SET BIOS ##############

write-host "_-_-_-_-_-_-_- Setting bios _-_-_-_-_-_-_-"
write-output "_-_-_-_-_-_-_- Setting bios _-_-_-_-_-_-_-"
$OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }
		
		# Supend Bitlocker if $OSVolumeEncypted is $true
		if ($OSVolumeEncypted -eq $true) {
			Write-output "Suspending BitLocker protected volume: C:" -Severity 1
            Write-host "Suspending BitLocker protected volume: C:"
			$a = Manage-Bde -Protectors -Disable C:
            write-output $a

		}

$b =Suspend-BitLocker -MountPoint "C:" -RebootCount 1
write-output $b

foreach($setting in $($args[1]))
{
write-host "+++++++++ Setting $setting +++++++++"
write-output "+++++++++ Setting $setting +++++++++"
    $run = "$setting"
    #$run = "$setting,$password,ascii,us"
    $Response = (gwmi -class Lenovo_SetBiosSetting -namespace root\wmi).SetBiosSetting("$run").return
    write-output ("Set Setting... $Response")
    $Response = (gwmi -class Lenovo_SaveBiosSettings -namespace root\wmi).SaveBiosSettings("").return
    write-output ("Saved setting... $Response")
    write-host "+++++++ Finished Setting $setting ++++++++`n"
write-output "+++++++ Finished Setting $setting ++++++++`n"
}
write-host "_-_-_-_-_-_-_- Finished Setting bios _-_-_-_-_-_-_-`n"
write-output "_-_-_-_-_-_-_- Finished Setting bios _-_-_-_-_-_-_-`n"

######### SET BIOS ##############




#Cleanup files pushed

#Files/Folder names that were pushed to C:\Temp
$fileList = @()
for ($i = 0; $i -le ($args).Length-1; $i++){ 
write-host "adding $($args[$i]) to file deletion list"
write-output "adding $($args[$i]) to file deletion list"
$fileList += $args[$i]

}
$filelist += "Bios"


#$fileList = @("t470client.ps1", "Invoke-LenovoBIOSUpdate.ps1", "PMDriver", "ME", "IntelVGA", "n1quj15w")

    #-----------------------Array Loop-----------------------------
foreach ($file in $fileList)
    {
    $newfilepath = "C:\Temp\$($file)"
        #------------Path Test and verify-----------
 if (test-path $newfilepath)
                {
                    Write-Host "$newfilepath file exists"
                    Write-output "$newfilepath file exists"
                    try
                    {
                        #We try to remove...
                        Remove-Item $newfilepath -force -recurse -ErrorAction Stop
                    }
                    catch
                    {
                        #And there will be an error message if it fails
                        Write-Host "Error while deleting $newfilepath on $computer.`n$($Error[0].Exception.Message)"
                        Write-output "Error while deleting $newfilepath on $computer.`n$($Error[0].Exception.Message)"
                        #We skip the rest and go back to the next object in the loop
                        continue
                    }
                    #On sucessful deletion of file...
                    Write-Host  "$newfilepath file deleted"
                    Write-output  "$newfilepath file deleted"
                }
        #------------Path Test and verify-----------

    }
    #-----------------------Array Loop-----------------------------
    }

    #Stop-Transcript

    write-output $t | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

#Restart no.3 timeout after 5 mins
$timedout = $null # reset any previously set timeout
restart-computer $computer -credential $Script:credentials -force -wait -for PowerShell -Timeout 900 -Delay 2 -ev timedout
if ($timedout)
{
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out, but pc is still responsive"
write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
wait -s 60
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out after bios update, waited 60 secs and now pc is responsive"
write-output "$($computer) restart timed out after bios update, waited 60 secs and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
write-host "$($computer) restart timed out after bios update, please check pc"
write-output "$($computer) restart timed out after bios update, please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-Host "adding $($computer) back to list and ending script on this pc"
write-output "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END -----------------------------#"
write-host "################################################################" 
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii
}
<#
foreach ($EUC in $EUCPCs)
{
if (Test-Connection $EUC -Quiet)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {
        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {
    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>

Remove-Item $path -force -recurse
exit
}
}
}
#-------------------------- Cleanup -----------------------------
#*****************************************************************

#Wait for 2 seconds to be sure it's ready
 Start-Sleep -s 2 
#$computer2 = Read-Host -Prompt "Type Full PC name or Serial to begin update"
#************************************************************************
#---------------------- Set AD ------------------------------------------

$Desc = "**NEW** Unassigned Laptop $Model"
$ADcomputer = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$computer'"
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

if ($changeADdesc -eq $true)
{
    Write-host "Setting $($ADcomputer.Name) Description in Active Directory... `n" 
    Write-output "Setting $($ADcomputer.Name) Description in Active Directory... `n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "Old Description: $($ADcomputer.Description)"  | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "New Description: $($Desc)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-host "Old Description: $($ADcomputer.Description)"
    Write-host "New Description: $($Desc)"
    Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Set-ADComputer $computer -Description $Desc -Credential $Script:credentials

    write-host -ForegroundColor cyan "Starting Scheduled Windows Update (with autoreboot)..."
Write-output "[START] Invoke-Windows Update for$($computer) $((Get-Date).ToString())"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}
Setup-IP-Invoke($($ADcomputer.Name))
Invoke-WUJob -ComputerName $($ADcomputer.Name) -Script {ipmo PSWindowsUpdate; Get-WindowsUpdate -install -MicrosoftUpdate -AcceptAll -AutoReboot |out-file "C:\temp\PSWindowsUpdate.log" } -Credential $Script:credentials -RunNow -Confirm:$false -Verbose

start-sleep -Seconds 2
if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
{
    write-host -ForegroundColor Cyan "Computer can't be contacted, waiting 3 mins..." -NoNewline
    Start-Sleep -Seconds 180
    write-host "DONE"
    if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
    {
        write-host -ForegroundColor Yellow "Computer STILL can't be contacted, waiting 3 more mins..." -NoNewline
        Start-Sleep -Seconds 180
        write-host "DONE"
        if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
        {
            write-host -ForegroundColor Yellow "Computer STILL can't be contacted, waiting LAST TIME 3 more mins..." -NoNewline
            Start-Sleep -Seconds 180
            write-host "DONE"
            if(!(Test-Connection $($ADcomputer.Name) -count 1 -quiet -ErrorAction SilentlyContinue))
            {
            write-host -ForegroundColor Red "Computer FAILED TO BE CONTACTED!"
            write-host "Computer FAILED TO BE CONTACTED!" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            else
            {
                $StartWU = $true
            }

        }
        else
        {
            $StartWU = $true
        }
    }
    else
    {
    $StartWU = $true
    }
}
else
{
$StartWU = $true
}

if($StartWU -eq $true)
{
start-sleep -Seconds 5
write-host -ForegroundColor Cyan "Checking Windows Update Status $((Get-Date).ToString())"
write-output "Checking Windows Update Status $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Invoke-Command -ComputerName $($ADcomputer.Name) -Credential $Script:credentials -ScriptBlock {
$WUtimeout = $false
$WUfailure = $false
$WUdone = $false
$i = 0
do{
     $failed = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "failed" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName

     $accepted = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "Accepted" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName

     $Downloaded = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "Downloaded" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName

      $Installed = Get-Item C:\temp\PSWindowsUpdate.log | Select-String -Pattern "Installed" -SimpleMatch |
     Select-Object -Property line | Select-Object -Property Line,PSComputerName
 
    if($accepted -eq $null)
    {
         if($failed -eq $null)
         {

         }
         else
         {
            write-host -ForegroundColor Red "FAILED to ACCEPT UPDATES"
            write-host $failed
            $WUfailure = $true
            break
         }
    }
    else
    {
        if($Downloaded -eq $null)
        {
            write-host -ForegroundColor Cyan "Waiting for download"
            if($failed -eq $null)
            {
            
            }
            else
            {
                write-host -ForegroundColor Red "FAILED to DOWNLOAD UPDATES"
                write-host $failed
                $WUfailure = $true
                break
            }
        }
        else
        {
            if($Installed -eq $null)
            {
                write-host -ForegroundColor Cyan "Installing..."
            }
            else
            {
                if($installed.count -lt $accepted.count -or $installed.count -lt $accepted.count - 1)
                {
                    write-host  -ForegroundColor Cyan "Installing..."
                }
                else
                {
                    write-host -ForegroundColor Cyan "Windows Update Completed!"
                    write-host $Installed
                    $WUdone = $true
                    break
                }
            }
        }
     }
     if($i -ge 120)
     {
         $WUTimeout = $true
         break
     }
     else
     {
         write-host -ForegroundColor Cyan "Waiting 1 min..." -NoNewline
         Start-Sleep -Seconds 60
         write-host "DONE"
     }
     $i++

 }until($WUtimeout -eq $true -or $WUfailure -eq $true -or $WUdone -eq $true)
 }

  $log = Get-Content "\\$($ADcomputer.Name)\C$\temp\PSWindowsUpdate.log" -Raw
 $inlogs = Get-content $PCLogs -Raw
 write-output ($inlogs + $log) |-FilePath "$($PCLogs)" -Encoding ascii
 write-host -ForegroundColor Cyan "Windows Update" -NoNewline
 write-host -ForegroundColor Green " Completed" -NoNewline
 write-host -ForegroundColor Cyan "$((Get-Date).ToString())"
 write-output "Windows Update Complete! $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
 }
 else
 {
    write-host -ForegroundColor RED "WINDOWS UPDATE COULD NOT BE DONE! $((Get-Date).ToString())"
    write-output "WINDOWS UPDATE COULD NOT BE DONE! $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
 }
}
else
{
    Write-host "Description: $($ADcomputer.Description)" 
    Write-output "Description: $($ADcomputer.Description)"  | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}

#Write-output ""| Out-File -FilePath $CompletedList -Encoding ascii -Append
Write-output "$($computer) Completed $((Get-Date).ToString())"| Out-File -FilePath $CompletedList -Encoding ascii -Append
Write-output "$($computer) Completed $((Get-Date).ToString())"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "$($computer)"| Out-File -FilePath $out_UpdateADConnectList -Encoding ascii -Append

write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END -----------------------------#"
write-host "################################################################"
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii
}
<#
foreach ($EUC in $EUCPCs)
{
    if (Test-Connection $EUC -Quiet)
    {
        $index = $EUCPCs.IndexOf($EUC)
        If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
        {
            Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
        }
        else
        {
            write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
        }

    }
}
#>

Remove-Item $path -force -recurse

<#
$logstopush = gc "$PSScriptroot\NeedtoPushlogs.txt"
$readdlogs = New-Object System.Collections.ArrayList
foreach ($log in $logstopush)
{
    if (Test-Path $log)
    {
        foreach ($EUC in $EUCPCs)
        {
            if (Test-Connection $EUC -Quiet)
            {
                $index = $EUCPCs.IndexOf($EUC)
                If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
                {
                    Copy-Item -Path $log -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
                }
                else
                {
                    $readdlogs.Add("$log")
                }
            }
        }
    }   
}
Write-Output $readdlogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii
#>
exit
#---------------------- Set AD ------------------------------------------
#************************************************************************
#}

