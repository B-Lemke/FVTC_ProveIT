﻿param
(
[Parameter(Mandatory=$false)]$computer
)
if(!($computer)){$Param_ErrorMsg = "No value entered for: computer"}
elseif(!($computer -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: computer"}
elseif(!($computer.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: computer"}
if(!($Param_ErrorMsg))
	{
$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        #Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}



#---------------------------------------------------------- 
#STATIC VARIABLES 
#---------------------------------------------------------- 
#$SCRIPT_PARENT   = Split-Path -Parent $MyInvocation.MyCommand.Definition 
 
#---------------------------------------------------------- 
#FUNCTION RepairSCCM 
#---------------------------------------------------------- 
Function Repair_SCCM 
{
Param
(
$PC
)
  Write-Host "[INFO] Get the list of computers from the input file and store it in an array." 
  #$arrComputer = Get-Content ($SCRIPT_PARENT + "\pc_list.txt") 
 $arrComputer = @()
 $arrComputer += "$PC" 
  Foreach ($strComputer In $arrComputer) 
  { 
    #Put an asterisk (*) in front of the lines that need to be skipped in the input file. 
    If ($strComputer.substring(0,1) -ne "*") 
    { 
      Write-Host "[INFO] Starting trigger script for $strComputer." 
      Try 
      { 
        $getProcess = Get-Process -Name ccmrepair* -ComputerName $strComputer 
        If ($getProcess) 
        { 
          Write-Host "[WARNING] SCCM Repair is already running. Script will end." 
          $i = 3601
              continue
        } 
        Else 
        { 
          Write-Host "[INFO] Connect to the WMI Namespace on $strComputer." 
          $SMSCli = [wmiclass] "\\$strComputer\root\ccm:sms_client" 
          Write-Host "[INFO] Trigger the SCCM Repair on $strComputer." 
          # The actual repair is put in a variable, to trap unwanted output. 
          $repair = $SMSCli.RepairClient() 
          
          Write-Host "[INFO] Successfully connected to the WMI Namespace and triggered the SCCM Repair on $strComputer." 
          ########## START - PROCESS / PROGRESS CHECK AND RUN 
          # Comment the lines below if it is unwanted to wait for each repair to finish and trigger multiple repairs quickly. 
          Write-Host "[INFO] Wait (a maximum of 60 minutes) for the repair to actually finish."
          $m = -1 
          For ($i = 0; $i -le 3600; $i++) 
          { 
            if ($i % 60 -eq 0)
            {
            $m += 1
            
            }
            else
            {
            $s = $i % 60
            }
            $checkProcess = Get-Process -Name ccmrepair* -ComputerName $strComputer 
            Start-Sleep 1
            if ($m -eq 0)
            { 
            Write-Progress -Activity "Repairing client $strComputer ..." -Status "Repair running for $s seconds ..." 
            }
            else
            {
            Write-Progress -Activity "Repairing client $strComputer ..." -Status "Repair running for $m Minutes and $s seconds ..." 
            }
            If ($checkProcess -eq $Null) 
            { 
              Write-Host "[INFO] SCCM Client repair ran for $i seconds." 
              Write-Host "[INFO] SCCM Client repair process ran successfully on $strComputer." 
              Write-Host "[INFO] Check \\$strComputer\c$\Windows\CCM\Logs\CCMRepair.log to make sure it was successful."
              $i = 3601
              continue
            } 
            ElseIf ($i -eq 3600) 
            { 
              Write-Host "[ERROR] Repair ran for more than 60 minutes. repair attempt will end and process will be stopped." 
              $end = read-host "hit enter to end the proccess"
              Invoke-Command -Computer $strComputer { Get-Process -Name ccmrepair* | Stop-Process -Force } 
               
            } 
          } 
          ########## END - PROCESS / PROGRESS CHECK AND RUN 
 
        } 
      } 
      Catch 
      { 
        Write-Host "[WARNING] Either the WMI Namespace connect or the SCCM Repair trigger returned an error." 
        Write-Host "[WARNING] This is most likely caused, because there is already a repair trigger running." 
        Write-Host "[WARNING] Wait a couple of minutes and try again." 
        # If the script keeps throwing errors, the WMI Namespace on $strComputer might be corrupt. 
      } 
    } 
  } 
} 
# RUN SCRIPT  
#Repair_SCCM  
#Finished 


$ErrorActionPreference = "Silentlycontinue"

if(!($computer))
{
Set-QuickEdit
$computerName = read-host -prompt "Enter full pc name"
$computerName = $computerName.Trim()
}
else
{
$computerName = $computer
}
Set-QuickEdit -DisableQuickEdit



if(Test-Connection $computerName -Count 1 -Quiet -ErrorAction SilentlyContinue)
{
$SMSCli = [wmiclass] "\\$computerName\root\ccm:SMS_Client"

write-output "Triggering Actions"

for ($i = 1; $i -lt 225; $i++)
{
if ($i -lt 10)
{
Write-Progress -Activity "Triggering Config actions on $computername..." -Status "Attempting to trigger {00000000-0000-0000-0000-00000000000$i}..." 
#write-output "Attempting to trigger {00000000-0000-0000-0000-00000000000$i}"
try{
$SMSCli.TriggerSchedule("{00000000-0000-0000-0000-00000000000$i}")
}
catch{

Write-Verbose "{00000000-0000-0000-0000-000000000$i} ACTION NOT FOUND"
}
}
elseif($i -gt 9 -and $i -lt 100)
{
Write-Progress -Activity "Triggering Config actions on $computername..." -Status "Attempting to trigger {00000000-0000-0000-0000-0000000000$i}..." 
#write-output "Attempting to trigger {00000000-0000-0000-0000-0000000000$i}"
try{
$SMSCli.TriggerSchedule("{00000000-0000-0000-0000-0000000000$i}")
}
catch{
Write-Verbose "{00000000-0000-0000-0000-000000000$i} ACTION NOT FOUND"
}
}
elseif($i -gt 99)
{
Write-Progress -Activity "Triggering Config actions on $computername..." -Status "Attempting to trigger {00000000-0000-0000-0000-000000000$i}..." 
#write-output "Attempting to trigger {00000000-0000-0000-0000-000000000$i}"
Try{
 $SMSCli.TriggerSchedule("{00000000-0000-0000-0000-000000000$i}")
}
catch{
Write-Verbose "{00000000-0000-0000-0000-000000000$i} ACTION NOT FOUND"
}
if ($trigger)
{

}
}

}
$command = "gpupdate /force"
$cmd = "CMD.EXE /c" + $command
write-host "Starting gpupdate."
invoke-wmimethod -ComputerName $computerName -class win32_process -name create -argumentlist $cmd | Out-null
write-host "Finished running Config actions for $computerName"
}
else
{
write-Host -ForegroundColor Red "$computerName was not able to be contacted"

}
write-output "`n"
Set-QuickEdit
Read-Host "`nPress Enter to exit"
exit
}
else
{
write-host "Run Config Actions: $Param_ErrorMsg"
Read-Host "`nPress Enter to exit"
exit
}
