Param
(
[switch]$changeADdesc
)

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

cls
Set-QuickEdit -DisableQuickEdit
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $Script:NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User = $Script:NonAdmin_User.trim()
            $Script:NonAdmin_User1 = "AFII\$($Script:NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Script:NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}
    #***************************************************************
    #-------------------------IGNORE THIS ADMIN PROMPTING-----------
    Set-Location "C:\"
    if ($changeADdesc -eq $true)
    {
        write-host "Change AD Description Switch is set to true"
        [bool]$changeADdesc1 = $true
    }
    else
    {
        write-host "Change AD Description Switch is set to false"
        [bool]$changeADdesc1 = $false
    }

    $scriptPath = "$($PSScriptRoot)"
    #$Root = (get-item $scriptPath).Parent.FullName
    $root = "$($PSScriptRoot)"
    Import-Module $Root\Modules\Excel.psm1

   
    #**************************************************************



    #-------Import-----------
    import-module ActiveDirectory
    #-------Import-----------

    $PCList = "pc_list.txt"
    $CompletedList = "CompletedList.txt"

    #Name of the folder on your desktop  where you want individual PC logs to be stored (C:\USERS\YOUR NONADMIN ACCOUNT\DESKTOP\THIS VALUE)
    $PCLogsFolderName = "CompletedLogs"

    #***************************************************************************************
    #---------------------------------OPTIONAL CHANGES END-------------------------------
    #***************************************************************************************

    if (test-Path "$($Root)\$($PCLogsFolderName)")
    {

    }
    else
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$($Root)\$($PCLogsFolderName)")
    }

    if (test-Path "$($Root)\$($PCList)")
    {
        write-host "Found PC list text file"
    }
    else
    {
        write-host "PC list text file not found"
        write-host "make sure this file is located in the in the same folder this script was run from"
    }


    #***************************************************************
    #-------------------------Directories---------------------------
    #**************************************************************
    $PCList = "$($Root)\$($PCList)"
    $Dir = "$($Root)\savedPSFiles"
    $out_PCLogsFolderPath = "$($Root)\$($PCLogsFolderName)"
    $out_CompletedList = "$($Root)\$($CompletedList)"
    $out_PCList = "$($PCList)"
    #$out_UpdateADConnectList = "$($Root)\RecentlyImagedList.txt"
    #***************************************************************
    #-------------------------Directories---------------------------
    #**************************************************************



    Check-Credentials

    #*************************************************
    #---------------For Each PC in List End----------
    #*************************************************
    $PCRunningScript = hostname
    $EUCPCs = @()
    $EUCUsers = @()
    $EUC = @{bwienk1 = "WILG00MP18YWSB";mjung11 = "WILG00PF0RCUKC"}
    foreach ($key in $EUC.Keys)
    {
        if ($EUC[$key] -ne $PCRunningScript)
        {
            $EUCPCs += $EUC[$key]
            $EUCUsers += $key
        }
    }

    #***************************************************************
    #------------------------Mapping Drive---------------------------
    #**************************************************************
    Try{
        New-PSDrive -Name "G" -PSProvider FileSystem -Root "\\aah.local\aah\Public" -Credential $Script:credentials2
    }
    Catch [System.UnauthorizedAccessException]
    {
        write-host "Problem with mapping G Drive with NonAdmin Credentials, attempting to map with Admin Credentials"
        Try{
            New-PSDrive -Name "G" -PSProvider FileSystem -Root "\\aah.local\aah\Public" -Credential $Script:credentials
        }
        Catch
        {
            write-host "Problem with mapping G Drive with either credentials"
            write-host "Error:"
            write-host $_
            $exit = Read-Host -Prompt "press enter to exit"
            exit
        }
    }

    #***************************************************************
    #------------------------Mapping Drive---------------------------
    #**************************************************************

    $Models = @("T470", "T480", "X270", "7010", "7020", "7040")

    foreach($pcmodel in $Models)
    {
        if (test-Path "G:\Temp\bwienk\$($pcmodel)\Bios\$($pcmodel)Bios.xlsx")
        {
                write-host "Copying new Bios instructions for $pcmodel version $BiosDocVer_Server"
                Copy-Item -Path "G:\Temp\bwienk\$($pcmodel)\Bios\$($pcmodel)Bios.xlsx" -Recurse -Destination "$($root)\Bios\$($pcmodel)Bios.xlsx" -Container -Force
                Copy-Item -Path "G:\Temp\bwienk\$($pcmodel)\Bios\$($pcmodel)Bios.xlsx" -Recurse -Destination "$($root)\xferfiles\$($pcmodel)\Bios\$($pcmodel)Bios.xlsx" -Container -Force   
        }
        else
        {
            if(test-path "G:\Temp\bwienk\$($pcmodel)")
            {
                write-host "Server Bios instructions not found for $pcmodel Copying new Bios instructions for $pcmodel version $BiosDocVer_Local"
                Copy-Item -Path "$($root)\Bios\$($pcmodel)Bios.xlsx" -Recurse -Destination "G:\Temp\bwienk\$($pcmodel)\Bios\$($pcmodel)Bios.xlsx" -Container -Force
            }
            else
            {
                write-host "Server files for $pcmodel not found, Copying files to server"
                Copy-Item -Path "$($root)\xferfiles\$($pcmodel)" -Recurse -Destination "G:\Temp\bwienk" -Container -Force
            }
        }

        if (test-Path "G:\Temp\bwienk\$($pcmodel)\Drivers\$($pcmodel)Drivers.xlsx")
        {
            write-host "Copying new Driver instructions for $pcmodel"
            Copy-Item -Path "G:\Temp\bwienk\$($pcmodel)\Drivers\$($pcmodel)Drivers.xlsx" -Recurse -Destination "$($root)\Drivers\$($pcmodel)Drivers.xlsx" -Container -Force
            Copy-Item -Path "G:\Temp\bwienk\$($pcmodel)\Drivers\$($pcmodel)Drivers.xlsx" -Recurse -Destination "$($root)\xferfiles\$($pcmodel)\Drivers\$($pcmodel)Drivers.xlsx" -Container -Force   
        }
        else
        {
  
        }
    }

    $sourceName = @()
    $sourceRoot = @()
    $sourceCMD = @()

    $t470Loaded = 0
    $t470sourceName = @()
    $t470sourceRoot = @()
    $t470sourceCMD = @()

    $t480Loaded = 0
    $t480sourceName = @()
    $t480sourceRoot = @()
    $t480sourceCMD = @()

    $x270Loaded = 0
    $x270sourceName = @()
    $x270sourceRoot = @()
    $x270sourceCMD = @()

    $7010Loaded = 0
    $7010sourceName = @()
    $7010sourceRoot = @()
    $7010sourceCMD = @()

    $7020Loaded = 0
    $7020sourceName = @()
    $7020sourceRoot = @()
    $7020sourceCMD = @()

    $7040Loaded = 0
    $7040sourceName = @()
    $7040sourceRoot = @()
    $7040sourceCMD = @()


    (gc $PCList) | ? {$_.trim() -ne "" } | set-content $PCList
    write-output "" | Out-File -FilePath "$($PCList)" -Encoding ascii -Append 
    $computers = Get-Content $PCList
    $readdList = @()
    $aryComputers = @()

    #*************************************************
    #---------------For Each PC in List Start----------
    #*************************************************
    foreach ($line in $computers)
    {
        Get-Content $PCList | where { $_ -ne "$($line)" } | out-file $PCList
        $line = $line.Trim()

         #---------variable adapter--------
        $PC = $line
         #---------variable adapter--------

        #****************************************************
        #------ Filter and Modify Adapter START---------------
        #****************************************************

        If ($PC -like "WILG000*")
        {
            #WI laptop Dell
            $PC = $PC -replace "WILG000"
        }
        elseif ($PC -like "WILG00*")
        {
            #WI laptop Lenovo
            $PC = $PC -replace "WILG00"
        }
        elseif ($PC -like "WIDG000*")
        {
            #WI Desktop Dell
            $PC = $PC -replace "WIDG000"
        }
        elseif ($PC -like "WIDG00*")
        {
            #WI Desktop Lenovo?
            $PC = $PC -replace "WIDG00"
        }
        elseif ($PC -like "AZLG000*")
        {
            #AZ laptop dell
            $PC = $PC -replace "AZLG000"
        }
        elseif ($PC -like "AZLG00*")
        {
            #AZ laptop lenovo
            $PC = $PC -replace "AZLG00"
        }
        elseif ($PC -like "AZDG000*")
        {
            #AZ Desktop dell
            $PC = $PC -replace "AZDG000"
        }
        elseif ($PC -like "AZDG00*")
        {
            #AZ Desktop lenovo?
            $PC = $PC -replace "AZDG00"
        }
        elseif ($PC -like "NVLG000*")
        {
            #LV laptop dell
            $PC = $PC -replace "NVLG000"
        }
        elseif ($PC -like "NVLG00*")
        {
            #LV laptop lenovo
            $PC = $PC -replace "NVLG00"
        }
        elseif ($PC -like "NVDG000*")
        {
            #LV Desktop dell
            $PC = $PC -replace "NVDG000"
        }
        elseif ($PC -like "NVDG00*")
        {
            #LV Desktop lenovo?
            $PC = $PC -replace "NVDG00"
        }
        elseif ($PC -like "WIVGP*")
        {
            #VDI's To be added
        }

        #****************************************************
        #------ Filter and Modify Adapter END---------------
        #****************************************************

        if($PC -eq "")
        {
            continue
        }
        $PCLogs = "$($out_PCLogsFolderPath)\Temp\$($PC).txt"
        if (test-path $($PCLogs))
        {
            Clear-Content $($PCLogs)
        }
        #****************************************************
        #-------------------Obtain AD Record START-----------
        #****************************************************
        write-host "`nStarted Setup Script for $PC $((Get-Date).ToString())"
        write-output "Started Setup Script for $PC $((Get-Date).ToString())"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

        $ADcomputer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$PC'")

        $secCheck = $false

        if($($ADcomputer.Count) -gt 1)
        {
            Write-Host "Too many Computers found for $($PC)"

            foreach ($entry in $ADcomputer)
            {
                write-host "$($ADcomputer.Indexof($entry)) = $($entry.Name) - $($entry.Description)"
            }
            write-host "none = None of these"
            $inputToFilter = Read-host -prompt "Enter Number of selection that should be used for $($PC)"
            if ($inputToFilter -like "none")
            {
                #TOO MANY RESULTS
                write-Host "$($PC) Brought back too many matches in AD"
                write-Host "readding $($PC) back to list and moving to next pc"
                write-output "$($PC) Brought back too many matches in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
                $readdList += $($PC)
                Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
                Write-output "$($PC) Failed due to too many results returned from AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append

                write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-host "################################################################"
                write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
                write-host "################################################################" 

                $path = $PCLogs
                $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
                if (test-path $PCLogs)
                {
                    (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                }
                else
                {
                    (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                }

                <#
                foreach ($EUC in $EUCPCs)
                {
                    if (Test-Connection $EUC -Quiet)
                    {
                        $index = $EUCPCs.IndexOf($EUC)
                        If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                        {
                            Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                        }
                        else
                        {
                            write-output $PCLogs | Out-File -FilePath "$Root\NeedtoPushlogs.txt" -Encoding ascii -Append
                        }
                    }
                }
                #>
                Remove-Item $path -force -recurse
                continue
            }
            else
            {
                try
                {
                    $selection = [int]$inputToFilter
                    $PC = $ADcomputer[$selection].Name
                    $ADcomputer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$PC'")
                    
                    if($($ADcomputer.Count) -gt 1)
                    {
                        Write-Host "Too many Computers found for $($PC)"
                        #TOO MANY RESULTS
                        write-Host "$($PC) Brought back too many matches in AD"
                        write-Host "readding $($PC) back to list and moving to next pc"
                        write-output "$($PC) Brought back too many matches in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
                        $readdList += $($PC)
                        Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
                        Write-output "$($PC) Failed due to too many results returned from AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append

                        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-host "################################################################"
                        write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
                        write-host "################################################################" 

                        $path = $PCLogs
                        $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
                        if (test-path $PCLogs)
                        {
                            (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                        }
                        else
                        {
                            (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        }

                        <#
                        foreach ($EUC in $EUCPCs)
                        {
                            if (Test-Connection $EUC -Quiet)
                            {
                                $index = $EUCPCs.IndexOf($EUC)
                                If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                                {
                                    Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                                }
                                else
                                {
                                    write-output $PCLogs | Out-File -FilePath "$Root\NeedtoPushlogs.txt" -Encoding ascii -Append
                                }
                            }
                        }
                        #>
                        Remove-Item $path -force -recurse
                        continue
                    }
                    elseif($($ADcomputer.Count) -lt 1)
                    {
                        Write-Host "No results found for $($PC)"
                        #TOO MANY RESULTS
                        write-Host "$($PC) Brought back no matches in AD"
                        write-Host "readding $($PC) back to list and moving to next pc"
                        write-output "$($PC) Brought back no matches in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
                        $readdList += $($PC)
                        Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
                        Write-output "$($PC) Failed due to no results returned from AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append

                        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        write-host "################################################################"
                        write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
                        write-host "################################################################" 

                        $path = $PCLogs
                        $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
                        if (test-path $PCLogs)
                        {
                            (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                        }
                        else
                        {
                            (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        }
                        <#
                        foreach ($EUC in $EUCPCs)
                        {
                            if (Test-Connection $EUC -Quiet)
                            {
                                $index = $EUCPCs.IndexOf($EUC)
                                If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                                {
                                    Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                                }
                                else
                                {
                                    write-output $PCLogs | Out-File -FilePath "$Root\NeedtoPushlogs.txt" -Encoding ascii -Append
                                }
                            }
                        }
                        #>
                        Remove-Item $path -force -recurse
                        continue
                    }
                    elseif ($($ADcomputer.Count) -eq 1)
                    {
                        write-host "Found PC - $($ADcomputer.name)"
                        $computer = $ADcomputer.Name
                        $aryComputers += $computer
                        $secCheck = $true
                    }
                }
                catch
                {
                    write-host $_
                }
            }
        }
        elseif ($ADcomputer.Count -lt 1)
        {
            #TOO MANY RESULTS
            write-Host "$($PC) Brought back no matches in AD"
            write-Host "readding $($PC) back to list and moving to next pc"
            write-output "$($PC) Brought back no matches in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
            $readdList += $($PC)
            Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
            Write-output "$($PC) Failed due to no results returned from AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append

            write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            write-host "################################################################"
            write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
            write-host "################################################################" 

            $path = $PCLogs
            $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
            if (test-path $PCLogs)
            {
                (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
            }
            else
            {
                (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            <#  
            foreach ($EUC in $EUCPCs)
            {
                if (Test-Connection $EUC -Quiet)
                {
                    $index = $EUCPCs.IndexOf($EUC)
                    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                    {
                        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                    }
                    else
                    {
                        write-output $PCLogs | Out-File -FilePath "$Root\NeedtoPushlogs.txt" -Encoding ascii -Append
                    }
                }
            }
            #>
            Remove-Item $path -force -recurse
            continue
        }
        if ($secCheck -eq $false)
        {
            $ADcomputer = $ADcomputer[0]
            $computer = $ADcomputer.Name
            $aryComputers += $computer
        }

        if ($computer)
        {
            write-host "Starting Reboot of $computer (computer will timeout after 9 mins if unresponsive after reboot)...`n`n"
            $computer1 = $null
            $PC1 = $null
            $readdList1 = $null
            $out_CompletedList1 = $null
            $out_PCList1 = $null
            $Root1 = $null
            $EUCPCs1 = $null
            $NonAdmin_User2 = $null
            $PCLogs1 = $null
            $out_PCLogsFolderPath1 = $null

            $a = start-job -name $computer -ScriptBlock{

                param(
                    [string]$computer1,
                    [string]$PC1,
                    [string[]]$readdList1,
                    [string]$out_CompletedList1,
                    [string]$out_PCList1,
                    [string]$Root1,
                    [System.Collections.ArrayList]$EUCPCs1,
                    $NonAdmin_User2,
                    $PCLogs1,
                    $out_PCLogsFolderPath1
                    )

                $timedout = $null # reset any previously set timeout
                restart-computer $computer1 -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
                if ($timedout)
                {
                    if (test-connection $computer1 -Quiet)
                    {
                        #Connection is good
                        write-Host "$($computer1) restart timed out, but pc is still responsive"
                        write-output "$($computer1) restart timed out, but pc is still responsive" | Out-File -FilePath "$($out_PCLogsFolderPath1)\Temp\$($PC1).txt" -Encoding ascii -Append
                    }
                    else
                    {
                        write-Host "$($computer1) restart timed out, please check pc"
                        write-Host "adding $($computer1) back to list and moving to next pc"
                        write-output "$($computer1) restart timed out, please check pc" | Out-File -FilePath "$($out_PCLogsFolderPath1)\Temp\$($PC1).txt" -Encoding ascii -Append
                        write-output "adding $($computer1) back to list and moving to next pc" | Out-File -FilePath "$($out_PCLogsFolderPath1)\Temp\$($PC1).txt" -Encoding ascii -Append
                        $readdList1 += $($computer1)
                        Write-output "$($computer1)"| Out-File -FilePath $out_PCList1 -Encoding ascii -Append
                        Write-output "$($computer1) Failed due restart timedout $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList1 -Encoding ascii -Append

                        write-output "################################################################" | Out-File -FilePath "$($out_PCLogsFolderPath1)\Temp\$($PC1).txt" -Encoding ascii -Append
                        write-output "#---------------------------- END $computer1 -----------------------------#" | Out-File -FilePath "$($out_PCLogsFolderPath1)\Temp\$($PC1).txt" -Encoding ascii -Append
                        write-output "################################################################" | Out-File -FilePath "$($out_PCLogsFolderPath1)\Temp\$($PC1).txt" -Encoding ascii -Append
                        write-host "################################################################"
                        write-host "#---------------------------- END $computer1 -----------------------------#"
                        write-host "################################################################" 

                        $path = $PCLogs1
                        #$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
                        if (test-path $PCLogs1)
                        {
                            (Get-Content $path -Raw) + (Get-Content "$($out_PCLogsFolderPath1)\$($computer1).txt" -Raw) | Set-Content $PCLogs1
                        }
                        else
                        {
                            (Get-Content $path -Raw) | Out-File -FilePath "$($out_PCLogsFolderPath1)\$($computer1).txt" -Encoding ascii -Append
                        }

                        <#
                        foreach ($EUC in $EUCPCs1)
                        {
                            if (Test-Connection $EUC -Quiet)
                            {
                                $index = $EUCPCs1.IndexOf($EUC)
                                If (Test-Path "\\$EUC\C$\users\$($EUCUsers1[$index])\Desktop\PCBatchUpdater\EUCLogs\$NonAdmin_User2")
                                {
                                    Copy-Item -Path "$($out_PCLogsFolderPath1)\$($computer1).txt" -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers1[$index])\Desktop\PCBatchUpdater\EUCLogs\$NonAdmin_User2\$($computer1).txt" -Container -Force
                                }
                                else
                                {
                                    write-output "$($out_PCLogsFolderPath1)\$($computer1).txt" | Out-File -FilePath "$Root1\NeedtoPushlogs.txt" -Encoding ascii -Append
                                }
                            }
                        }
                        #>
                        Remove-Item $path -force -recurse
                    }
                }
            } -ArgumentList(
            $computer,
            $PC,
            $readdList,
            $out_CompletedList,
            $out_PCList,
            $Root,
            $EUCPCs,
            $Script:NonAdmin_User,
            $PCLogs,
            $out_PCLogsFolderPath
            ) > $Null
        }
    }

    $t = 0
    $timedoutreboot = $false
    write-host "Waiting for all Computers to finish Rebooting (or timeout)..."
    while (((Get-Job).State -contains "Running") -and $t -lt 600) 
    {
        Start-Sleep -Seconds 1
        cls
        if ($t -gt 599 -or $t -eq 599)
        {
            $timedoutreboot = $true
            write-host -ForegroundColor Cyan  "REBOOT RESULTS"
            write-host -ForegroundColor Cyan  "-----------------------------------------"
            write-host -ForegroundColor Cyan "Seconds passed: " -NoNewline
            write-host " $t`n"
            get-job |  ForEach-Object{write-host -ForegroundColor Cyan  "Rebooting " -nonewline; write-host "$($_.Name)" -NoNewline; write-host -ForegroundColor Cyan  " status: " -nonewline ; write-host "$($_.State)"}
            write-host -ForegroundColor Cyan  "-----------------------------------------"
            Write-Host -ForegroundColor red "REBOOT TIMED OUT DETECTED!"
            $t += 1
        }
        else
        {
            write-host -ForegroundColor Cyan  "REBOOT STATUS"
            write-host -ForegroundColor Cyan  "-----------------------------------------"
            write-host -ForegroundColor Cyan "Seconds passed: " -NoNewline
            write-host " $t`n"
            get-job |  ForEach-Object{write-host -ForegroundColor Cyan  "Rebooting " -nonewline; write-host "$($_.Name)" -NoNewline; write-host -ForegroundColor Cyan  " status: " -nonewline ; write-host "$($_.State)"}
            write-host -ForegroundColor Cyan  "-----------------------------------------"
            Write-Host -ForegroundColor Cyan "Waiting for all jobs to complete..."
            $t += 1
        }
    
    }
        cls
        write-host -ForegroundColor Cyan  "REBOOT RESULTS"
        write-host -ForegroundColor Cyan  "-----------------------------------------"
        write-host -ForegroundColor Cyan "Seconds passed: " -NoNewline
        write-host " $t`n"
        get-job |  ForEach-Object{
            write-host -ForegroundColor Cyan  "Rebooting " -nonewline
            write-host "$($_.Name)" -NoNewline
            write-host -ForegroundColor Cyan  " status: " -nonewline
            if ($($_.State) -contains "Running")
            {
                write-host -ForegroundColor Red "TIMED OUT"
                $timedoutreboot = $true
            }
            else
            {
                write-host "$($_.State)"
            }  
        }
        write-host -ForegroundColor Cyan  "-----------------------------------------"

        if($timedoutreboot -eq $true)
        {
            Write-Host -ForegroundColor red "REBOOT TIMED OUT DETECTED!"
        }
        else
        {
            Write-Host -ForegroundColor cyan "`nRebooting Computers Completed in $t Seconds`n"
        }

    #(Get-Job | Wait-Job ) > $Null
    (Get-Job | Receive-Job |Stop-job |Remove-Job) > $Null
    #write-host "`nAll Computers to finished Rebooting (or timedout)!`n"

    foreach($computer in $aryComputers)
    {
        if($computer)
        {
            write-host "Getting $computer information..."
            #RESETUP PC TO CURRENT COMPUTER IN ARRAY
            $PC = $computer
            If ($PC -like "WILG000*")
            {
                #WI laptop Dell
                $PC = $PC -replace "WILG000"
            }
            elseif ($PC -like "WILG00*")
            {
                #WI laptop Lenovo
                $PC = $PC -replace "WILG00"
            }
            elseif ($PC -like "WIDG000*")
            {
                #WI Desktop Dell
                $PC = $PC -replace "WIDG000"
            }
            elseif ($PC -like "WIDG00*")
            {
                #WI Desktop Lenovo?
                $PC = $PC -replace "WIDG00"
            }
            elseif ($PC -like "AZLG000*")
            {
                #AZ laptop dell
                $PC = $PC -replace "AZLG000"
            }
            elseif ($PC -like "AZLG00*")
            {
                #AZ laptop lenovo
                $PC = $PC -replace "AZLG00"
            }
            elseif ($PC -like "AZDG000*")
            {
                #AZ Desktop dell
                $PC = $PC -replace "AZDG000"
            }
            elseif ($PC -like "AZDG00*")
            {
                #AZ Desktop lenovo?
                $PC = $PC -replace "AZDG00"
            }
            elseif ($PC -like "NVLG000*")
            {
                #LV laptop dell
                $PC = $PC -replace "NVLG000"
            }
            elseif ($PC -like "NVLG00*")
            {
                #LV laptop lenovo
                $PC = $PC -replace "NVLG00"
            }
            elseif ($PC -like "NVDG000*")
            {
                #LV Desktop dell
                $PC = $PC -replace "NVDG000"
            }
            elseif ($PC -like "NVDG00*")
            {
                #LV Desktop lenovo?
                $PC = $PC -replace "NVDG00"
            }
            elseif ($PC -like "WIVGP*")
            {
                #VDI's To be added
            }

            #RESETUP LOGS
            $PCLogs = $PCLogs = "$($out_PCLogsFolderPath)\Temp\$($PC).txt"

            $PCModel = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $computer

            if (($PCModel.Model -like "20JN*") -or ($PCModel.Model -like "20JM*") -or ($PCModel.Model -like "20HE*") -or ($PCModel.Model -like "20HD*"))
            {
                #T470
                $Model = "T470"
                write-Host "$($computer) detected as Model: $($Model)"
                if ($t470Loaded -eq 0)
                {
                    #Drivers and Bios not loaded from excel yet

                    ###################################################################
                    #-----------------------t470 Bios Load----------------------------
                    ###################################################################
                    write-Host "Loading t470 bios from excel documents..."
                    $xl3 = New-Object -COM "Excel.Application"
                    $xl3.Visible = $false
                    $wb3 = $xl3.Workbooks.Open("$($Root)\Bios\T470Bios.xlsx")
                    $ws3 = $wb3.Sheets.Item(1)

                    $WorksheetRange3 = $ws3.UsedRange
                    $RowCount3 = $WorksheetRange3.Rows.Count
                    $ColumnCount3 = $WorksheetRange3.Columns.Count
                    #Dump Arrays:
                    $T1 = @()
                    $T2 = @()
                    $T3 = @()

                    for ($t = 1; $t -le $ColumnCount3; $t++)
                    {
                       for ($ir = 2; $ir -le $RowCount3; $ir++)
                       {
                            #get data:
                            $testB = $ws3.Cells.Item($ir, $t).Text
                            if ($t -eq 1){$T1 += $testB}
                            if ($t -eq 2){$T2 += $testB}
                            if ($t -eq 3){$T3 += $testB}
                        }
                    }

                    $t470BiosName = $T1[0]
                    $t470sourceBios = $T2[0]
                    $t470BiosScript = $T3[0]

                    #clean up
                    $wb3.Close()
                    $xl3.Quit()
                    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)
                    ###################################################################
                    #-----------------------t470 Bios Load----------------------------
                    ###################################################################

                    ###################################################################
                    #-----------------------t470 Driver Load----------------------------
                    ###################################################################
                    write-Host "Loading t470 drivers from excel documents..."
                    $xl = New-Object -COM "Excel.Application"
                    $xl.Visible = $false
                    $wb = $xl.Workbooks.Open("$($Root)\Drivers\T470Drivers.xlsx")
                    $ws = $wb.Sheets.Item(1)

                    $WorksheetRange = $ws.UsedRange
                    $RowCount = $WorksheetRange.Rows.Count
                    $ColumnCount = $WorksheetRange.Columns.Count

                    #Dump Arrays:
                    $c1 = @()
                    $c2 = @()
                    $c3 = @()

                    for ($c = 1; $c -le $ColumnCount; $c++)
                    {
                        for ($i = 2; $i -le $RowCount; $i++)
                        {
                            #get data:
                            $test2 = $ws.Cells.Item($i, $c).Text
                            if ($c -eq 1){$c1 += $test2}
                            if ($c -eq 2){$c2 += $test2}
                            if ($c -eq 3){$c3 += $test2}
                        }
                    }

                    ###############
                    #FOR LOOP for each $i count
                    for ($i = 0; $i -le $c1.Length-1; $i++) 
                    {
                        #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
                        $t470sourceName += $c1[$i]
                        $t470sourceRoot += $c2[$i]
                        $t470sourceCMD += $c3[$i]
                    }
                    ###############
                    #FOR LOOP for each $i count

                    #clean up
                    $wb.Close()
                    $xl.Quit()
                    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)
                    ###################################################################
                    #-----------------------t470 Driver Load----------------------------
                    ###################################################################

                    $t470Loaded = 1
                }
                else
                {
                    #Drivers and Bios already loaded from excel
                }
                $sourceBios = $t470sourceBios
                $BiosName = $t470BiosName
                $BiosScript = $t470BiosScript
                $sourceName = $t470sourceName
                $sourceRoot = $t470sourceRoot
                $sourceCMD = $t470sourceCMD
                #BIOS Script
                $PSFile1 = "G:\Temp\bwienk\T470\Invoke-LenovoBIOSUpdate.ps1"
                #Driver Script
                $PSFile2 = "G:\Temp\bwienk\T470\t470client.ps1"
            }
            elseif (($PCModel.Model -like "20L5*") -or ($PCModel.Model -like "20L6*"))
            {
                #T480
                $Model = "T480"
                write-Host "$($computer) detected as Model: $($Model)"
                if ($t480Loaded -eq 0)
                {
                    #Drivers and Bios not loaded from excel yet

                    ###################################################################
                    #-----------------------t480 Bios Load----------------------------
                    ###################################################################
                    write-Host "Loading t480 bios from excel documents..."
                    $xl3 = New-Object -COM "Excel.Application"
                    $xl3.Visible = $false
                    $wb3 = $xl3.Workbooks.Open("$($Root)\Bios\T480Bios.xlsx")
                    $ws3 = $wb3.Sheets.Item(1)

                    $WorksheetRange3 = $ws3.UsedRange
                    $RowCount3 = $WorksheetRange3.Rows.Count
                    $ColumnCount3 = $WorksheetRange3.Columns.Count
                    #Dump Arrays:
                    $T1 = @()
                    $T2 = @()
                    $T3 = @()

                    for ($t = 1; $t -le $ColumnCount3; $t++)
                    {
                       for ($ir = 2; $ir -le $RowCount3; $ir++)
                       {
                            #get data:
                            $testB = $ws3.Cells.Item($ir, $t).Text
                            if ($t -eq 1){$T1 += $testB}
                            if ($t -eq 2){$T2 += $testB}
                            if ($t -eq 3){$T3 += $testB}
                            else
                            {
    
                            } 
                        }
                    }

                    $t480BiosName = $T1[0]
                    $t480sourceBios = $T2[0]
                    $t480BiosScript = $T3[0]

                    #clean up
                    $wb3.Close()
                    $xl3.Quit()
                    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)
                    ###################################################################
                    #-----------------------t480 Bios Load----------------------------
                    ###################################################################

                    ###################################################################
                    #-----------------------t480 Driver Load----------------------------
                    ###################################################################
                    write-Host "Loading t480 drivers from excel documents..."
                    $xl = New-Object -COM "Excel.Application"
                    $xl.Visible = $false
                    $wb = $xl.Workbooks.Open("$($Root)\Drivers\T480Drivers.xlsx")
                    $ws = $wb.Sheets.Item(1)

                    $WorksheetRange5 = $ws5.UsedRange
                    $RowCount5 = $WorksheetRange5.Rows.Count
                    $ColumnCount5 = $WorksheetRange5.Columns.Count

                    #Dump Arrays:
                    $c1 = @()
                    $c2 = @()
                    $c3 = @()


                    for ($c = 1; $c -le $ColumnCount5; $c++)
                    {
                        for ($i = 2; $i -le $RowCount; $i++)
                        {
                        #get data:
                        $test2 = $ws.Cells.Item($i, $c).Text
                        if ($c -eq 1){$c1 += $test2}
                        if ($c -eq 2){$c2 += $test2}
                        if ($c -eq 3){$c3 += $test2}
                        }
                    }

                    ###############
                    #FOR LOOP for each $i count
                    for ($i = 0; $i -le $c1.Length-1; $i++) 
                    {
                    #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
                    $t480sourceName += $c1[$i]
                    $t480sourceRoot += $c2[$i]
                    $t480sourceCMD += $c3[$i]
                    }
                    ###############
                    #FOR LOOP for each $i count

                    #clean up
                    $wb.Close()
                    $xl.Quit()
                    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)
                    ###################################################################
                    #-----------------------t480 Driver Load----------------------------
                    ###################################################################

                    $t480Loaded = 1
                }
                else
                {
                    #Drivers and Bios already loaded from excel
                }
                $sourceBios = $t480sourceBios
                $BiosName = $t480BiosName
                $BiosScript = $t480BiosScript
                $sourceName = $t480sourceName
                $sourceRoot = $t480sourceRoot
                $sourceCMD = $t480sourceCMD
                #BIOS Script
                $PSFile1 = "G:\Temp\bwienk\T470\Invoke-LenovoBIOSUpdate.ps1"
                #Driver Script
                $PSFile2 = "G:\Temp\bwienk\T470\t470client.ps1"
            }
            elseif (($PCModel.Model -like "20K6*") -or ($PCModel.Model -like "20HN*") -or ($PCModel.Model -like "20HM*"))
            {
                #x270
                $Model = "X270"
                write-Host "$($computer) detected as Model: $($Model)"
                if ($x270Loaded -eq 0)
                {
                #Drivers and Bios not loaded from excel yet
                ###################################################################
                #-----------------------x270 Driver Load----------------------------
                ###################################################################
                write-Host "Loading x270 drivers from excel documents..."
                $xl5 = New-Object -COM "Excel.Application"
                $xl5.Visible = $false
                $wb5 = $xl5.Workbooks.Open("$($Root)\Drivers\X270Drivers.xlsx")
                $ws5 = $wb5.Sheets.Item(1)

                $WorksheetRange5 = $ws5.UsedRange
                $RowCount5 = $WorksheetRange5.Rows.Count
                $ColumnCount5 = $WorksheetRange5.Columns.Count

                #Dump Arrays:
                $Q1 = @()
                $Q2 = @()
                $Q3 = @()

                ###############
                #FOR LOOP for each $c count
                for ($c = 1; $c -le $ColumnCount5; $c++)
                {
                    ###############
                    #FOR LOOP for each $i count
                    for ($i = 2; $i -le $RowCount5; $i++)
                    {
                        #get data:
                        $testD = $ws5.Cells.Item($i, $c).Text
                        if ($c -eq 1){$Q1 += $testD}
                        if ($c -eq 2){$Q2 += $testD}
                        if ($c -eq 3){$Q3 += $testD}
                    }
                    ###############
                    #FOR LOOP for each $i count
                }
                ###############
                #FOR LOOP for each $c count

                for ($i = 0; $i -le $Q1.Length-1; $i++) 
                {
                    #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
                    $x270sourceName += $Q1[$i]
                    $x270sourceRoot += $Q2[$i]
                    $x270sourceCMD += $Q3[$i]
                }

                #clean up:
                $wb5.Close()
                $xl5.Quit()
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl5)
                ###################################################################
                #-----------------------x270 Driver Load----------------------------
                ###################################################################

                ###################################################################
                #-----------------------x270 Bios Load----------------------------
                ###################################################################
                write-Host "Loading x270 bios from excel documents..."
                $xl4 = New-Object -COM "Excel.Application"
                $xl4.Visible = $false
                $wb4 = $xl4.Workbooks.Open("$($Root)\Bios\X270Bios.xlsx")
                $ws4 = $wb4.Sheets.Item(1)

                $WorksheetRange4 = $ws4.UsedRange
                $RowCount4 = $WorksheetRange4.Rows.Count
                $ColumnCount4 = $WorksheetRange4.Columns.Count

                #Dump Arrays
                $Z1 = @()
                $Z2 = @()
                $Z3 = @()
                for ($t = 1; $t -le $ColumnCount4; $t++)
                {
                    for ($ir = 2; $ir -le $RowCount4; $ir++)
                    {
                        #get data:
                        $testC = $ws4.Cells.Item($ir, $t).Text
                        if ($t -eq 1){$Z1 += $testC}
                        if ($t -eq 2){$Z2 += $testC}
                        if ($t -eq 3){$Z3 += $testC}
                    }
                }

                $x270BiosName = $Z1[0]
                $x270sourceBios = $Z2[0]
                $x270BiosScript = $Z3[0]

                #clean up
                $wb4.Close()
                $xl4.Quit()
                [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl4)
                ###################################################################
                #-----------------------x270 Bios Load----------------------------
                ###################################################################
                $x270Loaded = 1
                }
                else
                {
                    #Drivers and Bios already loaded from excel
                }

                $sourceBios = $x270sourceBios
                $BiosName = $x270BiosName
                $BiosScript = $x270BiosScript
                $sourceName = $x270sourceName
                $sourceRoot = $x270sourceRoot
                $sourceCMD = $x270sourceCMD
                #BIOS Script (works with t470 one as parameters are passed that ar x270s)
                $PSFile1 = "G:\Temp\bwienk\T470\Invoke-LenovoBIOSUpdate.ps1"
                #Driver Script (works with t470 one as parameters are passed that ar x270s)
                $PSFile2 = "G:\Temp\bwienk\T470\t470client.ps1"
            }
            elseif ($PCModel.Model -like "*OptiPlex*")
            {
                Copy-Item -Path "$Root\XferFiles\Modules\DellBIOSProvider" -Recurse -Destination "\\$computer\C$\Temp" -Container -Force
                #DELLs
                if($PCModel.Model -like "*7010*")
                {
                    #optiplex 7010
                    $Model = "7010"
                    write-Host "$($computer) detected as Model: $($Model)"
                    if($7010Loaded -eq 0)
                    {
                        #Drivers and Bios not loaded from excel yet
                        ###################################################################
                        #-----------------------7010 Bios Load----------------------------
                        ###################################################################
                        write-Host "Loading 7010 bios from excel documents..."
                        $xl3 = New-Object -COM "Excel.Application"
                        $xl3.Visible = $false
                        $wb3 = $xl3.Workbooks.Open("$($Root)\Bios\7010Bios.xlsx")
                        $ws3 = $wb3.Sheets.Item(1)

                        $WorksheetRange3 = $ws3.UsedRange
                        $RowCount3 = $WorksheetRange3.Rows.Count
                        $ColumnCount3 = $WorksheetRange3.Columns.Count
                        #Dump Arrays:
                        $DE1 = @()
                        $DE2 = @()
                        $DE3 = @()

                        for ($t = 1; $t -le $ColumnCount3; $t++)
                        {
                            for ($ir = 2; $ir -le $RowCount3; $ir++)
                            {
                                #get data:
                                $testB = $ws3.Cells.Item($ir, $t).Text
                                if ($t -eq 1){$DE1 += $testB}
                                if ($t -eq 2){$DE2 += $testB}
                                if ($t -eq 3){$DE3 += $testB}
                            }
                        }

                        $7010BiosName = $DE1[0]
                        $7010sourceBios = $DE2[0]
                        $7010BiosScript = $DE3[0]

                        #clean up
                        $wb3.Close()
                        $xl3.Quit()
                        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)

                        ###################################################################
                        #-----------------------7010 Bios Load----------------------------
                        ###################################################################

                        ###################################################################
                        #-----------------------7010 Driver Load----------------------------
                        ###################################################################
                        write-Host "Loading 7010 drivers from excel documents..."
                        $xl6 = New-Object -COM "Excel.Application"
                        $xl6.Visible = $false
                        $wb6 = $xl6.Workbooks.Open("$($Root)\Drivers\7010Drivers.xlsx")
                        $ws6 = $wb6.Sheets.Item(1)

                        $WorksheetRange6 = $ws6.UsedRange
                        $RowCount6 = $WorksheetRange6.Rows.Count
                        $ColumnCount6 = $WorksheetRange6.Columns.Count

                        #Dump Arrays:
                        $D1 = @()
                        $D2 = @()
                        $D3 = @()

                        for ($c = 1; $c -le $ColumnCount6; $c++)
                        {
                            for ($i = 2; $i -le $RowCount6; $i++)
                            {
                                #get data:
                                $testF = $ws6.Cells.Item($i, $c).Text
                                if ($c -eq 1){$D1 += $testF}
                                if ($c -eq 2){$D2 += $testF}
                                if ($c -eq 3){$D3 += $testF}
                            }
                        }

                        ###############
                        #FOR LOOP for each $i count
                        for ($i = 0; $i -le $D1.Length-1; $i++) 
                        {
                            #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
                            $7010sourceName += $D1[$i]
                            $7010sourceRoot += $D2[$i]
                            $7010sourceCMD += $D3[$i]
                        }
                        ###############
                        #FOR LOOP for each $i count

                        #clean up
                        $wb6.Close()
                        $xl6.Quit()
                        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl6)
                        ###################################################################
                        #-----------------------7010 Driver Load----------------------------
                        ###################################################################
                        $7010Loaded = 1
                    }
                    else
                    {
                        #Drivers and Bios already loaded from excel
                    }
        
                    $sourceBios = $7010sourceBios
                    $BiosName = $7010BiosName
                    $BiosScript = $7010BiosScript
                    $sourceName = $7010sourceName
                    $sourceRoot = $7010sourceRoot
                    $sourceCMD = $7010sourceCMD
                    #BIOS Script
                    $PSFile1 = "G:\Temp\bwienk\7010\UpdateDrivers.ps1"
                    #Driver Script
                    $PSFile2 = "G:\Temp\bwienk\7010\dellclient.ps1"
                }
                elseif($PCModel.Model -like "*7020*")
                {
                    #optiplex 7010
                    $Model = "7020"
                    write-Host "$($computer) detected as Model: $($Model)"

                    if($7020Loaded -eq 0)
                    {
                        #Drivers and Bios not loaded from excel yet
                        ###################################################################
                        #-----------------------7020 Bios Load----------------------------
                        ###################################################################
                        write-Host "Loading 7020 bios from excel documents..."
                        $xl3 = New-Object -COM "Excel.Application"
                        $xl3.Visible = $false
                        $wb3 = $xl3.Workbooks.Open("$($Root)\Bios\7020Bios.xlsx")
                        $ws3 = $wb3.Sheets.Item(1)

                        $WorksheetRange3 = $ws3.UsedRange
                        $RowCount3 = $WorksheetRange3.Rows.Count
                        $ColumnCount3 = $WorksheetRange3.Columns.Count
                        #Dump Arrays:
                        $YE1 = @()
                        $YE2 = @()
                        $YE3 = @()

                        for ($t = 1; $t -le $ColumnCount3; $t++)
                        {
                            for ($ir = 2; $ir -le $RowCount3; $ir++)
                            {
                                #get data:
                                $testB = $ws3.Cells.Item($ir, $t).Text
                                if ($t -eq 1){$YE1 += $testB}
                                if ($t -eq 2){$YE2 += $testB}
                                if ($t -eq 3){$YE3 += $testB}
                            }
                        }

                        $7020BiosName = $YE1[0]
                        $7020sourceBios = $YE2[0]
                        $7020BiosScript = $YE3[0]

                        #clean up
                        $wb3.Close()
                        $xl3.Quit()
                        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)

                        ###################################################################
                        #-----------------------7020 Bios Load----------------------------
                        ###################################################################

                        ###################################################################
                        #-----------------------7020 Driver Load----------------------------
                        ###################################################################
                        write-Host "Loading 7020 drivers from excel documents..."
                        $xl6 = New-Object -COM "Excel.Application"
                        $xl6.Visible = $false
                        $wb6 = $xl6.Workbooks.Open("$($Root)\Drivers\7020Drivers.xlsx")
                        $ws6 = $wb6.Sheets.Item(1)

                        $WorksheetRange6 = $ws6.UsedRange
                        $RowCount6 = $WorksheetRange6.Rows.Count
                        $ColumnCount6 = $WorksheetRange6.Columns.Count

                        #Dump Arrays:
                        $Y1 = @()
                        $Y2 = @()
                        $Y3 = @()

                        for ($c = 1; $c -le $ColumnCount6; $c++)
                        {
                            for ($i = 2; $i -le $RowCount6; $i++)
                            {
                                #get data:
                                $testF = $ws6.Cells.Item($i, $c).Text
                                if ($c -eq 1){$Y1 += $testF}
                                if ($c -eq 2){$Y2 += $testF}
                                if ($c -eq 3){$Y3 += $testF}
                            }
                        }

                        ###############
                        #FOR LOOP for each $i count
                        for ($i = 0; $i -le $Y1.Length-1; $i++) 
                        {
                            #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
                            $7020sourceName += $Y1[$i]
                            $7020sourceRoot += $Y2[$i]
                            $7020sourceCMD += $Y3[$i]
                        }
                        ###############
                        #FOR LOOP for each $i count

                        #clean up
                        $wb6.Close()
                        $xl6.Quit()
                        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl6)
                        ###################################################################
                        #-----------------------7020 Driver Load----------------------------
                        ###################################################################
                        $7020Loaded = 1
                    }
                    else
                    {
                        #already loaded    
                    }
                    $sourceBios = $7020sourceBios
                    $BiosName = $7020BiosName
                    $BiosScript = $7020BiosScript
                    $sourceName = $7020sourceName
                    $sourceRoot = $7020sourceRoot
                    $sourceCMD = $7020sourceCMD
                    #BIOS Script
                    $PSFile1 = "G:\Temp\bwienk\7010\UpdateDrivers.ps1"
                    #Driver Script
                    $PSFile2 = "G:\Temp\bwienk\7010\dellclient.ps1" #works with the 7010client ps1 file
                }
                elseif($PCModel.Model -like "*7040*")
                {
                    #optiplex 7040
                    $Model = "7040"
                    write-Host "$($computer) detected as Model: $($Model)"
                    if($7040Loaded -eq 0)
                    {
                        #Drivers and Bios not loaded from excel yet
                        ###################################################################
                        #-----------------------7040 Bios Load----------------------------
                        ###################################################################
                        write-Host "Loading 7040 bios from excel documents..."
                        $xl3 = New-Object -COM "Excel.Application"
                        $xl3.Visible = $false
                        $wb3 = $xl3.Workbooks.Open("$($Root)\Bios\7040Bios.xlsx")
                        $ws3 = $wb3.Sheets.Item(1)

                        $WorksheetRange3 = $ws3.UsedRange
                        $RowCount3 = $WorksheetRange3.Rows.Count
                        $ColumnCount3 = $WorksheetRange3.Columns.Count
                        #Dump Arrays:
                        $YER1 = @()
                        $YER2 = @()
                        $YER3 = @()

                        for ($t = 1; $t -le $ColumnCount3; $t++)
                        {
                            for ($ir = 2; $ir -le $RowCount3; $ir++)
                            {
                                #get data:
                                $testB = $ws3.Cells.Item($ir, $t).Text
                                if ($t -eq 1){$YER1 += $testB}
                                if ($t -eq 2){$YER2 += $testB}
                                if ($t -eq 3){$YER3 += $testB}
                            }
                        }

                        $7040BiosName = $YER1[0]
                        $7040sourceBios = $YER2[0]
                        $7040BiosScript = $YER3[0]

                        #clean up
                        $wb3.Close()
                        $xl3.Quit()
                        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl3)

                        ###################################################################
                        #-----------------------7040 Bios Load----------------------------
                        ###################################################################

                        ###################################################################
                        #-----------------------7040 Driver Load----------------------------
                        ###################################################################
                        write-Host "Loading 7040 drivers from excel documents..."
                        $xl6 = New-Object -COM "Excel.Application"
                        $xl6.Visible = $false
                        $wb6 = $xl6.Workbooks.Open("$($Root)\Drivers\7040Drivers.xlsx")
                        $ws6 = $wb6.Sheets.Item(1)

                        $WorksheetRange6 = $ws6.UsedRange
                        $RowCount6 = $WorksheetRange6.Rows.Count
                        $ColumnCount6 = $WorksheetRange6.Columns.Count

                        #Dump Arrays:
                        $YR1 = @()
                        $YR2 = @()
                        $YR3 = @()

                        for ($c = 1; $c -le $ColumnCount6; $c++)
                        {
                            for ($i = 2; $i -le $RowCount6; $i++)
                            {
                                #get data:
                                $testF = $ws6.Cells.Item($i, $c).Text
                                if ($c -eq 1){$YR1 += $testF}
                                if ($c -eq 2){$YR2 += $testF}
                                if ($c -eq 3){$YR3 += $testF}
                            }
                        }

                        ###############
                        #FOR LOOP for each $i count
                        for ($i = 0; $i -le $YR1.Length-1; $i++) 
                        {
                            #pass c1[$i] to name, c2[$i] to path, c3[$i] to cmd
                            $7040sourceName += $YR1[$i]
                            $7040sourceRoot += $YR2[$i]
                            $7040sourceCMD += $YR3[$i]
                        }
                        ###############
                        #FOR LOOP for each $i count

                        #clean up
                        $wb6.Close()
                        $xl6.Quit()
                        [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl6)
                        ###################################################################
                        #-----------------------7040 Driver Load----------------------------
                        ###################################################################
                        $7040Loaded = 1
                    }
                    else
                    {
                        #Drivers and Bios already loaded
                    }
                    $sourceBios = $7040sourceBios
                    $BiosName = $7040BiosName
                    $BiosScript = $7040BiosScript
                    $sourceName = $7040sourceName
                    $sourceRoot = $7040sourceRoot
                    $sourceCMD = $7040sourceCMD

                    #BIOS Script
                    $PSFile1 = "G:\Temp\bwienk\7010\UpdateDrivers.ps1"
                    #Driver Script
                    $PSFile2 = "G:\Temp\bwienk\7010\dellclient.ps1" #works with the 7010client ps1 file
                }
            }

            #Test Connect to PC
            if (test-connection $computer -Quiet)
            {
                #Connection is good
            }
            else
            {
                write-output "Read from file: $($PC)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "Read from Active Directory: $($computer)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "$($computer) unreachable currently" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-host "adding $($PC) back to PC text file" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
                $readdList += $($PC)
                Write-output "$($PC) Failed due to unreachable $((Get-Date).ToString())"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
                write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "#---------------------------- END -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-host "################################################################"
                write-host "#---------------------------- END -----------------------------#"
                write-host "################################################################" 

                $path = $PCLogs
                $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
                if (test-path $PCLogs)
                {
                    (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                }
                else
                {
                    (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                }
                <#
                foreach ($EUC in $EUCPCs)
                {
                    if (Test-Connection $EUC -Quiet)
                    {
                        $index = $EUCPCs.IndexOf($EUC)
                        If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                        {
                            Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                        }
                        else
                        {
                            write-output $PCLogs | Out-File -FilePath "$root\NeedtoPushlogs.txt" -Encoding ascii -Append
                        }
                    }
                }
                #>
                Remove-Item $path -force -recurse
                continue
            }
            #****************************************************
            #-------------------Obtain AD Record END-------------
            #****************************************************

            #****************************************************************************************************
            #-------set destination folder on the Target PC from local perpective and remote perpective START----
            #****************************************************************************************************
            $LocalRoot = "C:\Temp\"
            $RemoteRoot = "\\$($computer)\c$\Temp\"
            #****************************************************************************************************
            #-------set destination folder on the Target PC from local perpective and remote perpective END----
            #****************************************************************************************************


            write-output $PC | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            Write-output $computer | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append  

            write-host "Finished getting $computer information!`n"

            #**********************************************
            #------------------ Xfer --------------------
            #DRIVERS
            $FilesSkipped = 0
            for($i=0;$i-le $sourceName.Length-1;$i++)
            {
                if ($FilesSkipped -eq 1)
                {
                    Write-output "$($sourceName[$i]) Skipped as one file as already failed" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-Host "$($sourceName[$i]) Skipped as one file as already failed"
                    continue
                }
                Write-output "Copying $($sourceName[$i]) $($i+1) of $($sourceName.Length)..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-Host "Copying $($sourceName[$i]) $($i+1) of $($sourceName.Length)..."
                If (Test-Path $sourceRoot[$i])
                {
                    Copy-Item -Path $sourceRoot[$i] -Recurse -Destination $RemoteRoot -Container -Force
                }
                else
                {
                    [string[]]$aryPath = @($sourceRoot[$i].Split('\'))
                    $intIndex = $aryPath.IndexOf("bwienk")
                    $intPathInd = $intIndex + 1
                    $RootFile = $aryPath[$intPathInd]
                    Write-output "$($sourceName[$i]) Failed to copy from server, attempting to copy files to server from local..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-Host "$($sourceName[$i]) Failed to copy from server, attempting to copy files to server from local..."

        
                    if (test-path "$($Root)\XferFiles\$($RootFile)")
                    {
                        Copy-Item -Path "$($Root)\XferFiles\$($RootFile)" -Recurse -Destination "G:\Temp\bwienk" -Container -Force
                        If (Test-Path $sourceRoot[$i])
                        {
                            Write-output "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                            Write-Host "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server"
                            Copy-Item -Path $sourceRoot[$i] -Recurse -Destination $RemoteRoot -Container -Force
                        }
                        else
                        {
                            Write-output "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                            Write-Host "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server"
                            $FilesSkipped = 1
                            continue
                        }
                    }
                    else
                    {
                        write-host "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"
                        Write-output "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        $FilesSkipped = 1
                        continue
                    }
                } 
            }
            #BIOS
            if ($FilesSkipped -eq 1)
            {
                Write-output "One or more files could not be copied to the PC, adding PC back to list and moving to next PC" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-Host "One or more files could not be copied to the PC, adding PC back to list and moving to next PC"
                write-host "adding $($computer) back to PC text file"
                write-output "adding $($computer) back to PC text file"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-output "$($computer)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
                $readdList += $($computer)
                Write-output "$($computer) Failed due to copy files failed $((Get-Date).ToString())"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
                write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                write-host "################################################################"
                write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
                write-host "################################################################" 
    
                $path = $PCLogs
                $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
                if (test-path $PCLogs)
                {
                    (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                }
                else
                {
                    (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                }
                <#
                foreach ($EUC in $EUCPCs)
                {
                    if (Test-Connection $EUC -Quiet)
                    {
                        $index = $EUCPCs.IndexOf($EUC)
                        If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                        {
                            Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                        }
                        else
                        {
                            write-output $PCLogs | Out-File -FilePath "$Root\NeedtoPushlogs.txt" -Encoding ascii -Append
                        }
                    }
                }
                #>
                Remove-Item $path -force -recurse
                continue
            }
            write-host "Xfering Bios files..."
            Write-output "Xfering Bios files..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

            if (Test-Path $sourceBios)
            {
                Copy-Item -Path $sourceBios -Recurse -Destination $RemoteRoot -Container -Force
            }
            else
            {
                Write-output "$($sourceBios) Failed to copy from server, attempting to copy files to server from local..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-Host "$($sourceBios) Failed to copy from server, attempting to copy files to server from local..."

                [string[]]$aryPath = @($sourceBios.Split('\'))
                $intIndex = $aryPath.IndexOf("bwienk")
                $intPathInd = $intIndex + 1
                $RootFile = $aryPath[$intPathInd]

                if (test-path "$($Root)\XferFiles\$($RootFile)")
                {
                    Copy-Item -Path "$($Root)\XferFiles\$($RootFile)" -Recurse -Destination "G:\Temp\bwienk" -Container -Force
                    If (Test-Path $sourceRoot[$i])
                    {
                        Write-output "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        Write-Host "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server"
                        Copy-Item -Path $sourceBios -Recurse -Destination $RemoteRoot -Container -Force
                    }
                    else
                    {
                        Write-output "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        Write-Host "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server"
                        $FilesSkipped = 1
                    }
                }
                else
                {
                    write-host "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"
                    Write-output "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    $FilesSkipped = 1
                }
            }
            if ($FilesSkipped -eq 0)
            {
                #PS files
                Write-output "Xfering Local PS file..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-host "Xfering Local PS file..."
                if($PSFile1 -like "SKIP")
                {
                    #Skipped
                    Write-host "PSFile1 not needed"
                }
                else
                {
                    If (Test-Path $PSFile1)
                    {
                        Copy-Item -Path $PSFile1 -Recurse -Destination $RemoteRoot -Container -Force
                    }
                    else
                    {
                        Write-output "$($PSFile1) Failed to copy from server, attempting to copy files to server from local..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        Write-Host "$($PSFile1) Failed to copy from server, attempting to copy files to server from local..."

                        [string[]]$aryPath = @($PSFile1.Split('\'))
                        $intIndex = $aryPath.IndexOf("bwienk")
                        $intPathInd = $intIndex + 1
                        $RootFile = $aryPath[$intPathInd]
                        if (test-path "$($Root)\XferFiles\$($RootFile)")
                        {
                            Copy-Item -Path "$($Root)\XferFiles\$($RootFile)" -Recurse -Destination "G:\Temp\bwienk" -Container -Force
                            If (Test-Path $PSFile1)
                            {
                                Write-output "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                                Write-Host "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server"
                                Copy-Item -Path $PSFile1 -Recurse -Destination $RemoteRoot -Container -Force
                            }
                            else
                            {
                                Write-output "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                                Write-Host "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server"
                                $FilesSkipped = 1
                            }
                        }
                        else
                        {
                            write-host "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"
                            Write-output "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                            $FilesSkipped = 1
                        }
                    }
                }
                if($PSFile2 -like "SKIP")
                {
                    #Skipped
                    Write-host "PSFile2 not needed"
                }
                else
                {
                    If (Test-Path $PSFile2)
                    {
                        Copy-Item -Path $PSFile2 -Recurse -Destination $RemoteRoot -Container -Force
                    }
                    else
                    {
                        Write-output "$($PSFile2) Failed to copy from server, attempting to copy files to server from local..." | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                        Write-Host "$($PSFile2) Failed to copy from server, attempting to copy files to server from local..."

                        [string[]]$aryPath = @($PSFile2.Split('\'))
                        $intIndex = $aryPath.IndexOf("bwienk")
                        $intPathInd = $intIndex + 1
                        $RootFile = $aryPath[$intPathInd]
                        if (test-path "$($Root)\XferFiles\$($RootFile)")
                        {
                            Copy-Item -Path "$($Root)\XferFiles\$($RootFile)" -Recurse -Destination "G:\Temp\bwienk" -Container -Force
                            If (Test-Path $PSFile2)
                            {
                                Write-output "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                                Write-Host "$($Root)\XferFiles\$($RootFile) ...Successfully copied to server"
                                Copy-Item -Path $PSFile2 -Recurse -Destination $RemoteRoot -Container -Force
                            }
                            else
                            {
                                Write-output "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                                Write-Host "$($Root)\XferFiles\$($RootFile) ...Failed to copy to server"
                                $FilesSkipped = 1
                            }
                        }
                        else
                        {
                            write-host "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"
                            Write-output "$($Root)\XferFiles\$($RootFile) could not be found to be able to copy to server"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                            $FilesSkipped = 1
                        }
                    }
                }
                if ($FilesSkipped -eq 1)
                {
                    Write-output "One or more files could not be copied to the PC, adding PC back to list and moving to next PC" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-Host "One or more files could not be copied to the PC, adding PC back to list and moving to next PC"
                    write-host "adding $($computer) back to PC text file"
                    write-output "adding $($computer) back to PC text file"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    Write-output "$($computer)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
                    $readdList += $($computer)
                    Write-output "$($computer) Failed due to copy files failed $((Get-Date).ToString())"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
                    write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    write-host "################################################################"
                    write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
                    write-host "################################################################" 
            
                    $path = $PCLogs
                    $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
                    if (test-path $PCLogs)
                    {
                        (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
                    }
                    else
                    {
                        (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                    }
                    <#
                    foreach ($EUC in $EUCPCs)
                    {
                        if (Test-Connection $EUC -Quiet)
                        {
                            $index = $EUCPCs.IndexOf($EUC)
                            If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                            {
                                Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                            }
                            else
                            {
                                write-output $PCLogs | Out-File -FilePath "$Root\NeedtoPushlogs.txt" -Encoding ascii -Append
                            }
                        }
                    }
                    #>
                    Remove-Item $path -force -recurse
                    continue
                }
                #Finishing
                Write-host "Finished Xfer.`n"
                Write-output "Finished Xfer.`n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
                Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            #------------------ Xfer --------------------
            #**********************************************
            $strPasstemp = $strPass
            $strPassClean = "`'$strPass`'"
            $strPass = $strPassClean
            $strPasstemp2 = $strPass2
            $strPass2Clean = "`'$strPass2`'"
            $strPass2 = $strPass2

            #**********************************************
            #------------------ Model Filter --------------
            (Get-Job |Wait-Job) > $Null
            (Get-Job | Receive-Job) > $Null

            write-host "###############################################################################"
            write-host "#--------- Started Batch Base script for $($computer) $((Get-Date).ToString())-------#"
            write-host "###############################################################################" 

            Write-output "starting BatchBase script for $($computer) $((Get-Date).ToString())`n"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

            if(($Model -eq "T470") -or ($Model -eq "T480") -or ($Model -eq "X270"))
            {
                if ($changeADdesc -eq $true)
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\LenovoUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}" -ChangeADDesc' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model)
                }
                else
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\LenovoUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}"' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model)
                }
            }
            elseif($Model -eq "7010")
            {
                if ($changeADdesc -eq $true)
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\DellUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}" -changeADDesc' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model);
                }
                else
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\DellUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}"' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model);
                }
            }
            elseif($Model -eq "7020")
            {
                if ($changeADdesc -eq $true)
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\DellUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}" -changeADDesc' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model);
                }
                else
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\DellUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}"' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model);
                }
            }
            elseif($Model -eq "7040")
            {
                if ($changeADdesc -eq $true)
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\DellUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}" -changeADDesc' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model);
                }
                else
                {
                    $output = Start-Process Powershell -Verb runas -ArgumentList ('"{0}\DellUpdaterBatchBase.ps1" -line "{1}" -PCList "{2}" -out_PCLogsFolderPath "{3}" -CompletedList "{4}" -PCLogs "{5}" -ScriptRoot "{6}" -Model "{7}"' -f $Dir, $computer, $PCList, $out_PCLogsFolderPath, $out_CompletedList, $PCLogs, $Root, $Model);
                }
            }
            $strPass = $strPasstemp
            $strPass2 = $strPasstemp2

            write-host "`n-----------------------------------------------------------------------------------------------------"
            write-host "-------------------------------------- NEXT COMPUTER  -----------------------------------------------"
            write-host "-----------------------------------------------------------------------------------------------------`n"
        }
        else 
        { 
            $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
            write-Host "$($PC) is not found in AD"
            write-output "$($PC) is not found in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
            Write-output "$($PC)"| Out-File -FilePath $out_PCList -Encoding ascii -Append
            Write-output "adding $($PC) back to PC text file" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            $readdList += $($PC)
            Write-output "$($PC) Failed due to not found in AD $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
            write-host "adding $($PC) back to PC text file"

            write-output "#####################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            write-output "#####################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            write-host "#####################################################################"
            write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
            write-host "#####################################################################" 
            #$computer2 = Read-Host -Prompt "press enter to exit"
            $path = $PCLogs
            $PCLogs = "$($out_PCLogsFolderPath)\$($PC).txt"
            if (test-path $PCLogs)
            {
                (Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
            }
            else
            {
                (Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
            }
            <#
            foreach ($EUC in $EUCPCs)
            {
                if (Test-Connection $EUC -Quiet)
                {
                    $index = $EUCPCs.IndexOf($EUC)
                    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                    {
                        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($PC).txt" -Container -Force
                    }
                    else
                    {
                        write-output $PCLogs | Out-File -FilePath "$root\NeedtoPushlogs.txt" -Encoding ascii -Append
                    }
                }
            }
            #>
            Remove-Item $path -force -recurse
            continue
        }
    }
    (Get-Job | Wait-Job) > $null
    (Get-Job | Receive-Job) > $null
    $readdlogs = New-Object System.Collections.ArrayList
    foreach ($failedpc in $readdList)
    {
        Write-output "$($failedpc)"| Out-File -FilePath $PCList -Encoding ascii -Append
    }
    <#
    $logstopush = gc "$root\NeedtoPushlogs.txt"

    foreach ($log in $logstopush)
    {
        if (Test-Path "$log")
        {
            Write-host "`nLog found: $log`n"
            foreach ($EUC in $EUCPCs)
            {
                if (Test-Connection $EUC -Quiet)
                {
                    Write-host "Found $EUC"
                    $index = $EUCPCs.IndexOf($EUC)
                    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User")
                    {
                        Write-host "Found filepath: \\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User"
                        Write-host "Copying logs to other EUC members`n"
                        Copy-Item -Path $log -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
                    }
                    else
                    {
                        Write-host "FilePath Not found: \\$EUC\C$\users\$($EUCUsers[$index])\Desktop\PCBatchUpdater\EUCLogs\$Script:NonAdmin_User"
                        Write-host "Readding log`n"
                        $readdlogs.Add("$log")
                    }
                }
            }
        }   
    }
    $readdlogs | Out-File -FilePath "$root\NeedtoPushlogs.txt" -Encoding ascii
    #>
    Set-QuickEdit
    $computer2 = Read-Host -Prompt "press enter to exit"
    exit
}
else 
{
    #************************************************************************
    #-----------------------START ADMIN PS-----------------------------------
    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
    #-----------------------START ADMIN PS-----------------------------------
    #************************************************************************
}
