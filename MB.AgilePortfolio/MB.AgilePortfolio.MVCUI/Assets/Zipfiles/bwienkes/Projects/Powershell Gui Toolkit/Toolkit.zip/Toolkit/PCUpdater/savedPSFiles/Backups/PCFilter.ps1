﻿param
(
[string]$PC
)

If ($PC -like "WILG000*")
{
#WI laptop Dell
$PC = $PC -replace "WILG000"
}
elseif ($PC -like "WILG00*")
{
#WI laptop Lenovo
$PC = $PC -replace "WILG00"
}
elseif ($PC -like "WIDG000*")
{
#WI Desktop Dell
$PC = $PC -replace "WIDG000"
}
elseif ($PC -like "WIDG00*")
{
#WI Desktop Lenovo?
$PC = $PC -replace "WIDG00"
}
elseif ($PC -like "AZLG000*")
{
#AZ laptop dell
$PC = $PC -replace "AZLG000"
}
elseif ($PC -like "AZLG00*")
{
#AZ laptop lenovo
$PC = $PC -replace "AZLG00"
}
elseif ($PC -like "AZDG000*")
{
#AZ Desktop dell
$PC = $PC -replace "AZDG000"
}
elseif ($PC -like "AZDG00*")
{
#AZ Desktop lenovo?
$PC = $PC -replace "AZDG00"
}
elseif ($PC -like "NVLG000*")
{
#LV laptop dell
$PC = $PC -replace "NVLG000"
}
elseif ($PC -like "NVLG00*")
{
#LV laptop lenovo
$PC = $PC -replace "NVLG00"
}
elseif ($PC -like "NVDG000*")
{
#LV Desktop dell
$PC = $PC -replace "NVDG000"
}
elseif ($PC -like "NVDG00*")
{
#LV Desktop lenovo?
$PC = $PC -replace "NVDG00"
}
elseif ($PC -like "WIVGP*")
{
#VDI's To be added
}
return $PC