import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException

#scriptpath = 'C:/Users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver'
scriptpath = os.path.dirname(os.path.realpath(__file__))

OldComputerFullname = ["1R7YM02"]
LoginUsername = sys.argv[1]
LoginUserPassword = sys.argv[2]

StockroomLocation = 'AAH Green Bay'

OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"

#   SETUP CHROME DRIVER
options = Options()
options.add_argument("--disable-logging")
options.add_argument('log-level=3')
options.headless = True
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
#driver = webdriver.Chrome(options=options, executable_path= scriptpath)
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")

wait = WebDriverWait(driver, 5)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

Universal_SN_iframe = "gsft_main"

OldPCiframe = Universal_SN_iframe

stateID = "alm_hardware.install_status"
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"
#<option value="BCP">BCP</option>
#<option value="Call Center">Call Center</option>
#<option value="Disaster Recovery">Disaster Recovery</option>
#<option value="Lab Device">Lab Device</option>
#<option value="Loaner">Loaner</option>
#<option value="Monitoring">Monitoring</option>
#<option value="Primary Device">Primary Device</option>
#<option value="Secondary Device">Secondary Device</option>
#<option value="Security">Security</option>
#<option value="Shared Device">Shared Device</option>
#<option value="Testing">Testing</option>
#<option value="Training">Training</option>
#<option value="Development">Development</option>
#<option value="Spare">Spare</option>
#<option value="Hot-Spare" selected="SELECTED">Hot-Spare</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"

userAssignedID = "sys_display.alm_hardware.assigned_to"
departmentid = "sys_user.department_label"

DateAssignedID = "alm_hardware.assigned"

RequestMembershipPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
memberUserID = "sys_display.IO:3cd7f12a903da80087a863f119b63795"
memberModGroupID = "IO:cc7033214fd84f806f4d3e1ca310c75c"
memberTargetGroupID = "IO:94390d824fdc03006f4d3e1ca310c72f"
memberActionID = "IO:1f34c9844fecdb406f4d3e1ca310c7f7"
memberMembershipID = "sys_display.IO:42e078f74f8c0780c8e7e57d0210c77b"
memberPCtbxID = "computer_list_cmdb_ci_computer"
membership_PC_List_Hidden_ID = "cmdb_ci_computer.computer_list"
#memberPCHiddenListID
memberShowAvailablePCEvent = "\"return checkEnter(event, 'cmdb_ci_computer.computer_list')\""
membership_Element_PC_List_select_ID = "computer_list_select_0"
#memberPClistID = "computer_list_select_0"
memberReasonID = "IO:96695c1d311df0404c72ad13d18ba9f0"
memberSubmitBtnCode = "\"if ($$('.order_buttons .disabled_order_button').length == 0) { orderNow(); } else { alert('Please wait - price being updated'); };\""

#Begin Webpage navigation to Old PC record first
driver.get(OldPCWebpage)

#   INITIAL LOGIN PAGE
#SET ELEMENTS IN LOGIN PAGE
print(" ________________________________________________")
print("|             Logging in As user                 |")
print("|________________________________________________|")
print(" ")
userid = driver.find_element_by_id('userID')
password = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id("loginbtn")

#SEND KEYS TO ELEMENTS IN LOGIN PAGE
userid.send_keys(LoginUsername)
password.send_keys(LoginUserPassword)
btnLogin.click()


PCState = None
PCSubState = None
PCAssetFunction = None
NEWPCState = None
NEWPCSubState = None
NEWPCAssetFunction = None
NEWassigned = None
viewuserinfo_element = None
outputary = []
#pcary = []
#expectedwindows = 2
print(" ________________________________________________")
print("|        Getting PC Info from Service-now        |")
print("|________________________________________________|")
print(" ")
file = open('C:/Users/bwienk1/Desktop/Script Fixes/Logs/Retire PCs/Retired.csv',"w")
file.write('"NAME","WAS_USER_ASSIGNED","PC_MODEL","WAS_STATE","WAS_SECONDARY_STATE","WAS_ASSET_FUNCTION","NOW_USER_ASSIGNED","NOW_STATE,"NOW_SECONDARY_STATE,"NOW_ASSET_FUNCTION"\n')
userAssignedID = "sys_display.alm_hardware.assigned_to"
for pc in OldComputerFullname:
    #Find Old PC Serial
    
    PC = pc
    if "WILG000" in PC: pc = PC.replace("WILG000","")
    elif "WILG00" in PC: pc = PC.replace("WILG00","")
    elif "WIDG000" in PC: pc = PC.replace("WIDG000","")
    elif "WIDG00" in PC: pc = PC.replace("WIDG00","")
    elif "AZLG000" in PC: pc = PC.replace("AZLG000","")
    elif "AZLG00" in PC: pc = PC.replace("AZLG00","")
    elif "AZDG000" in PC: pc = PC.replace("AZDG000","")
    elif "AZDG00" in PC: pc = PC.replace("AZDG00","")
    elif "NVLG000" in PC: pc = PC.replace("NVLG000","")
    elif "NVLG00" in PC: pc = PC.replace("NVLG00","")
    elif "NVDG000" in PC: pc = PC.replace("NVDG000","")
    elif "NVDG00" in PC: pc = PC.replace("NVDG00","")
    elif "MILG000" in PC: pc = PC.replace("MILG000","")
    elif "MILG00" in PC: pc = PC.replace("MILG00","")
    elif "MIDG000" in PC: pc = PC.replace("MIDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "MNLG000" in PC: pc = PC.replace("MNLG000","")
    elif "MNLG00" in PC: pc = PC.replace("MNLG00","")
    elif "MNDG000" in PC: pc = PC.replace("MNDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "WIVGP" in PC:
        #PC is VDI (different functions required)
        pc = PC
        isVDI_Old_PC = True
    else:
        pc = PC
    
    PCState = None
    PCSubState = None
    PCAssetFunction = None
    viewuserinfo_element = None
    OldUserAssigned = None
    PCModel = None
    
    print("Getting values for " + pc + "...")
    pcary = None
    OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + pc
    #windows_before  = driver.current_window_handle
    #driver.execute_script("window.open('" + OldPCWebpage + "')")
    #WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    #windows_after = driver.window_handles
    #driver.switch_to.window(windows_after[expectedwindows - 1])
    #expectedwindows = expectedwindows + 1
    driver.get(OldPCWebpage)
    
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    try:
        Element = driver.find_element_by_id(userAssignedID)
        OldUserAssigned = Element.get_attribute("value")
        #time.sleep(.5)
        #print("User Assigned to Old PC was: " + OldUserAssigned)
        #print(" ")
        assigned = OldUserAssigned
        if not assigned:
            #Empty string check for assigned
            assigned = "NOT ASSIGNED"
            NEWassigned = "NOT ASSIGNED"
    except:
        #no user assigned
        OldUserAssigned = None
        assigned = "NOT ASSIGNED"
        NEWassigned = "NOT ASSIGNED"


    try:
        Element = driver.find_element_by_id('alm_hardware.model_label')
        Model = Element.get_attribute("value")
        #time.sleep(.5)
        #print("User Assigned to Old PC was: " + OldUserAssigned)
        #print(" ")
        PCModel = Model
        if not PCModel:
            #Empty string check for assigned
            PCModel = "NONE"
    except:
        #no user assigned
        Model = None
        PCModel = "NONE"

    

    try:
        Element = driver.find_element_by_id(stateID)
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        select = Select(driver.find_element_by_id(stateID))
        try:
            selected_option = select.first_selected_option
            PCState = selected_option.text
        except:
            PCState = "NONE"
            
        select.select_by_value('6')
        NEWPCState = "In Stock"
        NEWassigned = "NOT ASSIGNED"
        #PCState = selected_option.text
        try:
            wait.until(EC.visibility_of_element_located((By.ID, StockRoomID)))
            Element = driver.find_element_by_id(StockRoomID)
            Element.click()
            Element.send_keys(Keys.CONTROL, 'a')
            Element.send_keys(StockroomLocation)
            #Element.click()
            wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
            Element = driver.find_element_by_id(SecondaryStateID)
            select = Select(driver.find_element_by_id(SecondaryStateID))
            try:
                selected_option = select.first_selected_option
                PCSubState = selected_option.text
            except:
                PCSubState = "NONE"
                
            select.select_by_value('pending_disposal')
            NEWPCSubState = "Pending Disposal"
            #PCSubState = selected_option.text
            #if PCSubState == "Reserved":
                ##no user will be assigned
                #assigned = "NOT ASSIGNED"
        except:
            #No PC SubState found
            print("STATE NOT FOUND")
            PCSubState = "NONE"
            NEWPCState = "ERROR"
    except:
        #No PC State found
        print("STATE NOT FOUND")
        print("SUBSTATE NOT FOUND")
        PCSubState = "NONE"
        PCState = "NONE"
        NEWPCState = "ERROR"
        NEWPCSubState = "ERROR"
        
    try:
        Element = driver.find_element_by_id(AssetFunctionID)
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        select = Select(driver.find_element_by_id(AssetFunctionID))
        try:
            selected_option = select.first_selected_option
            PCAssetFunction = selected_option.text
        except:
            PCAssetFunction = "NONE"
            
        select.select_by_value('Spare')
        NEWPCAssetFunction = "Spare"
        #PCAssetFunction = selected_option.text
    except:
        #No PC Asset Function found
        print("ASSET FUNCTION NOT FOUND")
        PCAssetFunction = "NONE"
        NEWPCAssetFunction = "ERROR"

    wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
    driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
    pcary = [pc, assigned, PCModel, PCState, PCSubState, PCAssetFunction, NEWassigned, NEWPCState, NEWPCSubState, NEWPCAssetFunction]
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()
    file.write('"' + pcary[0] + '","' + pcary[1] + '","' + pcary[2] + '","' + pcary[3] + '","' + pcary[4] + '","' + pcary[5] + '"\n')

    


print("Service Now is complete")
print("Starting Ticket Creation")
file.close()


    
driver.quit()
