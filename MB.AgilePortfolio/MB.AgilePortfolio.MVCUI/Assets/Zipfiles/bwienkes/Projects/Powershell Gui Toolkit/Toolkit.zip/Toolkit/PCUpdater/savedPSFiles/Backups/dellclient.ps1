﻿Param(

#(name),(remoteroot),(cmd command)

[String[]]$Name,
[String[]]$Root,
[String[]]$CMD


)


for($i=0;$i-le $Name.Length-1;$i++){

$Root[$i] = Split-Path $Root[$i] -Leaf



Try{
    Write-output "Installing $($Name[$i])..."
    Write-Host "Installing $($Name[$i])..."
    #Start-Process -verb runas -filePath "C:\Temp\$($Root[$i])\$($CMD[$i])" -ArgumentList " /S" -wait
    Start-Process -Verb runas -FilePath "C:\Windows\System32\CMD.EXE" -ArgumentList "/C C:\Temp\$($Root[$i])\$($CMD[$i])" -Wait -WindowStyle Hidden
  }
  Catch{[Exception]
  Write-Host"Failed: $_"
   Write-Output "Failed: $_"

}
}




    

