﻿param
(
[Parameter(Mandatory=$false)] $computer
)
if(($computer)){if(!($computer -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: computer"}
elseif(!($computer.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: computer"}}

if(!($Param_ErrorMsg))
	{

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Register-Reboot
{
    param
    (
    $computer,
    $filepath
    )
    if($computer)
    {
    $PC_Name = $computer
    }
if(!(test-path "\\$PC_Name\C$\Temp\RebootGui.ps1"))
{
write-host -ForegroundColor Cyan "Copying Reboot Gui script to PC..." -NoNewline
copy-item -Path "$filepath" -Destination "\\$PC_Name\C$\Temp" -Force -Recurse
write-host "Done"
}
$forcedRestart = $false
$nousers = $false
$quserOut = quser.exe /SERVER:$PC_Name 2>&1
	$out_User_Sessions = @()
	if ($quserOut -match "No user exists")
	{ 
	$nousers = $true
	}

	    $users = $quserOut -replace '\s{2,}', ',' |
	ConvertFrom-CSV -Header 'username', 'sessionname', 'id', 'state', 'idleTime', 'logonTime' |
	Add-Member -MemberType NoteProperty -Name ComputerName -Value $PC_Name -PassThru
	$users = $users[1..$users.count]
	for ($i = 0; $i -lt $users.count; $i++)
	{
	            if ($users[$i].sessionname -match '^\d+$')
	{
	                $users[$i].logonTime = $users[$i].idleTime
	$users[$i].idleTime = $users[$i].STATE
	$users[$i].STATE = $users[$i].ID
	$users[$i].ID = $users[$i].SESSIONNAME
	$users[$i].SESSIONNAME = $null
	}
	
	# cast the correct datatypes
	$users[$i].ID = [int]$users[$i].ID
	
	$idleString = $users[$i].idleTime
	if ($idleString -eq '.') { $users[$i].idleTime = 0 }
	
	# if it's just a number by itself, insert a '0:' in front of it. Otherwise [timespan] cast will interpret the value as days rather than minutes
	if ($idleString -match '^\d+$')
	{ $users[$i].idleTime = "0:$($users[$i].idleTime)" }
	            
	# if it has a '+', change the '+' to a colon and add ':0' to the end
	if ($idleString -match "\+")
	{
	                $newIdleString = $idleString -replace "\+", ":"
	$newIdleString = $newIdleString + ':0'
	$users[$i].idleTime = $newIdleString
	}
	if($users[$i].idleTime -ne "none")
	{
	                $users[$i].idleTime = [timespan]$users[$i].idleTime
	}
	$users[$i].logonTime = [datetime]$users[$i].logonTime
	}
	$users = @($users | Sort-Object -Property idleTime)

if($Users.count -eq 1 -or $nousers -eq $false)
{
if($Users.username)
{
write-host -ForegroundColor Cyan "Giving User 5 min prompt for restart with ability to delay"
Invoke-Command -ComputerName $PC_name -Credential $Script:credentials -ArgumentList $users -ScriptBlock{
$users = $args[0]
$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument 'C:\Temp\RebootGui.ps1' 
$trigger =  New-ScheduledTaskTrigger -Once  -At (get-date).AddSeconds(30) ; $trigger.EndBoundary = (get-date).AddSeconds(80).ToString('s')
$S = New-ScheduledTaskSettingsSet -StartWhenAvailable -DeleteExpiredTaskAfter 00:00:30
write-host -ForegroundColor Cyan "Found 1 user logged on, sending reboot prompt to warn user"
$usertorunas = "AFII\" + $($users.username)
write-host "registering task: Reboot as user: $usertorunas"
write-host "Task will trigger in 30 secs"
#(Unregister-ScheduledTask -TaskName "Reboot" -Confirm |out-null) >$null
Register-ScheduledTask -Force -user $usertorunas -TaskName "Reboot" -Action $action -Trigger $trigger -Settings $S
start-sleep -Seconds 30
}
}
}
elseif($Users.count -lt 1 -or $nousers -eq $true)
{
$forcedRestart = $true
write-host -ForegroundColor Cyan "No Users are logged into " -NoNewline
write-host "$PC_Name" -nonewline
write-host " currently"
#restart
$timedout = $null # reset any previously set timeout
try{
write-host -ForegroundColor Cyan "`nRestarting " -NoNewline
write-host "$PC_Name`n"
restart-computer $PC_Name -credential $Script:credentials -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
}
Catch [System.UnauthorizedAccessException]
{
write-host "Problem with reseting pc with Admin Credentials, attempting to map with NonAdmin Credentials"
    Try{
   restart-computer $PC_Name -credential $Script:credentials2 -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
    }
    Catch
    {
    write-host "Problem with reseting pc with either credentials"
    write-host "Error:"
    write-host $_
    $exit = Read-Host -Prompt "press enter to exit"
    exit
    }
}
if ($timedout)
{
    if (test-connection $PC_Name -Quiet)
    {
        #Connection is good
        write-Host "$($PC_Name) restart timed out, but pc is still responsive"
    }
    else
    {
        write-Host "$($PC_Name) restart timed out, please check pc"

        continue
    }

}

}
else
{
write-host -ForegroundColor Red "Too many users logged into computer"
}

$timeout = 0
$pcrestarted = $false
if ($forcedRestart -eq $false)
{
    write-host "waiting for pc to restart"-NoNewline
    while ($pcrestarted -eq $false)
    {
        if(!(Test-Connection -ComputerName $PC_name -Count 1))
        {
            write-host "PC has restarted"
            $pcrestarted = $true
        }
        elseif($timeout -eq 300)
        {
            write-host -ForegroundColor Red "PC Timed out waiting to restart after 5 mins"
            $pcrestarted = $true
        }
        else
        {
            write-host "."-NoNewline
            $timeout += 1
            Start-Sleep -Seconds 1
        }
    }
    $timeout = 0
    while (!(Test-Connection -ComputerName $PC_name -Count 1))
    {
        if($timeout -eq 300)
        {
            write-host -ForegroundColor Red "PC Timed out waiting to come back online after 5 mins"
            break
        }
        write-host "Waiting for pc to come back online..."
        $timeout += 1
        Start-Sleep -Seconds 1
    }
}
#Invoke-Command -ComputerName $PC_name -Credential $Script:credentials -ScriptBlock{
#write-host "removing scheduled reboot task..." -NoNewline
#(Unregister-ScheduledTask -TaskName "Reboot" -Confirm |out-null) >$null
#write-host "Done"
#}
if(test-path "\\$PC_name \C$\Temp\RebootGui.ps1" -ErrorAction SilentlyContinue)
{
    Write-Host -ForegroundColor Cyan "Removing Reboot script from $PC_Name..." -NoNewline
    Remove-Item -Path "\\$PC_name \C$\Temp\RebootGui.ps1" -Force -Recurse
    Write-Host "Done"
}

}

function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

Function Check-If-IP
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$isIP = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if ($Computername -like "*.*.*.*")
	{
	# Is an IP Address
	$isIP =  $true
	}
	else
	{
	# NOT an IP Address
	$isIP = $false
	}
	}
	else
	{
	Write-Debug "[FAILURE] Check-If-IP - Initial parameter input was null"
	$ErrorMsg = "Check-If-IP - $Param_ErrorMsg"
	
	}
	$properties = @{'Output' = $isIP;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


Function Filter-PC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$PC = $null
	$ErrorMsg = $null
	$Return_Object = $null
    
	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	    $Computername = $Computername.trim()
	    $PC = $Computername
	    If ($PC -like "WILG000*")
	    {
	        #WI laptop Dell
	        $PC = $PC -replace "WILG000"
	    }
	    elseif ($PC -like "WILG00*")
	    {
	        #WI laptop Lenovo
	        $PC = $PC -replace "WILG00"
	    }
	    elseif ($PC -like "WIDG000*")
	    {
	        #WI Desktop Dell
	        $PC = $PC -replace "WIDG000"
	    }
	    elseif ($PC -like "WIDG00*")
	    {
	        #WI Desktop Lenovo?
	        $PC = $PC -replace "WIDG00"
	    }
	    elseif ($PC -like "AZLG000*")
	    {
	        #AZ laptop dell
	        $PC = $PC -replace "AZLG000"
	    }
	    elseif ($PC -like "AZLG00*")
	    {
	        #AZ laptop lenovo
	        $PC = $PC -replace "AZLG00"
	    }
	    elseif ($PC -like "AZDG000*")
	    {
	        #AZ Desktop dell
	        $PC = $PC -replace "AZDG000"
	    }
	    elseif ($PC -like "AZDG00*")
	    {
	        #AZ Desktop lenovo?
	        $PC = $PC -replace "AZDG00"
	    }
	    elseif ($PC -like "NVLG000*")
	    {
	        #LV laptop dell
	        $PC = $PC -replace "NVLG000"
	    }
	    elseif ($PC -like "NVLG00*")
	    {
	        #LV laptop lenovo
	        $PC = $PC -replace "NVLG00"
	    }
	    elseif ($PC -like "NVDG000*")
	    {
	        #LV Desktop dell
	        $PC = $PC -replace "NVDG000"
	    }
	    elseif ($PC -like "NVDG00*")
	    {
	        #LV Desktop lenovo?
	        $PC = $PC -replace "NVDG00"
	    }
	    elseif ($PC -like "WIVGP*")
	    {
	        #VDI's To be added
	    }
	    elseif ($PC -like "*.*.*.*")
    	{
        	$script:IPaddress = $true
	    }
	    else
	    {
	        #BAD ENTRY CODE HERE
	        $ErrorMsg = "Filter-PC - Not a valid input"
	    }
	}
	else
	{
	    Write-Debug "[FAILURE] Filter-PC - Initial parameter input was null"
	    $ErrorMsg = "Filter-PC - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $PC;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object –TypeName PSObject –Prop $properties
	return $Return_Object
}


function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}

function Teardown-IP-Invoke
{
		#Post Reset Trustedhosts back
		if ($Script:TrustedHosts)
		{
			Set-Item WSMan:\localhost\Client\TrustedHosts -Value $Script:TrustedHosts -Force
		}
}

Function Show-SelectionForm($lstSelections)
{
 
	#---------------------------------------------- 
	#region Import Assemblies 
	#---------------------------------------------- 
	[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	#endregion Import Assemblies  
 
	function SelectForm($input1) 
	{ 
	$Script:SelectionForm_RowIndex = $null
	<# 
	    .SYNOPSIS 
	The Main function starts the project application. 
	     
	    .PARAMETER Input1
	$Input1 contains the complete argument string passed to the script packager executable. 
	     
	    .NOTES 
	Use this function to initialize your script and to call GUI forms. 
	         
	    .NOTES 
	To get the console output in the Packager (Forms Engine) use:  
	$ConsoleOutput (Type: System.Collections.ArrayList) 
	#> 
	     
	#-------------------------------------------------------------------------- 
     
	if((Call-SelectForm_psf($input1)) -eq 'OK') 
	{ 
	# ADD VALIDATION IF NEEDED
	    } 
	$global:ExitCode = 0 #Set the exit code for the Packager 
	} 
 
	#endregion Source: Startup.pss 
 
	#region Source: MainForm.psf 
	function Call-SelectForm_psf($input1) 
	{ 
	#Datagrid click Function
	    Function dg_Selections_GridClick
	{
	#Set $Script:SelectionForm_RowIndex to index of the currently selected row
	[int]$Script:SelectionForm_RowIndex = $dg_Selections.CurrentRow.Index
	}
    
	#Add Data to Datagrid function
	function Get-ProcessInfo($input1) 
	{
	$array = New-Object System.Collections.ArrayList
	$array.AddRange($input1)
	$dg_Selections.DataSource = $array
	$selectform.refresh()
	$dg_Selections.ClearSelection()
	}
 
	#---------------------------------------------- 
	#region Import the Assemblies 
	#---------------------------------------------- 
	[void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	#endregion Import Assemblies 
	 
	#---------------------------------------------- 
	#region Generated Form Objects 
	#---------------------------------------------- 
	[System.Windows.Forms.Application]::EnableVisualStyles() 
	$SelectForm = New-Object 'System.Windows.Forms.Form'
	$ButtonCancel = New-Object 'System.Windows.Forms.Button' 
	$ButtonSelect = New-Object 'System.Windows.Forms.Button' 
	$panel1 = New-Object 'System.Windows.Forms.Panel'
	$panel2 = New-Object 'System.Windows.Forms.Panel'
	$panel3 = New-Object 'System.Windows.Forms.Panel'
	$panel4 = New-Object 'System.Windows.Forms.Panel'
	$dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
	#endregion Generated Form Objects 
 
	#---------------------------------------------- 
	# Form Object Functions
	#---------------------------------------------- 

	#Form Load function
	$SelectForm_Load =
	{ 
	get-processinfo($input1)         
	}
	
	#Select Button clicked function
	$ButtonSelect_Click = 
	{     
	#Checks for input selected before allowing form close from select button click
	if ($Script:SelectionForm_RowIndex -or $Script:SelectionForm_RowIndex -eq 0)
	{
	$SelectForm.Close()
	}
	} 

	#Cancel Button clicked function
	$ButtonCancel_Click =
	{
           #TODO: Place custom script here on canceling form
	$SelectForm.Close() 
	} 
     
        # --End Form Object Functions-- 
	#---------------------------------------------- 
	#region Generated Events 
	#---------------------------------------------- 
	
	#Fix Form Load function
	$Form_StateCorrection_Load = 
	{ 
	        #Correct the initial state of the form to prevent the .Net maximized form issue 
	$SelectForm.WindowState = $InitialFormWindowState 
	} 
     
	#Store Values of form function
	$Form_StoreValues_Closing = 
	{ 
	#Store the control values here
	} 
 
	$Form_Cleanup_FormClosed = 
	{ 
	        #Remove all event handlers from the controls 
	try 
	{ 
	            $ButtonCancel.remove_Click($buttonCancel_Click) 
	$ButtonSelect.remove_Click($ButtonSelect_Click)
	$SelectForm.remove_Load($SelectForm_Load) 
	$SelectForm.remove_Load($Form_StateCorrection_Load) 
	$SelectForm.remove_Closing($Form_StoreValues_Closing) 
	$SelectForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	} 
	catch [Exception] 
	{ } 
	} 
	#endregion Generated Events 
 
	#---------------------------------------------- 
	#region Form Setup Objects
	#---------------------------------------------- 
	#Suspend layouts
	$SelectForm.SuspendLayout()
	$panel4.SuspendLayout() 
	$panel3.SuspendLayout() 
	$panel2.SuspendLayout() 
	$panel1.SuspendLayout()
	 
	# 
	# SelectForm Attributes
	# 
	$SelectForm.Controls.Add($panel1)
	$SelectForm.Controls.Add($panel2) 
	$SelectForm.AutoScaleDimensions = '6, 13' 
	$SelectForm.AutoScaleMode = 'Font' 
	$SelectForm.BackColor = 'White' 
	$SelectForm.ClientSize = '373, 329'   
	$SelectForm.MaximizeBox = $False 
	$SelectForm.MinimizeBox = $False 
	$SelectForm.Name = 'SelectForm' 
	$SelectForm.ShowIcon = $False 
	$SelectForm.ShowInTaskbar = $False 
	$SelectForm.StartPosition = 'CenterScreen' 
	$SelectForm.Text = 'Select One'
	$formsizex = $SelectForm.ClientSize.Width + 100
	$formsizey =  $SelectForm.ClientSize.Height + 100
	$SelectForm.MinimumSize = "$formsizex,$formsizey"
	$selectform.MaximumSize = "$($formsizex + 600),$formsizey"
	$SelectForm.TopMost = $True 
	$SelectForm.add_Load($SelectForm_Load)
	# 
	# ButtonCancel Attributes
	# 
	$ButtonCancel.Location = '250, 50' 
	$ButtonCancel.Name = 'ButtonCancel' 
	$ButtonCancel.Size = '77, 45' 
	$ButtonCancel.TabIndex = 7 #TODO FIX TABINDEXES
	$ButtonCancel.Text = 'Cancel' 
	$ButtonCancel.UseVisualStyleBackColor = $True 
	$ButtonCancel.add_Click($buttonCancel_Click)
	$ButtonCancel.Dock = [System.Windows.Forms.DockStyle]::Right
	# 
	# ButtonSelect Attributes
	# 
	$ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	$ButtonSelect.ForeColor = 'Blue' 
	$ButtonSelect.Location = '42, 50' 
	$ButtonSelect.Name = 'ButtonSelect' 
	$ButtonSelect.Size = '91, 45' 
	$ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	$ButtonSelect.Text = 'Select' 
	$ButtonSelect.UseVisualStyleBackColor = $True 
	$ButtonSelect.add_Click($ButtonSelect_Click)
	$ButtonSelect.MaximumSize.Height = '60' 
	$ButtonSelect.Dock = [System.Windows.Forms.DockStyle]::Left
	# 
	# Panel1 Attributes
	#  
	$panel1.Controls.Add($dg_Selections)
	$panel1.Location = '0, 0' 
	$panel1.Name = 'panel1' 
	$panel1.Size = '375, 310' 
	$panel1.TabIndex = 8 #TODO FIX TABINDEXES
	$panel1.BackColor = 'LightGray'
	$panel1.Dock = [System.Windows.Forms.DockStyle]::Top
	# 
	# Panel3 Attributes
	# 
	$panel3.Controls.Add($ButtonSelect)  
	$panel3.Location = '188, 310' 
	$panel3.Name = 'panel2' 
	$panel3.Size = '188, 80' 
	$panel3.TabIndex = 8 #TODO FIX TABINDEXES
	$panel3.Padding = '100,20,0,20' 
	$panel3.BackColor = 'LightSkyBlue'
	$panel3.Dock = [System.Windows.Forms.DockStyle]::Left
	# 
	# Panel4 Attributes
	# 
	$panel4.Controls.Add($ButtonCancel)    
	#$panel2.Controls.Add($dg_Selections) 
	#$panel1.BackColor = '0, 114, 198' 
	$panel4.Location = '0, 310' 
	$panel4.Name = 'panel2' 
	$panel4.Size = '188, 80' 
	$panel4.TabIndex = 8 #TODO FIX TABINDEXES
	$panel4.Padding = '0,20,100,20' 
	$panel4.BackColor = 'LightSkyBlue'
	$panel4.Dock = [System.Windows.Forms.DockStyle]::Right
	# 
	# Panel2 Attributes
	# 
	$panel2.Controls.Add($panel3)  
	$panel2.Controls.Add($panel4)  
	$panel2.Location = '0, 310' 
	$panel2.Name = 'panel2' 
	    $panel2.Size = '376, 80' 
	    $panel2.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel2.BackColor = 'LightSkyBlue'
	    $panel2.Dock = [System.Windows.Forms.DockStyle]::Bottom
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.Size = '375, 300'
	$dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	$dg_Selections.Name = "dg_Selections"
	$dg_Selections.DataMember = ""
	#$dg_Selections.TabIndex = 0 #TODO FIX TABINDEXES
	$dg_Selections.Location = '0,0'
	$dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	$dg_Selections.AutoSizeRowsMode = "AllCells"
	$dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	$dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	$dg_Selections.DefaultCellStyle.WrapMode = 'True'
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	$dg_Selections.Margin = New-Object System.Windows.Forms.Padding(3, 3, 3, 3)
	$dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
	$dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	$dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	$dg_Selections.RowHeadersVisible = $false
	$dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	#Resume Layouts
	$panel1.ResumeLayout() 
	$panel2.ResumeLayout()
	$panel3.ResumeLayout() 
	$panel4.ResumeLayout()  
	$SelectForm.ResumeLayout()
	 
	#endregion Form Setup Objects
	#---------------------------------------------- 
	
	#Save the initial state of the form 
	$InitialFormWindowState = $SelectForm.WindowState 
	#Init the OnLoad event to correct the initial state of the form 
	$SelectForm.add_Load($Form_StateCorrection_Load) 
	#Clean up the control events 
	$SelectForm.add_FormClosed($Form_Cleanup_FormClosed) 
	#Store the control values when form is closing 
	$SelectForm.add_Closing({
	#Add Closing code here
	}) 
	#Show the Form 
	return $SelectForm.ShowDialog()

	#endregion Source: MainForm.psf 
	$self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	}
	
	#Start the application 
	SelectForm ($lstSelections)
return $Script:SelectionForm_RowIndex
}


Function Get-PC-By_PCName($PC)
{
    $Filter_pc = $null
	if($PC -ne "" -and $PC -ne $null)
	{
	if (((Check-If-IP -computername $PC).output) -eq $false)
	{
	$Filter_pc = ((Filter-PC -computername $PC).output)
	$computer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$Filter_pc'")
	if($computer -ne $null)
	{
	$lstPCs = @() 
	foreach ($entry in $computer)
	{
	$properties = @{'Selection'= $($computer.Indexof($entry));
	'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
	$object = New-Object –TypeName PSObject –Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	}
	if($($computer.Count) -gt 1)
	{
        $Script:SelectForm_RowIndex = $null
	    Show-SelectionForm($lstPCs)
	if ($Script:SelectForm_RowIndex -or $Script:SelectForm_RowIndex -eq 0)
	{
	    #Computer returned from selection
	    $computer = $lstPCs[$Script:SelectForm_RowIndex]
	    $Script:SelectForm_RowIndex = $null
	    return $computer
	}
	else
	{
	#No Computer returned from selection
	    return $null
	}
	  
	<#	
	# OLD CONSOLE OUTPUT

	$lstPcs| Format-Table -Autosize `
	@{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	@{Name="Computer Name";Expression = { $_.Name }; Alignment="left" },
	@{Name="AD Description";Expression = { $_.Description }; Alignment="left" }|out-host
	$select = read-host "`n Enter a Selection"
	$computer = ($lstPCs|Where-Object -Property Selection -eq -Value $select |Select-Object *)
	return $computer
	#>
	}
	elseif ($($computer.Count) -eq 1)
	{
	$computer = $lstPCs[0]
	return $computer
	}
	}
	else
	{   
	#No Computer returned from AD
	return $null
	}
	}
	else
	{
    Setup-IP-Invoke($PC)
	#RETURN IP
	#	IP can get buggy
	$lstPCs = @() 
	#foreach ($entry in $PC)
	#{
	    $properties = @{'Selection'= 0;
	    'Name'= $PC;
        'Description'= "No Description for IP Address"}
	$object = New-Object –TypeName PSObject –Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	#}
	$computer = $lstPCs
	return $computer
	}
	}
	else
	{
	#Input was null or empty
	return $null
	}
}


function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $NonAdmin_User1 = $NonAdmin_User.trim()
            $NonAdmin_User1 = "AFII\$($NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
        if($Script:CredentialsLoaded -eq $false)
        {
            $Script:Credentials = $null
            $Script:Credentials = Get-Credential -Credential $env:USERDOMAIN/$Env:USERNAME
            if(!($Script:Credentials))
            {
                write-host -ForegroundColor red "Admin Credentials are required to run script and none were stored or Entered!"
                read-host "Press enter to exit"
                exit
            }
        }
    }
}


    #***************************************************************
    #-------------------------IGNORE THIS ADMIN PROMPTING-----------
    #**************************************************************

    # Get the ID and security principal of the current user account
    $myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
    $myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

    # Get the security principal for the administrator role
    $adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

    # Check to see if we are currently running as an administrator
    if ($myWindowsPrincipal.IsInRole($adminRole))
    {
        # We are running as an administrator, so change the title and background colour to indicate this
        $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
        $Host.UI.RawUI.BackgroundColor = "DarkBlue";
        Clear-Host;
    #***************************************************************
    #-------------------------IGNORE THIS ADMIN PROMPTING-----------

    cls
    $MST = "Mountain Standard Time"
    $CST = "Central Standard Time"
    $PST = "Pacific Standard Time"
    $EST = "Eastern Standard Time"

    $computer = $computer.trim()
    if($computer)
    {
        Check-Credentials
        $computer = (Get-PC-By_PCName($computer)).name
        if(!($computer))
        {
            Write-Warning "No Computer found in AD!"
            Read-Host "`n Press Enter to exit"
            exit
        }

        while(!($NewTZ))
        {
            Write-Host -ForegroundColor Cyan  "Change Time Zone to:"
            Write-Host -ForegroundColor Cyan "------------------------------"
            Write-Host -ForegroundColor Cyan " 1 - $MST"
            Write-Host -ForegroundColor Cyan " 2 - $CST"
            Write-Host -ForegroundColor Cyan " 3 - $PST"
            Write-Host -ForegroundColor Cyan " 4 - $EST"
            Write-Host -ForegroundColor Cyan "------------------------------"
            $input = read-host " Select an option"
            if($input -eq 1){$NewTZ = $MST}
            elseif($input -eq 2){$NewTZ = $CST}
            elseif($input -eq 3){$NewTZ = $PST}
            elseif($input -eq 4){$NewTZ = $EST}
            else{$NewTZ = $null}
        }
        Write-Host -ForegroundColor Cyan "Stopping Windows Time Service on " -NoNewline
        Write-Host "$computer" -NoNewline
        Write-Host -ForegroundColor Cyan "..." -NoNewline
        (get-service -ComputerName $computer -Name W32Time).Stop()
        Write-Host "Done"
        Invoke-Command -Computer $computer -Credential $script:credentials -ArgumentList $NewTZ -ScriptBlock {
            $NewTZ = $args[0]
            $Key = Get-Item "Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\TimeZoneInformation"
            if (test-path "registry::$key")
            {
                Write-Host -ForegroundColor Cyan  "Found Registry Key"
                $currentval = Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\TimeZoneInformation" -Name "TimeZoneKeyName"
                $CurrentTime = $currentval.TimeZoneKeyName

                Write-Host -ForegroundColor Cyan "Current TimeZone Reg key value was set to: "-NoNewline
                Write-Host "$CurrentTime"
                Write-Host -ForegroundColor Cyan "Setting TimeZone Reg key value to " -NoNewline
                Write-Host "$NewTZ" -NoNewline
                Write-Host -ForegroundColor Cyan "..." -NoNewline
                Set-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\TimeZoneInformation" -Name "TimeZoneKeyName" -Value $NewTZ -Force | Out-Null
                Write-Host "Done"
        
                Write-Host -ForegroundColor Cyan  "Verifying registry key is set..." -NoNewline
                $currentval = $null
                $currentval = Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\TimeZoneInformation" -Name "TimeZoneKeyName"
                $currentTiem = $null
                $CurrentTime = $currentval.TimeZoneKeyName
                #write-host -ForegroundColor Cyan "`nCurrent TimeZone Reg key value is currently set to: "-NoNewline
                #write-host "$currentval"
                if($CurrentTime -like $NewTZ)
                {
                    $ChangedTime = "SUCCESS"
                    Write-Host -ForegroundColor Green $ChangedTime
                }
                else
                {
                    $ChangedTime = "FAILED"
                    Write-Host -ForegroundColor red $ChangedTime
                }
                #New-ItemProperty
            }
            else
            {
                Write-Host -ForegroundColor Yellow  "Didn't Find Registry Key"
                $exit = read-exit " Press enter to exit"
                exit
            }
        }
        Write-Host -ForegroundColor Cyan "Starting Windows Time Service..." -NoNewline
        (get-service -ComputerName $computer -Name W32Time).Start()
        Write-Host "Done"

        write-host -ForegroundColor cyan "`n Final Result: " -NoNewline
        if($ChangedTime -like "SUCCESS")
        {
            write-host -ForegroundColor Green "$ChangedTime"
        }
        else
        {
            write-host -ForegroundColor Red "$ChangedTime"
        }
        Write-Host "PC needs to restart to complete."
        $ansreboot = read-host "Do you want to initiate reboot user prompt?(y/n)"
        if($ansreboot -like "y")
        {
            write-host "Initiating Reboot Prompting Script"
            Register-Reboot -computer $computer -filepath "$PSscriptroot\Files\RebootGui.ps1"
        }
        else
        {
            write-host "Skipping rebooting computer"
            write-host -ForegroundColor Yellow "PLEASE INFORM User they will have to reboot computer before time zone will be correct!"
        }
        write-host "Time zone change script completed!"
        $exit = read-host "`nPress enter to exit"
    }
    else
    {
            Write-Warning "Invalid Computer input!"
           $exit =  Read-Host "`n Press Enter to exit"
            exit
    }
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}

}
else
{
write-host "Reinstall Office 365: $Param_ErrorMsg"
Read-Host "`nPress Enter to exit"
exit
}