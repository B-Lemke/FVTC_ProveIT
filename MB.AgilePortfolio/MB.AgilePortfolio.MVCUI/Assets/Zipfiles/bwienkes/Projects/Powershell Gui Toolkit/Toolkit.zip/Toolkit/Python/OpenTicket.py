import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException

#scriptpath = 'C:/Users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver'
scriptpath = os.path.dirname(os.path.realpath(__file__))

SN_Login_Username = sys.argv[1]
SN_Login_Password = sys.argv[2]
Email = sys.argv[3]
Url = sys.argv[4]
expectedwindows = 2

OldPCWebpage = str(Url)


#   SETUP CHROME DRIVER
options = Options()
#options.headless = True
options.add_argument('log-level=3')
options.add_argument('--window-size=1920x1080')
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
#driver = webdriver.Chrome(options=options, executable_path= scriptpath)
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")

wait = WebDriverWait(driver, 5)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

Universal_SN_iframe = "gsft_main"



#Begin Webpage navigation to Old PC record first
driver.get(OldPCWebpage)

#   INITIAL LOGIN PAGE
#SET ELEMENTS IN LOGIN PAGE
if driver.title == "Login":
    print(" ________________________________________________")
    print("|             Logging in As user                 |")
    print("|________________________________________________|")
    print(" ")
    #login
    userid = driver.find_element_by_id('userID')
    password = driver.find_element_by_id('password')
    btnLogin = driver.find_element_by_id("loginbtn")

    #SEND KEYS TO ELEMENTS IN LOGIN PAGE
    userid.send_keys(SN_Login_Username)
    password.send_keys(SN_Login_Password)
    btnLogin.click()

#pcary = []
#expectedwindows = 2
print(" ________________________________________________")
print("|        Getting PC Info from Service-now        |")
print("|________________________________________________|")
print(" ")


try:    
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    time.sleep(2)
    try:
        element = driver.find_element_by_id('sys_display.incident.assigned_to')
    except:
        element = driver.find_element_by_id('sys_display.sc_task.assigned_to')
except:
    try:
        print("exception finding Iframe")
        time.sleep(2)
        try:
            element = driver.find_element_by_id('sys_display.incident.assigned_to')
        except:
            element = driver.find_element_by_id('sys_display.sc_task.assigned_to')
    except:
        print("exception finding element")
        quit()
        exit()

#element = driver.find_element(By.XPATH, "//*[@id='alm_hardware_table']/tbody")
actions = ActionChains(driver)
actions.move_to_element(element)
actions.click(element)
actions.perform()

element.send_keys(Email)
time.sleep(1)
element.send_keys(Keys.TAB)


time.sleep(1)
try:
    select = Select(driver.find_element_by_id('incident.state'))
    select.select_by_value('2')
except:
    select = Select(driver.find_element_by_id('sc_task.state'))
    select.select_by_value('2')

buttonclick = driver.find_element_by_id('sysverb_update_and_stay')
actions = ActionChains(driver)
actions.move_to_element(buttonclick)
actions.click(buttonclick)
actions.perform()
time.sleep(1)
print("Python script finished")
driver.quit()
exit()
#print(ticketary)
