﻿param
(
[string]$UserFullname,
[string]$UserEmail,
[string]$OldComputerFullname
)


#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************
cls
# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#add search for Combo / Laptoplock / laptop lock /"lock " with [0..9][0..9][0..9][0..9] from work notes to find combo to add to new pc work notes
<#
function Find-user-by-email($Useremail)
{
#run python script with selenium and chromewebdriver to find and return
#   - users fullname in SN

# return $SN_Fullname
}
#>

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User1 = $NonAdmin_User.trim()
            $NonAdmin_User1 = "AFII\$($Script:NonAdmin_User1)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}

function Call-Reassignment($OldComputerFullname, $NewComputerFullname, $UserFullname, $UserEmail, $StockRoomValue, $Memberships, $loginUsername, $loginPassword, $ticket, $logpath)
{

$scriptPath = "$($PSScriptRoot)"
$LogRoot = (get-item $scriptPath).Parent.Parent.FullName
$Python_Script = "$LogRoot\Python\Swap PC.py"
#$ChromeDriver = "C:\Users\bwienk1\Desktop\Script Fixes\Python\ChromeDriver\chromedriver"

#Format filepath for Python
#$ChromeDriver = $ChromeDriver.Replace('\','/')

#To Uppercase for comparisons
$OldComputerFullname = $OldComputerFullname.ToUpper()
$NewComputerFullname = $NewComputerFullname.ToUpper()
if($userfullname -like "`'`'")
{
    $UserFullname.replace("`'`'","`'")
}

        $i= 0
        if(Test-Path "$Python_Script")
        {

            $content = $null
            $content = (get-content "$Python_Script")

                if($Memberships)
                {
                    if($Memberships.Trim())
                    {
                        $i= 0
                        $content2 = ($content | Where-Object {$_ -like 'Memberships = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
                        if($content2.count -gt 1)
                        {
                            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                        }
                        else
                        {
                            $content[$index] = "Memberships = [$Memberships]" 
                        }
                    }
                    else
                    {
                        $i= 0
                        $content2 = ($content | Where-Object {$_ -like 'Memberships = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
                        if($content2.count -gt 1)
                        {
                            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                        }
                        else
                        {
                            $content[$index] = "Memberships = ''" 
                        }
                    }
                }
                else
                {
                        $i= 0
                        $content2 = ($content | Where-Object {$_ -like 'Memberships = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
                        if($content2.count -gt 1)
                        {
                            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                        }
                        else
                        {
                            $content[$index] = "Memberships = ''" 
                        }
                }

                if($Ticket)
                {
                    if($Ticket.Trim())
                    {
                        $i= 0
                        $content2 = ($content | Where-Object {$_ -like 'TicketNumber = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
                        if($content2.count -gt 1)
                        {
                            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                        }
                        else
                        {
                            if($Ticket -ne "None")
                            {
                                $content[$index] = "TicketNumber = `'$Ticket`'" 
                            }
                            else
                            {
                                $content[$index] = "TicketNumber = None" 
                            }
                        }
                    }
                    else
                    {
                        $i= 0
                        $content2 = ($content | Where-Object {$_ -like 'TicketNumber = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
                        if($content2.count -gt 1)
                        {
                            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                        }
                        else
                        {
                            $content[$index] = "TicketNumber = None" 
                        }
                    }
                }
                else
                {
                        $i= 0
                        $content2 = ($content | Where-Object {$_ -like 'TicketNumber = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})
                        if($content2.count -gt 1)
                        {
                            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                        }
                        else
                        {
                            $content[$index] = "TicketNumber = None" 
                        }
                }



                $content |Set-Content "$Python_Script"
                Start-Sleep -Milliseconds 500
            
                write-host -ForegroundColor Cyan "Starting Service-Now Record updates..."
                write-output "Starting Service-Now Record updates..."
                $pythonlogpath = $logpath.replace('\','/')
                & "C:\Program Files (x86)\Python37-32\python.exe" "$Python_Script" "$OldComputerFullname" "$NewComputerFullname" "$UserFullname" "$UserEmail" "$StockRoomValue" "$loginUsername" "$loginPassword" "$pythonlogpath"
                write-host -ForegroundColor Cyan "Starting Service-Now Record updates Complete!"
                $logs = gc $logpath
                $splitlogs = $logs.split("|")
               $splitlogs | Out-File $logpath
                write-Host -ForegroundColor Cyan "Log Formatting complete!"

        }
        else
        {
            #write-debug "location fixes is not valid path"
        }
    }
#}

function Get-OldPC-Memberships
{
param
(
$AD_OldPC,
$logpath
)
$Group = $AD_OldPC|Select -ExpandProperty MemberOf |% {$_.Split(",")[0].TrimStart("CN=")}
#write-host $group
$memberships = @()
$i = 0
$strMemberships = ""
foreach($member in $Group)
{
    write-host -ForegroundColor Cyan "Found membership: " -NoNewline
    write-host "$member"
    write-output "Found membership: $member" |Out-File -FilePath $logpath -Encoding ascii -Append
    if($i -eq 0)
    {
        $strMemberships += "`"$member`""
    }
    else
    {
        $strMemberships += ",`"$member`""
    }

    $i++
}
if($i -gt 0)
{

return $strMemberships
}
else
{
return $null
}
}

function Swap-PCs($OldComputerFullname, $NewComputerFullname, $UserFullname, $UserEmail, $StockRoomValue, $loginUsername, $loginPassword, $ticket, $logpath)
{
    $AD_OldPC = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "name -like '$OldComputerFullname'"
    if($AD_OldPC)
    {
        $AD_OldPC_Desc = $AD_OldPC.Description
        if($AD_OldPC_Desc)
        {
            
        }
        else
        {
            write-host -ForegroundColor Yellow "Old PC Has no Description in AD!"
            while(!($newdesccheck))
            {
                $formatcorrect = $false
                $deptcorrect = $false

                $newdesccheck =  read-host "Enter Description for New PCs AD Description"
                if($newdesccheck -like "* - *")
                {
                    $arraydesc = $newdesccheck.Split('-')
                    if($arraydesc)
                    {
                        if($arraydesc.count -eq 2)
                        {
                            $formatcorrect = $true
                        }
                    }
                }
                
                if($formatcorrect -eq $true)
                {
                    $deptdesc = $arraydesc[0].Trim()
                    $deptdesc = $deptdesc.ToTitleCase()

                    $userdesc = $arraydesc[1].Trim()
                    $titlecase = $null
                    $titlecase = (Get-Culture).TextInfo
                    $userdesc = $titlecase.ToTitleCase($userdesc)
                    if($deptdesc -like "*PHS*")
                    {
                        write-host -ForegroundColor Yellow "PHS is not a department allowed!"
                    }
                    elseif($deptdesc -like "CS")
                    {
                        write-host -ForegroundColor Cyan "Changing Department: " -NoNewline
                        write-host $deptdesc -NoNewline
                        write-host -ForegroundColor Cyan " to: " -NoNewline
                        write-host "Client Service"
                        $deptDesc = "Client Service"
                        $deptcorrect = $true
                    }
                    elseif($deptdesc -like "Client Services")
                    {
                        write-host -ForegroundColor Cyan "Changing Department: " -NoNewline
                        write-host $deptdesc -NoNewline
                        write-host -ForegroundColor Cyan " to: " -NoNewline
                        write-host "Client Service"
                        $deptDesc = "Client Service"
                        $deptcorrect = $true
                    }
                    else
                    {
                        $deptcorrect = $true
                    }

                    if($deptdesc -like "It")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "IT"
                        $deptDesc = "IT"
                    }
                    elseif($deptdesc -like "Administrative Assistant")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Admin Assistant"
                        $deptDesc = "Admin Assistant"
                    }
                    elseif($deptdesc -like "Admin Support")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Administrative Support"
                        $deptDesc = "Administrative Support"
                    }
                    elseif($userdept -like "Actuarial")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Actuary"
                        $userdept = "Actuary"
                    }
                    elseif($userdept -like "*Claims")
                    {
                        write-host -ForegroundColor Cyan "Setting Department to: " -NoNewline
                        write-host "Claims"
                        $userdept = "Claims"
                    }

                    if($deptcorrect -eq $false)
                    {
                        $newdesccheck = $null
                    }
                }
                else
                {
                    write-host -ForegroundColor Yellow "Format is incorrect!"
                    write-host -ForegroundColor Cyan "Use Format: " -NoNewline
                    write-host "[DEPARTMENT] - [USERS NAME]"
                    $newdesccheck = $null
                }
            }
        }
            
            $AD_NewPC = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "name -like '*$NewComputerFullname'"
            if($AD_NewPC)
            {
                $AD_NewPC_Desc = "$($AD_NewPC.description)"
                if($AD_NewPC_Desc)
                {

                }
                else
                {
                    write-host -ForegroundColor Yellow "Warning: New PC Description is empty (hasn't been run through updater?)"
                    $continuenodesc = read-host "Do you want to continue?(y/n)"
                    if($continuenodesc -like "y")
                    {
                        
                    }
                    else
                    {
                        read-host "Press enter to exit"
                        exit
                    }
                }
                    if($AD_OldPC_Desc -like "`*`*OLD`*`**")
                    {
                        write-host -ForegroundColor Cyan "Current Description for Old PC: " -nonewline
                        write-host "$AD_OldPC_Desc"
                        $newOldDesc = ($AD_OldPC_Desc.replace('**OLD**',''))
                        write-host "newolddesc = $newoldDesc"
                        $newOldDesc = $newOldDesc.trim()
                        $AD_OldPC_Desc = $newOldDesc
                    }
                    $SetDescOldPC = "**OLD** " + $AD_OldPC_Desc
                    write-host -ForegroundColor Cyan "Current Description for Old PC: " -nonewline
                    write-host "$AD_OldPC_Desc"
                    write-host -ForegroundColor Cyan "Setting " -NoNewline
                    write-host "$($AD_OldPC.name)" -NoNewline
                    write-host -ForegroundColor Cyan " Description to: " -NoNewline
                    write-host "$SetDescOldPC"
                    try{
                        while(!($Script:Credentials))
                        {
                            $Script:Credentials = Get-Credential -Credential "$env:USERDOMAIN\$env:USERNAME"
                        }
                        Set-ADComputer $AD_OldPC -Description $SetDescOldPC -Credential $Script:Credentials
                    }
                    catch
                    {
                        write-host $_
                        read-host "Press enter to exit"
                        exit
                    }

                    write-host -ForegroundColor Cyan "Current Description for New PC: " -nonewline
                    write-host "$AD_NewPC_Desc"
                    write-host -ForegroundColor Cyan "Setting " -NoNewline
                    write-host "$($AD_NewPC.name)" -NoNewline
                    write-host -ForegroundColor Cyan " Description to: " -NoNewline
                    write-host "$AD_OldPC_Desc"
                    try{
                            while(!($Script:Credentials))
                            {
                                $Script:Credentials = Get-Credential -Credential "$env:USERDOMAIN\$env:USERNAME"
                            }
                            Set-ADComputer $AD_NewPC -Description $AD_OldPC_Desc -Credential $Script:Credentials
                    }
                    catch
                    {
                        write-host $_
                        read-host "Press enter to exit"
                        exit
                    }
                    Start-Sleep -Seconds 1
                    $AD_NewTestPC = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$NewComputerFullname'"
                    if("$($AD_NewTestPC.description)" -like "$AD_OldPC_Desc")
                    {
                        write-host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                        write-host -ForegroundColor Cyan "set New PC Description in AD"
                        write-output "[SUCCESS] Set New PC Description in AD $((Get-date).ToString())" |Out-File -FilePath $logpath -Encoding ascii -Append
                    }
                    else
                    {
                        write-host -ForegroundColor Red "FAILED " -NoNewline
                        write-host -ForegroundColor Cyan "to set New PC Description in AD"
                        write-output "[FAILURE] Set New PC Description in AD $((Get-date).ToString())" |Out-File -FilePath $logpath -Encoding ascii -Append
                        read-host "Press enter to exit"
                        exit
                    }
                    write-host -ForegroundColor Cyan  "Getting Memberships from " -NoNewline
                    write-host "$($AD_OldPC.Name)" -NoNewline
                    write-host -ForegroundColor Cyan "..."
                    write-output "Getting Memberships from $($AD_OldPC.Name)..." |Out-File -FilePath $logpath -Encoding ascii -Append
                    $Memberships = Get-oldpc-memberships -AD_OldPC $AD_OldPC -logpath $logpath
                    Call-Reassignment -OldComputerFullname $OldComputerFullname -NewComputerFullname $NewComputerFullname -UserFullname $UserFullname -UserEmail $UserEmail -StockRoomValue $StockRoomValue -Memberships $Memberships -loginUsername $loginUsername -loginPassword $loginPassword -ticket $Ticket -logpath $logpath
                #}

            }
        #}
    }
}

#Test Values
#$NewComputerFullname = "WILG0001G3KTC2"
Check-Credentials
$StockRoomValueGB = "AAH Green Bay"
$StockRoomValueLV = 'AAH LV Site'
$StockRoomValuePHX = 'AAH PHX'
$loginPassword = $Script:Password
$loginUsername = $Script:NonAdmin_User1


While(!($loginUsername))
{
   $loginUsername = read-host "Enter Your Non Admin Username (enter q to exit)"
   if ($loginUsername -eq "q"){exit}
}
if(!($Script:Password))
{
    while(!($loginPassword))
    {
        $loginPassword = read-host "Enter Your Non Admin Password (enter q to exit)"
        if ($loginPassword -eq "q"){exit}
    }
}
while(!($OldComputerFullname))
{
   $OldComputerFullname = read-host "Enter Old PC's Full Name (enter q to exit)"
   if ($OldComputerFullname -eq "q"){exit}
    $PC = $null
    $PC = $OldComputerFullname
    If ($PC -like "WILG000*")
    {
        #WI laptop Dell
        $PC = $PC -replace "WILG000"
    }
    elseif ($PC -like "WILG00*")
    {
        #WI laptop Lenovo
        $PC = $PC -replace "WILG00"
    }
    elseif ($PC -like "WIDG000*")
    {
        #WI Desktop Dell
        $PC = $PC -replace "WIDG000"
    }
    elseif ($PC -like "WIDG00*")
    {
        #WI Desktop Lenovo?
        $PC = $PC -replace "WIDG00"
    }
    elseif ($PC -like "AZLG000*")
    {
        #AZ laptop dell
        $PC = $PC -replace "AZLG000"
    }
    elseif ($PC -like "AZLG00*")
    {
        #AZ laptop lenovo
        $PC = $PC -replace "AZLG00"
    }
    elseif ($PC -like "AZDG000*")
    {
        #AZ Desktop dell
        $PC = $PC -replace "AZDG000"
    }
    elseif ($PC -like "AZDG00*")
    {
        #AZ Desktop lenovo?
        $PC = $PC -replace "AZDG00"
    }
    elseif ($PC -like "NVLG000*")
    {
        #LV laptop dell
        $PC = $PC -replace "NVLG000"
    }
    elseif ($PC -like "NVLG00*")
    {
        #LV laptop lenovo
        $PC = $PC -replace "NVLG00"
    }
    elseif ($PC -like "NVDG000*")
    {
        #LV Desktop dell
        $PC = $PC -replace "NVDG000"
    }
    elseif ($PC -like "NVDG00*")
    {
        #LV Desktop lenovo?
        $PC = $PC -replace "NVDG00"
    }
    elseif ($PC -like "WIVGP*")
    {
        #VDI
    }
elseif($PC -like "*.*.*.*")
{
    write-host -ForegroundColor red "IP ADDRESSES NOT SUPPORTED!"
    $OldComputerFullname = $null
    read-host "`nPress enter to continue`n"
}
else
{
    #write-host -ForegroundColor Red "NAME NOT VALID!"
    $OldComputerFullname = $null
#read-host "`nPress enter to continue`n"
}
$PC = $PC.Trim()
if($PC)
{
    $AD_TestPC = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$PC'")
    if($AD_TestPC)
    {
        if($AD_TestPC.Count -eq 1)
        {
            #newpc is valid
        }
        elseif($AD_TestPC.count -lt 1)
        {
            write-host -ForegroundColor Red "NO PC FOUND IN AD FOR NEW PC!"
            $OldComputerFullname = $null
            read-host "`nPress enter to continue`n"
        }
        elseif($AD_TestPC.count -gt 1)
        {
            write-host -ForegroundColor Red "TOO MANY PCS FOUND IN AD FOR NEW PC!"
            $OldComputerFullname = $null
            read-host "`nPress enter to continue`n"
        }
    }
}
else
{
    write-host -ForegroundColor Red "NEW PC FULLNAME NOT VALID!"
   $NewComputerFullname = $null
   read-host "`nPress enter to continue`n"
}
}
write-host -ForegroundColor Cyan "Old Computer Set to: " -NoNewline
write-host "$OldComputerFullname"

While(!($NewComputerFullname))
{
   $NewComputerFullname = read-host "Enter New PC's Full Name (enter q to exit)"
   if ($NewComputerFullname -eq "q")
    {exit}
    $PC = $null
    $PC = $NewComputerFullname
    If ($PC -like "WILG000*")
{
#WI laptop Dell
$PC = $PC -replace "WILG000"
}
elseif ($PC -like "WILG00*")
{
#WI laptop Lenovo
$PC = $PC -replace "WILG00"
}
elseif ($PC -like "WIDG000*")
{
#WI Desktop Dell
$PC = $PC -replace "WIDG000"
}
elseif ($PC -like "WIDG00*")
{
#WI Desktop Lenovo?
$PC = $PC -replace "WIDG00"
}
elseif ($PC -like "AZLG000*")
{
#AZ laptop dell
$PC = $PC -replace "AZLG000"
}
elseif ($PC -like "AZLG00*")
{
#AZ laptop lenovo
$PC = $PC -replace "AZLG00"
}
elseif ($PC -like "AZDG000*")
{
#AZ Desktop dell
$PC = $PC -replace "AZDG000"
}
elseif ($PC -like "AZDG00*")
{
#AZ Desktop lenovo?
$PC = $PC -replace "AZDG00"
}
elseif ($PC -like "NVLG000*")
{
#LV laptop dell
$PC = $PC -replace "NVLG000"
}
elseif ($PC -like "NVLG00*")
{
#LV laptop lenovo
$PC = $PC -replace "NVLG00"
}
elseif ($PC -like "NVDG000*")
{
#LV Desktop dell
$PC = $PC -replace "NVDG000"
}
elseif ($PC -like "NVDG00*")
{
#LV Desktop lenovo?
$PC = $PC -replace "NVDG00"
}
elseif ($PC -like "WIVGP*")
{
        Write-host -ForegroundColor Yellow "This will only update VDI SN Record"
        Write-host -ForegroundColor Yellow "VDI's MUST BE ASSIGNED IN CITRIX SEPERATELY!"
        #write-host -ForegroundColor red "`nVDI's Cannot be done currently`n"
        read-host "`nPress Enter to continue`n"
        #exit
}
elseif($PC -like "*.*.*.*")
{
    write-host -ForegroundColor Red "IP ADDRESSES NOT SUPPORTED!"
    $NewComputerFullname = $null
    $PC = $null
    read-host "`nPress enter to continue`n"
}
else
{
   # write-host -ForegroundColor Red "NEW PC FULLNAME NOT VALID!"
    $NewComputerFullname = $null
   # read-host "`nPress enter to continue`n"
}
$PC = $PC.Trim()
if($PC)
{
    $AD_TestPC = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$PC'")
    if($AD_TestPC)
    {
        if($AD_TestPC.Count -eq 1)
        {
            $NewComputerFullname = $AD_TestPC.Name
        }
        elseif($AD_TestPC.count -lt 1)
        {
            write-host -ForegroundColor Red "NO PC FOUND IN AD FOR NEW PC!"
            $NewComputerFullname = $null
            read-host "`nPress enter to continue`n"
        }
        elseif($AD_TestPC.count -gt 1)
        {
            write-host -ForegroundColor Red "TOO MANY PCS FOUND IN AD FOR NEW PC!"
            $NewComputerFullname = $null
            read-host "`nPress enter to continue`n"
        }
    }
}
else
{
   write-host -ForegroundColor Red "NEW PC FULLNAME NOT VALID!"
   $NewComputerFullname = $null
   read-host "`nPress enter to continue`n"
}
}
$scriptPath = "$($PSScriptRoot)"
$LogRoot = (get-item $scriptPath).Parent.Parent.FullName
$ParentLogContainingFolderName = "Python"
$LogContainingFolderName = "Swap PC"
$logfilename = "$OldComputerFullname to $NewComputerFullname.txt"
$logpath = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"
if(!(test-path "$LogRoot\Logs"))
{
$fso = new-object -ComObject scripting.filesystemobject
            $fso.CreateFolder("$LogRoot\Logs")
}
if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName"))
{
$fso = new-object -ComObject scripting.filesystemobject
            $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName")
}
if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName"))
{
$fso = new-object -ComObject scripting.filesystemobject
            $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName")
}

if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"))
{
write-output "$((Get-Date).ToString())" |Out-File -FilePath $logpath
}
write-host -ForegroundColor Cyan "New Computer Set to: " -NoNewline
write-host "$NewComputerFullname"
write-output "Old Computer Set to: $OldComputerFullname" |Out-File -FilePath $logpath -Encoding ascii -Append
write-output "New Computer Set to: $NewComputerFullname" |Out-File -FilePath $logpath -Encoding ascii -Append
While(!($StockroomLocation))
{
    $Stockroomin = $Null
    $Stockroomin = read-host "Enter Stockroom Old PC will be located IE:(LV, GB, AZ)"
    $StockroomLocation = ($Stockroomin.ToUpper()).Trim()

    if ($StockroomLocation -eq "GB"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "GREEN BAY"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "GREENBAY"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "WI"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "WISCONSIN"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "DEPERE"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "DE PERE"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "PACKERLAND"){$StockRoomValue = $StockRoomValueGB}
    elseif ($StockroomLocation -eq "q"){exit}
    else
    {
        if ($StockroomLocation -eq "LV"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "LASVEGAS"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "LAS VEGAS"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "PILOTRD"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "PILOT RD"){$StockRoomValue = $StockRoomValueLV}
        elseif ($StockroomLocation -eq "PILOT"){$StockRoomValue = $StockRoomValueLV}
        else
        {
            if ($StockroomLocation -eq "AZ"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "DUNLAP"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "BC"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHOENIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHEONIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHENIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHONIX"){$StockRoomValue = $StockRoomValuePHX}
            elseif ($StockroomLocation -eq "PHX"){$StockRoomValue = $StockRoomValuePHX}
            else
            {
                write-host -ForegroundColor Red "Stockroom invalid!"
                $StockRoomValue = $Null
                read-host "`nPress enter to continue`n"
            }  
        }
    }
    if(!($StockRoomValue))
    {
        $StockroomLocation = $Null
    }
}

write-host -ForegroundColor Cyan "Stockroom set to: " -nonewline
write-host $StockRoomValue
write-output "Stockroom set to: $StockRoomValue" |Out-File -FilePath $logpath -Encoding ascii -Append
while(!($UserFullname))
{
   $UserFullname = read-host "Enter Fullname of User to swap PC's for (Enter q to exit)"
   if ($UserFullname -eq "q"){exit}
}

while(!($UserEmail))
{
   $UserEmail = read-host "Enter Email of User to swap PC's for (Enter q to exit)"
   if ($UserEmail -eq "q"){exit}
}
#$UserEmail = $UserEmail.Replace('@ampf.com','')

$addTicket = Read-host "`n Do you want to add notes to Ticket?(y/n)"
if($addTicket -like "y")
{
    while(!($Ticketnumber))
    {
    $Ticketnumber = Read-host "Enter Ticket Number (TASKXXXX, ITASKXXXX, or INCXXXXXXX, Enter q to exit)"
    $Ticketnumber = $Ticketnumber.ToUpper()
    $Ticketnumber = $Ticketnumber.Trim()
        if($Ticketnumber)
        {
            if ($Ticketnumber -eq "q"){exit}

            if($Ticketnumber -like "TASK*" -or $Ticketnumber -like  "INC*" -or $Ticketnumber -like  "ITASK*")
            {
                write-host -ForegroundColor Cyan  "Ticket number set to: $Ticketnumber"
            }
            else
            {
                $Ticketnumber = $null
            }
        }
        else
        {
            $Ticketnumber = $null
        }
    }
    Swap-PCs -OldComputerFullname $OldComputerFullname -NewComputerFullname $NewComputerFullname -UserFullname "$UserFullname" -UserEmail $UserEmail -StockRoomValue $StockRoomValue -loginUsername $loginUsername -loginPassword $loginPassword -ticket $Ticketnumber -logpath $logpath

}
else
{
    Swap-PCs -OldComputerFullname $OldComputerFullname -NewComputerFullname $NewComputerFullname -UserFullname "$UserFullname" -UserEmail $UserEmail -StockRoomValue $StockRoomValue -loginUsername $loginUsername -loginPassword $loginPassword -ticket "None" -logpath $logpath
}

}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------
    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}


