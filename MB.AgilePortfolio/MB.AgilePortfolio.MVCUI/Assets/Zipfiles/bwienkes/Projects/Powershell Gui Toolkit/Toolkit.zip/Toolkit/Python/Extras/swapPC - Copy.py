import sys, getopt
import re
import time
import string
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

import datetime            
#print("The arguments are: " , str(sys.argv))
#ArgumentList: [sys.argv[0],sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4],sys.argv[5],sys.argv[6],sys.argv[7]]
#print(sys.argv[1])
OldComputerFullname = ''
NewComputerFullname = ''
UserFullname = ''
StockroomLocation = ''
Memberships = ''
LoginUsername = ''
LoginUserPassword = ''

StockRoomValueGB = 'AAH Green Bay'
StockRoomValueLV = 'AAH LV Site'
StockRoomValuePHX = 'AAH PHX'

if StockroomLocation == "GB":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "GREEN BAY":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "WI":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "WISCONSIN":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "DEPERE":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "DE PERE":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "PACKERLAND":
    StockroomLocation = StockRoomValueGB

if StockroomLocation == "LV":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "LASVEGAS":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "LAS VEGAS":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOTRD":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOT RD":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOT":
    StockroomLocation = StockRoomValueLV

if StockroomLocation == "AZ":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "DUNLAP":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "BC":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHOENIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHEONIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHENIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHONIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHX":
    StockroomLocation = StockRoomValuePHX

# TEST VALUES
#Memberships = ["SCCM-AAH-LIC APP - Adobe Acrobat Creator DC"]
#LoginUsername = "bwienk1"
#LoginUserPassword = 
#OldComputerFullname = "wilg00mp18ywsb"
#NewComputerFullname = "wilg00mp18ytuu"
#StockroomLocation = "AAH Green Bay"
#UserFullname = "Brenton M Wienkes"
#OldComputerFullname = OldComputerFullname.upper()
#NewComputerFullname = NewComputerFullname.upper()

    
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"

#   SETUP CHROME DRIVER
options = Options()
#options.headless = True
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver')
wait = WebDriverWait(driver, 10)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

#Find Old PC Serial
PC = OldComputerFullname
if "WILG000" in PC: PC = PC.replace("WILG000","")
elif "WILG00" in PC: PC = PC.replace("WILG00","")
elif "WIDG000" in PC: PC = PC.replace("WIDG000","")
elif "WIDG00" in PC: PC = PC.replace("WIDG00","")
elif "AZLG000" in PC: PC = PC.replace("AZLG000","")
elif "AZLG00" in PC: PC = PC.replace("AZLG00","")
elif "AZDG000" in PC: PC = PC.replace("AZDG000","")
elif "AZDG00" in PC: PC = PC.replace("AZDG00","")
elif "NVLG000" in PC: PC = PC.replace("NVLG000","")
elif "NVLG00" in PC: PC = PC.replace("NVLG00","")
elif "NVDG000" in PC: PC = PC.replace("NVDG000","")
elif "NVDG00" in PC: PC = PC.replace("NVDG00","")
elif "MILG000" in PC: PC = PC.replace("MILG000","")
elif "MILG00" in PC: PC = PC.replace("MILG00","")
elif "MIDG000" in PC: PC = PC.replace("MIDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "MNLG000" in PC: PC = PC.replace("MNLG000","")
elif "MNLG00" in PC: PC = PC.replace("MNLG00","")
elif "MNDG000" in PC: PC = PC.replace("MNDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "WIVGP" in PC:
    #PC is VDI (different functions required)
    PC = PC
    isVDI_Old_PC = True
else:
    #Can't Format to Serial number from full name
    print("NO PC SERIAL COULD BE FOUND FOR: " + PC)
    print("Exiting script")
    sys.exit
    
OldPCSerial = PC

PC = NewComputerFullname
if "WILG000" in PC:
    PC = PC.replace("WILG000","")
    isLaptop = True
elif "WILG00" in PC:
    PC = PC.replace("WILG00","")
    isLaptop = True
elif "WIDG000" in PC: PC = PC.replace("WIDG000","")
elif "WIDG00" in PC: PC = PC.replace("WIDG00","")
elif "AZLG000" in PC:
    PC = PC.replace("AZLG000","")
    isLaptop = True
elif "AZLG00" in PC:
    PC = PC.replace("AZLG00","")
    isLaptop = True
elif "AZDG000" in PC: PC = PC.replace("AZDG000","")
elif "AZDG00" in PC: PC = PC.replace("AZDG00","")
elif "NVLG000" in PC:
    PC = PC.replace("NVLG000","")
    isLaptop = True
elif "NVLG00" in PC:
    PC = PC.replace("NVLG00","")
    isLaptop = True
elif "NVDG000" in PC: PC = PC.replace("NVDG000","")
elif "NVDG00" in PC: PC = PC.replace("NVDG00","")
elif "MILG000" in PC:
    PC = PC.replace("MILG000","")
    isLaptop = True
elif "MILG00" in PC:
    PC = PC.replace("MILG00","")
    isLaptop = True
elif "MIDG000" in PC: PC = PC.replace("MIDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "MNLG000" in PC:
    PC = PC.replace("MNLG000","")
    isLaptop = True
elif "MNLG00" in PC:
    PC = PC.replace("MNLG00","")
    isLaptop = True
elif "MNDG000" in PC: PC = PC.replace("MNDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "WIVGP" in PC:
    #PC is VDI (different functions required)
    PC = PC
    isVDI_New_PC = True
else:
    #Can't Format to Serial number from full name
    print("NO PC SERIAL COULD BE FOUND FOR: " + PC)
    print("Exiting script")
    sys.exit

NewPCSerial = PC

Universal_SN_iframe = "gsft_main"

OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + OldPCSerial
OldPCiframe = Universal_SN_iframe

NewPCWebPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + NewPCSerial
NewPCiframe = Universal_SN_iframe

stateID = "alm_hardware.install_status"
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"

userAssignedID = "sys_display.alm_hardware.assigned_to"

DateAssignedID = "alm_hardware.assigned"

RequestMembershipPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
memberUserID = "sys_display.IO:3cd7f12a903da80087a863f119b63795"
memberModGroupID = "IO:cc7033214fd84f806f4d3e1ca310c75c"
memberTargetGroupID = "IO:94390d824fdc03006f4d3e1ca310c72f"
memberActionID = "IO:1f34c9844fecdb406f4d3e1ca310c7f7"
memberMembershipID = "sys_display.IO:42e078f74f8c0780c8e7e57d0210c77b"
memberPCtbxID = "computer_list_cmdb_ci_computer"
membership_PC_List_Hidden_ID = "cmdb_ci_computer.computer_list"
#memberPCHiddenListID
memberShowAvailablePCEvent = "\"return checkEnter(event, 'cmdb_ci_computer.computer_list')\""
membership_Element_PC_List_select_ID = "computer_list_select_0"
#memberPClistID = "computer_list_select_0"
memberReasonID = "IO:96695c1d311df0404c72ad13d18ba9f0"
memberSubmitBtnCode = "\"if ($$('.order_buttons .disabled_order_button').length == 0) { orderNow(); } else { alert('Please wait - price being updated'); };\""

#Begin Webpage navigation to Old PC record first
driver.get(OldPCWebpage)

#   INITIAL LOGIN PAGE
#SET ELEMENTS IN LOGIN PAGE
userid = driver.find_element_by_id('userID')
password = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id("loginbtn")

#SEND KEYS TO ELEMENTS IN LOGIN PAGE
print(userid.get_attribute('id') + " adding text...")
userid.send_keys(LoginUsername)
print(password.get_attribute('id') + " adding text...")
#test = input('this is pass =' + LoginUserPassword)
print(LoginUserPassword)
#test = input('Continue?')
#test = input('Continue?')
#test = input('Continue?')
password.send_keys(LoginUserPassword)
print(btnLogin.get_attribute('id') + " clicking button...")
btnLogin.click()

#   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
if driver.title == "Password is about expire":
    #NEEDS RDO BUTTON TO BE SELECTED YET BEFORE CLICKING
    
    #   RADIO BUTTON
    print("finding Radio button")
    rdoProceed = driver.find_element_by_css_selector("input[id='proceedWebsite']")
    print("checking Radio button")
    rdoProceed.checked()
    print("checked Radio button")
    print("sleeping 10")
    time.sleep(10)
    #rdoProceed.click()
    
    #   SUBMIT BUTTON
    print("getting continue button")
    button = driver.find_element_by_id("//button[@onclick=\"JavaScript:setValues();\"]")
    print("Clicking continue button")
    
    #   BUTTON COMMENTED OUT AS RDO NEEDS TO BE SELECTED PROPERLY FIRST
    #button.click()

print("Old PC Service-Now Records Started")

#SWITCH IFRAME
wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))

#Assigned User
wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
Element = driver.find_element_by_id(userAssignedID)
Element.send_keys(Keys.CONTROL, 'a')
Element.send_keys(Keys.DELETE)

#State to In Stock
wait.until(EC.visibility_of_element_located((By.ID, stateID)))
select = Select(driver.find_element_by_id(stateID))
select.select_by_value('6')

#Set Stockroom PC is Located
wait.until(EC.visibility_of_element_located((By.ID, StockRoomID)))
Element = driver.find_element_by_id(StockRoomID)
Element.send_keys(StockroomLocation)
#Set Substate Available
wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
select = Select(driver.find_element_by_id(SecondaryStateID))
select.select_by_value('available')

#Set Assigned Date
wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
                   

#WORK NOTES
Element = driver.find_element_by_id("section_tab.5999f4f1dbb302001e0599b8f0b8f5db")
driver.execute_script("document.getElementById('section_tab.5999f4f1dbb302001e0599b8f0b8f5db').setAttribute('style', \"display: block;\")")
driver.execute_script("document.getElementById('section_tab.5999f4f1dbb302001e0599b8f0b8f5db').setAttribute('aria-hidden', \"false\")")

driver.execute_script("document.getElementById('section_tab.66338a92cb11220005ee77a4634c9c83').setAttribute('style', \"display: none;\")")
driver.execute_script("document.getElementById('section_tab.66338a92cb11220005ee77a4634c9c83').setAttribute('aria-hidden', \"true\")")

html_list = driver.find_element_by_xpath("//ul[@class='h-card-wrapper activities-form']")
items = html_list.find_elements_by_tag_name("li")
sameline = False
location = None
combo = None
output = None
possiblcombodigits = None
for item in items:
    text = item.text
    utext = text.upper()
    if "LOCATION" in utext:
        str1 = "LOCATION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOACTION" in utext:
        str1 = "LOCATION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCTAION" in utext:
        str1 = "LOCTAION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCAITON" in utext:
        str1 = "LOCAITON"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCATINO" in utext:
        str1 = "LOCATINO"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LCATION" in utext:
        str1 = "LCATION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOATION" in utext:
        str1 = "LOATION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCTION" in utext:
        str1 = "LOCTION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCAION" in utext:
        str1 = "LOCAION"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCATON" in utext:
        str1 = "LOCATON"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCATIN" in utext:
        str1 = "LOCATIN"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCATIO" in utext:
        str1 = "LOCATIO"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "LOCATOIN" in utext:
        str1 = "LOCATOIN"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "DESK" in utext:
        str1 = "DESK"
        startingindex = utext.index(str1)
        location = utext[startingindex:]
    elif "DSEK" in utext:
        str1 = "DSEK"
        startingindex = utext.index(str1)
        location = utext[startingindex:]

    if not location is None:
        possiblcombodigits = re.findall(r'(?:^|\D)(\d{4})(?:\D|$)', location)
        if not possiblcombodigits is None:
            if "COMBO" in utext:
                str1 = "COMBO"
                startingindex = utext.index(str1)
                utext[startingindex:]
                combo = utext[startingindex:]
            elif "LOCK" in utext:
                str1 = "LOCK"
                startingindex = utext.index(str1)
                combo = utext[startingindex:]
            elif "COMBINATION" in utext:
                str1 = "COMBINATION"
                startingindex = utext.index(str1)
                combo = utext[startingindex:]
            elif "COMBONATION" in utext:
                str1 = "COMBONATION"
                startingindex = utext.index(str1)
                combo = utext[startingindex:]
            elif "COMBNATION" in utext:
                str1 = "COMBNATION"
                startingindex = utext.index(str1)
                combo = utext[startingindex:]
            elif "KENSINGTON" in utext:
                str1 = "KENSINGTON"
                startingindex = utext.index(str1)
                combo = utext[startingindex:]
            elif "CODE" in utext:
                str1 = "CODE"
                startingindex = utext.index(str1)
                #combo = utext[startingindex:]
            else:
                possiblcombodigits = re.findall(r'(?:^|\D)(\d{4})(?:\D|$)', utext)
                if not possiblcombodigits is None:
                    if "COMBO" in utext:
                        str1 = "COMBO"
                        startingindex = utext.index(str1)
                        utext[startingindex:]
                        combo = utext[startingindex:]
                    elif "LOCK" in utext:
                        str1 = "LOCK"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBINATION" in utext:
                        str1 = "COMBINATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBONATION" in utext:
                        str1 = "COMBONATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBNATION" in utext:
                        str1 = "COMBNATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "KENSINGTON" in utext:
                        str1 = "KENSINGTON"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "CODE" in utext:
                        str1 = "CODE"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
    if not location is None:
        if not combo is None:
            if location == combo:
                sameline = True
                if location in combo:
                    output = combo
                elif combo in location:
                    output = location
if not location is None:
    print("Location found = " + location)
else:
    print("No Location found in notes")
if not combo is None:
    print ("Combo found = " + combo)
else:
    print("No Combo found in notes")

#SUBMIT CHANGES TO OLD PC
#driver.execute_script("javascript:\"return gsftSubmit(this);\"")


#   NEW PC
#New Tab, switch tab, and navigate new tab to New PC webpage
print("New PC Service-Now Records Started")
expectedwindows = 2 
windows_before  = driver.current_window_handle
driver.execute_script("window.open('" + NewPCWebPage + "')")
WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
windows_after = driver.window_handles
driver.switch_to.window(windows_after[expectedwindows - 1])
expectedwindows = expectedwindows + 1 
print("Page Title after Tab Switching is : %s" %driver.title)


#SWITCH IFRAME
wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))

#State to In use
wait.until(EC.visibility_of_element_located((By.ID, stateID)))
select = Select(driver.find_element_by_id(stateID))
select.select_by_value('1')

#Assigned User
wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
Element = driver.find_element_by_id(userAssignedID)
Element.send_keys(Keys.CONTROL, 'a')
Element.send_keys(UserFullname)

#Assigned Dated
wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
#Element = driver.find_element_by_id("//input[@id='" + DateAssignedID + "']")
driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
                   
#Work Notes / set combo and location
print("Adding worknotes to New PC...")

Element = driver.find_element_by_id("section_tab.5999f4f1dbb302001e0599b8f0b8f5db")
driver.execute_script("document.getElementById('section_tab.5999f4f1dbb302001e0599b8f0b8f5db').setAttribute('style', \"display: block;\")")
driver.execute_script("document.getElementById('section_tab.5999f4f1dbb302001e0599b8f0b8f5db').setAttribute('aria-hidden', \"false\")")

driver.execute_script("document.getElementById('section_tab.66338a92cb11220005ee77a4634c9c83').setAttribute('style', \"display: none;\")")
driver.execute_script("document.getElementById('section_tab.66338a92cb11220005ee77a4634c9c83').setAttribute('aria-hidden', \"true\")")

if sameline == True:
    print("Location and combo on same line")
    print(output)
    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id("activity-stream-textarea"), output)
else:
    if not location is None:
        if not combo is None:
            output = location + "\n" + combo
        else:
            output = location
    elif not combo is None:
        output = combo 
    else:
        output = "No Location or Combo found in " + OldComputerFullname + " work notes"
    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id("activity-stream-textarea"), location)

#SUBMIT CHANGES TO OLD PC HERE
#driver.execute_script("javascript:\"return gsftSubmit(this);\"")

#GET MEMBERSHIPS WEBPAGES
print("Starting Memberships...")

#Filter if membership is a type that is ordered
for member in Memberships:
    if "SCCM-" in member:
        #SCCM membership
        SCCM = member
    elif "RG-" in member:
        #Role Group membership
        RG = member
    else:
        #No Other memberships defined currently, so skip
        continue
    
    #New Tab, switch tab, and navigate new tab to Request AD Membership webpage
    windows_before  = driver.current_window_handle
    driver.execute_script("window.open('" + RequestMembershipPage + "')")
    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    windows_after = driver.window_handles
    driver.switch_to.window(windows_after[expectedwindows - 1])
    print("Page Title after Tab Switching is : %s" %driver.title)
    expectedwindows = expectedwindows + 1
    
    #IFrame switch
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    
    #Username element
    wait.until(EC.visibility_of_element_located((By.ID, memberUserID)))
    Element = driver.find_element_by_id(memberUserID)
    Element.send_keys(UserFullname)
    Element.send_keys(Keys.TAB)
    driver.execute_script("document.getElementById('" + memberUserID + "').setAttribute('value', '" + UserFullname + "')")

    #Group Modify element
    wait.until(EC.visibility_of_element_located((By.ID, memberModGroupID)))
    select = Select(driver.find_element_by_id(memberModGroupID))
    select.select_by_value('Modify Computer Group Membership')

                       
    #Group target element
    wait.until(EC.visibility_of_element_located((By.ID, memberTargetGroupID)))
    select = Select(driver.find_element_by_id(memberTargetGroupID))
                       
    if "SCCM-" in member: select.select_by_value('SCCM Group')
    elif "RG-" in member: select.select_by_value('Role Group')
    else:
        #Failsafe continue in case one slips by
        continue
    
    #Action to perform element
    wait.until(EC.visibility_of_element_located((By.ID, memberActionID)))
    select = Select(driver.find_element_by_id(memberActionID))
    select.select_by_value('Add a computer to a group')

    #Membership element
    wait.until(EC.visibility_of_element_located((By.ID, memberMembershipID)))
    Element = driver.find_element_by_id(memberMembershipID)
    print("Adding " + member + " to " + NewComputerFullname)
    Element.send_keys(member)
    Element.send_keys(Keys.TAB) #Send_Keys tends to work better here

    #PC textbox Element
    wait.until(EC.visibility_of_element_located((By.ID, memberPCtbxID)))
    Element1 = driver.find_element_by_id(memberPCtbxID)
    Element1.send_keys(NewComputerFullname)
    driver.execute_script("document.getElementById('" + membership_PC_List_Hidden_ID + "').setAttribute('value', '^nameSTARTSWITH" + NewComputerFullname + "')")
    Element1.send_keys(Keys.TAB)
    Element2 = driver.find_element_by_id(membership_Element_PC_List_select_ID)
    time.sleep(5)
    Element2 = driver.find_element_by_id(membership_Element_PC_List_select_ID)
    selected = Select(Element2).select_by_index(0)
    Element2.send_keys(Keys.RIGHT)
    time.sleep(.5)
    Element3 = driver.find_element_by_id("computer_list_select_1")
    time.sleep(.5)
    select = Select(Element3)
    selected_option = select.first_selected_option
    selectedtext = selected_option.text
    if selectedtext is None:
        print("Could not find PC to add " + member + " membership to!")
        print("Please be sure " + NewComputerFullname + " does not already have " + member + " membership")
        sys.exit()
    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id(memberReasonID), "Transfering Membership from " + OldComputerFullname + " to " + NewComputerFullname)

    #Submit
    #driver.execute_script("javascript:" + memberSubmitBtnCode)
    

#   ORDER CREDENTIALS
if isLaptop == True:
    print("Starting wireless credentials request...")
    windows_before  = driver.current_window_handle
    driver.execute_script("window.open('https://ameriprise.service-now.com/ameriprise/catalog.do?sysparm_document_key=sc_cat_item,2b468f379cb941004c7201eb33272b42')")
    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    windows_after = driver.window_handles
    driver.switch_to.window(windows_after[expectedwindows - 1])
    print("Page Title after Tab Switching is : %s" %driver.title)
    expectedwindows = expectedwindows + 1
                          
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    
    #Username textbox for order credentials
    wait.until(EC.visibility_of_element_located((By.ID, "sys_display.IO:3cd7f12a903da80087a863f119b63795")))
    driver.execute_script("document.getElementById('sys_display.IO:3cd7f12a903da80087a863f119b63795').setAttribute('value', '" + UserFullname + "')")
    wait.until(EC.visibility_of_element_located((By.ID, "IO:9d76cf379cb941004c7201eb33272b36")))
    select = Select(driver.find_element_by_id('IO:9d76cf379cb941004c7201eb33272b36'))
    select.select_by_value('Yes - Employee')
    
    wait.until(EC.visibility_of_element_located((By.ID, "IO:4b3787779cb941004c7201eb33272bdc")))
    select = Select(driver.find_element_by_id('IO:4b3787779cb941004c7201eb33272bdc'))
    select.select_by_value('No')
    
    wait.until(EC.visibility_of_element_located((By.ID, "IO:4f674b779cb941004c7201eb33272b18")))
    select = Select(driver.find_element_by_id('IO:4f674b779cb941004c7201eb33272b18'))
    select.select_by_value('No')
    
    wait.until(EC.visibility_of_element_located((By.ID, "IO:1c87cf379cb941004c7201eb33272b56")))
    select = Select(driver.find_element_by_id('IO:1c87cf379cb941004c7201eb33272b56'))
    select.select_by_value('Yes')
    
    wait.until(EC.visibility_of_element_located((By.ID, "IO:dac086244ddf91004c72de7a362d4691")))
    select = Select(driver.find_element_by_id('IO:dac086244ddf91004c72de7a362d4691'))
    select.select_by_value('No')
                  
#driver.quit()
