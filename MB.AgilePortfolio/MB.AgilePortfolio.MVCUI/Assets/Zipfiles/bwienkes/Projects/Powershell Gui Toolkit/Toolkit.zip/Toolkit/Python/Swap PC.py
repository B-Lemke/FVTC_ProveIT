import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

scriptpath = os.path.dirname(os.path.realpath(__file__))

OldComputerFullname = sys.argv[1]
NewComputerFullname = sys.argv[2]
UserFullname = sys.argv[3]
UserEmail = sys.argv[4]
StockroomLocation = sys.argv[5]
Memberships = ["GP-EUC-CB-RemovableMediaExceptionAll"]
TicketNumber = None
LoginUsername = sys.argv[6]
LoginUserPassword = sys.argv[7]

TicketNotes = []
StockRoomValueGB = 'AAH Green Bay'
StockRoomValueLV = 'AAH LV Site'
StockRoomValuePHX = 'AAH PHX'
file = codecs.open(sys.argv[8],"w","utf-8")

file.write("---------- START INPUT VALUES PASSED TO SCRIPT ---------------- |")
stringout = "OldComputerFullname set to: " + str(OldComputerFullname) + "|"
file.write(stringout)

stringout = "NewComputerFullname set to: " + str(NewComputerFullname) + "|"
file.write(stringout)

stringout = "UserFullname set to: " + str(UserFullname) + "|"
file.write(stringout)

stringout = "UserEmail set to: " + str(UserEmail) + "|"
file.write(stringout)

stringout = "StockroomLocation set to: " + str(StockroomLocation) + "|"
file.write(stringout)

stringout = "TicketNumber set to: " + str(TicketNumber) + "|"
file.write(stringout)
file.write("---------- END INPUT VALUES PASSED TO SCRIPT ---------------- | |")


file.write("---------- START TICKET SETUP ---------------- |")
try:
    if not TicketNumber is None:   
        if TicketNumber.startswith('INC'):
            stringout = str(TicketNumber) + " detected as: INC|" 
            ticketurl = "https://ameriprise.service-now.com/incident.do?uri=&sysparm_query=number=" + str(TicketNumber)
        elif TicketNumber.startswith('TASK'):
            ticketurl = "https://ameriprise.service-now.com/sc_task.do?uri=&sysparm_query=number=" + str(TicketNumber)
            stringout = str(TicketNumber) + " detected as: TASK|"
        elif TicketNumber.startswith('ITASK'):
            stringout = str(TicketNumber) + " detected as: ITASK|"
            ticketurl = "https://ameriprise.service-now.com/u_incident_task.do?uri=&sysparm_query=number=" + str(TicketNumber)
        else:
            ticketurl = "NONE"
            stringout = str(TicketNumber) + " NOT SUPPORTED|"
            print("Ticket Type not supported (ONLY ITASK, TASK, and INC are supported at this time")
            TicketNumber = None
    else:
        #No Ticket Provided
        ticketurl = "NONE"
        stringout = TicketNumber + " NOT SUPPORTED|"
except:
    ticketurl = "NONE"
    print("Couldn't set ticket")
    
#Write ticketnumber and URL set
file.write(" |")
file.write(str(stringout))
file.write("TicketURL set to: " + str(ticketurl) + "|")
file.write("---------- END TICKET SETUP ---------------- | |")

file.write("---------- START MEMBERSHIPS ON OLD PC ---------------- |")
for mbr in Memberships:
    #write member in memberships
    file.write(str(mbr) + "|")

file.write("---------- END MEMBERSHIPS ON OLD PC ---------------- | |")

file.write("---------- START STOCKROOM FILTERING ---------------- |")
#GB
if StockroomLocation == "GB":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "GREEN BAY":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "WI":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "WISCONSIN":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "DEPERE":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "DE PERE":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "PACKERLAND":
    StockroomLocation = StockRoomValueGB
#NV
if StockroomLocation == "LV":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "NV":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "LASVEGAS":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "LAS VEGAS":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOTRD":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOT RD":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOT":
    StockroomLocation = StockRoomValueLV
#AZ
if StockroomLocation == "AZ":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "DUNLAP":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "BC":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHOENIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHEONIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHENIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHONIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHX":
    StockroomLocation = StockRoomValuePHX
    
stringout = "StockroomLocation set to: " + str(StockroomLocation) + "|"
file.write(stringout)

file.write("---------- END STOCKROOM FILTERING ---------------- | |")

file.write("---------- START DATETIME SETUP ---------------- |")
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"
stringout = "Date set to: " + str(nowoutput) + "|"
file.write(stringout)
file.write("---------- END DATETIME SETUP ---------------- | |")

file.write("---------- START CHROMEWEBDRIVER SETUP ---------------- |")
file.write("              FOR DEBUGGING ONLY|")
#   SETUP CHROME DRIVER
options = Options()

# -------- HEADLESS MODE (UNCOMMENT TO TURN ON)

#options.headless = True
#options.add_argument('log-level=3')
#options.add_argument('--window-size=1920x1080')

# -------- HEADLESS MODE (UNCOMMENT TO TURN ON)

waittimeout = 10
chromewebdriverpath = scriptpath + '/ChromeDriver/chromedriver'
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")
wait = WebDriverWait(driver, waittimeout)

file.write("Chrome Web Driver Path set to: " + str(chromewebdriverpath) + "|")
file.write("Chrome Web Driver Options set to: " + str(options) + "|")
file.write("Chrome Web Driver Wait Timeout (in seconds) set to: " + str(waittimeout) + "|")
file.write("---------- END CHROMEWEBDRIVER SETUP ---------------- | |")

file.write("---------- START DEFAULTING BOOLS ---------------- |")
file.write("             FOR DEBUGGING ONLY|")
isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

file.write("isVDI_Old_PC = False|")
file.write("isVDI_New_PC = False|")
file.write("isLaptop = False|")
file.write("---------- END DEFAULTING BOOLS ---------------- | |")


file.write("---------- START OLD PC FILTERING ---------------- |")
#Find Old PC Serial
PC = OldComputerFullname
if "WILG000" in PC: PC = PC.replace("WILG000","")
elif "WILG00" in PC: PC = PC.replace("WILG00","")
elif "WIDG000" in PC: PC = PC.replace("WIDG000","")
elif "WIDG00" in PC: PC = PC.replace("WIDG00","")
elif "AZLG000" in PC: PC = PC.replace("AZLG000","")
elif "AZLG00" in PC: PC = PC.replace("AZLG00","")
elif "AZDG000" in PC: PC = PC.replace("AZDG000","")
elif "AZDG00" in PC: PC = PC.replace("AZDG00","")
elif "NVLG000" in PC: PC = PC.replace("NVLG000","")
elif "NVLG00" in PC: PC = PC.replace("NVLG00","")
elif "NVDG000" in PC: PC = PC.replace("NVDG000","")
elif "NVDG00" in PC: PC = PC.replace("NVDG00","")
elif "MILG000" in PC: PC = PC.replace("MILG000","")
elif "MILG00" in PC: PC = PC.replace("MILG00","")
elif "MIDG000" in PC: PC = PC.replace("MIDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "MNLG000" in PC: PC = PC.replace("MNLG000","")
elif "MNLG00" in PC: PC = PC.replace("MNLG00","")
elif "MNDG000" in PC: PC = PC.replace("MNDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "WIVGP" in PC:
    #PC is VDI (different functions required)
    PC = PC
    isVDI_Old_PC = True
    file.write("isVDI_Old_PC set to: True|")
else:
    #Can't Format to Serial number from full name
    print("NO PC SERIAL COULD BE FOUND FOR: " + str(PC))
    stringout = "NO PC SERIAL COULD BE FOUND FOR: " + str(PC) + "|"
    file.write(stringout)
    print("Exiting script")
    stringout = "Exiting script |"
    file.write(stringout)
    file.close()
    exit()
    
OldPCSerial = PC

stringout = "OldPCSerial set to: " + str(OldPCSerial) + "|"
file.write(stringout)
file.write("---------- END OLD PC FILTERING ---------------- | |")

file.write("---------- START NEW PC FILTERING ---------------- |")
PC = NewComputerFullname
if "WILG000" in PC:
    PC = PC.replace("WILG000","")
    isLaptop = True
elif "WILG00" in PC:
    PC = PC.replace("WILG00","")
    isLaptop = True
elif "WIDG000" in PC: PC = PC.replace("WIDG000","")
elif "WIDG00" in PC: PC = PC.replace("WIDG00","")
elif "AZLG000" in PC:
    PC = PC.replace("AZLG000","")
    isLaptop = True
elif "AZLG00" in PC:
    PC = PC.replace("AZLG00","")
    isLaptop = True
elif "AZDG000" in PC: PC = PC.replace("AZDG000","")
elif "AZDG00" in PC: PC = PC.replace("AZDG00","")
elif "NVLG000" in PC:
    PC = PC.replace("NVLG000","")
    isLaptop = True
elif "NVLG00" in PC:
    PC = PC.replace("NVLG00","")
    isLaptop = True
elif "NVDG000" in PC: PC = PC.replace("NVDG000","")
elif "NVDG00" in PC: PC = PC.replace("NVDG00","")
elif "MILG000" in PC:
    PC = PC.replace("MILG000","")
    isLaptop = True
elif "MILG00" in PC:
    PC = PC.replace("MILG00","")
    isLaptop = True
elif "MIDG000" in PC: PC = PC.replace("MIDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "MNLG000" in PC:
    PC = PC.replace("MNLG000","")
    isLaptop = True
elif "MNLG00" in PC:
    PC = PC.replace("MNLG00","")
    isLaptop = True
elif "MNDG000" in PC: PC = PC.replace("MNDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "WIVGP" in PC:
    #PC is VDI (different functions required)
    PC = PC
    isVDI_New_PC = True
    stringout = "isVDI_New_PC set to: True"
    file.write(stringout)
else:
    #Can't Format to Serial number from full name
    print("NO PC SERIAL COULD BE FOUND FOR: " + str(PC))
    file.write("NO PC SERIAL COULD BE FOUND FOR: " + str(PC) + "|")
    print("Exiting script")
    stringout = "Exiting script" + "|"
    file.write(stringout)
    file.close()
    exit()

NewPCSerial = PC
stringout = "NewPCSerial set to: " + str(NewPCSerial) + "|"
file.write(stringout)
file.write("---------- END NEW PC FILTERING ---------------- | |")

file.write("----------- START WEB ELEMENT VARIABLES -------------------|")
file.write("              DEBUGGING PURPOSES ONLY      |")

#Univseral Service-Now iframe
Universal_SN_iframe = "gsft_main"
file.write("Universal_SN_iframe set to: " + str(Universal_SN_iframe) + "|")

#Old PC Webpage/iframe
OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + OldPCSerial
stringout = "OldPCWebpage set to: " + str(OldPCWebpage) + "|"
file.write(stringout)
OldPCiframe = Universal_SN_iframe
file.write("OldPCiframe set to: " + str(OldPCiframe) + "|")

#New PC Webpage/iframe
NewPCWebPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + NewPCSerial
stringout = "NewPCWebPage set to: " + str(NewPCWebPage) + "|"
file.write(stringout)
NewPCiframe = Universal_SN_iframe
file.write("NewPCiframe set to: " + str(NewPCiframe) + "|")

#State Element
stateID = "alm_hardware.install_status"
file.write("stateID set to: " + str(stateID) + "|")
file.write("            Option Values of Element:|")
file.write("   --------------------------------------------------|")
file.write('    <option value="1">In use</option>|')
file.write('    <option value="2">On order</option>|')
file.write('    <option value="3">In maintenance</option>|')
file.write('    <option value="6">In stock</option>|')
file.write('    <option value="7">Retired</option>|')
file.write('    <option value="8">Missing</option>|')
file.write('    <option value="9">In transit</option>|')
file.write('    <option value="10">Consumed</option>| |')
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

#Secondary State Element
SecondaryStateID = "alm_hardware.substatus"
file.write("SecondaryStateID set to: " + str(SecondaryStateID) + "|")
file.write("                Option Values of Element:|")
file.write("   --------------------------------------------------|")
file.write('    <option value="available">Available</option>|')
file.write('    <option value="reserved">Reserved</option>|')
file.write('    <option value="defective">Defective</option>|')
file.write('    <option value="pending_repair">Pending repair</option>|')
file.write('    <option value="pending_install">Pending install</option>|')
file.write('    <option value="pending_disposal">Pending disposal</option>|')
file.write('    <option value="pending_transfer">Pending transfer</option>|')
file.write('    <option value="pre_allocated">Pre-allocated</option></select>| |')
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"
file.write("AssetFunctionID set to: " + str(AssetFunctionID) + "|")
file.write("                Option Values of Element:|")
file.write("   --------------------------------------------------|")
file.write('    <option value="BCP">BCP</option>|')
file.write('    <option value="Call Center">Call Center</option>|')
file.write('    <option value="Disaster Recovery">Disaster Recovery</option>|')
file.write('    <option value="Lab Device">Lab Device</option>|')
file.write('    <option value="Loaner">Loaner</option>|')
file.write('    <option value="Monitoring">Monitoring</option>|')
file.write('    <option value="Primary Device">Primary Device</option>|')
file.write('    <option value="Secondary Device">Secondary Device</option>| |')
#<option value="BCP">BCP</option>
#<option value="Call Center">Call Center</option>
#<option value="Disaster Recovery">Disaster Recovery</option>
#<option value="Lab Device">Lab Device</option>
#<option value="Loaner">Loaner</option>
#<option value="Monitoring">Monitoring</option>
#<option value="Primary Device">Primary Device</option>
#<option value="Secondary Device">Secondary Device</option>
#<option value="Security">Security</option>
#<option value="Shared Device">Shared Device</option>
#<option value="Testing">Testing</option>
#<option value="Training">Training</option>
#<option value="Development">Development</option>
#<option value="Spare">Spare</option>
#<option value="Hot-Spare" selected="SELECTED">Hot-Spare</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"
file.write("StockRoomID set to: " + str(StockRoomID) + "|")

userAssignedID = "sys_display.alm_hardware.assigned_to"
file.write("userAssignedID set to: " + str(userAssignedID) + "|")

DateAssignedID = "alm_hardware.assigned"
file.write("DateAssignedID set to: " + str(DateAssignedID) + "|")

RequestMembershipPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
file.write("RequestMembershipPage set to: " + str(RequestMembershipPage) + "|")

memberUserID = "sys_display.IO:3cd7f12a903da80087a863f119b63795"
file.write("memberUserID set to: " + str(memberUserID) + "|")

memberModGroupID = "IO:cc7033214fd84f806f4d3e1ca310c75c"
file.write("memberModGroupID set to: " + str(memberModGroupID) + "|")

memberTargetGroupID = "IO:94390d824fdc03006f4d3e1ca310c72f"
file.write("memberTargetGroupID set to: " + str(memberTargetGroupID) + "|")

memberActionID = "IO:1f34c9844fecdb406f4d3e1ca310c7f7"
file.write("memberActionID set to: " + str(memberActionID) + "|")

memberMembershipID = "sys_display.IO:42e078f74f8c0780c8e7e57d0210c77b"
file.write("memberMembershipID set to: " + str(memberMembershipID) + "|")

memberPCtbxID = "computer_list_cmdb_ci_computer"
file.write("memberPCtbxID set to: " + str(memberPCtbxID) + "|")

membership_PC_List_Hidden_ID = "cmdb_ci_computer.computer_list"
file.write("membership_PC_List_Hidden_ID set to: " + str(membership_PC_List_Hidden_ID) + "|")

#   NOT NEEDED
#memberShowAvailablePCEvent = "\"return checkEnter(event, 'cmdb_ci_computer.computer_list')\""

membership_Element_PC_List_select_ID = "computer_list_select_0"
file.write("membership_Element_PC_List_select_ID set to: " + str(membership_Element_PC_List_select_ID) + "|")

memberReasonID = "IO:96695c1d311df0404c72ad13d18ba9f0"
file.write("memberReasonID set to: " + str(memberReasonID) + "|")

memberNotesID = "IO:3823341e0a0a0b27003118193596953f"
file.write("memberNotesID set to: " + str(memberNotesID) + "|")

file.write("------- END WEB ELEMENT VARIABLES -------------------| |")

file.write(" ------- START WEBSITE NAVIGATION  -------------------|")

#Begin Webpage navigation to Old PC record first
file.write("Navigating to OldPCWebpage...")
driver.get(OldPCWebpage)
file.write("DONE|")

#   INITIAL LOGIN PAGE REDIRECT
if driver.title == "Login":
    file.write("    ------- START LOGIN PAGE ---------|")
    file.write("   Redirected to Login Page|")
               
    print("Logging in As User...")

    #USER INPUT TEXTBOX ELEMENT SETUP
    file.write("    Getting UserID element...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, 'userID')))
        userid = driver.find_element_by_id('userID')
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #PASSWORD INPUT TEXTBOX ELEMENT SETUP
    file.write("    Getting password element...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, 'password')))
        password = driver.find_element_by_id('password')
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #LOGIN BUTTON ELEMENT SETUP
    file.write("    Getting password element...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, 'loginbtn')))
        btnLogin = driver.find_element_by_id("loginbtn")
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #SEND KEYS USER ELEMENT
    file.write("    Entering Username...")
    try:
        userid.send_keys(LoginUsername)
    except:
        file.write("FAILED: ERROR OCCURED DURING Username ENTRY|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #SEND KEYS PASSWORD ELEMENT
    file.write("    Entering Password...")
    try:
        password.send_keys(LoginUserPassword)
    except:
        file.write("FAILED: ERROR OCCURED DURING password ENTRY|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #CLICK LOGIN BUTTON ELEMENT
    file.write("    Clicking Login Button...")
    try:
        btnLogin.click()
    except:
        file.write("FAILED: ERROR OCCURED DURING Login button CLICK|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")
    file.write("    ------- END LOGIN PAGE ---------| |")

    #   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
    if driver.title == "Password is about expire":
        Element = driver.find_element_by_id("proceedWebsite")
        actions = ActionChains(driver)
        actions.move_to_element(Element)
        actions.click(Element)
        actions.perform()
        Element = driver.find_element_by_id("passwordToExpire")
        Element.click()

file.write("------------ START OLD PC SERVICE-NOW RECORD GET/SET ----------------------------|")
#OLD PC WEBPAGE
if OldPCSerial in driver.title:
    file.write("Found correct webpage for Old PC by title: " + str(driver.title) + "|")
    file.write("Starting Old PC Service-Now Record Update...|")
    print("Updating Old PC Service-Now Record...")
    
    #SWITCH IFRAME
    file.write("   Switching to iFrame...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    file.write("    Selecting General tab in record...")
    try:
        acttext = driver.find_element(By.XPATH, '//span[text()="General"]')
        actions = ActionChains(driver)
        actions.reset_actions()
        actions.move_to_element(acttext)
        actions.click(acttext)
        actions.perform()
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    if isVDI_Old_PC == False:
        file.write("   Getting Old User Assigned Element...")
        #Open User info panel
        time.sleep(1)
        
        try:
            wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
            Element = driver.find_element_by_id(userAssignedID)
            file.write("SUCCESS|")
            file.write("    Getting Old User Assigned Value...")
            try:
                OldUserAssigned = Element.get_attribute("value")
                time.sleep(.5)
                file.write("SUCCESS|")
                print("User Assigned to Old PC was: " + str(OldUserAssigned))
                file.write("        User Assigned to Old PC was: " + str(OldUserAssigned) + "|")
                print(" ")

                #Get User record show button element
                file.write("   Getting Old User Records Attributes Element...")
                try:
                    element = driver.find_element_by_id("viewr.alm_hardware.assigned_to")
                    actions = ActionChains(driver)
                    actions.reset_actions()
                    actions.move_to_element(element)
                    actions.click(element)
                    actions.perform()
                    time.sleep(3)
                    file.write("SUCCESS|")
                    #wait.until(EC.visibility_of_element_located((By.ID, "sys_user.u_space_id")))
        
                    #Get User location from user panel
                    file.write("   Getting User Location from User Attributes...")
                    try:           
                        element = driver.find_element_by_id("sys_user.u_space_id")
                        atr = element.get_attribute("value")
                        print("Location from user: " + str(atr))
                        if atr:
                            location2 = "LOCATION: " + str(atr)
                            file.write("SUCCESS|")
                            file.write("        User Space is: " + str(location2) + "|")
                        else:
                            location2 = ''
                            file.write("SUCCESS|")
                            file.write("        User Space was empty|")
                    except:
                        location2 = ''
                        file.write("FAILED: ERROR OCCURED getting user space from user attributes|")
                except:
                    location2 = ''
                    file.write("FAILED: AN ERROR OCCURED Getting User information record (Location from user) |")   
            except:
                file.write("FAILED: AN ERROR OCCURED getting value from User assigned to OLD PC!|")
                OldUserAssigned = ''
        except NoSuchElementException:
            file.write("FAILED: COULDNT FIND ELEMENT!|")
        except TimeoutException:
            file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        except:
            file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("    SUCCESSFULLY RETRIEVED USER ELEMENT|") 
    else:
        #Remove User if VDI
        file.write("   Getting Old User Assigned Element...")
        #Open User info panel
        time.sleep(1)
        
        try:
            wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
            Element = driver.find_element_by_id(userAssignedID)
            file.write("SUCCESS|")
            file.write("    Getting Old User Assigned Value...")
            try:
                OldUserAssigned = Element.get_attribute("value")
                time.sleep(.5)
                file.write("SUCCESS|")
                print("User Assigned to Old PC was: " + str(OldUserAssigned))
                file.write("        User Assigned to Old PC was: " + str(OldUserAssigned) + "|")
                print(" ")

                #Get User record show button element
                file.write("   Getting Old User Records Attributes Element...")
                try:
                    element = driver.find_element_by_id("viewr.alm_hardware.assigned_to")
                    actions = ActionChains(driver)
                    actions.reset_actions()
                    actions.move_to_element(element)
                    actions.click(element)
                    actions.perform()
                    time.sleep(3)
                    file.write("SUCCESS|")
                    #wait.until(EC.visibility_of_element_located((By.ID, "sys_user.u_space_id")))
        
                    #Get User location from user panel
                    file.write("   Getting User Location from User Attributes...")
                    try:           
                        element = driver.find_element_by_id("sys_user.u_space_id")
                        atr = element.get_attribute("value")
                        print("Location from user: " + str(atr))
                        if atr:
                            location2 = "LOCATION: " + str(atr)
                            file.write("SUCCESS|")
                            file.write("        User Space is: " + str(location2) + "|")
                        else:
                            location2 = ''
                            file.write("SUCCESS|")
                            file.write("        User Space was empty|")
                    except:
                        location2 = ''
                        file.write("FAILED: ERROR OCCURED getting user space from user attributes|")
                except:
                    location2 = ''
                    file.write("FAILED: AN ERROR OCCURED Getting User information record (Location from user) |")   
            except:
                file.write("FAILED: AN ERROR OCCURED getting value from User assigned to OLD PC!|")
                OldUserAssigned = ''
        except NoSuchElementException:
            file.write("FAILED: COULDNT FIND ELEMENT!|")
        except TimeoutException:
            file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        except:
            file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()

            
        file.write("Clearing User Assigned Field for VDI...|")
        try:                
            actions = ActionChains(Element)
            actions.reset_actions()
            actions.move_to_element(Element).click(Element).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).pause(.5).send_keys(Keys.DELETE).perform()
        except:
            file.write("ERROR Clearing User Assigned Field for VDI occured|")

    #State to In Stock (NO CHANGE if OLD VDI)
    Element = driver.find_element_by_id(StockRoomID)
    #Element.click()
    wait.until(EC.visibility_of_element_located((By.ID, stateID)))
    select = Select(driver.find_element_by_id(stateID))
    if isVDI_Old_PC == True:
        stringout = "NOT CHANGING Old VDI State|"
        file.write(stringout)
        print("NOT CHANGING Old VDI State")

        #   UNCOMMENT TO HAVE OLD VDI UPDATED IN SERVICE-NOW AS RETIRED
        #Set Disposed if VDI
        #stringout = "Setting State to Retired (value: 7)|"
        #file.write(stringout)
        #select.select_by_value('7')
        #print("Setting Old PC State to: Retired")
    else:
        #OLD PC IS NOT VDI
        stringout = "Setting State to In Stock (value: 6)|"
        file.write(stringout)
        select.select_by_value('6')
        print("Setting Old PC State to: In Stock")

        #Set OLD PC Stockroom PC to Parmameter StockroomLocation
        stringout = "Selecting all text in Stockroom field and overwritting with: " + StockroomLocation + "|"
        file.write(stringout)
        wait.until(EC.visibility_of_element_located((By.ID, StockRoomID)))
        Element = driver.find_element_by_id(StockRoomID)
        Element.click()
        Element.send_keys(Keys.CONTROL, 'a')
        Element.send_keys(StockroomLocation)

        print("Setting Old PC Stockroom to: "+ StockroomLocation)

    #Set OLD PC Substate
    wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
    select = Select(driver.find_element_by_id(SecondaryStateID))
    if isVDI_Old_PC == True:
        stringout = "NOT CHANGING Setting Secondary State for old VDI|"
        file.write(stringout)
        print("NOT CHANGING Setting Secondary State for old VDI")
        
        #   UNCOMMENT TO HAVE OLD VDI SET TO DISPOSED IN SERVICE-NOW
        #stringout = "Setting Secondary State to: disposed|"
        #file.write(stringout)
        #select.select_by_value('disposed')
        #print("Setting Old PC SubState to: disposed")
    else:
        #OLD PC IS NOT VDI
        stringout = "Setting Secondary State to: available|"
        file.write(stringout)
        select.select_by_value('available')
        print("Setting Old PC SubState to: available")
    
    #Set OLD PC Asset Function to SPARE
    wait.until(EC.visibility_of_element_located((By.ID, AssetFunctionID)))
    select = Select(driver.find_element_by_id(AssetFunctionID))
    if isVDI_Old_PC == False:
        #OLD PC IS NOT VDI
        stringout = "Setting Asset Function to: Spare|"
        file.write(stringout)
        select.select_by_value('Spare')
        print("-------------------------------------------------------")
        print("|  Setting Old PC Asset Function to:")
        print("|  Spare")
        print("-------------------------------------------------------")
        print(" ")
    
        #Set Assigned Date
        stringout = "Setting Assigned Date to: " + str(nowoutput) + "|"
        file.write(stringout)
        wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
        driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
        print("Setting Old PC Assigned Date: " + nowoutput)
    
    #WORK NOTES
    stringout = "Navigating to Activities tab...|"
    file.write(stringout)
    acttext = driver.find_element(By.XPATH, '//span[text()="Activities"]')
    actions = ActionChains(driver)
    actions.reset_actions()
    actions.move_to_element(acttext)
    actions.click(acttext)
    actions.perform()
    
    #Search for combo/location
    print("-------------------------------------------------------")
    print("|  Accessing Old PC Work notes...")
    html_list = driver.find_element_by_xpath("//ul[@class='h-card-wrapper activities-form']")
    items = html_list.find_elements_by_tag_name("li")
    sameline = False
    location = None
    combo = None
    output = None
    possiblcombodigits = None
    if isVDI_New_PC == False:
        for item in items:
            text = item.text
            utext = text.upper()
            if location is None:
                if "LOCATION" in utext:
                    str1 = "LOCATION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOACTION" in utext:
                    str1 = "LOCATION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCTAION" in utext:
                    str1 = "LOCTAION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCAITON" in utext:
                    str1 = "LOCAITON"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCATINO" in utext:
                    str1 = "LOCATINO"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LCATION" in utext:
                    str1 = "LCATION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOATION" in utext:
                    str1 = "LOATION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCTION" in utext:
                    str1 = "LOCTION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCAION" in utext:
                    str1 = "LOCAION"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCATON" in utext:
                    str1 = "LOCATON"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCATIN" in utext:
                    str1 = "LOCATIN"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCATIO" in utext:
                    str1 = "LOCATIO"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "LOCATOIN" in utext:
                    str1 = "LOCATOIN"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "DESK" in utext:
                    str1 = "DESK"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
                elif "DSEK" in utext:
                    str1 = "DSEK"
                    startingindex = utext.index(str1)
                    location = utext[startingindex:]
            
            if not location is None:
                stringout = "Location currently found in work notes: " + str(location) + "|"
                file.write(stringout)
                possiblcombodigits = re.findall(r'(?:^|\D)(\d{4})(?:\D|$)', location)
                if not possiblcombodigits is None:
                    if "COMBO" in utext:
                        str1 = "COMBO"
                        startingindex = utext.index(str1)
                        utext[startingindex:]
                        combo = utext[startingindex:]
                    elif "LOCK" in utext:
                        str1 = "LOCK"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBINATION" in utext:
                        str1 = "COMBINATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBONATION" in utext:
                        str1 = "COMBONATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBNATION" in utext:
                        str1 = "COMBNATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "KENSINGTON" in utext:
                        str1 = "KENSINGTON"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "CODE" in utext:
                        str1 = "CODE"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    else:
                        possiblcombodigits = re.findall(r'(?:^|\D)(\d{4})(?:\D|$)', utext)
                        if not possiblcombodigits is None:
                            if "COMBO" in utext:
                                str1 = "COMBO"
                                startingindex = utext.index(str1)
                                utext[startingindex:]
                                combo = utext[startingindex:]
                            elif "LOCK" in utext:
                                str1 = "LOCK"
                                startingindex = utext.index(str1)
                                combo = utext[startingindex:]
                            elif "COMBINATION" in utext:
                                str1 = "COMBINATION"
                                startingindex = utext.index(str1)
                                combo = utext[startingindex:]
                            elif "COMBONATION" in utext:
                                str1 = "COMBONATION"
                                startingindex = utext.index(str1)
                                combo = utext[startingindex:]
                            elif "COMBNATION" in utext:
                                str1 = "COMBNATION"
                                startingindex = utext.index(str1)
                                combo = utext[startingindex:]
                            elif "KENSINGTON" in utext:
                                str1 = "KENSINGTON"
                                startingindex = utext.index(str1)
                                combo = utext[startingindex:]
                            elif "CODE" in utext:
                                str1 = "CODE"
                                startingindex = utext.index(str1)
                                combo = utext[startingindex:]
            else:
                possiblcombodigits = re.findall(r'(?:^|\D)(\d{4})(?:\D|$)', utext)
                if not possiblcombodigits is None:
                    if "COMBO" in utext:
                        str1 = "COMBO"
                        startingindex = utext.index(str1)
                        utext[startingindex:]
                        combo = utext[startingindex:]
                    elif "LOCK" in utext:
                        str1 = "LOCK"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBINATION" in utext:
                        str1 = "COMBINATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBONATION" in utext:
                        str1 = "COMBONATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "COMBNATION" in utext:
                        str1 = "COMBNATION"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "KENSINGTON" in utext:
                        str1 = "KENSINGTON"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
                    elif "CODE" in utext:
                        str1 = "CODE"
                        startingindex = utext.index(str1)
                        combo = utext[startingindex:]
    stringout = "Combo from work notes found: " + str(combo) + "|"
    file.write(stringout)
    oldpcoutput = NewComputerFullname +  " is replacing " + OldComputerFullname
    stringout = str(oldpcoutput) + "|"
    file.write(stringout)
    if not TicketNumber is None:
        #Add Replacing note
        stringout = "oldpcoutput added to TicketNotes Array|"
        file.write(stringout)
        TicketNotes += [oldpcoutput]
    
    stringout = "adding oldpcoutput to work notes...|"
    file.write(stringout)
    Element = driver.find_element_by_id("activity-stream-textarea")
    actions = ActionChains(driver)
    actions.reset_actions()
    actions.move_to_element(Element).click().send_keys(oldpcoutput).perform()
    print("________________________________")
    print("|  Adding Work Note:")
    print("|  " + str(oldpcoutput))
    print("________________________________")
    print("  Searching Work notes for Location and Combo...")

    #SUBMIT CHANGES TO OLD PC
    stringout = "Saving Old PC Service-Now Record...|"
    file.write(stringout)
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()

    if isVDI_Old_PC == False:
        if isVDI_New_PC == False:
            if not location is None:
                if not combo is None:
                    if location == combo:
                        sameline = True
                        if location in combo:
                            combo = combo.Replace(location, "")
                            stringout = "combo set to : " + str(combo) + "|"
                            file.write(stringout)
                        elif combo in location:
                            location = location.Replace(combo,"")
                            stringout = "Location set to : " + str(location) + "|"
                            file.write(stringout)
                    else:
                        sameline = False
                        file.write("sameline set to : False" + "|")
                        stringout = "sameline set to : False|"
                        file.write(stringout)
                
        if isVDI_New_PC == False:
            if not location is None:
                #location in notes
                print("  Location found in work notes = {" + location + "}")
            else:
                #No location in notes
                print("  No Location found in notes")
            if not combo is None:
                #combo in notes
                print ("  Combo found in work notes = {" + str(combo) + "}")
            else:
                #No combo in notes
                print("  No Combo found in notes")
else:
    #OLD PC WEBPAGE NOT NAVIGATED TO
    print(OldPCSerial + " Not Found in webpage title")
    print("Exiting Script")
    file.close()
    exit()

print("-------------------------------------------------------")
print(" ")
file.write("Old PC Service-Now Record Update Complete|")
stringout = "sameline set to : False|"
file.write(stringout)

#   NEW PC
#New Tab, switch tab, and navigate new tab to New PC webpage
#print("New PC Service-Now Records Started")
file.write("Starting New PC Service-Now Record Update..." + "|")
print(" ________________________________________________")
print("|      Updating New PC Service-Now Records       |")
print("|________________________________________________|")
print(" ")
file.write("Opening New Tab to NewPCWebsite..." + "|")
expectedwindows = 2 
windows_before  = driver.current_window_handle
driver.execute_script("window.open('" + NewPCWebPage + "')")
WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
windows_after = driver.window_handles
driver.switch_to.window(windows_after[expectedwindows - 1])
expectedwindows = expectedwindows + 1 


#SWITCH IFRAME
file.write("Switching to iFrame..." + "|")
wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
time.sleep(2)
try:
    acttext = driver.find_element(By.XPATH, '//span[text()="General"]')
    actions = ActionChains(driver)
    actions.reset_actions()
    actions.move_to_element(acttext).click(acttext).pause(1).perform()
except:
    time.sleep(1)
    acttext = driver.find_element(By.XPATH, '//*[@id="tabs2_section"]/span[1]/span/span[2]')
    actions = ActionChains(driver)
    actions.reset_actions()
    actions.move_to_element(acttext).click(acttext).pause(1).perform()
    

#State to In use
print("Updating PC State to: In use")
file.write("Setting State to: In use (value: 1)" + "|")
#print("-------------------------------------------------------")
#print("|  Setting New PC State to:")
#print("|  In use")
#print("-------------------------------------------------------")
#print(" ")
wait.until(EC.visibility_of_element_located((By.ID, stateID)))
select = Select(driver.find_element_by_id(stateID))
select.select_by_value('1')

#Assigned User
print("Assigning User Based off User Email: " + str(UserEmail))
file.write("Using User email to set User Assigned field..." + "|")
#print("-------------------------------------------------------")
#print("|  Setting New PC Assigned User: Based off User Email:")
#print("|  (Using User Email): " + str(UserEmail))
#print("-------------------------------------------------------")
#print(" ")
wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
Element = driver.find_element_by_id(userAssignedID)
actions = ActionChains(driver)
actions.reset_actions()
actions.move_to_element(Element).click(Element).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).pause(1).send_keys(UserEmail).pause(2).send_keys(Keys.DOWN).pause(.5).send_keys(Keys.TAB).perform()
time.sleep(2)

#Set Asset Function to
file.write("Setting Asset Function to: Primary Device|")
wait.until(EC.visibility_of_element_located((By.ID, AssetFunctionID)))
select = Select(driver.find_element_by_id(AssetFunctionID))
select.select_by_value('Primary Device')
print("-------------------------------------------------------")
print("|  Setting New PC Asset Function to:")
print("|  Primary Device")
print("-------------------------------------------------------")
print(" ")

#Assigned Dated
file.write("Setting Date Assigned to: " + nowoutput + "|")
wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
print("-------------------------------------------------------")
print("|  Setting New PC Date Assigned:")
print("|  " + str(nowoutput))
print("-------------------------------------------------------")
print(" ")
driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
                   
#Work Notes / set combo and location
#print("Adding worknotes to New PC...")



#add combo location work notes if new pc is not vdi
if isVDI_Old_PC == False:
    
    if isVDI_New_PC == False:
        if sameline == True:
            #print("Location and combo on same line")
            output = combo
            file.write("Setting output (for work note) to: " + str(output) + "|")        
        else:
            if location2:
                #use user location over notes location
                location = location2
                file.write("Overwriting location var with User location var (location2): " + str(location) + "|")
            if not location is None:
                if not combo is None:
                    if not location in combo:
                        if not combo in location:
                            output = location + "\n" + combo
                            file.write("Setting output (for work note) to: " + str(output) + "|")
                        else:
                            output = location
                            file.write("Setting output (for work note) to: " + str(output) + "|")
                    else:
                        output = combo
                        file.write("Setting output (for work note) to: " + str(output) + "|")
                else:
                    output = location
                    file.write("Setting output (for work note) to: " + str(output) + "|")
            elif not combo is None:
                output = combo
                file.write("Setting output (for work note) to: " + str(output) + "|")
            else:
                output = 'No Location or Combo found in ' + str(OldComputerFullname) + ' work notes'
                file.write("Setting output (for work note) to: " + str(output) + "|")
        if output:
            output = str(output)
            file.write("Setting output (for work note) to: " + str(output) + "|")
    print(" ")
    print("Adding Work Note: ")
    print("---------------------------------")
    print(output)
    print("---------------------------------")
    print(" ")
    file.write("Selecting Activities Tab...|")
    acttext = driver.find_element(By.XPATH, '//span[text()="Activities"]')
    actions = ActionChains(driver)
    actions.reset_actions()
    actions.move_to_element(acttext)
    actions.click(acttext)
    actions.perform()
    time.sleep(1)

    file.write("Adding Work Note: " + str(output) + "|")
    Element = driver.find_element_by_id("activity-stream-textarea")
    actions = ActionChains(driver)
    actions.move_to_element(Element).click(Element).pause(1).send_keys(output).perform()

#SUBMIT CHANGES TO NEW PC
file.write("Saving New PC Service-Now Record..." + "|")
buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
actions = ActionChains(driver)
actions.move_to_element(buttonclick)
actions.click(buttonclick)
actions.perform()
file.write("----------- END NEW PC SERVICE-NOW UPDATE RECORD -----------------| |")

#GET MEMBERSHIPS WEBPAGES
#Filter if membership is a type that is ordered
file.write("--------------- START MEMBERSHIP REQUESTS ---------------------|")
for member in Memberships:
    file.write("Membership: " + str(member) + "|")
    if "SCCM-" in member:
        #SCCM membership
        SCCM = member
    elif "RG-" in member:
        #Role Group membership
        RG = member
    else:
        print("Skipping membership request for: " + member)
        file.write("Skipping membership as EUC doesn't request these: " + member + "|")
        #No Other memberships defined currently, so skip
        continue
    print("Starting " + str(member) + " Request")
    file.write("|    --------------- START " + str(member) + " REQUEST ---------------------|")
    #New Tab, switch tab, and navigate new tab to Request AD Membership webpage
    file.write("    Opening new tab for membership request...")
    try:
        windows_before  = driver.current_window_handle
        driver.execute_script("window.open('" + RequestMembershipPage + "')")
        WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
        windows_after = driver.window_handles
        driver.switch_to.window(windows_after[expectedwindows - 1])
        #print("Page Title after Tab Switching is : %s" %driver.title)
        expectedwindows = expectedwindows + 1
        file.write("SUCCESS|")
        try:
            #IFrame switch
            file.write("    Switching to iFrame...")
            wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
            driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))



            #Username element
            wait.until(EC.visibility_of_element_located((By.ID, memberUserID)))
    
            time.sleep(1)
    
            if OldUserAssigned is None:
                OldUserAssigned = ''
        
            if OldUserAssigned:
                Element = driver.find_element_by_id(memberUserID)
                file.write("Clearing User field, and entering: " + str(OldUserAssigned) + "|")
                Element.send_keys(Keys.CONTROL, 'a')
                Element.send_keys(Keys.BACKSPACE)
                Element.send_keys(OldUserAssigned)
                Element.send_keys(Keys.TAB)
                time.sleep(1)
                driver.execute_script("document.getElementById('" + memberUserID + "').setAttribute('value', '" + OldUserAssigned + "')")
                print("-------------------------------------------------------")
                print("|  Who is this request for?: " + str(OldUserAssigned))
                print("-------------------------------------------------------")
                print(" ")
            else:
                Element = driver.find_element_by_id(memberUserID)
                file.write("No OLD USER FOUND, Clearing User field, and entering: " + str(UserFullname) + "|")
                Element.send_keys(Keys.CONTROL, 'a')
                Element.send_keys(Keys.BACKSPACE)
                Element.send_keys(UserFullname)
                Element.send_keys(Keys.TAB)
                time.sleep(1)
                driver.execute_script("document.getElementById('" + memberUserID + "').setAttribute('value', '" + UserFullname + "')")
                print("-------------------------------------------------------")
                print("|  Who is this request for?: " + str(UserFullname))
                print("-------------------------------------------------------")
                print(" ")
                
            #Group Modify element
            file.write("Setting Service Requested to: Modify Computer Group Membership" + "|")
            wait.until(EC.visibility_of_element_located((By.ID, memberModGroupID)))
            select = Select(driver.find_element_by_id(memberModGroupID))
            select.select_by_value('Modify Computer Group Membership')
            #print("Setting -- Select the Active Directory service requested: Modify Computer Group Membership")
            print("-------------------------------------------------------")
            print("|  Select the Active Directory service requested: Modify Computer Group Membership")
            print("-------------------------------------------------------")
            print(" ")
                               
            #Group target element
            wait.until(EC.visibility_of_element_located((By.ID, memberTargetGroupID)))
            select = Select(driver.find_element_by_id(memberTargetGroupID))
                               
            if "SCCM-" in member:
                file.write("Setting Target Active Directory group to: SCCM Group" + "|")
                select.select_by_value('SCCM Group')
                #print("Setting -- Target Active Directory group type: SCCM Group")
                print("-------------------------------------------------------")
                print("|  Target Active Directory group type: SCCM Group")
                print("-------------------------------------------------------")
                print(" ")
            elif "RG-" in member:
                file.write("Setting Target Active Directory group to: Role Group" + "|")
                select.select_by_value('Role Group')
                #print("Setting -- Target Active Directory group type: Role Group")
                print("-------------------------------------------------------")
                print("|  Target Active Directory group type: Role Group")
                print("-------------------------------------------------------")
                print(" ")
            else:
                #Failsafe continue in case one slips by
                continue
            
            #Action to perform element
            wait.until(EC.visibility_of_element_located((By.ID, memberActionID)))
            select = Select(driver.find_element_by_id(memberActionID))
            select.select_by_value('Add a computer to a group')
            file.write("Setting action to: Add a computer to a group" + "|")
            #print("Setting -- What action would you like to perform?: Add a computer to a group")
            print("-------------------------------------------------------")
            print("|  What action would you like to perform?:  Add a computer to a group")
            print("-------------------------------------------------------")
            print(" ")
        
            #Membership element
            wait.until(EC.visibility_of_element_located((By.ID, memberMembershipID)))
            Element = driver.find_element_by_id(memberMembershipID)
            file.write("Setting Target Active Directory group to: " + str(member) + "|")
            print("-------------------------------------------------------")
            print("|  Target Active Directory group: " + str(member))
            print("-------------------------------------------------------")
            print(" ")
            Element.send_keys(member)
            print("waiting for list...")
            file.write("waiting for list to populate...")
            x = 1
            EXList = False
            for x in range(50):
                try:
                    Element = driver.find_element_by_id(memberMembershipID)
                    AriaOut = Element.get_attribute("aria-expanded")
                    if "true" in AriaOut:
                        print("List Found in " + str(x) + " Secs")
                        file.write("List Found in " + str(x) + " secs!|")
                        break
                    else:
                        if x > 49:
                            print("timed out!")
                            file.write("timed out waiting for list!|")
                            EXList = True
                            x = 51
                            break
                        else:
                            time.sleep(1)
                            x = x + 1
                except:
                    file.write("Exception during waiting occured (handled)|")
                    if x > 49:
                        print("timed out!")
                        file.write("timed out waiting for list during excecption(handled)!|")
                        EXList = True
                        x = 51
                        break
                    else:
                        time.sleep(1)
                        x = x + 1
                    
            Element.send_keys(Keys.TAB) #Send_Keys tends to work better here
            time.sleep(2)
            #PC textbox Element
            file.write("Searching for PC in available pc list..." + "|")
            wait.until(EC.visibility_of_element_located((By.ID, memberPCtbxID)))
            Element1 = driver.find_element_by_id(memberPCtbxID)
            Element1.send_keys(NewComputerFullname)
            driver.execute_script("document.getElementById('" + membership_PC_List_Hidden_ID + "').setAttribute('value', '^nameSTARTSWITH" + NewComputerFullname + "')")
            Element1.send_keys(Keys.TAB)
            Element2 = driver.find_element_by_id(membership_Element_PC_List_select_ID)
            time.sleep(5)
            Element2 = driver.find_element_by_id(membership_Element_PC_List_select_ID)
            try:
                selected = Select(Element2).select_by_index(0)
                try:
                    if str(selected.text) in str(NewComputerFullname):
                        file.write("PC FOUND IN LIST" + "|")
                        print("found")
                    else:
                        file.write("PC NOT FOUND IN LIST" + "|")
                        time.sleep(5)
                        selected = Select(Element2).select_by_index(0)
                except:
                    file.write("Exception occured, waiting 5 seconds" + "|")
                    time.sleep(5)
                    selected = Select(Element2).select_by_index(0)
                    
                Element2.send_keys(Keys.RIGHT)
                time.sleep(.5)
                Element3 = driver.find_element_by_id("computer_list_select_1")
                time.sleep(.5)
                select = Select(Element3)
                selected_option = select.first_selected_option
                selectedtext = selected_option.text
                file.write("PC Found for " + str(member) + ": " + str(selectedtext)+ "|")
                print("-------------------------------------------------------")
                print("|  Computer selected: " + str(selectedtext))
                print("-------------------------------------------------------")
                print(" ")
            except:
                file.write("PC NOT Found for membership: " + str(member) + "|")
                selectedtext = None
                
            if selectedtext is None:
                file.write("Could not find PC to add " + str(member) + " membership to!" + "|")
                print("Could not find PC to add " + str(member) + " membership to!")
                print("Please be sure " + str(NewComputerFullname) + " does not already have " + str(member) + " membership")
                file.write("Please be sure " + str(NewComputerFullname) + " does not already have " + str(member) + " membership" + "|")
        
            else:
                file.write("Adding Reason: Transfering Membership from " + str(OldComputerFullname) + " to " + str(NewComputerFullname) + "|")
                if not TicketNumber is None:
                    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id(memberReasonID), "Transfering Membership from " + OldComputerFullname + " to " + NewComputerFullname + " via " + str(TicketNumber))
                    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id(memberNotesID), "Transfering Membership from " + OldComputerFullname + " to " + NewComputerFullname + " via " + str(TicketNumber))
                else:
                    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id(memberReasonID), "Transfering Membership from " + OldComputerFullname + " to " + NewComputerFullname)
                    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id(memberNotesID), "Transfering Membership from " + OldComputerFullname + " to " + NewComputerFullname)
                
        
                #SUBMIT MEMBERSHIP
                if EXList == False:
                    file.write("Submitting request...")
                    buttonclick = driver.find_element(By.ID, 'order_now')
                    actions = ActionChains(driver)
                    actions.move_to_element(buttonclick)
                    actions.click(buttonclick)
                    actions.perform()
                    try:
                        wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@id='sc_cart_view']/table/tbody/tr/td[1]/a")))
                        Element = driver.find_element_by_xpath("//*[@id='sc_cart_view']/table/tbody/tr/td[1]/a")
                        RequestNumber = Element.text
                        file.write("SUCCESS|")
                        if not RequestNumber is None:
                            if not TicketNumber is None:
                                #Add Location found from old notes
                                file.write(member + " membership request: " + RequestNumber.strip() + "|")
                                TicketNotes += [member + " membership request: " + RequestNumber.strip()]
                        file.write("Request Number found: " + str(RequestNumber) + "|")
                    except:
                        file.write("FAILED: ERROR OCCURED|")
                        file.write(str(member) + "Request FAILED!|")
                        print(str(member) + "Request FAILED!")
                else:
                    print("PLEASE CHECK " + str(member) + "REQUEST AND MANUALLY SUBMIT!")
                    file.write("Skipped Request Submit|")
        except:
            file.write("FAILED: ERORR OCCURED|")
    except:
        file.write("FAILED: ERORR OCCURED|")
    file.write("    --------------- END " + str(member) + " REQUEST ---------------------| |")
    
    
        
file.write("------------ END MEMBERSHIP REQUESTS -----------------| |")
#   ORDER CREDENTIALS NO LONGER NEEDED
#if isVDI_New_PC == False:
#    if isLaptop == True:
#        file.write("--------------- START WIRELESS CERTIFICATE REQUEST ---------------------|")
#        #print("Starting wireless credentials request...")
#        print("Starting Wireless Credentials Request")
#        file.write("Opening New tab to Wireless Credentials Request Webpage..." + "|")
#        windows_before  = driver.current_window_handle
#        driver.execute_script("window.open('https://ameriprise.service-now.com/ameriprise/catalog.do?sysparm_document_key=sc_cat_item,2b468f379cb941004c7201eb33272b42')")
#        WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
#        windows_after = driver.window_handles
#        driver.switch_to.window(windows_after[expectedwindows - 1])
        #print("Page Title after Tab Switching is : %s" %driver.title)
#        expectedwindows = expectedwindows + 1
        
#        file.write("Switching to iFrame..." + "|")                      
#        wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
#        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
        
        #Username textbox for order credentials
#        wait.until(EC.visibility_of_element_located((By.ID, "sys_display.IO:3cd7f12a903da80087a863f119b63795")))
#        if OldUserAssigned:
#            print("Requesting for: " + OldUserAssigned)
#            file.write("Requesting for: " + OldUserAssigned + "|")
#            driver.execute_script("document.getElementById('sys_display.IO:3cd7f12a903da80087a863f119b63795').setAttribute('value', '" + OldUserAssigned + "')")
#        else:
#            driver.execute_script("document.getElementById('sys_display.IO:3cd7f12a903da80087a863f119b63795').setAttribute('value', '" + UserFullname + "')")
#            print("Requesting Wireless Cert for: " + UserFullname)
#            file.write("Requesting Wireless Cert for: " + UserFullname + "|")

#        file.write("Does the selected user work for Auto & Home?: Yes - Employee" + "|")
#        wait.until(EC.visibility_of_element_located((By.ID, "IO:9d76cf379cb941004c7201eb33272b36")))
#        select = Select(driver.find_element_by_id('IO:9d76cf379cb941004c7201eb33272b36'))
#        select.select_by_value('Yes - Employee')
#        print("----------------------------------------------------------------")
#        print("|  Does the selected user work for Auto & Home?: Yes - Employee")
#        print("----------------------------------------------------------------")
#        print(" ")
        
#        wait.until(EC.visibility_of_element_located((By.ID, "IO:4b3787779cb941004c7201eb33272bdc")))
#        select = Select(driver.find_element_by_id('IO:4b3787779cb941004c7201eb33272bdc'))
#        select.select_by_value('No')
        #print("Setting -- Does the selected user work in the AFG (Franchise) group?: No")
#        file.write("Does the selected user work in the AFG (Franchise) group?: No" + "|")
#        print("----------------------------------------------------------------")
#        print("|  Does the selected user work in the AFG (Franchise) group?: No")
#        print("----------------------------------------------------------------")
#        print(" ")

#        file.write("Is this for a computer that has been re-imaged?: No" + "|")
#        wait.until(EC.visibility_of_element_located((By.ID, "IO:4f674b779cb941004c7201eb33272b18")))
#        select = Select(driver.find_element_by_id('IO:4f674b779cb941004c7201eb33272b18'))
#        select.select_by_value('No')
#        #print("Setting -- Is this for a computer that has been re-imaged?: No")
#        print("----------------------------------------------------------------")
#        print("|  Is this for a computer that has been re-imaged?: No")
#        print("----------------------------------------------------------------")
#        print(" ")
        
#        wait.until(EC.visibility_of_element_located((By.ID, "IO:1c87cf379cb941004c7201eb33272b56")))
#        select = Select(driver.find_element_by_id('IO:1c87cf379cb941004c7201eb33272b56'))
#        select.select_by_value('Yes')
        #print("Setting -- Is this for a new laptop for an existing resource?: Yes")
#        file.write("Is this for a new laptop for an existing resource?: Yes" + "|")
#        print("----------------------------------------------------------------")
#        print("|  Is this for a new laptop for an existing resource?: Yes")
#        print("----------------------------------------------------------------")
#        print(" ")
        
#        wait.until(EC.visibility_of_element_located((By.ID, "IO:dac086244ddf91004c72de7a362d4691")))
#        select = Select(driver.find_element_by_id('IO:dac086244ddf91004c72de7a362d4691'))
#        select.select_by_value('No')
        #print("Setting -- Does the user have an additional laptop that also requires a workstation certificate?: No")
#        file.write("Does the user have an additional laptop that also requires a workstation certificate?: No" + "|")
#        print("----------------------------------------------------------------")
#        print("|  Does the user have an additional laptop that also requires a workstation certificate?: No")
#        print("----------------------------------------------------------------")
#        print(" ")
        #SUBMIT CERT
#        file.write("Submitting Cert Request..." + "|")
#        buttonclick = driver.find_element(By.ID, 'submit_button')
#        actions = ActionChains(driver)
#        actions.move_to_element(buttonclick)
#        actions.click(buttonclick)
#        actions.perform()

#        file.write("Getting Request Number..." + "|")
#        wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@id='dropzone10']/div[3]/div/div[1]/p")))
#        Element = driver.find_element_by_xpath("//*[@id='dropzone10']/div[3]/div/div[1]/p")
#        RequestNumber = Element.text
#        file.write("Request String: " + RequestNumber + "|")
#        if not RequestNumber is None:
#            if not TicketNumber is None:
#                RequestNumber = RequestNumber.split()
#                RITM = RequestNumber[2]
#                file.write("Request String array item 3: " + RITM + "|")
#                if not RITM is None:
#                    #Add Note for Cert request
#                    TicketNotes += ["Cert request: " + RITM]
#                    file.write("Adding to Ticket Notes Array: " + RITM + "|")
#
#        file.write("--------------- END WIRELESS CERTIFICATE REQUEST ---------------------| |")
        
if not TicketNumber is None:
    file.write("--------------- START ADDING NOTES TO " + str(TicketNumber) + " ---------------------|")
    file.write("    Adding Additional Notes to Ticket Notes Array: Updated AD, and Service-Now|")
    TicketNotes += ["Updated AD, and Service-Now"]
    #print("Starting wireless cr=\edentials request...")
    print("Start: Add note to " + str(TicketNumber))
    print(" ")
    print("----------------------------------------------------------------")
    print("|  WORKS NOTES BEING ADDED:")
    file.write("Adding to Ticket Notes:" + "|")
    file.write("-------------------------------------------------------------------|")
    for note in TicketNotes:
        file.write(note + "|")
        print("|  " + note)
        print("----------------------------------------------------------------")
        print(" ")
    file.write("-------------------------------------------------------------------| |")
    file.write("Saving Ticket..." + "|")
    windows_before  = driver.current_window_handle
    driver.execute_script("window.open('" + ticketurl + "')")
    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    windows_after = driver.window_handles
    driver.switch_to.window(windows_after[expectedwindows - 1])
    #print("Page Title after Tab Switching is : %s" %driver.title)
    expectedwindows = expectedwindows + 1

    #if TicketNumber.startswith('INC'):
        #Universal_SN_iframe = "https://ameriprise.service-now.com/incident.do?uri=&sysparm_query=number=" + TicketNumber
    #elif TicketNumber.startswith('TASK'):
        #Universal_SN_iframe = "AC.sc_task.request_item.u_requested_for_shim"
    #elif TicketNumber.startswith('ITASK'):
        #Universal_SN_iframe = "https://ameriprise.service-now.com/u_incident_task.do?uri=&sysparm_query=number=" + TicketNumber
        
                              
    #wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    #driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    time.sleep(2)
    Element = driver.find_element_by_id("activity-stream-textarea")
    actions = ActionChains(driver)
    actions.move_to_element(Element).click(Element).pause(1).perform()
    for note in TicketNotes:
        actions = ActionChains(driver)
        actions.send_keys(note).pause(.1).send_keys(Keys.ENTER).pause(.1).perform()

        #Post Work note in ticket
    #time.sleep(.5)
    #Postbtn = driver.find_element_by_class_name('btn btn-default pull-right activity-submit')
    #actions = ActionChains(driver)
    #actions.move_to_element(Element).click(Element).pause(1).perform()
    
    #SUBMIT CHANGES TO TICKET
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()
    file.write("--------------- END ADDING NOTES TO " + str(TicketNumber) + " ---------------------| |")
    
file.write("END OF SCRIPT")
file.close()

print("Service Now Script complete")
#driver.quit()
