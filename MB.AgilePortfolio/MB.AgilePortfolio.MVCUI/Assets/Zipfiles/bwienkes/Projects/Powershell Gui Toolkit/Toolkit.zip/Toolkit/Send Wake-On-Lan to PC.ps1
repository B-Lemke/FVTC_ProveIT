﻿param
(
[Parameter(Mandatory=$false)]$computer
)
if(!($computer)){$Param_ErrorMsg = "No value entered for: computer"}
elseif(!($computer -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: computer"}
elseif(!($computer.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: computer"}
if(!($Param_ErrorMsg))
	{




#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
Set-Location "C:\"


#***************************************************************************************
#---------------------------------OPTIONAL CHANGES START-------------------------------
#***************************************************************************************

# This is H:\ Drive path DO NOT NEED TO CHANGE UNLESS YOUR H:\ can't be accessed by your nonadmin account
$RootInstallLocation = "$($HDrivePath)"

#**************************************************************
#-------Import-----------
import-module ActiveDirectory
#-------Import-----------


#name of text file that will have the list of pcs to update Located in the t470BatchUpdater folder on the desktop (each one is a new line and can accept serial number or full name)
$PCList = "pc_list.txt"
$CompletedList = "CompletedList.txt"

    #---------------------DEFAULT-------------
    #$txtFileCompletedPCs = "pc_list.txt"
    #---------------------DEFAULT-------------



#Name of the folder on your desktop  where you want individual PC logs to be stored (C:\USERS\YOUR NONADMIN ACCOUNT\DESKTOP\THIS VALUE)
$PCLogsFolderName = "CompletedLogs"


    #---------------------DEFAULT-------------
    #$PCLogsFolderName = "CompletedLogs"
    #---------------------DEFAULT-------------

#***************************************************************************************
#---------------------------------OPTIONAL CHANGES END-------------------------------
#***************************************************************************************

if (test-Path "$($PSScriptRoot)\$($PCLogsFolderName)")
{

}
else
{
$fso = new-object -ComObject scripting.filesystemobject
$fso.CreateFolder("$($PSScriptRoot)\$($PCLogsFolderName)")
}

if (test-Path "$($PSScriptRoot)\$($PCList)")
{
write-host "Found PC list text file"
}
else
{
write-host "PC list text file not found"
write-host "make sure this file is located in the in the same folder this script was run from"
}


#***************************************************************
#-------------------------Directories---------------------------
#**************************************************************
$PCList = "$($PSScriptRoot)\$($PCList)"
$out_PCList = $PCList
$Dir = "$($PSScriptRoot)\savedPSFiles"
$out_PCLogsFolderPath = "$($PSScriptRoot)\Logs\Fixes\Wake-On-Lan"

#***************************************************************
#-------------------------Directories---------------------------
#**************************************************************


#*************************************************
#---------------For Each PC in List End----------
#*************************************************





$scriptPath = "$($PSScriptRoot)"
$Root = (get-item $scriptPath).FullName

Import-Module $Root\Files\wakeonlan.psm1
$SiteCode = "MSP"
$ProviderMachineName = "mspcsc12sccm01"
$Mac=(Get-WmiObject -Class SMS_R_SYSTEM -Namespace "root\sms\site_$SiteCode" -computerName $ProviderMachineName -Filter "Name=`'$($computer)`'").MacAddresses
$mac=$mac.replace(":","") 

write-host "using $mac"
send-packet $mac | Out-Host
$i = 0
$timeout= 300
$timedout = $false
write-host "Waiting for PC to come back online..." -NoNewline
do{
if(test-connection -ComputerName $computer -Quiet -count 1 -ErrorAction SilentlyContinue)
{
Write-host -ForegroundColor Green "$computer is now online"
break
}
else
{
write-host "." -NoNewline
start-sleep 1
$i++
if ($i -ge $timeout)
{
Write-host -ForegroundColor Red "Timed out waiting for PC to come online."
$timedout = $true
break
}
}}while($timeout -le 300)



$computer2 = Read-Host -Prompt "press enter to exit"
exit
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}
}
else
{
write-host "Run Wake Pc: $Param_ErrorMsg"
Read-Host "`nPress Enter to exit"
exit
}
