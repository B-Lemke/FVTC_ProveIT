﻿

function Get-Excel {

param(
    [string]$FilePath,
    [int[]]$ColumnsNeeded,
    [int]$ColumnStartsAt,
    [int]$RowStartsAt,
    [boolean]$AllRows,
    [int]$CheckColForEmptyRow,
    [string[]]$RowsNeeded
    )
    ##################################################
    #--------Defaults and Validation of parms--------#
    ##################################################
    if ($FilePath -eq "")
    {
        #DEFAULT FILEPATH IS SET TO SAME AS THIS MODULES IF NOT PASSED IN ARGUMENTS

        $FilePath = $PSScriptRoot
    }

    if (Test-Path $Filepath)
    {

        #Filepath given exists
        write-host "Filepath found"
    }
    else
    {
    write-host "filepath = $FilePath"
        #Filepath given doesnt exists
        write-host "FilePath given doesn't exit"
        read-host -prompt "press any key to exit"
        exit
    }
    if ($ColumnStartsAt -eq 0)
    {
        #DEFAULT COLUMNS START COUNTING AT INT

        #Starts at column 1
        $ColumnStartsAt = 1
    }
    if ($ColumnsNeeded.count -eq 0)
    {
        #DEFAULT COLUMNS TO CHECK FOR INPUT ARRAY

        #FOR LOGIN 1,2,and 3 are needed
        $ColumnsNeeded = @(1, 2, 3)
    }
    if ($RowStartsAt -eq 0)
    {
        #DEFAULT ROWS START COUNTING AT INT

        #Starts at row 1
        $RowStartsAt = 1
    }
    
    if ($RowsNeeded.count -eq 0)
    {
        #DEFAULT COLUMNS TO CHECK FOR INPUT ARRAY

        #FOR LOGIN 1,2,and 3 are needed
        $RowsNeeded = @("2")
    }
    ##################################################
    #--------Defaults and Validation of parms--------#
    ##################################################


############################
#-------- Imports----------#
############################
Add-Type -AssemblyName Microsoft.Office.Interop.Excel
############################
#-------- Imports----------#
############################


##############################
#----------EXCEL SETUP-------#
##############################
$xl = New-Object -COM "Excel.Application"
$xl.Visible = $false
$wb = $xl.Workbooks.Open("$FilePath")
$ws = $wb.Sheets.Item(1)
$xlFixedFormat = [Microsoft.Office.Interop.Excel.XlFileFormat]::xlWorkbookDefault

$WorksheetRange = $ws.UsedRange
$RowCount = $WorksheetRange.Rows.Count
$ColumnCount = $WorksheetRange.Columns.Count
##############################
#----------EXCEL SETUP-------#
##############################

write-host "Loading from $($FilePath)"

foreach ($col in $ColumnsNeeded)
{
#Create Global variable arrays for column (ex: column 1 row 1 is c1[0] column 2 row 2 is c2[1]
new-Variable -name "c$col" -value @() -scope "Global"
}

#$i for current row

for ($i = $RowStartsAt; $i -lt $RowCount + 1; $i++)
{
    #$c for current column
    for ($c = $ColumnStartsAt; $c -le $ColumnCount + 1; $c++)
    {
    #write-host "c check"
    if ($AllRows)
    {
        if($ColumnsNeeded.Contains($c))
        {
            if ($c -ne 0)
            {
                if ($i -ne 0)
                {
                    $cell = $ws.Cells.Item($i, $c).Text
                    
                    if ($cell -eq "" -or $null)
                    {
                    $cell = "empty"
                    }
                    if ($c -eq $CheckColForEmptyRow)
                    {
                        if ($cell -eq "empty")
                        { 
                        write-host "row: $i"
                            write-host "col $c"
                            $Range = $ws.Cells.Item($i,$c).EntireRow
                            $Range.Delete()
                            $RowCount = $RowCount - 1
                            $c = $ColumnStartsAt
                            break
                        }    
                    }
                    Invoke-Expression "`$Global:c$c += '$cell'"
                }
            }
        }
    }
    else
    {
        if($RowsNeeded.Contains("$i"))
        {
            if($ColumnsNeeded.Contains($c))
            {
                $cell = $ws.Cells.Item($i, $c).Text
                if ($cell -eq "" -or $null)
                {
                    $cell = "empty"
                }
                if ($c -eq $CheckColForEmptyRow)
                {
                    if ($cell -eq "empty")
                    { 
                        $Range = $ws.Cells.Item($i,$c).EntireRow
                        $Range.Delete()
                        $RowCount = $RowCount - 1
                        $c = $ColumnStartsAt - 1
                        continue
                    }    
                }
                    Invoke-Expression "`$Global:c$c += '$cell'"
            }
        }  
    }
}
}
$wb.Save()
$wb.Close()
$xl.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)
}

function Set-Excel 
{

param(
    [string]$FilePath,
    [int]$Column,
    [int]$Row,
    #[int[]]$Rows,
    #[int[]]$Columns,
    [string]$Value,
    #[string]$Values,
    [int]$ColumnStartsAt,
    [int]$RowStartsAt
    )
    ##################################################
    #--------Defaults and Validation of parms--------#
    ##################################################
    $ColumnSelected = $false
    $RowSelected = $false
    #$ColumnsSelected = $false
    #$RowsSelected = $false
    if ($FilePath -eq "")
    {
        #DEFAULT FILEPATH IS SET TO SAME AS THIS MODULES IF NOT PASSED IN ARGUMENTS
        $FilePath = $PSScriptRoot
    }
    if (Test-Path $Filepath)
    {
        #Filepath given exists
        write-host "Filepath found"
    }
    else
    {
        #Filepath given doesnt exists
        write-host "FilePath given doesn't exit"
        read-host -prompt "press any key to exit"
        exit
    }
    if ($Row -eq 0)
    {
        if ($Rows.count -eq 0)
        {
        #Row not given
        write-host "Row Given (use -Row (insert [int]) or -Rows (insert [int[]]))"
        read-host -prompt "press any key to exit"
        exit
        }
        else
        {
        $RowSelected = $true
        }

    }
    else
        {
        $RowSelected = $true
        }
    if ($Column -eq 0)
    {
        if ($Columns.count -eq 0)
        {
        #Row not given
        write-host "Column or Columns not Given (use -Column (insert [int]) or -Columns (insert [int[]]))"
        read-host -prompt "press any key to exit"
        exit
        }
        else
        {
        $ColumnSelected = $true
        }

    }
    else
        {
        $ColumnSelected = $true
        }
    if ($RowStartsAt -eq 0 -or $RowStartsAt -eq $null -or  $RowStartsAt -eq "")
    {
        #DEFAULT ROWS START COUNTING AT INT

        #Starts at row 1
        $RowStartsAt = 0
    }
    if ($ColumnStartsAt -eq 0 -or $ColumnStartsAt -eq $null -or  $ColumnStartsAt -eq "")
    {
        #DEFAULT COLUMNS START COUNTING AT INT

        #Starts at column 1
        $ColumnStartsAt = 0
    }
    if ($Rows.count -eq 0)
    {
        if ($Row -eq 0)
        {
        #Row not given
        write-host "Need to Specify either -Row integer or -Rows array of integers"
        read-host -prompt "press any key to exit"
        exit
        }
        else
        {
        #$RowsSelected = $true
        }

    }
    
    if ($Columns.count -eq 0)
    {
        if ($Column -eq 0)
        {
        #Row not given
        write-host "Need to Specify either -Column integer or -Columns array of integers"
        read-host -prompt "press any key to exit"
        exit
        }else
        {
        #$ColumnsSelected = $true
        }

    }
      
    if ((($RowsSelected) -and ($RowSelected)) -or (($RowsSelected) -and ($ColumnSelected)))
    {
        write-host "You cannot use both -Row/-Column and -Rows/-Columns together"
        read-host -prompt "press any key to exit"
        exit
    }
    if ((($ColumnsSelected) -and ($ColumnSelected)) -or (($ColumnsSelected) -and ($RowSelected)))
    {
        write-host "You cannot use both -Row/-Column and -Rows/-Columns together"
        read-host -prompt "press any key to exit"
        exit
    }
    if (($Value -eq "") -and ($Values.count -eq 0))
    {
        write-host "You need to specify -Value or -Values"
        read-host -prompt "press any key to exit"
        exit
    }
    elseif ($Value -ne "")
    {
    $ValueSelected = $true
    }
    elseif ($Values.count -ne 0)
    {
    $ValuesSelected = $true
    }
    ##################################################
    #--------Defaults and Validation of parms--------#
    ##################################################


############################
#-------- Imports----------#
############################
Add-Type -AssemblyName Microsoft.Office.Interop.Excel
############################
#-------- Imports----------#
############################


##############################
#----------EXCEL SETUP-------#
##############################
$xl = New-Object -COM "Excel.Application"
$xl.Visible = $false
$wb = $xl.Workbooks.Open("$FilePath")
$ws = $wb.Sheets.Item(1)
$xlFixedFormat = [Microsoft.Office.Interop.Excel.XlFileFormat]::xlWorkbookDefault

##############################
#----------EXCEL SETUP-------#
##############################

#write-host "Loading from $($FilePath)"

if ($RowSelected)
{
    $i = $Row + $RowStartsAt
    $c = $Column + $ColumnStartsAt
    $ws.Cells.Item($i, $c) = $Value
    
}
    $wb.Save()
    $wb.Close()
    $xl.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)

<#

if (($RowsSelected) -and ($ColumnsSelected) -and ($ValuesSelected))
{
    for ($V = 0; $V -lt $Values.count; $V++)
    {
        for ($r = 1; $r -lt $Rows.count)
        {
            for ($col = 1; $col -lt $Columns.count)
            {
                $i = $r + $RowStartsAt
                $c = $col + $ColumnStartsAt
            
                $ws.Cells.Item($i, $c) = $Values[$V]
            }
        }
    }
    $wb.Save()
    $wb.Close()
    $xl.Quit()
    [System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl)

}

#>

}

Export-ModuleMember -function 'Get-*'
Export-ModuleMember -function 'Set-*'
