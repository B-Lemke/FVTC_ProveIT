<# 
    .NOTES 
    -------------------------------------------------------------------------------- 
     Created by:           Brenton Wienkes
     Created on:           10/08/2018
    -------------------------------------------------------------------------------- 
#> 

#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************
cls
# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#***************************************************************
$global:dbforms = @"
Imports System
Imports System.Diagnostics
Imports System.ComponentModel
Imports System.Windows.Forms

Public Class DoubleBufferedForm
   Inherits Form
 
   Public Sub New()
  Me.SetStyle( _
  ControlStyles.ResizeRedraw Or _
  ControlStyles.DoubleBuffer Or _
  ControlStyles.AllPaintingInWmPaint, _
  True _
 )
 Me.UpdateStyles()
 End Sub
   
End Class
"@
$RefAssem = (
 "System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089"
    )

Add-Type -Language VisualBasic -typeDefinition $dbforms -ReferencedAssemblies $RefAssem -ErrorAction SilentlyContinue| Out-Null

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp
#$ErrorActionPreference = "silentlycontinue"

Function ExtractValidIPAddress($String){
    $IPregex=�(?<Address>((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))�
    If ($String -Match $IPregex) {$Matches.Address}
}

function Get-Background-info
{
param(
[Parameter(Mandatory=$false)] $Computer,
[Parameter(Mandatory=$false)] $UserID,
[Parameter(Mandatory=$false)] $ScriptRoot
)

$Script:BackgroundInfo = "BackgroundInfo"

Add-JobTracker -Name $Script:BackgroundInfo  -ArgumentList ("$Computer", "$UserID", "$ScriptRoot") `
    -JobScript {
        $computer = $args[0]
        $userID = $args[1]
        $ScriptRoot = $args[2]

        $ErrorMsg = $null
        if($Computer)
        {
            function Check-Credentials
            {
                $Script:CredentialsLoaded = $false
                $Script:credentials = $null
                $Script:credentials2 = $null
                if(test-path "C:\Temp\CKey.key")
                {
                    $failedcreds = $false
                    [Byte[]]$key = gc C:\Temp\CKey.key
                    if(test-path 'C:\Temp\A_User.txt')
                    {
                        $Admin_User = gc 'C:\Temp\A_User.txt'
                        $Admin_User = $Admin_User.trim()
                        $Admin_User1 = "AFII\$($Admin_User)"
                        if(test-path 'C:\Temp\ACreds_ss.txt')
                        {
                            $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
                        }
                        else
                        {
                            $failedcreds = $True
                        }
                    }
                    else
                    {
                        $failedcreds = $True
                    }
                    if(test-path 'C:\Temp\NA_User.txt')
                    {
                        $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
                        $Script:NonAdmin_User1 = $NonAdmin_User.trim()
                        $emailfound = $false
                        if(!(test-path 'C:\Temp\M_Email.txt'))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "sAMAccountName -like '$Script:NonAdmin_User1'")
                            if ($($AD_User.count) -lt 1)
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=Corp,DC=i,DC=ameriprise,DC=com"-Properties * -filter "sAMAccountName -like '$Script:NonAdmin_User1'")
                            }
                            elseif ($($AD_User.count) -eq 1)
                            {
                                #Found 1 entry
                                $emailfound = $true
                                $Script:MerakiLoginEmail = $($AD_User.UserPrincipalName)
                                $Script:MerakiLoginEmail | Out-File -FilePath 'C:\Temp\M_Email.txt' -Encoding ascii
                            }
                        }
                        else
                        {
                            $emailfound = $true
                            $Script:MerakiLoginEmail = gc 'C:\Temp\M_Email.txt'
                        }

                        if($emailfound -eq $true)
                        {
                            if(test-path 'C:\Temp\M_Creds_ss.txt')
                            {
                                $SecurePass =  (Get-Content 'C:\Temp\M_Creds_ss.txt' | ConvertTo-SecureString -key $key )
                                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                                $Script:MerakiLoginPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                            }
                            else
                            {
                                $failedcreds = $true
                            }
                        }

                        $NonAdmin_User1 = "AFII\$($Script:NonAdmin_User1)"
                        if(test-path 'C:\Temp\Creds_ss.txt')
                        {

                            $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                            $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                            $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                            $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                        }
                        else
                        {
                            $failedcreds = $True
                        }
                    }
                    else
                    {
                        $failedcreds = $True
                    }

                    if($failedcreds -eq $false)
                    {
                        $Script:CredentialsLoaded = $true
                        return $null
                    }
                    else
                    {
                        return "Credentials Failed"
                    }
                }
                else
                {
                    $key = New-Object Byte[] 16
                    $key | out-file "C:\Temp\CKey.key"
                    $failedcreds = $True
                    return "CKey was missing"
                }
            }

            $checkmsg = Check-Credentials
            if($checkmsg)
            {
                $Errormsg = $checkmsg
            }

            if(!(Test-Path 'C:\Program Files (x86)\Python37-32\python.exe' -ErrorAction SilentlyContinue))
            {
                $Errormsg = "Python Not installed!"
            }

            If(!($Script:NonAdmin_User1))
            {
                $Errormsg = "Non Admin Username was not found"
            }

            if(!($Script:Password))
            {
                $Errormsg = "Non Admin Password was not found"
            }

            if(!($Script:MerakiLoginEmail))
            {
                $Errormsg = "Meraki Login Email was not found"
            }

            if(!($Script:MerakiLoginPassword))
            {
                $Errormsg = "Meraki Login Password was not found"
            }

            if(!($computer))
            {
                $Errormsg = "Computer name was not present"
            }

            if(!($UserID))
            {
                $UserID = "NONE"
                #$Errormsg = "UserID was not present"
            }

            $Script:Return_Results = $null


            $computer = $computer.trim()
            if(!($computer))
            {
                $Errormsg = "Computer input was Empty String"
            }

            if(!($Errormsg))
            {
                $pc2 = Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "Name -like '*$computer'"
                if($PC2.name)
                {
                    $ComputerName = $PC2.name

                }
                else
                {
                    $Errormsg = "Computer not found in AD"
                }

                # Script fixes\files
                $LogRoot = $ScriptRoot
                $Python_Script = "$LogRoot\Python\Get-Meraki.py"
                $ParentLogContainingFolderName = "Python"
                $LogContainingFolderName = "Get-Meraki"
                $logfilename = "$ComputerName.txt"
                $logfilenamecopy = "$ComputerName(1).txt"
                $logpath = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"
                if (test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilenamecopy" -ErrorAction SilentlyContinue)
                {
                    Remove-Item "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilenamecopy" -Force
                    if (test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename" -ErrorAction SilentlyContinue)
                    {
                        Remove-Item "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename" -Force
                    }
                }
                $CSVOutput = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\PythonCSVOutput.csv"
                if (!(Test-path "$CSVOutput"))
                {
                    "test" |Export-CSV -Path $CSVOutput
                }
                else
                {
                    Clear-Content -Path $CSVOutput
                }
                $PythonCSVoutput = $CSVOutput
                $PythonCSVoutput = $PythonCSVoutput.Replace('\','/')

                if(!(test-path "$LogRoot\Logs"))
                {
                    $fso = new-object -ComObject scripting.filesystemobject
                    $fso.CreateFolder("$LogRoot\Logs") > $null
                }

                if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName"))
                {
                    $fso = new-object -ComObject scripting.filesystemobject
                    $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName") > $null
                }

                if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName"))
                {
                    $fso = new-object -ComObject scripting.filesystemobject
                    $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName") > $null
                }

                if(!(test-path "$logpath"))
                {
                    write-output "$((Get-Date).ToString())" |Out-File -FilePath $logpath
                }

                $i= 0
                if(Test-Path "$Python_Script")
                {
                if(!($UserID))
                {
                    $userID = "NONE"
                }
                    $Pythonlog = $logpath.Replace('\','/')
                    & "C:\Program Files (x86)\Python37-32\python.exe" "$Python_Script" "$Script:MerakiLoginEmail" "$Script:MerakiLoginPassword" "$Script:NonAdmin_User1" "$Script:Password" "$ComputerName" "$UserID" "$Pythonlog" "$PythonCSVoutput"
                    $ResultsCsv = $null
                    $ResultsCsv = Import-Csv $CSVOutput
                    $logs = gc $logpath
                    $splitlogs = $logs.split("|")
                    $splitlogs | Out-File $logpath

                    if ($ResultsCsv.HAS_MERAKI -eq 'FALSE')
                    {
                        $properties = @{'Meraki_IP' = "No Meraki Found";
                        'Meraki_Serial' = "No Meraki Found";
                        'User_Address' = "No Meraki Found";
                        'User_Assigned' = $($ResultsCSV.USER_ASSIGNED);
                        'User_Dept' = $($ResultsCSV.USER_DEPT);
                        'Asset_State' = $($ResultsCSV.STATE);
                        'Asset_Substate' = $($ResultsCSV.SECONDARY_STATE);
                        'Asset_Function' = $($ResultsCSV.ASSET_FUNCTION);
                        'User_Location' = $($ResultsCSV.USER_LOCATION);
                        'PC_Model' = $($ResultsCSV.PC_MODEL);
                        'ErrorMsg' = $Errormsg;
                        }
                    }
                    else
                    {
                        $properties = @{'Meraki_IP' = $($ResultsCsv.MERAKI_IP_ADDRESS);
                        'Meraki_Serial' = $($ResultsCSV.MERAKI_SERIAL);
                        'User_Address' = $($ResultsCSV.USER_ADDRESS);
                        'User_Assigned' = $($ResultsCSV.USER_ASSIGNED);
                        'User_Dept' = $($ResultsCSV.USER_DEPT);
                        'Asset_State' = $($ResultsCSV.STATE);
                        'Asset_Substate' = $($ResultsCSV.SECONDARY_STATE);
                        'Asset_Function' = $($ResultsCSV.ASSET_FUNCTION);
                        'User_Location' = $($ResultsCSV.USER_LOCATION)
                        'PC_Model' = $($ResultsCSV.PC_MODEL);
                        'ErrorMsg' = $Errormsg;
                        }
                    }
                }
                else
                {
                    #write-debug "location fixes is not valid path"
                    $properties = @{'Meraki_IP' = 'Script Not Found';
                    'Meraki_Serial' = 'Script Not Found';
                    'User_Address' = 'Script Not Found';
                    'User_Assigned' = 'Script Not Found';
                    'User_Dept' = 'Script Not Found';
                    'Asset_State' = 'Script Not Found';
                    'Asset_Substate' = 'Script Not Found';
                    'Asset_Function' = 'Script Not Found';
                    'User_Location' = 'Script Not Found';
                    'PC_Model' = 'Script Not Found';
                    'ErrorMsg' = "Python Script not found";
                    }
                }
            }
            else
            {
                #write-debug "location fixes is not valid path"
                $properties = @{'ErrorMsg' = $ErrorMsg;}
            }
        }
        else
        {
            $ErrorMsg = "No PC Name Input"
            $properties = @{'ErrorMsg' = $ErrorMsg;}
        }
	    $Return_Object = New-Object �TypeName PSObject �Prop $properties
	    return $Return_Object
        for($i = 0; $i -lt 50; $i++){ Start-Sleep -Milliseconds 100 } 
        
        #--------------------------------------------------
    }`
    -CompletedScript {
        Param($Job)
        #Enable the Button
        #$buttonStartJob.ImageIndex = -1
        #$buttonStartJob.Enabled = $true
        
        #write-host "Completed Script"
    }`
    -UpdateScript {
        Param($Job)
        #$results = Receive-Job -Job $Job -Keep
        #write-host $results
    }
}

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
    
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User1 = $NonAdmin_User.trim()
            $emailfound = $false
            if(!(test-path 'C:\Temp\M_Email.txt'))
            {
                $AD_User = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "sAMAccountName -like '$Script:NonAdmin_User1'")
                if ($($AD_User.count) -lt 1)
                {
                    $AD_User = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=Corp,DC=i,DC=ameriprise,DC=com"-Properties * -filter "sAMAccountName -like '$Script:NonAdmin_User1'")
                }
                elseif ($($AD_User.count) -eq 1)
                {
                    #Found 1 entry
                    $emailfound = $true
                    $Script:MerakiLoginEmail = $($AD_User.UserPrincipalName)
                    $Script:MerakiLoginEmail | Out-File -FilePath 'C:\Temp\M_Email.txt' -Encoding ascii
                }
            }
            else
            {
                $emailfound = $true
                $Script:MerakiLoginEmail = gc 'C:\Temp\M_Email.txt'
            }

            if($emailfound -eq $true)
            {
                if(test-path 'C:\Temp\M_Creds_ss.txt')
                {
                    $SecurePass =  (Get-Content 'C:\Temp\M_Creds_ss.txt' | ConvertTo-SecureString -key $key )
                    $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                    $Script:MerakiLoginPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                }
                else
                {
                    $failedcreds = $true
                }
            }

            $NonAdmin_User1 = "AFII\$($Script:NonAdmin_User1)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
    else
    {
        $key = New-Object Byte[] 16
        $key | out-file "C:\Temp\CKey.key"
        $failedcreds = $True
    }
}

function Add-JobTracker
{
    <#
        .SYNOPSIS
            Add a new job to the JobTracker and starts the timer.
    
        .DESCRIPTION
            Add a new job to the JobTracker and starts the timer.
    
        .PARAMETER  Name
            The name to assign to the Job
    
        .PARAMETER  JobScript
            The script block that the Job will be performing. 
            Important: Do not access form controls from this script block.
    
        .PARAMETER ArgumentList
            The arguments to pass to the job
    
        .PARAMETER  CompleteScript
            The script block that will be called when the job is complete.
            The job is passed as an argument. The Job argument is null when the job fails.
    
        .PARAMETER  UpdateScript
            The script block that will be called each time the timer ticks. 
            The job is passed as an argument. Use this to get the Job's progress.
    
        .EXAMPLE
            Job-Begin -Name "JobName" `
            -JobScript {    
                Param($Argument1)#Pass any arguments using the ArgumentList parameter
                #Important: Do not access form controls from this script block.
                Get-WmiObject Win32_Process -Namespace "root\CIMV2"
            }`
            -CompletedScript {
                Param($Job)        
                $results = Receive-Job -Job $Job        
            }`
            -UpdateScript {
                Param($Job)
                #$results = Receive-Job -Job $Job -Keep
            }
    
        .LINK
            
    #>
    
    Param(
    [ValidateNotNull()]
    [Parameter(Mandatory=$true)]
    [string]$Name, 
    [ValidateNotNull()]
    [Parameter(Mandatory=$true)]
    [ScriptBlock]$JobScript,
    $ArgumentList = $null,
    [ScriptBlock]$CompletedScript,
    [ScriptBlock]$UpdateScript)
    
    #Start the Job
    $job = Start-Job -Name $Name -ScriptBlock $JobScript -ArgumentList $ArgumentList
    
    if($job -ne $null)
    {
        #Create a Custom Object to keep track of the Job & Script Blocks
        $psObject = New-Object System.Management.Automation.PSObject
        
        Add-Member -InputObject $psObject -MemberType 'NoteProperty' -Name Job  -Value $job
        Add-Member -InputObject $psObject -MemberType 'NoteProperty' -Name CompleteScript  -Value $CompletedScript
        Add-Member -InputObject $psObject -MemberType 'NoteProperty' -Name UpdateScript  -Value $UpdateScript
        
        [void]$JobTrackerList.Add($psObject)    
        
        #Start the Timer
        if(-not $timerJobTracker.Enabled)
        {
            $timerJobTracker.Start()
        }
    }
    elseif($CompletedScript -ne $null)
    {
        #Failed
        Invoke-Command -ScriptBlock $CompletedScript -ArgumentList $null
    }

}

function Update-JobTracker
{
    <#
        .SYNOPSIS
            Checks the status of each job on the list.
    #>
    
    #Poll the jobs for status updates
    #$timerJobTracker.Stop() #Freeze the Timer
    
    for($index =0; $index -lt $JobTrackerList.Count; $index++)
    {
        $psObject = $JobTrackerList[$index]
        
        if($psObject -ne $null) 
        {
            if($psObject.Job -ne $null)
            {
                if($psObject.Job.State -ne "Running")
                {                
                    #Call the Complete Script Block
                    if($psObject.CompleteScript -ne $null)
                    {
                        #$results = Receive-Job -Job $psObject.Job
                        Invoke-Command -ScriptBlock $psObject.CompleteScript -ArgumentList $psObject.Job
                    }
                    
                    $JobTrackerList.RemoveAt($index)
                    #Remove-Job -Job $psObject.Job
                    $index-- #Step back so we don't skip a job
                }
                elseif($psObject.UpdateScript -ne $null)
                {
                    #Call the Update Script Block
                    Invoke-Command -ScriptBlock $psObject.UpdateScript -ArgumentList $psObject.Job
                }
            }
        }
        else
        {
            $JobTrackerList.RemoveAt($index)
            $index-- #Step back so we don't skip a job
        }
    }
    
    if($JobTrackerList.Count -gt 0)
    {
       # $timerJobTracker.Start()#Resume the timer    
    }    
}

function Stop-JobTracker
{
   <#
        .SYNOPSIS
            Stops and removes all Jobs from the list.
    #>
   #Stop the timer
   $timerJobTracker.Stop()
    
   #Remove all the jobs
   while($JobTrackerList.Count-gt 0)
    {
       $job = $JobTrackerList[0].Job
       $JobTrackerList.RemoveAt(0)
       Stop-Job $job
       Remove-Job $job
    }
}

Function Show-AD-Memberships
{
    if($($tbx_PC_Name.text))
    {
        if($tbx_PC_Name.text.trim())
        {
            $MainForm.text = "Getting PC From AD..."
            $AD_Computer = $null
            $AD_Computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "name -like '$($tbx_PC_Name.text)'")
            $MainForm.text = "Validtating PC From AD..."
            if($AD_Computer)
            {
                $sccmGroups = @()
                $MainForm.text = "Getting PC Memberships From AD..."
                $Group = $AD_Computer | Select -ExpandProperty MemberOf |% {$_.Split(",")[0].TrimStart("CN=")}
                $MainForm.text = "Validating PC Memberships From AD..."
                if ($Group.count -lt 1)
                {
                    #no memberships
                    $MainForm.text = "PC Has No Memberships!"
                }
                else
                {
                    $MainForm.text = "Filtering SCCM Memberships..."
                    
                    foreach ($member in $Group)
                    {
                        if ($member -like "SCCM*")
                        {
                            #$sccmGroups += $member
                        }
                        $properties = @{'Membership' = $member;}
                        $obj = New-Object �TypeName PSObject �Prop $properties
                        $sccmGroups += $obj
                    }
                    $MainForm.text = "Displaying SCCM Memberships..."
                    $selectedMembership = Show-DGForm($sccmGroups)
                    $MainForm.text = "PC Memberships Done!"
                }
            }
        }
        else
        {
            $MainForm.text = "Can't Get Memberships!"
        }
    }
    else
    {
        $MainForm.text = "Can't Get Memberships!"
    }
}

Function Open-CShare($PC)
{
    if ($PC -ne "" -and $PC -ne $null)
    {
        $MainForm.Text = "Checking Credentials..."
        Check-Credentials
        $MainForm.Text = "Getting PC from AD..."
        $computer = (Get-PC-By_PCName($PC)).name
        if($computer)
        {
            $MainForm.Text = "Adding Credentials to Credential Manager"
            #cmdkey /add:$computer /user:$($Script:credentials.UserName)  /pass:$($Script:credentials.Password)
            $MainForm.Text = "Opening C Share..."
            start-process explorer.exe "\\$computer\c$"
            $MainForm.Text = "C Share Done! (May take a moment)"
        }
        Else
        {
            $MainForm.Text = "C Share Couldn't Find PC in AD!"
        }       
    }
}

Function Set-Display-Controls
{
    $panel1.controls.clear()
    $panel2.controls.clear()
    $panel3.controls.clear()
    $panel4.controls.clear()
    $panel5.controls.clear()
    $panel6.controls.clear()
    $panel7.controls.clear()
    $panel8.controls.clear()
    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls1.count; $i1++)
    {
        if ($Script:aryDisplayLblControls1[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls1[$i1].Location = "3, $($i * 22)"
            $panel1.controls.add($Script:aryDisplayLblControls1[$i1])
            $i += 1
        }
    }
    $panel1.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls2.count; $i1++)
    {
        if ($Script:aryDisplayLblControls2[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls2[$i1].Location = "3, $($i * 22)"
            $panel2.controls.add($Script:aryDisplayLblControls2[$i1])
            $i += 1
        }
    }
    $panel2.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls3.count; $i1++)
    {
        if ($Script:aryDisplayLblControls3[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls3[$i1].Location = "3, $($i * 22)"
            $panel3.controls.add($Script:aryDisplayLblControls3[$i1])
            $i += 1
        }
    }
    $panel3.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls4.count; $i1++)
    {
        if ($Script:aryDisplayLblControls4[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls4[$i1].Location = "3, $($i * 22)"
            $panel4.controls.add($Script:aryDisplayLblControls4[$i1])
            $i += 1
        }
    }
    $panel4.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls5.count; $i1++)
    {
        if ($Script:aryDisplayLblControls5[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls5[$i1].Location = "3, $($i * 22)"
            $panel5.controls.add($Script:aryDisplayLblControls5[$i1])
            $i += 1
        }
    }
    $panel5.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls6.count; $i1++)
    {
        if ($Script:aryDisplayLblControls6[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls6[$i1].Location = "3, $($i * 22)"
            $panel6.controls.add($Script:aryDisplayLblControls6[$i1])
            $i += 1
        }
    }
    $panel6.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls7.count; $i1++)
    {
        if ($Script:aryDisplayLblControls7[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls7[$i1].Location = "3, $($i * 22)"
            $panel7.controls.add($Script:aryDisplayLblControls7[$i1])
            $i += 1
        }
    }
    $panel7.Height = ($i * 22)

    $i = 0
    for($i1 = 0; $i1 -lt $Script:aryDisplayLblControls8.count; $i1++)
    {
        if ($Script:aryDisplayLblControls8[$i1].Visible -eq $true)
        {
            $Script:aryDisplayLblControls8[$i1].Location = "3, $($i * 22)"
            $panel8.controls.add($Script:aryDisplayLblControls8[$i1])
            $i += 1
        }
    }
    $panel8.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls1.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls1[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls1[$i1].Location = "120, $($i * 22)"
            $panel1.controls.add($Script:aryDisplaytbxControls1[$i1])
            $i += 1
        }
    }
    #$panel1.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls2.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls2[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls2[$i1].Location = "120, $($i * 22)"
            $panel2.controls.add($Script:aryDisplaytbxControls2[$i1])
            $i += 1
        }
    }
    #$panel2.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls3.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls3[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls3[$i1].Location = "180, $($i * 22)"
            $panel3.controls.add($Script:aryDisplaytbxControls3[$i1])
            $i += 1
        }
    }
    #$panel3.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls4.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls4[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls4[$i1].Location = "60, $($i * 22)"
            $panel4.controls.add($Script:aryDisplaytbxControls4[$i1])
            $i += 1
        }
    }
    #$panel4.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls5.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls5[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls5[$i1].Location = "120, $($i * 22)"
            $panel5.controls.add($Script:aryDisplaytbxControls5[$i1])
            $i += 1
        }
    }
    #$panel5.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls6.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls6[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls6[$i1].Location = "120, $($i * 22)"
            $panel6.controls.add($Script:aryDisplaytbxControls6[$i1])
            $i += 1
        }
    }
    #$panel6.Height = ($i * 22)

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls7.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls7[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls7[$i1].Location = "120, $($i * 22)"
            $panel7.controls.add($Script:aryDisplaytbxControls7[$i1])
            $i += 1
        }
    }

    $i = 1
    for($i1 = 0; $i1 -lt $Script:aryDisplaytbxControls8.count; $i1++)
    {
        if ($Script:aryDisplaytbxControls8[$i1].Visible -eq $true)
        {
            $Script:aryDisplaytbxControls8[$i1].Location = "120, $($i * 22)"
            $panel8.controls.add($Script:aryDisplaytbxControls8[$i1])
            $i += 1
        }
    }
}

function reset-script-vars()
{
$Script:LastSearchBy = $null;$Script:LastSearch = $null;$Script:InitialFixesLocation = $null;$Script:FixesLocation = $Script:InitialFixesLocation;$Script:InitialEUCLocation = $null;$Script:EUCLocation = $Script:InitialEUCLocation;$Script:AryFixButtons = $null;$Script:AryEUCButtons1 = $null;$Script:CredentialsLoaded = $false;$Script:HDriveLocation = $null;$Script:credentials = $null;$Script:credentials2 = $null;$Script:InitialUserStarted = $null
        $MainForm.Text = "Finding H:\ Drive location var in Script..."
        $i= 0
        $content = $null
        $scriptname = Split-Path "$($MyInvocation.PSCommandPath)" -leaf
        $content = (get-content "$($MyInvocation.PSCommandPath)")
        if ($content -ne $null -and $content -ne "")
        {
            $content2 = ($content | Where-Object {$_ -like '$Script:HDriveLocation = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})

            if($content2.count -gt 1)
            {
                #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
            }
            else
            {
                $MainForm.Text = "Setting H:\ Drive location var in Script..."
                
                $content[$index] = "`$Script:HDriveLocation = `'$null`'"
                $content |Set-Content "$($MyInvocation.PSCommandPath)"
            }
        }
        $MainForm.Text = "H Drive Set"


}

Function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        #Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

function Setup-IP-Invoke($IP)
{
    $Script:TrustedHosts = $null
    if($IP)
	{
		$Script:TrustedHosts =  (Get-Item WSMan:\localhost\Client\TrustedHosts -Force).value
		Set-Item WSMan:\localhost\Client\TrustedHosts -Value "$IP" -Force
	}
}

function Load-Gfx-Info($PC_Name, [switch]$AsJob)
{
    $GfxVer = $null
    $GfxDriver = $null
    $out_GfxDriver = $null
    $out_GfxVer = $null
    $VideoControllerName = $null
    $graphicsVer = $null
    $ErrorMsg = $null
    if($PC_Name)
    {
        $MainForm.Text = 'Getting Video Controller info from WMI...'
        $VideoControllerName = (Get-WmiObject win32_videocontroller -ComputerName $PC_Name -Credential $Script:Credentials | select caption).caption
        if ($videoControllerName)
        {
            $GfxDriver = $VideoControllerName
        }
        else
        {
            $ErrorMsg = "Couldn't find Video Controller"
        }
        $MainForm.Text = 'Getting PnPSignedDriver info from WMI...'
        $graphicsVer = Get-WmiObject Win32_PnPSignedDriver -ComputerName $PC_Name -Credential $Script:Credentials | select DeviceName, DriverVersion | where {$_.DeviceName -eq "$VideoControllerName"}
        $MainForm.Text = 'Validating Graphics info returned...'
	    if ($graphicsVer)
	    {
    	    #$GfxDriver = $($graphicsVer.DeviceName)
	        $GfxVer = $($graphicsVer.DriverVersion)
	        if($GfxDriver)
	        {
                $MainForm.Text = 'Setting Graphics Driver...'
	            $out_GfxDriver = $GfxDriver
                if($GfxVer)
	            {
                    $MainForm.Text = 'Setting Graphics version...'
	                $out_GfxVer = $GfxVer	
	            }
	            else
	            {
                    $MainForm.Text = 'Setting Graphics version...'
	                $ErrorMsg = "Couldn't get Graphics version"
	            }
	        }
	        else
	        {
                $MainForm.Text = 'Setting Graphics Driver...'
	            $ErrorMsg = "Couldn't get Graphic Driver"
	        }
	    }
	    else
	    {
            if($GfxDriver)
	        {
                $MainForm.Text = 'Setting Graphics Driver...'
	            $out_GfxDriver = $GfxDriver
	        }
	        else
	        {
                $MainForm.Text = 'Setting Graphics Driver...'
	            $ErrorMsg = "Couldn't get Graphic Info"
	        }
	    }
    }
    $properties = @{'GfxVersion' = $out_GfxVer;
                    'GfxDriver' = $out_GfxDriver;
	                'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
    $MainForm.Text = 'Graphics Info Loaded!'
	return $Return_Object
}

function Teardown-IP-Invoke
{
		# Reset Trustedhosts back
		if ($Script:TrustedHosts)
		{
			Set-Item WSMan:\localhost\Client\TrustedHosts -Value $Script:TrustedHosts -Force
		}
}

function Find-Folders 
{
    [Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms") | Out-Null
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $browse = New-Object System.Windows.Forms.FolderBrowserDialog
    if(test-path "$(((get-item "$psscriptroot").parent).fullname)")
    {
    $browse.SelectedPath = "$(((get-item "$psscriptroot").parent).fullname)"
    }
    elseif(test-path "C:\users\$Script:InitialUserStarted\desktop")
    {
        $browse.SelectedPath = "C:\users\$Script:InitialUserStarted\desktop"
    }
    else
    {
        $browse.SelectedPath = "C:\users"
    }
    
    $browse.ShowNewFolderButton = $false
    $browse.Description = "Select the folder that contains Scripts"
    
    
    $loop = $true
    while($loop)
    {
        if ($browse.ShowDialog() -eq "OK")
        {
            $loop = $false
		
		    #Insert your script here
		
        } 
        else
        {
            #$res = [System.Windows.Forms.MessageBox]::Show("You clicked Cancel. Would you like to try again or exit?", "Select a location", [System.Windows.Forms.MessageBoxButtons]::RetryCancel)
            #if($res -eq "Cancel")
            #{
                #Ends script
                return
            #}
        }
    }
    $browse.SelectedPath
    $browse.Dispose()
}

Function Set-FixButtons($buttons_functionslist)
{
$panelRight.controls.clear()
$mainform.suspendlayout()
$splitcontainer.suspendlayout()
$panelright.suspendLayout()

    
    $buttons_functionslist = $buttons_functionslist | sort -Descending
    $buttons_functionbuttoncount = $buttons_functionslist.count
    $loop = 0
    while($loop -lt $buttons_functionbuttoncount)
	{
	    $thisbutton = New-Object System.Windows.Forms.Button
        $thisbutton.Size = '77, 45' 
        [string]$calling = $buttons_functionslist[$loop]
        $thisbutton.tag=@{Script=$calling}
        $thisbutton.UseVisualStyleBackColor = $True 
	    $thisbutton.Dock = [System.Windows.Forms.DockStyle]::Top 
	    $thisbutton.Add_Click({param($Sender)
            #call script
            [string]$thisbuttonname = Split-Path $($Sender.Tag.script) -Leaf
            if($thisbuttonname -eq "Order Creds.ps1")
            {
            $MainForm.Text = "Running $thisbuttonname..."
            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Username '$($tbx_User_AD_Email.text)'")
            $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Run Assign Empty VDI.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Run Get-Emails.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Run Retire PCs.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Run Retire PCs And Close Ticket.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Run Show PC Memberships.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Run Show User Memberships.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserID '$($tbx_User_AD_ID.text)'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            elseif($thisbuttonname -eq "Send Wake-On-Lan to PC.ps1")
            {
                $MainForm.Text = "Running $thisbuttonname..."
                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                $MainForm.Text = "$thisbuttonname Script Started!"
            }
            else
            {
                $MainForm.Text = "Testing if $($tbx_PC_Name.text) is Online..."
                if(!(Test-Connection $($tbx_PC_Name.text) -count 1 -quiet -ErrorAction SilentlyContinue))
                {
                write-host "$($tbx_PC_Name.text) is not online"
                    if($tbx_PC_IP.text)
                    {
                        write-host "$($tbx_PC_IP.text) text was found"
                        if(($tbx_PC_IP.text).trim())
                        {
                         write-host "$($tbx_PC_IP.text) text was found trimmed"
                            $MainForm.Text = "Testing by IP Address if $($tbx_PC_IP.text) is Online..."
                            if(Test-Connection $($tbx_PC_IP.text) -count 1 -quiet -ErrorAction SilentlyContinue)
                            {
                                write-host "$($tbx_PC_IP.text) is online"
                                $MainForm.Text = "Running $thisbuttonname..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_IP.text)'")
                                $MainForm.Text = "$thisbuttonname Script Started!"
                            }
                            else
                            {
                                $MainForm.Text = "$($tbx_PC_IP.text) NOT ONLINE!"
                            }
                        }
                        else
                        {
                            $MainForm.Text = "Invalid IP Address!"
                        }
                    }
                    else
                    {
                        $MainForm.Text = "Invalid IP Address!"
                    }
                }
                else
                {
                    write-host "$($tbx_PC_Name.text) was found online"
                    Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                    $MainForm.Text = "$thisbuttonname Script Started!"
                }
            }
		})
        [string]$thisbuttonname = Split-Path $buttons_functionslist[$loop] -Leaf
        $thisbuttonname  = $thisbuttonname -replace ".ps1"
        $thisbutton.Text = $thisbuttonname
        $panelRight.controls.add($thisbutton)
	    $loop += 1
	}
    if($Script:InitialUserStarted = "bwienk1")
    {
        #DEBUG FOR CREATOR
        $panelRight.Controls.Add($ButtonShowConsole)
    }
    $panelRight.Controls.Add($ButtonChangeFixFolder)
	$panelRight.Controls.Add($ButtonShowMain)

    #$MainForm.Refresh()
    $panelright.resumeLayout()
    $splitcontainer.resumeLayout()
    $mainform.Resumelayout()
}

Function Set-EUCButtons($buttons_functionslist)
{
    $panelRight.Controls.Clear()
    $mainform.suspendLayout()
    $splitcontainer.suspendLayout()
    $panelright.suspendLayout()                 
                       
    $buttons_functionslist = $buttons_functionslist | sort -Descending
    
    $buttons_functionbuttoncount = $buttons_functionslist.count
    $loop = 0
    $tabindex = $buttons_functionslist.count + 20
    while($loop -lt $buttons_functionbuttoncount)
	{
        [string]$namesplit = $buttons_functionslist[$loop]
        $foldername = Split-Path $namesplit -Leaf
        if ($foldername -notlike "Logs" -and $foldername -notlike "PSExec" -and $foldername -notlike "Python" -and $foldername -notlike "COPY GUI OUT" -and $foldername -notlike "Files")
        {
            if ($foldername -like "PCUpdater")
            {
            $thisbutton = New-Object System.Windows.Forms.Button
            $thisbutton.Size = '77, 45' 
            [string]$calling = $buttons_functionslist[$loop]
            $PCListFile = Get-PCListInLocation-NoRecurse($calling)
            $thisbutton.tag=@{Script=$calling;Script2 = $PCListFile}
            $thisbutton.UseVisualStyleBackColor = $True
            $thisbutton.TabIndex = $tabindex
            $tabindex = $tabindex - 1
	        $thisbutton.Dock = [System.Windows.Forms.DockStyle]::Top 
	        $thisbutton.Add_Click({param($Sender)
                #call script
                $panelRight.Controls.Clear()
                $mainform.suspendLayout()
                $splitcontainer.suspendLayout()
                $panelright.suspendLayout() 
                if($sender.tag.script2)
                {
                    #PC_List.txt File found
                }
                else
                {
                    #PC_List.txt file not found
                }
                [string]$thisbuttonname = Split-Path $($Sender.Tag.script) -Leaf
                $MainForm.Text = "Loading $thisbuttonname Scripts..."            
                $lstScriptsinFolder = Get-FixesInLocation-NoRecure($($Sender.Tag.script))
                $buttons_functionbuttoncount2 = $lstScriptsinFolder.count
                        
                $loop2 = 0
                while($loop2 -lt $buttons_functionbuttoncount2)
	            {
                    $2ndTabIndex = 90
	                $thisbutton2 = New-Object System.Windows.Forms.Button
                    $thisbutton2.Size = '77, 45' 
                    if($buttons_functionbuttoncount2 -gt 1)
                    {
                        [string]$calling = $($lstScriptsinFolder[$loop2])
                    }
                    else
                    {
                        [string]$calling = $lstScriptsinFolder
                    }
                    if($PCListFile)
                    {
                        #pc_list.txt found
                        $PClistFound = $true
                    }
                    else
                    {
                        #pc_list.txt not found
                        $PClistFound = $false
                    }
                    $namecheck = (Split-Path $($calling) -Leaf)

                    if($namecheck -like "Run *")
                    {
                        $Runcolor = 'DarkBlue'
                    }
                    else
                    {
                        $Runcolor = 'Black'
                    }
                        #EXCEPTION BUTTONS THAT NEED CUSTOM CODE
                    if ($namecheck -eq "Run Retire VDI.ps1")
                    {
                        #Retire VDI Button exception
                        if ($($tbx_PC_Name.text) -like "WIVGP*")
                        {
                            #VDI is selected 
                            $ButtonRetireVDI = New-Object System.Windows.Forms.Button
                            $ButtonRetireVDI.Size = '77, 45'
                            $ButtonRetireVDI.tag=@{Script=$calling}
                            $ButtonRetireVDI.ForeColor = $Runcolor
                            $ButtonRetireVDI.UseVisualStyleBackColor = $True
                            $ButtonRetireVDI.TabIndex = $2ndTabIndex
                            $2ndTabIndex = $2ndTabIndex - 1
                            $ButtonRetireVDI.Dock = [System.Windows.Forms.DockStyle]::Top               
                            $ButtonRetireVDI.Add_Click({param($Sender)
                                #call script
                                [string]$ButtonRetireVDIName = Split-Path $($Sender.Tag.script) -Leaf
                                $MainForm.Text = "Running $ButtonRetireVDIName..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                                $MainForm.Text = "Started Retire VDI Script!"
		                    })
                            $ButtonRetireVDI.Text = "Run Retire This VDI"
                            $panelright.controls.add($ButtonRetireVDI)

                            $ButtonRetireVDI2 = New-Object System.Windows.Forms.Button
                            $ButtonRetireVDI2.Size = '77, 45'
                            $ButtonRetireVDI2.tag=@{Script=$calling}
                            $ButtonRetireVDI2.ForeColor = $Runcolor
                            $ButtonRetireVDI2.UseVisualStyleBackColor = $True
                            $ButtonRetireVDI2.TabIndex = $2ndTabIndex
                            $2ndTabIndex = $2ndTabIndex - 1
                            $ButtonRetireVDI2.Dock = [System.Windows.Forms.DockStyle]::Top                      
                            $ButtonRetireVDI2.Add_Click({param($Sender)
                                #call script
                                [string]$ButtonRetireVDIName2 = Split-Path $($Sender.Tag.script) -Leaf
                                $MainForm.Text = "Running $ButtonRetireVDIName2..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                                $MainForm.Text = "Started Retire VDI Script!"
		                    })
                            $ButtonRetireVDI2.Text = "Run Retire Different VDI"
                            $panelright.controls.add($ButtonRetireVDI2)
                        }
                        else
                        {
                            #No VDI is selected
                            $ButtonRetireVDI = New-Object System.Windows.Forms.Button
                            $ButtonRetireVDI.Size = '77, 45'
                            $ButtonRetireVDI.ForeColor = $Runcolor
                            $ButtonRetireVDI.tag=@{Script=$calling}
                            $ButtonRetireVDI.UseVisualStyleBackColor = $True
                            $ButtonRetireVDI.TabIndex = $2ndTabIndex
                            $2ndTabIndex = $2ndTabIndex - 1
                            $ButtonRetireVDI.Dock = [System.Windows.Forms.DockStyle]::Top                      
                            $ButtonRetireVDI.Add_Click({param($Sender)
                                #call script
                                [string]$ButtonRetireVDIName = Split-Path $($Sender.Tag.script) -Leaf
                                $MainForm.Text = "Running $ButtonRetireVDIName..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                                $MainForm.Text = "Started Retire VDI Script!"
		                    })
                            $ButtonRetireVDI.Text = "Run Retire A VDI" 
                        }
                        $panelright.controls.add($ButtonRetireVDI) 
                    }
                    elseif($namecheck -eq "Run Swap PC.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonSwapPC = New-Object System.Windows.Forms.Button
                        $ButtonSwapPC.Size = '77, 45'
                        $ButtonSwapPC.ForeColor = $Runcolor
                        $ButtonSwapPC.tag=@{Script=$calling}
                        $ButtonSwapPC.UseVisualStyleBackColor = $True
                        $ButtonSwapPC.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonSwapPC.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonSwapPC.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonSwapPCName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonSwapPCName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserFullname '$($tbx_User_AD_Name.text)' -UserEmail '$($tbx_User_AD_Email.text)' -OldComputerFullname '$($tbx_PC_Name.text)'")
                            $MainForm.Text = "Started Swap PC Script!"
                            })
                        $ButtonSwapPC.Text = $name
                        $panelright.controls.add($ButtonSwapPC) 
                    }
                    elseif($namecheck -eq "Run Update Thunderbolt Firmware.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonUpdateTBT = New-Object System.Windows.Forms.Button
                        $ButtonUpdateTBT.Size = '77, 45'
                        $ButtonUpdateTBT.ForeColor = $Runcolor
                        $ButtonUpdateTBT.tag=@{Script=$calling}
                        $ButtonUpdateTBT.UseVisualStyleBackColor = $True
                        $ButtonUpdateTBT.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonUpdateTBT.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonUpdateTBT.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonUpdateTBTName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonUpdateTBTName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computer '$($tbx_PC_Name.text)' -Model '$($tbx_PC_Model.text)'")
                            $MainForm.Text = "Started Thunderbolt Firmware Update Script!"
                            })
                        $ButtonSwapPC.Text = $name
                        $panelright.controls.add($ButtonSwapPC) 
                    }
                    elseif($namecheck -eq "RebootGui.ps1")
                    {
                        #Don't A
                    }
                    elseif($namecheck -eq "Run Transfer Files From Old to New PC.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonTransferPC = New-Object System.Windows.Forms.Button
                        $ButtonTransferPC.Size = '77, 45'
                        $ButtonTransferPC.ForeColor = $Runcolor
                        $ButtonTransferPC.tag=@{Script=$calling}
                        $ButtonTransferPC.UseVisualStyleBackColor = $True
                        $ButtonTransferPC.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonTransferPC.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonTransferPC.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonTransferPCName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonTransferPCName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computername '$($tbx_PC_Name.text)' -Userfullname '$($tbx_User_AD_Name.text)'")
                            $MainForm.Text = "Started Transfer Files From Old to New PC Script!"
                            })
                        $ButtonTransferPC.Text = $name
                        $panelright.controls.add($ButtonTransferPC) 
                    }
                    elseif($namecheck -eq "Run Show PC Memberships.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonPCMemberships = New-Object System.Windows.Forms.Button
                        $ButtonPCMemberships.Size = '77, 45'
                        $ButtonPCMemberships.ForeColor = $Runcolor
                        $ButtonPCMemberships.tag=@{Script=$calling}
                        $ButtonPCMemberships.UseVisualStyleBackColor = $True
                        $ButtonPCMemberships.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonPCMemberships.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonPCMemberships.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonPCMembershipsName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonPCMembershipsName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computername '$($tbx_PC_Name.text)'")
                            $MainForm.Text = "Started Transfer Files From Old to New PC Script!"
                            })
                        $ButtonPCMemberships.Text = $name
                        $panelright.controls.add($ButtonPCMemberships) 
                    }

                    elseif($namecheck -eq "Run Show User Memberships.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonPCMemberships = New-Object System.Windows.Forms.Button
                        $ButtonPCMemberships.Size = '77, 45'
                        $ButtonPCMemberships.ForeColor = $Runcolor
                        $ButtonPCMemberships.tag=@{Script=$calling}
                        $ButtonPCMemberships.UseVisualStyleBackColor = $True
                        $ButtonPCMemberships.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonPCMemberships.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonPCMemberships.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonPCMembershipsName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonPCMembershipsName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserID '$($tbx_User_AD_ID.text)'")
                            $MainForm.Text = "Started Transfer Files From Old to New PC Script!"
                            })
                        $ButtonPCMemberships.Text = $name
                        $panelright.controls.add($ButtonPCMemberships) 
                    }
                    elseif($namecheck -eq "PCUpdater No Desc Change.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonPCUpdater2 = New-Object System.Windows.Forms.Button
                        $ButtonPCUpdater2.Size = '77, 45'
                        $ButtonPCUpdater2.ForeColor = $Runcolor
                        $ButtonPCUpdater2.tag=@{Script=$calling}
                        $ButtonPCUpdater2.UseVisualStyleBackColor = $True
                        $ButtonPCUpdater2.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonPCUpdater2.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonPCUpdater2.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonPCUpdater2Name = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonPCUpdater2Name..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                            $MainForm.Text = "Started PCUpdater No Desc Change Script!"
                            })
                        $ButtonPCUpdater2.Text = $name
                        $panelright.controls.add($ButtonPCUpdater2) 
                    }
                    elseif($namecheck -eq "Send Wake-On-Lan to PC.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonPCUpdater2 = New-Object System.Windows.Forms.Button
                        $ButtonPCUpdater2.Size = '77, 45'
                        $ButtonPCUpdater2.ForeColor = $Runcolor
                        $ButtonPCUpdater2.tag=@{Script=$calling}
                        $ButtonPCUpdater2.UseVisualStyleBackColor = $True
                        $ButtonPCUpdater2.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonPCUpdater2.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonPCUpdater2.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonPCUpdater2Name = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonPCUpdater2Name..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                            $MainForm.Text = "Started Send Wake-On-Lan Script!"
                            })
                        $ButtonPCUpdater2.Text = $name
                        $panelright.controls.add($ButtonPCUpdater2) 
                    }

                    elseif($namecheck -eq "PCUpdater CHANGE DESC.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonPCUpdater1 = New-Object System.Windows.Forms.Button
                        $ButtonPCUpdater1.Size = '77, 45'
                        $ButtonPCUpdater1.ForeColor = $Runcolor
                        $ButtonPCUpdater1.tag=@{Script=$calling}
                        $ButtonPCUpdater1.UseVisualStyleBackColor = $True
                        $ButtonPCUpdater1.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonPCUpdater1.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonPCUpdater1.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonPCUpdater1Name = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonPCUpdater1Name..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                            $MainForm.Text = "Started PCUpdater DESC CHANGE Script!"
                            })
                        $ButtonPCUpdater1.Text = $name
                        $panelright.controls.add($ButtonPCUpdater1) 
                    }
                    else
                    {
                        #STANDARD BUTTONS 
                        #    - checks if PC_list.txt for the script and calls the script with no arguments if found
                        #    - If pc_list.txt is not found calls script with -computer argument equal to the PC Name textbox text
             
                        
                        $thisbutton2.tag=@{Script=$calling;PCListExists = $PClistFound}
                        $thisbutton2.UseVisualStyleBackColor = $True
                        $thisbutton2.ForeColor = $Runcolor
                        $thisbutton2.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
	                    $thisbutton2.Dock = [System.Windows.Forms.DockStyle]::Top
	                    $thisbutton2.Add_Click({param($Sender)
                            #call script
                            [string]$thisbuttonname2 = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $thisbuttonname..."
                            if($Sender.Tag.PCListExists)
                            {
                                #write-debug "Button Triggered with no Computer argument passed (pc list should be used)"
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")            
                            }
                            else
                            {
                                if($thisbuttonname2 -like "Run Return To Stock and Make SD Ticket.ps1" -or $thisbuttonname2 -like "Run Return Meraki To Stock.ps1")
                                {
                                    Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                                    $MainForm.Text = "$thisbuttonname Script Started!"
                                }
                                else
                                {
                                    $MainForm.Text = "Testing if $($tbx_PC_Name.text) is Online..."
                                    if(!(Test-Connection $($tbx_PC_Name.text) -count 1 -quiet -ErrorAction SilentlyContinue))
                                    {
                                        write-host "$($tbx_PC_Name.text) is not online"
                                        if($tbx_PC_IP.text)
                                        {
                                            write-host "$($tbx_PC_IP.text) text was found"
                                            if(($tbx_PC_IP.text).trim())
                                            {
                                             write-host "$($tbx_PC_IP.text) text was found trimmed"
                                                $MainForm.Text = "Testing by IP Address if $($tbx_PC_IP.text) is Online..."
                                                if(Test-Connection $($tbx_PC_IP.text) -count 1 -quiet -ErrorAction SilentlyContinue)
                                                {
                                                    write-host "$($tbx_PC_IP.text) is online"
                                                    $MainForm.Text = "Running $thisbuttonname..."
                                                    Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                                                    $MainForm.Text = "$thisbuttonname Script Started!"
                                                }
                                                else
                                                {
                                                    $MainForm.Text = "$($tbx_PC_IP.text) NOT ONLINE!"
                                                }
                                            }
                                            else
                                            {
                                                $MainForm.Text = "Invalid IP Address!"
                                            }
                                        }
                                        else
                                        {
                                            $MainForm.Text = "Invalid IP Address!"
                                        }
                                    }
                                    else
                                    {
                                        write-host "$($tbx_PC_Name.text) was found online"
                                        Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                                        $MainForm.Text = "$thisbuttonname Script Started!"
                                    }
                                }
                            }

                            
		                })
                        if($($buttons_functionbuttoncount2) -gt 1)
                        {
                            [string]$thisbuttonname2 = (Split-Path $($lstScriptsinFolder[$loop2]) -Leaf)
                        }
                        else
                        {
                            [string]$thisbuttonname2 = (Split-Path $lstScriptsinFolder -Leaf)
                        }
                        $thisbuttonname2 = $thisbuttonname2 -replace ".ps1"
                        $thisbutton2.Text = $thisbuttonname2
                        $panelRight.controls.add($thisbutton2)
                    }
	                $loop2 += 1
	            } # End While Loop2
                $PCListFile = $($Sender.tag.script2)
                if($PCListFile)
                {
                    # PC_List.txt file found
                    $thisbutton3 = New-Object System.Windows.Forms.Button
                    $thisbutton3.Size = '77, 45' 
                    $thisbutton3.ForeColor = $Runcolor
                    $thisbutton3.tag=@{Script=$PCListFile}
                    $thisbutton3.UseVisualStyleBackColor = $True
                    $thisbutton3.TabIndex = $2ndTabIndex
                    $2ndTabIndex = $2ndTabIndex - 1
	                $thisbutton3.Dock = [System.Windows.Forms.DockStyle]::Top
            
	                $thisbutton3.Add_Click({param($Sender)
                        #call script
                        [string]$thisbuttonname3 = Split-Path $($Sender.Tag.script) -Leaf
                        $MainForm.Text = "Waiting for PC List to be closed..."
                        start-process notepad -ArgumentList "$($sender.tag.script)" -wait
                        $MainForm.Text = "$thisbuttonname3 Done!"
		            })
                    [string]$thisbuttonname3 = "Edit PC List..."
                    $thisbutton3.Text = $thisbuttonname3
                    $panelright.controls.add($thisbutton3)
                }
                else
                {
                    #No PC_list.txt file found
                }
                if($Script:InitialUserStarted = "bwienk1")
                {
                    #DEBUG FOR CREATOR
                    $panelRight.Controls.Add($ButtonShowConsole)
                }
                $panelRight.Controls.Add($ButtonChangeEUCFolder)
                $panelRight.Controls.add($ButtonReturnToEUC)
	            $panelRight.Controls.Add($ButtonShowMain)
                #$panelRight.Controls.Add($ButtonExit)
	            #$MainForm.Refresh()
                $panelright.resumeLayout() 
                $splitcontainer.resumeLayout()
                $mainform.resumeLayout()
                $MainForm.Text = "Loading $thisbuttonname Scripts Done!"
		    })
        [string]$thisbuttonname = Split-Path $buttons_functionslist[$loop] -Leaf
        $thisbutton.Text = $thisbuttonname
        $panelright.controls.add($thisbutton)

            } #END OF FOLDERNAME = PCUPDATER
            elseif($foldername -eq "Update AD And SN Records")
            {
                $ButtonADSN = New-Object System.Windows.Forms.Button
                    $ButtonADSN.Size = '77, 45'
                    #$ButtonADSN.ForeColor = $Runcolor
                    $ButtonADSN.tag=@{Script=$namesplit}
                    $ButtonADSN.UseVisualStyleBackColor = $True
                    $2ndTabIndex = 50
                    $ButtonADSN.TabIndex = $2ndTabIndex
                    $2ndTabIndex = $2ndTabIndex - 1
                    $ButtonADSN.Dock = [System.Windows.Forms.DockStyle]::Top               
                    $ButtonADSN.Add_Click({param($Sender)
                        #call script
                        $lstEUCScripts = Get-SubfoldersInLocation($Sender.Tag.script)
                        if($lstEUCScripts)
                        {

                            Set-EUCButtons($lstEUCScripts)

                        }
                        if($Script:InitialUserStarted = "bwienk1")
                        {
                            #DEBUG FOR CREATOR
                            $panelRight.Controls.Add($ButtonShowConsole)
                        }
                        $panelRight.Controls.Add($ButtonChangeEUCFolder)
                        $panelRight.Controls.add($ButtonReturnToEUC)
	                    $panelRight.Controls.Add($ButtonShowMain)
                        #$MainForm.Text = "Opened Modify AD And SN Records!"
                        })
                    $ButtonADSN.Text = "Update AD And SN Records"
                    $panelright.controls.add($ButtonADSN)
                         
                    
            }
            elseif($foldername -eq "Replace PC")
            {
                $ButtonADSN = New-Object System.Windows.Forms.Button
                $ButtonADSN.Size = '77, 45'
                #$ButtonADSN.ForeColor = $Runcolor
                $ButtonADSN.tag=@{Script=$namesplit}
                $ButtonADSN.UseVisualStyleBackColor = $True
                $2ndTabIndex = 50
                $ButtonADSN.TabIndex = $2ndTabIndex
                $2ndTabIndex = $2ndTabIndex - 1
                $ButtonADSN.Dock = [System.Windows.Forms.DockStyle]::Top               
                $ButtonADSN.Add_Click({param($Sender)
                    #call script
                    $lstEUCScripts = Get-SubfoldersInLocation($Sender.Tag.script)
                    if($lstEUCScripts)
                    {
                        Set-EUCButtons($lstEUCScripts)
                    }
                    if($Script:InitialUserStarted = "bwienk1")
                    {
                        #DEBUG FOR CREATOR
                        $panelRight.Controls.Add($ButtonShowConsole)
                    }
                    $panelRight.Controls.Add($ButtonChangeEUCFolder)
                    $panelRight.Controls.add($ButtonReturnToEUC)
	                $panelRight.Controls.Add($ButtonShowMain)
                    #$MainForm.Text = "Opened Modify AD And SN Records!"
                    })
                $ButtonADSN.Text = "$foldername"
                $panelright.controls.add($ButtonADSN)                
            }
            elseif($foldername -eq "Program Installs")
            {
                $ButtonADSN = New-Object System.Windows.Forms.Button
                $ButtonADSN.Size = '77, 45'
                #$ButtonADSN.ForeColor = $Runcolor
                $ButtonADSN.tag=@{Script=$namesplit}
                $ButtonADSN.UseVisualStyleBackColor = $True
                $2ndTabIndex = 50
                $ButtonADSN.TabIndex = $2ndTabIndex
                $2ndTabIndex = $2ndTabIndex - 1
                $ButtonADSN.Dock = [System.Windows.Forms.DockStyle]::Top               
                $ButtonADSN.Add_Click({param($Sender)
                    #call script
                    $lstEUCScripts = Get-SubfoldersInLocation($Sender.Tag.script)
                    if($lstEUCScripts)
                    {

                        Set-EUCButtons($lstEUCScripts)

                    }
                    if($Script:InitialUserStarted = "bwienk1")
                    {
                        #DEBUG FOR CREATOR
                        $panelRight.Controls.Add($ButtonShowConsole)
                    }
                    $panelRight.Controls.Add($ButtonChangeEUCFolder)
                    $panelRight.Controls.add($ButtonReturnToEUC)
	                $panelRight.Controls.Add($ButtonShowMain)
                    #$MainForm.Text = "Opened Modify AD And SN Records!"
                    })
                $ButtonADSN.Text = "$foldername"
                $panelright.controls.add($ButtonADSN)                
            }
            elseif($foldername -eq "Get Other Info")
            {
                $ButtonADSN = New-Object System.Windows.Forms.Button
                $ButtonADSN.Size = '77, 45'
                #$ButtonADSN.ForeColor = $Runcolor
                $ButtonADSN.tag=@{Script=$namesplit}
                $ButtonADSN.UseVisualStyleBackColor = $True
                $2ndTabIndex = 50
                $ButtonADSN.TabIndex = $2ndTabIndex
                $2ndTabIndex = $2ndTabIndex - 1
                $ButtonADSN.Dock = [System.Windows.Forms.DockStyle]::Top               
                $ButtonADSN.Add_Click({param($Sender)
                    #call script
                    $lstEUCScripts = Get-SubfoldersInLocation($Sender.Tag.script)
                    if($lstEUCScripts)
                    {

                        Set-EUCButtons($lstEUCScripts)

                    }
                    if($Script:InitialUserStarted = "bwienk1")
                    {
                        #DEBUG FOR CREATOR
                        $panelRight.Controls.Add($ButtonShowConsole)
                    }
                    $panelRight.Controls.Add($ButtonChangeEUCFolder)
                    $panelRight.Controls.add($ButtonReturnToEUC)
	                $panelRight.Controls.Add($ButtonShowMain)
                    #$MainForm.Text = "Opened Modify AD And SN Records!"
                    })
                $ButtonADSN.Text = "$foldername"
                $panelright.controls.add($ButtonADSN)                
            }
            elseif($foldername -eq "Fixes")
            {
                $ButtonADSN = New-Object System.Windows.Forms.Button
                $ButtonADSN.Size = '77, 45'
                $ButtonADSN.tag=@{Script=$namesplit}
                $ButtonADSN.UseVisualStyleBackColor = $True
                $2ndTabIndex = 50
                $ButtonADSN.TabIndex = $2ndTabIndex
                $2ndTabIndex = $2ndTabIndex - 1
                $ButtonADSN.Dock = [System.Windows.Forms.DockStyle]::Top               
                $ButtonADSN.Add_Click({param($Sender)
                    #call script
                    $lstEUCScripts = Get-SubfoldersInLocation($Sender.Tag.script)
                    if($lstEUCScripts)
                    {
                        Set-EUCButtons($lstEUCScripts)

                    }
                    if($Script:InitialUserStarted = "bwienk1")
                    {
                        #DEBUG FOR CREATOR
                        $panelRight.Controls.Add($ButtonShowConsole)
                    }
                    $panelRight.Controls.Add($ButtonChangeEUCFolder)
                    $panelRight.Controls.add($ButtonReturnToEUC)
	                $panelRight.Controls.Add($ButtonShowMain)
                    #$MainForm.Text = "Opened Modify AD And SN Records!"
                    })
                $ButtonADSN.Text = "$foldername"
                $panelright.controls.add($ButtonADSN)                
            }
            else
            {
	            $thisbutton = New-Object System.Windows.Forms.Button
                $thisbutton.Size = '77, 45' 
                [string]$calling = $buttons_functionslist[$loop]
                $PCListFile = Get-PCListInLocation-NoRecurse($calling)
                $thisbutton.tag=@{Script=$calling;Script2 = $PCListFile}
                $thisbutton.UseVisualStyleBackColor = $True
                $thisbutton.ForeColor = $Runcolor
                $thisbutton.TabIndex = $tabindex
                $tabindex = $tabindex - 1
	            $thisbutton.Dock = [System.Windows.Forms.DockStyle]::Top 
	            $thisbutton.Add_Click({param($Sender)
                #call script
                $panelRight.Controls.Clear()
                $mainform.suspendLayout()
                $splitcontainer.suspendLayout()
                $panelright.suspendLayout()
                
                if($sender.tag.script2)
                {
                    #PC_List.txt File found
                }
                else
                {
                    #PC_List.txt file not found
                }
                [string]$thisbuttonname = Split-Path $($Sender.Tag.script) -Leaf
                $MainForm.Text = "Loading $thisbuttonname Scripts..."            
                $lstScriptsinFolder = Get-FixesInLocation($($Sender.Tag.script))
                $buttons_functionbuttoncount2 = $lstScriptsinFolder.count
                        
                $loop2 = 0
                while($loop2 -lt $buttons_functionbuttoncount2)
	            {
                    $2ndTabIndex = 50
	                $thisbutton2 = New-Object System.Windows.Forms.Button
                    $thisbutton2.Size = '77, 45' 
                    if($buttons_functionbuttoncount2 -gt 1)
                    {
                        [string]$calling = $($lstScriptsinFolder[$loop2])
                    }
                    else
                    {
                        [string]$calling = $lstScriptsinFolder
                    }
                    if($PCListFile)
                    {
                        #pc_list.txt found
                        $PClistFound = $true
                    }
                    else
                    {
                        #pc_list.txt not found
                        $PClistFound = $false
                    }
                    $namecheck = (Split-Path $($calling) -Leaf)
                    if ($namecheck -like "Run*")
                    {
                        $RunColor = 'DarkBlue'
                    }
                    else
                    {
                        $RunColor = 'Black'
                    }
                        #EXCEPTION BUTTONS THAT NEED CUSTOM CODE
                    if ($namecheck -eq "Run Retire VDI.ps1")
                    {
                        #Retire VDI Button exception
                        if ($($tbx_PC_Name.text) -like "WIVGP*")
                        {
                            #VDI is selected
                            $name = $namecheck
                            $ButtonRetireVDI = New-Object System.Windows.Forms.Button
                            $ButtonRetireVDI.Size = '77, 45'
                            $ButtonRetireVDI.ForeColor = $RunColor
                            $ButtonRetireVDI.tag=@{Script=$calling}
                            $ButtonRetireVDI.UseVisualStyleBackColor = $True
                            $ButtonRetireVDI.TabIndex = $2ndTabIndex
                            $2ndTabIndex = $2ndTabIndex - 1
                            $ButtonRetireVDI.Dock = [System.Windows.Forms.DockStyle]::Top               
                            $ButtonRetireVDI.Add_Click({param($Sender)
                                #call script
                                [string]$ButtonRetireVDIName = Split-Path $($Sender.Tag.script) -Leaf
                                $MainForm.Text = "Running $ButtonRetireVDIName..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                                $MainForm.Text = "Started Retire VDI Script!"
		                    })
                            $ButtonRetireVDI.Text = "Run Retire This VDI"
                            $panelright.controls.add($ButtonRetireVDI)

                            $ButtonRetireVDI2 = New-Object System.Windows.Forms.Button
                            $ButtonRetireVDI2.Size = '77, 45'
                            $ButtonRetireVDI2.ForeColor = $RunColor
                            $ButtonRetireVDI2.tag=@{Script=$calling}
                            $ButtonRetireVDI2.UseVisualStyleBackColor = $True
                            $ButtonRetireVDI2.TabIndex = $2ndTabIndex
                            $2ndTabIndex = $2ndTabIndex - 1
                            $ButtonRetireVDI2.Dock = [System.Windows.Forms.DockStyle]::Top                      
                            $ButtonRetireVDI2.Add_Click({param($Sender)
                                #call script
                                [string]$ButtonRetireVDIName2 = Split-Path $($Sender.Tag.script) -Leaf
                                $MainForm.Text = "Running $ButtonRetireVDIName2..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                                $MainForm.Text = "Started Retire VDI Script!"
		                    })
                            $ButtonRetireVDI2.Text = "Run Retire Different VDI"
                            $panelright.controls.add($ButtonRetireVDI2)
                        }
                        else
                        {
                            #No VDI is selected
                            $ButtonRetireVDI = New-Object System.Windows.Forms.Button
                            $ButtonRetireVDI.Size = '77, 45'
                            $ButtonRetireVDI.ForeColor = $RunColor
                            $ButtonRetireVDI.tag=@{Script=$calling}
                            $ButtonRetireVDI.UseVisualStyleBackColor = $True
                            $ButtonRetireVDI.TabIndex = $2ndTabIndex
                            $2ndTabIndex = $2ndTabIndex - 1
                            $ButtonRetireVDI.Dock = [System.Windows.Forms.DockStyle]::Top                      
                            $ButtonRetireVDI.Add_Click({param($Sender)
                                #call script
                                [string]$ButtonRetireVDIName = Split-Path $($Sender.Tag.script) -Leaf
                                $MainForm.Text = "Running $ButtonRetireVDIName..."
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                                $MainForm.Text = "Started Retire A VDI Script!"
		                    })
                            $ButtonRetireVDI.Text = "Run Retire A VDI" 
                        }
                        $panelright.controls.add($ButtonRetireVDI) 
                    }
                    elseif($namecheck -eq "Run Swap PC.ps1")
                    {
                        #Swap PC is selected
                        $name = $namecheck
                        $ButtonSwapPC = New-Object System.Windows.Forms.Button
                        $ButtonSwapPC.Size = '77, 45'
                        $ButtonSwapPC.ForeColor = $RunColor
                        $ButtonSwapPC.tag=@{Script=$calling}
                        $ButtonSwapPC.UseVisualStyleBackColor = $True
                        $ButtonSwapPC.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonSwapPC.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonSwapPC.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonSwapPCName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonSwapPCName..."
                            $unformatedUsername = $null
                            $unformatedUsername = $($tbx_User_AD_Name.text)
                            $formatedUsername = $unformatedUsername.replace("`'","`'`'")
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserFullname '$formatedUsername' -UserEmail '$($tbx_User_AD_Email.text)' -OldComputerFullname '$($tbx_PC_Name.text)'")
                            $MainForm.Text = "Started Run Swap PC Script!"
                            })
                        $ButtonSwapPC.Text = $name
                        $panelright.controls.add($ButtonSwapPC) 
                    }
                    elseif($namecheck -eq "Run Assign Meraki.ps1")
                    {
                        #Assign Meraki is selected
                        $name = $namecheck
                        $ButtonAssignMeraki = New-Object System.Windows.Forms.Button
                        $ButtonAssignMeraki.Size = '77, 45'
                        $ButtonAssignMeraki.ForeColor = $RunColor
                        $ButtonAssignMeraki.tag=@{Script=$calling}
                        $ButtonAssignMeraki.UseVisualStyleBackColor = $True
                        $ButtonAssignMeraki.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonAssignMeraki.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonAssignMeraki.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonAssingMerakiName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonAssingMerakiName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserEmail '$($tbx_User_AD_Email.text)'")
                            $MainForm.Text = "Started Run Assign Meraki Script!"
                            })
                        $ButtonAssignMeraki.Text = $name
                        $panelright.controls.add($ButtonAssignMeraki) 
                    }
                    elseif($namecheck -eq "Run Return Meraki To Stock and Make SD Ticket.ps1")
                    {
                        #Return Meraki To Stock is selected
                        $name = $namecheck
                        $ButtonReturnMeraki = New-Object System.Windows.Forms.Button
                        $ButtonReturnMeraki.Size = '77, 45'
                        $ButtonReturnMeraki.ForeColor = $RunColor
                        $ButtonReturnMeraki.tag=@{Script=$calling}
                        $ButtonReturnMeraki.UseVisualStyleBackColor = $True
                        $ButtonReturnMeraki.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonReturnMeraki.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonReturnMeraki.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonReturnMerakiName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonReturnMerakiName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                            $MainForm.Text = "Started Return Meraki To Stock w/SD Ticket Script!"
                            })
                        $ButtonReturnMeraki.Text = $name
                        $panelright.controls.add($ButtonReturnMeraki) 
                    }
                    elseif($namecheck -eq "Run Return Meraki To Stock.ps1")
                    {
                        #Return Meraki To Stock is selected
                        $name = $namecheck
                        $ButtonReturnMeraki = New-Object System.Windows.Forms.Button
                        $ButtonReturnMeraki.Size = '77, 45'
                        $ButtonReturnMeraki.ForeColor = $RunColor
                        $ButtonReturnMeraki.tag=@{Script=$calling}
                        $ButtonReturnMeraki.UseVisualStyleBackColor = $True
                        $ButtonReturnMeraki.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonReturnMeraki.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonReturnMeraki.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonReturnMerakiName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonReturnMerakiName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                            $MainForm.Text = "Started Return Meraki To Stock Script!"
                            })
                        $ButtonReturnMeraki.Text = $name
                        $panelright.controls.add($ButtonReturnMeraki) 
                    }
                    elseif($namecheck -eq "RebootGui.ps1")
                    {
                        #Don't A
                    }
                    elseif($namecheck -eq "Run Transfer Files From Old to New PC.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonTransferPC = New-Object System.Windows.Forms.Button
                        $ButtonTransferPC.Size = '77, 45'
                        $ButtonTransferPC.ForeColor = $RunColor
                        $ButtonTransferPC.tag=@{Script=$calling}
                        $ButtonTransferPC.UseVisualStyleBackColor = $True
                        $ButtonTransferPC.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonTransferPC.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonTransferPC.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonTransferPCName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonTransferPCName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computername '$($tbx_PC_Name.text)' -Userfullname '$($tbx_User_AD_Name.text)'")
                            $MainForm.Text = "Started Transfer Files From Old to New PC Script!"
                            })
                        $ButtonTransferPC.Text = $name
                        $panelright.controls.add($ButtonTransferPC) 
                    }
                    elseif($namecheck -eq "Run Get IP Address From Meraki.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonCheckMerakiIP = New-Object System.Windows.Forms.Button
                        $ButtonCheckMerakiIP.ForeColor = $RunColor
                        $ButtonCheckMerakiIP.Size = '77, 45'
                        $ButtonCheckMerakiIP.tag=@{Script=$calling}
                        $ButtonCheckMerakiIP.UseVisualStyleBackColor = $True
                        $ButtonCheckMerakiIP.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonCheckMerakiIP.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonCheckMerakiIP.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonCheckMerakiIPName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonCheckMerakiIPName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computer '$($tbx_PC_Name.text)' -userID '$($tbx_User_AD_ID.text)'")
                            $MainForm.Text = "Started Transfer Files From Old to New PC Script!"
                            })
                        $ButtonCheckMerakiIP.Text = $name
                        $panelright.controls.add($ButtonCheckMerakiIP) 
                    }
                    elseif($namecheck -eq "Run Assign Empty VDI.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonAssignemptyVDI = New-Object System.Windows.Forms.Button
                        $ButtonAssignemptyVDI.Size = '77, 45'
                        $ButtonAssignemptyVDI.ForeColor = $RunColor
                        $ButtonAssignemptyVDI.tag=@{Script=$calling}
                        $ButtonAssignemptyVDI.UseVisualStyleBackColor = $True
                        $ButtonAssignemptyVDI.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonAssignemptyVDI.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonAssignemptyVDI.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonAssignemptyVDIName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonAssignemptyVDIName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computer '$($tbx_PC_Name.text)'")
                            $MainForm.Text = "Started Assign Empty VDI Script!"
                            })
                        $ButtonAssignemptyVDI.Text = $name
                        $panelright.controls.add($ButtonAssignemptyVDI) 
                    }
                    elseif($namecheck -eq "Run Seperate PCs.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonSeperate = New-Object System.Windows.Forms.Button
                        $ButtonSeperate.Size = '77, 45'
                        $ButtonSeperate.ForeColor = $RunColor
                        $ButtonSeperate.tag=@{Script=$calling}
                        $ButtonSeperate.UseVisualStyleBackColor = $True
                        $ButtonSeperate.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonSeperate.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonSeperate.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonSeperateName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonSeperateName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computer '$($tbx_PC_Name.text)'")
                            $MainForm.Text = "Started Seperate PCs Script!"
                            })
                        $ButtonSeperate.Text = $name
                        $panelright.controls.add($ButtonSeperate) 
                    }
                    elseif($namecheck -eq "Run Show PC Memberships.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonMemberships = New-Object System.Windows.Forms.Button
                        $ButtonMemberships.Size = '77, 45'
                        $ButtonMemberships.ForeColor = $RunColor
                        $ButtonMemberships.tag=@{Script=$calling}
                        $ButtonMemberships.UseVisualStyleBackColor = $True
                        $ButtonMemberships.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonMemberships.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonMemberships.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonMembershipsName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonMembershipsName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -Computer '$($tbx_PC_Name.text)'")
                            $MainForm.Text = "Started $ButtonMembershipsName Script!"
                            })
                        $ButtonMemberships.Text = $name
                        $panelright.controls.add($ButtonMemberships) 
                    }
                    elseif($namecheck -eq "Run Show User Memberships.ps1")
                    {
                        #Swap PC is selected 
                        $name = $namecheck
                        $ButtonMemberships = New-Object System.Windows.Forms.Button
                        $ButtonMemberships.Size = '77, 45'
                        $ButtonMemberships.ForeColor = $RunColor
                        $ButtonMemberships.tag=@{Script=$calling}
                        $ButtonMemberships.UseVisualStyleBackColor = $True
                        $ButtonMemberships.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
                        $ButtonMemberships.Dock = [System.Windows.Forms.DockStyle]::Top               
                        $ButtonMemberships.Add_Click({param($Sender)
                            #call script
                            [string]$ButtonMembershipsName = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $ButtonMembershipsName..."
                            Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserID '$($tbx_User_AD_ID.text)'")
                            $MainForm.Text = "Started $ButtonMembershipsName Script!"
                            })
                        $ButtonMemberships.Text = $name
                        $panelright.controls.add($ButtonMemberships) 
                    }
                    else
                    {
                        #STANDARD BUTTONS 
                        #    - checks if PC_list.txt for the script and calls the script with no arguments if found
                        #    - If pc_list.txt is not found calls script with -computer argument equal to the PC Name textbox text
             
                        $thisbutton2.tag=@{Script=$calling;PCListExists = $PClistFound}
                        $thisbutton2.UseVisualStyleBackColor = $True
                        $thisbutton2.ForeColor = $RunColor
                        $thisbutton2.TabIndex = $2ndTabIndex
                        $2ndTabIndex = $2ndTabIndex - 1
	                    $thisbutton2.Dock = [System.Windows.Forms.DockStyle]::Top
	                    $thisbutton2.Add_Click({param($Sender)
                            #call script
                            [string]$thisbuttonname2 = Split-Path $($Sender.Tag.script) -Leaf
                            $MainForm.Text = "Running $thisbuttonname2..."
                            if($Sender.Tag.PCListExists  -or $thisbuttonname2 -eq "Run Get-Emails.ps1" -or $thisbuttonname2 -eq "Run Retire PCs.ps1" -or $thisbuttonname2 -eq "Run Retire PCs And Close Ticket.ps1" -or $thisbuttonname2 -eq "Show Queue.ps1" -or $thisbuttonname2 -eq "Run Return Meraki To Stock.ps1" -or $thisbuttonname2 -eq "Run Return Meraki To Stock and Make SD Ticket.ps1")
                            {
                                #write-debug "Button Triggered with no Computer argument passed (pc list should be used)"
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`'")
                                $MainForm.Text = "$thisbuttonname2 Script Started!"            
                            }
                            elseif($thisbuttonname2 -eq "Run Assign Meraki.ps1")
                            {
                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -UserEmail '$($tbx_User_AD_Email.text)'")
                                $MainForm.Text = "$thisbuttonname2 Script Started!" 
                            }
                            else
                            {
                                if($($tbx_PC_Name.text))
                                {
                                    if(test-connection "$($tbx_PC_Name.text)" -Count 1 -Quiet -ErrorAction SilentlyContinue)
                                    {
                                        # write-host "sender tag = $($Sender.Tag.script)"
                                        #write-debug "Button Triggered with Computer argument passed (pc list shouldn't be used)"
                                        Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$($tbx_PC_Name.text)'")
                                        $MainForm.Text = "$thisbuttonname2 Script Started!"
                                    }
                                    else
                                    {
                                        if($($tbx_PC_IP.text))
                                        {
                                            $IP_Address = ExtractValidIPAddress($($tbx_PC_IP.text))
                                            if($IP_Address)
                                            {
                                                if(test-connection "$IP_Address" -Count 1 -Quiet -ErrorAction SilentlyContinue)
                                                {
                                                    Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$IP_Address'")
                                                    $MainForm.Text = "$thisbuttonname2 Script Started!"
                                                }
                                                else
                                                {
                                                    $MainForm.Text = "$IP_Address is Offline!"
                                                }
                                            }
                                            else
                                            {
                                                $MainForm.Text = "IP Address is Invalid!"
                                            }
                                        }
                                        else
                                        {
                                             $MainForm.Text = "IP Address is Invalid!"
                                        }
                                    }
                                }
                                else
                                {
                                    if($($tbx_PC_IP.text))
                                    {
                                        $IP_Address = ExtractValidIPAddress($($tbx_PC_IP.text))
                                        if($IP_Address)
                                        {
                                            if(test-connection "$IP_Address" -Count 1 -Quiet -ErrorAction SilentlyContinue)
                                            {
                                                Start-Process Powershell -ArgumentList ("& `'$($Sender.Tag.script)`' -computer '$IP_Address'")
                                                $MainForm.Text = "$thisbuttonname2 Script Started!"
                                            }
                                            else
                                            {
                                                $MainForm.Text = "$IP_Address is Offline!"
                                            }
                                        }
                                        else
                                        {
                                            $MainForm.Text = "IP Address is Invalid!"
                                        }
                                    }
                                    else
                                    {
                                            $MainForm.Text = "IP Address is Invalid!"
                                    }
                                }
                            }   
		                })
                        if($($buttons_functionbuttoncount2) -gt 1)
                        {
                            [string]$thisbuttonname2 = (Split-Path $($lstScriptsinFolder[$loop2]) -Leaf)
                        }
                        else
                        {
                            [string]$thisbuttonname2 = (Split-Path $lstScriptsinFolder -Leaf)
                        }
                        $thisbuttonname2 = $thisbuttonname2 -replace ".ps1"
                        $thisbutton2.Text = $thisbuttonname2
                        $panelRight.controls.add($thisbutton2)
                    }

                
                
	                $loop2 += 1
	            } # End While Loop2
                $PCListFile = $($Sender.tag.script2)
                if($PCListFile)
                {
                    # PC_List.txt file found
                    $thisbutton3 = New-Object System.Windows.Forms.Button
                    $thisbutton3.Size = '77, 45' 
                    $thisbutton3.tag=@{Script=$PCListFile}
                    $thisbutton3.ForeColor = $RunColor
                    $thisbutton3.UseVisualStyleBackColor = $True
                    $thisbutton3.TabIndex = $2ndTabIndex
                    $2ndTabIndex = $2ndTabIndex - 1
	                $thisbutton3.Dock = [System.Windows.Forms.DockStyle]::Top
            
	                $thisbutton3.Add_Click({param($Sender)
                        #call script
                        [string]$thisbuttonname3 = Split-Path $($Sender.Tag.script) -Leaf
                        $MainForm.Text = "Waiting for PC List to be closed..."
                        start-process notepad -ArgumentList "$($sender.tag.script)" -wait
                        $MainForm.Text = "$thisbuttonname3 Done!"
		            })
                    [string]$thisbuttonname3 = "Edit PC List..."
                    $thisbutton3.Text = $thisbuttonname3
                    $panelright.controls.add($thisbutton3)
                }
                else
                {
                    #No PC_list.txt file found
                }
            if($Script:InitialUserStarted = "bwienk1")
            {
                #DEBUG FOR CREATOR
                $panelRight.Controls.Add($ButtonShowConsole)
            }
            $panelRight.Controls.Add($ButtonChangeEUCFolder)
            $panelRight.Controls.add($ButtonReturnToEUC)
	        $panelRight.Controls.Add($ButtonShowMain)
            #$panelRight.Controls.Add($ButtonExit)
	        #$MainForm.Refresh()
            $panelright.resumeLayout()
            $splitcontainer.resumeLayout()
            $mainform.resumeLayout()
            $MainForm.Text = "Loading $thisbuttonname Scripts Done!"
		})
        [string]$thisbuttonname = Split-Path $buttons_functionslist[$loop] -Leaf
        $thisbutton.Text = $thisbuttonname
        $panelright.controls.add($thisbutton)
        }
        }
	    $loop += 1
	} # End While Loop
$panelright.resumeLayout()
$splitcontainer.resumeLayout()
$mainform.resumeLayout()
}

Function Set-EUCLocation($Location_Fixes)
{
    if($Location_Fixes)
    {
        $i= 0
        if(Test-Path "$Location_Fixes")
        {
            $content = $null
            $scriptname = Split-Path "$($MyInvocation.PSCommandPath)" -leaf
            $content = (get-content "$($MyInvocation.PSCommandPath)")
            if ($content -ne $null -and $content -ne "")
            {
                $content2 = ($content | Where-Object {$_ -like '$Script:InitialEUCLocation = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})

                if($content2.count -gt 1)
                {
                    #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                }
                else
                {
                    $content[$index] = "`$Script:InitialEUCLocation = `'$Location_Fixes`'"
                    $content |Set-Content "$($MyInvocation.PSCommandPath)"
                }
            }
            $Script:EUCLocation = $Location_Fixes
        }
        else
        {
            ##write-debug "location fixes is not valid path"
        }
    }
    else
    {
        ##write-debug "location fixes is null"
    }
}

Function Set-FixesLocation($Location_Fixes)
{
    if($Location_Fixes)
    {
        $i= 0
        if(Test-Path "$Location_Fixes")
        {
            $content = $null
            $scriptname = Split-Path "$($MyInvocation.PSCommandPath)" -leaf
            $content = (get-content "$($MyInvocation.PSCommandPath)")
            if ($content -ne $null -and $content -ne "")
            {
                $content2 = ($content | Where-Object {$_ -like '$Script:InitialFixesLocation = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})

                if($content2.count -gt 1)
                {
                    #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
                }
                else
                {
                    $content[$index] = "`$Script:InitialFixesLocation = `'$Location_Fixes`'"
                    $content |Set-Content "$($MyInvocation.PSCommandPath)"
                }
            }
            $Script:FixesLocation = $Location_Fixes
        }
        else
        {
            ##write-debug "location fixes is not valid path"
        }
    }
    else
    {
        ##write-debug "location fixes is null"
    }
}

function Set-HDriveLocation
{
    if($Script:HDriveLocation)
    {
        $MainForm.Text = "Finding H:\ Drive location var in Script..."
        $i= 0
        $content = $null
        $scriptname = Split-Path "$($MyInvocation.PSCommandPath)" -leaf
        $content = (get-content "$($MyInvocation.PSCommandPath)")
        if ($content -ne $null -and $content -ne "")
        {
            $content2 = ($content | Where-Object {$_ -like '$Script:HDriveLocation = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})

            if($content2.count -gt 1)
            {
                #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
            }
            else
            {
                $MainForm.Text = "Setting H:\ Drive location var in Script..."
                
                $content[$index] = "`$Script:HDriveLocation = `'$Script:HDriveLocation`'"
                $content |Set-Content "$($MyInvocation.PSCommandPath)"
            }
        }
    }
    $MainForm.Text = "H Drive Set"
}

Function Set-CredentialsLoaded
{
    if($Script:HDriveLocation)
    {   
    #***************************************************************
    #-------------------------Credentials--------------------------*
    #***************************************************************
        $failedcreds = $false
        if($MainForm)
        {
            $MainForm.Text = "Creating Secure Key..."
        }
        [Byte[]]$key = gc C:\Temp\CKey.key
        #$MainForm.Text = "Testing Admin User file..."
        if(test-path 'C:\Temp\A_User.txt')
        {
            if($MainForm)
            {
                $MainForm.Text = "Retrieving Admin User file..."
            }
            $Admin_User = gc 'C:\Temp\A_User.txt'
            if($MainForm)
            {
                $MainForm.Text = "Trimming Admin User file..."
            }
            $Admin_User = $Admin_User.trim()
            if($MainForm)
            {
                $MainForm.Text = "Formatting Admin User file..."
            }
            $Admin_User1 = "AFII\$($Admin_User)"
            if($MainForm)
            {
                $MainForm.Text = "Testing for Admin Secure String..."
            }
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                if($MainForm)
                {
                    $MainForm.Text = "Setting Admin Credentials..."
                }
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
            
        }
        else
        {
            $failedcreds = $True
        }
        if($MainForm)
        {
            $MainForm.Text = "Testing User file..."
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            if($MainForm)
            {
                $MainForm.Text = "Retrieving User file..."
            }
            $NonAdmin_User1 = gc 'C:\Temp\NA_User.txt'
            if($MainForm)
            {
                $MainForm.Text = "Trimming User file..."
            }
            $NonAdmin_User1 = $NonAdmin_User1.trim()
            if($MainForm)
            {
                $MainForm.Text = "Formatting User file..."
            }
            $NonAdmin_User1 = "AFII\$($NonAdmin_User1)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {
                if($MainForm)
                {
                    $MainForm.Text = "Setting User Credentials..."
                }
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            if($MainForm)
            {
                $MainForm.Text = "Setting Credentials to loaded..."
            }
            $Script:CredentialsLoaded = $true

            if($MainForm)
            {
                $MainForm.Text = "Credentials Loaded!"
            }
        }
    }
    else
    {
        ##write-debug "H Drive null"
        if($MainForm)
        {
            $MainForm.Text = "Credentials failed to Load!"
        }
    }
}

function Get-SubfoldersInLocation($Location)
{
    #$MainForm.Text = "Retrieving Scripts in Folder..."
    $FoldersFullname = @()
    $folders = Get-ChildItem -Path $Location -Directory

    
    foreach ($folder in $folders)
    {
        #$MainForm.Text = "Adding ($file.fullname)..."
        if ("$($folder.Fullname)" -eq "Python")
        {

        }
        elseif("$($folder.Fullname)" -eq "Logs")
        {

        }
        else
        {
            $FoldersFullname += "$($folder.Fullname)"
        }
    }
    
    #$MainForm.Text = "Adding Fixes Complete!"
    return $FoldersFullname
}

function Get-FixesInLocation-NoRecure($Location)
{
    $MainForm.Text = "Retrieving Scripts in Folder..."
    $FixesFullname = @()
    $files = (Get-ChildItem -Path $Location |Where-Object {($_ -like "*.ps1")})
    foreach ($file in $files)
    {
        $MainForm.Text = "Adding $($file.fullname)..."
        $FixesFullname += "$($file.Fullname)"
    }
    $MainForm.Text = "Adding Fixes Complete!"
    return $FixesFullname
}

function Get-FixesInLocation($Location)
{
    $MainForm.Text = "Retrieving Scripts in Folder and Subfolders..."
    $Fixes = @()
    $FixesFullName = @()
    $files = (Get-ChildItem -Path $Location -Recurse |Where-Object {($_ -like "*.ps1")})
    foreach ($file in $files)
    {
        $MainForm.Text = "Getting $($file.name)..."
        $Fixes += $file
    }
    $MainForm.Text = "Sorting Array of Files Alphabetically..."
    $Fixes = $Fixes |sort $_.name -Descending
    $MainForm.Text = "Adding Files..."
    foreach ($file in $Fixes)
    {
        $MainForm.Text = "Adding $($file.fullname)..."
        $FixesFullname += $file.FullName
    }
    $MainForm.Text = "Adding Scripts Complete!"
    return $FixesFullname
}

function Get-PCListInLocation-NoRecurse($Location)
{
    $MainForm.Text = "Looking if script is set for batch in Folder..."
    $PClistFullname = @()
    $files = (Get-ChildItem -Path $Location)
    foreach ($file in $files)
    {
        if($file.FullName -like "*pc_list.txt")
        {
        $MainForm.Text = "Found required PC List file $($file.fullname)..."
        $PClistFullname += "$($file.Fullname)"
        }
    }
    $MainForm.Text = "Loading Scripts Complete!"
    return $PClistFullname
}

Function Filter-PC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$PC = $null
	$ErrorMsg = $null
	$Return_Object = $null
    
	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	    $Computername = $Computername.trim()
	    $PC = $Computername
	    If ($PC -like "WILG000*")
	    {
	        #WI laptop Dell
	        $PC = $PC -replace "WILG000"
	    }
	    elseif ($PC -like "WILG00*")
	    {
	        #WI laptop Lenovo
	        $PC = $PC -replace "WILG00"
	    }
	    elseif ($PC -like "WIDG000*")
	    {
	        #WI Desktop Dell
	        $PC = $PC -replace "WIDG000"
	    }
	    elseif ($PC -like "WIDG00*")
	    {
	        #WI Desktop Lenovo?
	        $PC = $PC -replace "WIDG00"
	    }
	    elseif ($PC -like "AZLG000*")
	    {
	        #AZ laptop dell
	        $PC = $PC -replace "AZLG000"
	    }
	    elseif ($PC -like "AZLG00*")
	    {
	        #AZ laptop lenovo
	        $PC = $PC -replace "AZLG00"
	    }
	    elseif ($PC -like "AZDG000*")
	    {
	        #AZ Desktop dell
	        $PC = $PC -replace "AZDG000"
	    }
	    elseif ($PC -like "AZDG00*")
	    {
	        #AZ Desktop lenovo?
	        $PC = $PC -replace "AZDG00"
	    }
	    elseif ($PC -like "NVLG000*")
	    {
	        #LV laptop dell
	        $PC = $PC -replace "NVLG000"
	    }
	    elseif ($PC -like "NVLG00*")
	    {
	        #LV laptop lenovo
	        $PC = $PC -replace "NVLG00"
	    }
	    elseif ($PC -like "NVDG000*")
	    {
	        #LV Desktop dell
	        $PC = $PC -replace "NVDG000"
	    }
	    elseif ($PC -like "NVDG00*")
	    {
	        #LV Desktop lenovo?
	        $PC = $PC -replace "NVDG00"
	    }
	    elseif ($PC -like "WIVGP*")
	    {
	        #VDI's To be added
	    }
        elseif ($PC -like "WITG*")
	    {
	        #VDI's To be added
	    }
	    elseif ($PC -like "*.*.*.*")
    	{
        	#IP ADDRESS SLIPPED THROUGH!
	    }
	    else
	    {
	        #BAD ENTRY CODE HERE
	        $ErrorMsg = "Filter-PC - Not a valid input"
	    }
	}
	else
	{
	    #write-debug "[FAILURE] Filter-PC - Initial parameter input was null"
	    $ErrorMsg = "Filter-PC - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $PC;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Run-RDP
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ReturnValuefromoutput = $false
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	Start-Process "C:\Windows\system32\mstsc.exe" -ArgumentList "/v $Computername" -Credential $Script:credentials
	}
	else
	{
	#write-debug "[FAILURE] Run-RDP - Initial parameter input was null"
	$ErrorMsg = "Run-RDP - $Param_ErrorMsg"
	
	}
	$properties = @{'Output' = $ReturnValuefromoutput;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Run-MSRA
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
    if(!($Param_ErrorMsg))
    {
	If ($ComputerName -eq "")
	{
		#Start-Process -FilePath "C:\Windows\System32\msra.exe" -Argumentlist "/Offerra" -Credential $Script:credentials2
	}
	Else
	{

            Set-Clipboard -Value "msra /offerra $computername"
            Add-Type -AssemblyName System.Windows.Forms
            [System.Windows.Forms.SendKeys]::SendWait("^{Esc}")
            [System.Windows.Forms.SendKeys]::SendWait("^{v}")
            [System.Windows.Forms.SendKeys]::SendWait("{Enter}")
			#Start-Process -FilePath "C:\Windows\System32\msra.exe" -Argumentlist "/Offerra $ComputerName" -Credential $Script:credentials2

	}
	}
	else
	{
	#write-debug "[FAILURE] Run-MSRA - Initial parameter input was null"
	$ErrorMsg = "Run-MSRA - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $ReturnValuefromoutput;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Reboot-PC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------
	Add-Type -AssemblyName System.Windows.Forms
	Add-Type -AssemblyName System.Drawing
	Add-Type -AssemblyName PresentationFramework
	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ReturnValuefromoutput = $false
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $MainForm.Text = "Restarting $Computername..."
	    restart-computer $Computername -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
	    if ($timedout)
	    {
	        $Timeout = 1000
	        $filter = $null
	        $Filter = 'Address="{0}" and Timeout={1}' -f $Computername, $Timeout
	        if ((Get-WmiObject -Class Win32_PingStatus -Filter $Filter | Select-Object Address, ResponseTime, Timeout).ResponseTime -ne $null)
	        {
	            #Connection is good
	            $ErrorMsg = "$($Computername) restart timed out, but pc is still responsive"
	        }
	        else
	        {
	            $ErrorMsg = "$($Computername) restart timed out, please check pc"
	        }
	    }
	    else
	    {
	        $ReturnValuefromoutput = $true
	    }
	}
	else
	{
	    #write-debug "[FAILURE] Reboot-PC - Initial parameter input was null"
	    $ErrorMsg = "Reboot-PC - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $ReturnValuefromoutput;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	if($Errormsg)
	{
	    [System.Windows.MessageBox]::Show("Restart ERROR: $errormsg")
	}
	else
	{
	    #[System.Windows.MessageBox]::Show('Restart Finished')
	}
	$MainForm.Text = "Restarting Complete!"
	return $Return_Object
}

Function Test-IsOnline
{
	[CmdletBinding()]
	param(
	[Parameter(ValueFromPipeline = $True,ValueFromPipelineByPropertyName = $True)]
	[ValidateNotNullOrEmpty()]
	[Alias('Computers', 'CN')]

	[string[]] $ComputerName,

	[int] $Threads = $env:NUMBER_OF_PROCESSORS,
	[switch] $ShowProgress = $True,
	[switch] $ShowTime = $false,
	[int] $Timeout = 120,
	[int]$RetryCount = 1,
	[int]$RetryWaitTime = 10,
	[switch] $DNSLookup
	)

	Begin
	{

	Function Get-Result
	{
	[CmdletBinding()]
	Param(
	[switch] $Wait
	)
	Do
	{
	$More = $false
	foreach ($Runspace in $Runspaces) 
	{
	$StartTime = $RunspaceTimers[$Runspace.ID]
	if ($Runspace.Handle.IsCompleted)
	{
	$Runspace.PowerShell.EndInvoke($Runspace.Handle)
	$Runspace.PowerShell.Dispose()
	$Runspace.PowerShell = $Null
	$Runspace.Handle = $Null
	}
	elseif ($Runspace.Handle -ne $Null)
	{
	$More = $True
	}
	if ($Timeout -and $StartTime)
	{
	if ((New-TimeSpan -Start $StartTime).TotalSeconds -ge $Timeout -and $Runspace.PowerShell) 
	{
	Write-Warning -Message ('Timeout {0}' -f $Runspace.IObject)
	$Runspace.PowerShell.Dispose()
	$Runspace.PowerShell = $Null
	$Runspace.Handle = $Null
	}
	}
	}

	if ($More -and $PSBoundParameters['Wait'])
	{
	Start-Sleep -Milliseconds 100
	}

	foreach ($Thread in $Runspaces.Clone())
	{
	if (-not $Thread.Handle) 
	{
	Write-Verbose -Message ('Removing [{0}] from runspaces' -f $Thread.IObject)
	$Runspaces.Remove($Thread)
	}
	}

	if ($ShowProgress)
	{
	$ProgressSplatting = @{
	Activity        = 'Checking hosts'
	Status          = 'Processing: {0} of {1} total hosts' -f ($RunspaceCounter - $Runspaces.Count), $RunspaceCounter
	PercentComplete = ($RunspaceCounter - $Runspaces.Count) / $RunspaceCounter * 100
	}
	Write-Progress @ProgressSplatting
	}
	}
	while ($More -and $PSBoundParameters['Wait'])
	}


	if($ComputerName.Count -gt 1) {
	Write-Verbose -Message "Processing [$($ComputerName.Count)] hosts"
	}

	$CachedErrorActionPreference = 'Stop'
	$ErrorActionPreference = $CachedErrorActionPreference

	#$Script:VerbosePreference = 'Continue'

	$StartTime = Get-Date

	$RunspaceTimers = [HashTable]::Synchronized(@{})
	$Output = [HashTable]::Synchronized(@{})
	$Runspaces = New-Object -TypeName System.Collections.ArrayList
	$RunspaceCounter = 0

	Write-Verbose -Message 'Creating initial session state'

	$ISS = [initialsessionstate]::CreateDefault()
	$ISS.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'RunspaceTimers', $RunspaceTimers, ''))
	$ISS.Variables.Add((New-Object -TypeName System.Management.Automation.Runspaces.SessionStateVariableEntry -ArgumentList 'Output', $Output, ''))

	Write-Verbose -Message 'Creating runspace factory'

	$RunspacePool = [runspacefactory]::CreateRunspacePool(1, $Threads, $ISS, $Host)
	$RunspacePool.ApartmentState = 'STA'
	$RunspacePool.Open()


	$PsExecScriptBlock = {
	[CmdletBinding()]
	param(
	[int] $ID,
	[string] $ComputerName,
	[int]$RetryCount,
	[int]$RetryWaitTime,
	[switch] $DNSLookup
	)

	$RunspaceTimers.$ID = Get-Date
	if (-not $Output.ContainsKey($ComputerName))
	{
	$Output[$ComputerName] = New-Object -TypeName PSObject -Property @{
	ComputerName = $ComputerName
	}
	}
	if ($DNSLookup)
	{
	Write-Verbose -Message "[${ComputerName}] Performing DNS lookup."
	$ErrorActionPreference = 'SilentlyContinue'
	$HostEntry = [Net.Dns]::GetHostEntry($ComputerName)
	$Result = $?
	$ErrorActionPreference = $CachedErrorActionPreference

	if ($Result)
	{
	if ($HostEntry.HostName.Split('.')[0] -ieq $ComputerName.Split('.')[0])
	{
	$IPDns = @($HostEntry |
	Select-Object -ExpandProperty AddressList |
	Select-Object -ExpandProperty IPAddressToString)
	}
	else
	{
	$IPDns = @(@($HostEntry.HostName) + @($HostEntry.Aliases))
	}
	$Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name 'IP' -Value $IPDns
	}
	else
	{
	$Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name 'IP' -Value $Null
	}
	}

	Write-Verbose -Message "Pinging host [${ComputerName}]"

	$Online = $false

	1..$RetryCount | ForEach-Object -Process {
	$Param = @{
	ComputerName = $ComputerName
	BufferSize   = 1
	Count        = 1
	Quiet        = $True
	}

	$Online = Test-Connection @Param
	}
	    if($Online) 
            {
                $Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name Online -Value $True
            } else 
            {
                $Output[$ComputerName] | Add-Member -MemberType NoteProperty -Name Online -Value $false
            }
	}

	}
	process
	{
	foreach ($Computer in $ComputerName)
	{
	Write-Verbose -Message "Processing [${Computer}]"
	++$RunspaceCounter
	$psCMD = [powershell]::Create().AddScript($PsExecScriptBlock)
	[void] $psCMD.AddParameter('ID', $RunspaceCounter)
	[void] $psCMD.AddParameter('ComputerName', $Computer)
	[void] $psCMD.AddParameter('RetryCount', $RetryCount)
	[void] $psCMD.AddParameter('RetryWaitTime', $RetryWaitTime)
	[void] $psCMD.AddParameter('DNSLookup', $DNSLookup)
	[void] $psCMD.AddParameter('Verbose', $VerbosePreference)
	$psCMD.RunspacePool = $RunspacePool

	[void]$Runspaces.Add(@{
	Handle     = $psCMD.BeginInvoke()
	PowerShell = $psCMD
	IObject    = $Computer
	ID         = $RunspaceCounter
	})

	Get-Result
	}
	}

	End 
	{
	Get-Result -Wait
	if ($ShowProgress)
	{
	Write-Progress -Activity 'Checking if host is online' -Status 'Done' -Completed
	}
	Write-Verbose -Message 'Closing runspace pool.'
	$RunspacePool.Close()
	Write-Verbose -Message 'Disposing runspace pool.'
	$RunspacePool.Dispose()

	[hashtable[]] $Properties = @{
	Name       = 'ComputerName'
	Expression = {
	$_.Name
	}
	}
	if ($DNSLookup)
	{
	$Properties += @{
	Name       = 'IP'
	Expression = {
	$_.Value.'IP' 
	}
	}
	}
	$Properties += @{
	Name       = 'Online'
	Expression = {
	$_.Value.Online
	}
	}

	$Output.GetEnumerator() | Select-Object -Property $Properties | Sort-Object Online

	if ($ShowTime)
	{
	Write-Host -ForegroundColor Green ('Start time: ' + $StartTime)
	Write-Host -ForegroundColor Green ('End time:   ' + (Get-Date))
	}

	}
}

Function Get-PC-By_PCName($PC)
{
    $Filter_pc = $null
	if($PC -ne "" -and $PC -ne $null)
	{
	if (((Check-If-IP -computername $PC).output) -eq $false)
	{
	$Filter_pc = ((Filter-PC -computername $PC).output)
	$computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$Filter_pc'")
	if($computer -ne $null)
	{
	$lstPCs = @() 
	foreach ($entry in $computer)
	{
	$properties = @{'Selection'= $($computer.Indexof($entry) + 1);
	'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
	$object = New-Object �TypeName PSObject �Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	}
	if($($computer.Count) -gt 1)
	{
	$result = Show-SelectionForm($lstPCs)
	if ($result)
	{
    $result = $result - 1
	#Computer returned from selection
	$computer = $lstPCs[$result]
    $result = $null
	$Script:SelectForm_RowIndex = $null
	return $computer
	}
	else
	{
	#No Computer returned from selection
	return $null
	}

	}
	elseif ($($computer.Count) -eq 1)
	{
	$computer = $lstPCs[0]
	return $computer
	}
	}
	else
	{   
	#No Computer returned from AD
	return $null
	}
	}
	else
	{
    Setup-IP-Invoke($PC)
	#RETURN IP
	#	IP can get buggy
	$lstPCs = @() 
	#foreach ($entry in $PC)
	#{
	    $properties = @{'Selection'= 0;
	    'Name'= $PC;
        'Description'= "No Description for IP Address"}
	$object = New-Object �TypeName PSObject �Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	#}
	$computer = $lstPCs
	return $computer
	}
	}
	else
	{
	#Input was null or empty
	return $null
	}
}

Function Get-PC-By_UserFirstLastName($firstname, $lastname)
{
        $firstname = $firstname.replace("`'","*")
        $lastname = $lastname.replace("`'","*")
    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$firstname*$lastname'")
    $firstname = $firstname.replace("*","`'")
        $lastname = $lastname.replace("*","`'")
   if($($computer.Count) -gt 1)
        {
       
            Write-Host -ForegroundColor Yellow "`n Multiple PCs Found`n"
            
               $lstPCs = @() 
            foreach ($entry in $computer)
            {
                $properties = @{'Selection'= $($computer.Indexof($entry));
                                'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
                $object = New-Object �TypeName PSObject �Prop $properties
                $lstPCs += $object
                #write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
            }
      
    if($computer -ne $null)
    {
    $lstPCs = @() 
            foreach ($entry in $computer)
            {
                $properties = @{'Selection'= $($computer.Indexof($entry));
                                'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
                $object = New-Object �TypeName PSObject �Prop $properties
                $lstPCs += $object
                #write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
            }
    if($($computer.Count) -gt 1)
    {
    $lstPcs| Format-Table -Autosize `
        @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
        @{Name="Computer Name";Expression = { $_.Name }; Alignment="left" },
        @{Name="AD Description";Expression = { $_.Description }; Alignment="left" }|out-null
        $select = read-host "`n Enter a Selection"
        $computer = ($lstPCs|Where-Object -Property Selection -eq -Value $select |Select-Object *)
        return $computer
    }
    
    elseif ($($computer.Count) -eq 1)
    {
    return $lstPCs
    }
    }
    else
    {   
       $computer = Get-PC-By_Userlastname($lastname)
        return $computer
    }
        }
 }

Function Get-PC-By_UserLastName($lastname)
{
	$lastname = $lastname.replace("`'","*")
    $AD_computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$lastname*'")
	$lastname = $lastname.replace("*","`'")
	 Write-Host -ForegroundColor Yellow "`n Multiple PCs Found`n"
	$lstPCs = @() 
	foreach ($entry in $computer)
	{
	$properties = @{'Selection'= $($computer.Indexof($entry));
	'Name'=$($entry.Name);
	'Description'= $($entry.Description)}
	$object = New-Object �TypeName PSObject �Prop $properties
	$lstPCs += $object
	#write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
	}
      
    if($computer -ne $null)
    {
    $lstPCs = @() 
            foreach ($entry in $computer)
            {
                $properties = @{'Selection'= $($computer.Indexof($entry));
                                'Name'=$($entry.Name);
                                'Description'= $($entry.Description)}
                $object = New-Object �TypeName PSObject �Prop $properties
                $lstPCs += $object
                #write-host " $($computer.Indexof($entry)) = $($entry.Name) | $($entry.Description)"
            }
    if($($computer.Count) -gt 1)
    {
    $lstPcs| Format-Table -Autosize `
        @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
        @{Name="Computer Name";Expression = { $_.Name }; Alignment="left" },
        @{Name="AD Description";Expression = { $_.Description }; Alignment="left" }|out-null
        $select = read-host "`n Enter a Selection"
        $computer = ($lstPCs|Where-Object -Property Selection -eq -Value $select |Select-Object *)
        return $computer
    }
    
    elseif ($($computer.Count) -eq 1)
    {
    return $lstPCs
    }
    }
    else
    {
        return $null
    }
}

Function Get-WinVer
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	#	isOnline = [bool]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername,
        [Parameter(Mandatory=$false)]$isOnline
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# OPTIONAL CHECK (NULLS PASS) > BOOL TYPE CHECK
	if(($isOnline) -and !($isOnline -is [boolean])){$Param_ErrorMsg = "wrong data type entered for parameter: isOnline"}

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$key = $null
	$valuename = $null
	$reg = $null
	$regkey = $null
	$winver = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if(!($isOnline))
	{
	$isOnline = $false
	if (((Test-IsOnline $Computername).online) -eq $true)
	{
	$isOnline = $true
	}	  
	}
	if($isOnline -eq $true)
	{
	$key = "SOFTWARE\Microsoft\Windows NT\CurrentVersion"
	$valuename = "ReleaseId"
	$reg = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey('LocalMachine', $Computername)
	$regkey = $reg.opensubkey($key)
	$winver = $regkey.getvalue($valuename)
	if(!($winver))
	{
	$ErrorMsg = "Couldn't get Windows version"
	}
	}
	else
	{
	#write-debug "[FAILURE] Get-WinVer - PC is not online"
	$ErrorMsg = "Couldn't Contact Computer"
	}
	}
	else
	{
	#write-debug "[FAILURE] Get-WinVer - Initial parameter input was null"
	$ErrorMsg = "Get-WinVer - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $winver;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Get-LastBootupTime
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	#	isOnline = [bool]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername,
        [Parameter(Mandatory=$false)]$isOnline
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# OPTIONAL CHECK (NULLS PASS) > BOOL TYPE CHECK
	if(($isOnline) -and !($isOnline -is [boolean])){$Param_ErrorMsg = "wrong data type entered for parameter: isOnline"}

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$LastBoot_Time = $null
	$PC_Events = $null
	$Return_Object = $null
	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	    if(!($isOnline))
	    {
	        $isOnline = $false
	        if (((Test-IsOnline $Computername).online) -eq $true)
	        {
	            $isOnline = $true
	        }	  
	    }
	    if($isOnline -eq $true)
	    {
	        #write-debug "[SUCCESS] Get-LastbootupTime - Test-isonline returned true"
            if(((Check-If-IP $Computername).output) -eq $true)
            {
                if(!($Script:credentials))
                {
                    $Script:credentials = Get-Credential -Credential AFII\$env:USERNAME
                }
    
                $LastBoot_Time = invoke-command -ComputerName $Computername -Credential $Script:credentials -script {
	                $PC_Events = Get-Eventlog -LogName system -newest 1 -message "The Event log service was started." -erroraction silentlycontinue
	                if ($PC_Events)
	                {
    	                # "The Event log service was started." log found
	                    Write-output $PC_Events.TimeGenerated
	                }
	                else
	                {
    	                # No "The Event log service was started." logs found
	                    #Write-output "No Event found"
	                }
	            }
	            if (!($LastBoot_Time))
	            {
	                #Return value from invoke-command was null
	                #write-debug "[FAILURE] Get-LastBootupTime - invoke-command search for last 'The Event log service was started.' event returned NULL"
	                $LastBoot_Time = $null
	                $ErrorMsg = "Computer Is Online But Unresponsive"
	            }
	            else
	            {
	                #Return value from invoke-command was NOT null
	                if($LastBoot_Time -eq "No Event found")
	                {
	                    #No Event 7001 logs found on computer
	                    #write-debug "[WARNING] Get-LastBootupTime - invoke-command search for last 'The Event log service was started.' event returned 'No Event Found'"
	                    $LastBoot_Time = $null
	                    $ErrorMsg = "No Bootup event was present on computer"
	                }
	                else
	                {
	                    #SUCCESSFULLY Found last 7001 Event on computer
	                    #write-debug "[SUCCESS] Get-LastBootupTime - invoke-command search for last 'The Event log service was started.' event returned acceptable range"
	                    #write-debug "[RESULT] Get-LastBootupTime - $LastBoot_Time"
	                }
	            }
            }
            else
            {
                $LastBoot_Time = invoke-command -ComputerName $Computername -script {
	                $PC_Events = Get-Eventlog -LogName system -newest 1 -message "The Event log service was started." -erroraction silentlycontinue
	                if ($PC_Events)
	                {
    	                # "The Event log service was started." log found
	                    Write-output $PC_Events.TimeGenerated
	                }
	                else
	                {
    	                # No "The Event log service was started." logs found
	                    #Write-output "No Event found"
	                }
	            }
	            if (!($LastBoot_Time))
	            {
    	            #Return value from invoke-command was null
	                #write-debug "[FAILURE] Get-LastBootupTime - invoke-command search for last 'The Event log service was started.' event returned NULL"
	                $LastBoot_Time = $null
	                $ErrorMsg = "Computer Is Online But Unresponsive"
	            }
	            else
	            {
    	            #Return value from invoke-command was NOT null
	                if($LastBoot_Time -eq "No Event found")
	                {
    	                #No Event 7001 logs found on computer
	                    #write-debug "[WARNING] Get-LastBootupTime - invoke-command search for last 'The Event log service was started.' event returned 'No Event Found'"
	                    $LastBoot_Time = $null
	                    $ErrorMsg = "No Bootup event was present on computer"
	                }
	                else
	                {
    	                #SUCCESSFULLY Found last 7001 Event on computer
	                    #write-debug "[SUCCESS] Get-LastBootupTime - invoke-command search for last 'The Event log service was started.' event returned acceptable range"
	                    #write-debug "[RESULT] Get-LastBootupTime - $LastBoot_Time"
	                }
	            }
            }
	    }
	    else
	    {
	        # PC is not online
	        #write-debug "[FAILURE] Get-LastbootupTime - Test-isonline returned false"
	        $ErrorMsg = "Couldn't Contact Computer"
	    }
	}
	else
	{
    	#write-debug "[FAILURE] Get-LastbootupTime - Initial parameter input was null"
    	$ErrorMsg = "Get-LastbootupTime - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $LastBoot_Time;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Get-LastLoginTime
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	#	isOnline = [bool]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername,
        [Parameter(Mandatory=$false)]$isOnline
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# OPTIONAL CHECK (NULLS PASS) > BOOL TYPE CHECK
	if(($isOnline) -and !($isOnline -is [boolean])){$Param_ErrorMsg = "wrong data type entered for parameter: isOnline"}

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$LastLogin_Time = $null
	$PC_Events = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
    
	if(!($isOnline))
	{
	$isOnline = $false
	if (((Test-IsOnline $Computername).online) -eq $true)
	{
	$isOnline = $true
	}	  
	}
	if($isOnline -eq $true)
	{

    if(((Check-If-IP $Computername).output) -eq $false)
    {

	#write-debug "[SUCCESS] Get-LastLoginTime - Test-isonline returned true"
            $LastLogin_Time = invoke-command -ComputerName $Computername -script {
	$PC_Events = Get-Eventlog -LogName system -newest 1 -InstanceId 7001 -erroraction silentlycontinue
	if ($PC_Events)
	{
	# 7001 log found
	Write-Output $PC_Events.TimeGenerated
	}
	else
	{
	# No 7001 logs found
	#Write-output "No Event found"
	}
	}
	if (!($LastLogin_Time))
	{
	#Return value from invoke-command was null
	#write-debug "[FAILURE] Get-LastLoginTime - invoke-command search for last 7001 event returned NULL"
	$LastLogin_Time = $null
	$ErrorMsg = "Computer Is Online But Unresponsive"
	}
	else
	{
	#Return value from invoke-command was NOT null
	if($LastLogin_Time -eq "No Event found")
	{
	#No Event 7001 logs found on computer
	#write-debug "[WARNING] Get-LastLoginTime - invoke-command search for last 7001 event returned 'No Event Found'"
	$LastLogin_Time = $null
	$ErrorMsg = "No Login event was present on computer"
	}
	else
	{
	#SUCCESSFULLY Found last 7001 Event on computer
	#write-debug "[SUCCESS] Get-LastLoginTime - invoke-command search for last 7001 event returned acceptable range"
	#write-debug "[RESULT] Get-LastLoginTime - $LastLogin_Time"
	}
	}
}
else
{
    if(!($Script:credentials))
    {
    $Script:credentials = Get-Credential -Credential AFII\$env:USERNAME
    }
	#write-debug "[SUCCESS] Get-LastLoginTime - Test-isonline returned true"
            $LastLogin_Time = invoke-command -ComputerName $Computername -Credential $Script:credentials -script {
	$PC_Events = Get-Eventlog -LogName system -newest 1 -InstanceId 7001 -erroraction silentlycontinue
	if ($PC_Events)
	{
	# 7001 log found
	Write-Output $PC_Events.TimeGenerated
	}
	else
	{
	# No 7001 logs found
	#Write-output "No Event found"
	}
	}
	if (!($LastLogin_Time))
	{
	#Return value from invoke-command was null
	#write-debug "[FAILURE] Get-LastLoginTime - invoke-command search for last 7001 event returned NULL"
	$LastLogin_Time = $null
	$ErrorMsg = "Computer Is Online But Unresponsive"
	}
	else
	{
	#Return value from invoke-command was NOT null
	if($LastLogin_Time -eq "No Event found")
	{
	#No Event 7001 logs found on computer
	#write-debug "[WARNING] Get-LastLoginTime - invoke-command search for last 7001 event returned 'No Event Found'"
	$LastLogin_Time = $null
	$ErrorMsg = "No Login event was present on computer"
	}
	else
	{
	#SUCCESSFULLY Found last 7001 Event on computer
	#write-debug "[SUCCESS] Get-LastLoginTime - invoke-command search for last 7001 event returned acceptable range"
	#write-debug "[RESULT] Get-LastLoginTime - $LastLogin_Time"
	}
	}

}
	}
	else
	{
	# PC is not online
	#write-debug "[FAILURE] GET-LastbootupTime - Test-isonline returned false"
	$ErrorMsg = "Couldn't Contact Computer"
	}
	}
	else
	{
	#write-debug "[FAILURE] Get-LastLoginTime - Initial parameter input was null"
	$ErrorMsg = "Get-LastLoginTime - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $LastLogin_Time;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Get-LastRebootInitiatedTime
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	#	isOnline = [bool]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername,
        [Parameter(Mandatory=$false)]$isOnline
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# OPTIONAL CHECK (NULLS PASS) > BOOL TYPE CHECK
	if(($isOnline) -and !($isOnline -is [boolean])){$Param_ErrorMsg = "wrong data type entered for parameter: isOnline"}

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$LastReboot_Time = $null
	$PC_Events = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{

	if(!($isOnline))
	{
	$isOnline = $false
	$isOnline = (((Test-IsOnline $Computername).online) -eq $true)  
	}
	if($isOnline -eq $true)
	{
    if(((Check-If-IP $Computername).output) -eq $true)
    {

    if(!($Script:credentials))
    {
    $Script:credentials = Get-Credential -Credential AFII\$env:USERNAME
    }
	#write-debug "[SUCCESS] Get-LastRebootInitiatedTime - Test-isonline returned true"    
	$LastReboot_Time = invoke-command -ComputerName $Computername -Credential $Script:credentials -script {
	$PC_Events = get-eventlog -logname system -newest 1 -Message "The Event log service was stopped." -ErrorAction SilentlyContinue
	if ($PC_Events)
	{
	write-output $PC_Events.TimeGenerated
	}
	else
	{
	#write-output "No Event Found"
	}
	}

	if (!($LastReboot_Time))
	{
	#Return value from invoke-command was null
	#write-debug "[FAILURE] GET-LastRebootInitiatedTime - invoke-command search for last 'The Event log service was stopped.' event returned NULL"
	$LastReboot_Time = $null
	$ErrorMsg = "Computer Is Online But Unresponsive"
	}
	else
	{
	#Return value from invoke-command was NOT null
	if($LastReboot_Time -eq "No Login event found")
	{
	#No Event 7001 logs found on computer
	#write-debug "[WARNING] GET-LastRebootInitiatedTime - invoke-command search for last 'The Event log service was stopped.' event returned 'No Event Found'"
	$LastReboot_Time = $null
	$ErrorMsg = "No reboot event was present on computer"
	}
	else
	{
	#SUCCESSFULLY Found last 7001 Event on computer
	#write-debug "[SUCCESS] GET-LastRebootInitiatedTime - invoke-command search for last 'The Event log service was stopped.' event returned acceptable range"
	#write-debug "[RESULT] GET-LastRebootInitiatedTime - $LastReboot_Time"
	}
	}
}
else
{
    #write-debug "[SUCCESS] Get-LastRebootInitiatedTime - Test-isonline returned true"    
	$LastReboot_Time = invoke-command -ComputerName $Computername -script {
	$PC_Events = get-eventlog -logname system -newest 1 -Message "The Event log service was stopped." -ErrorAction SilentlyContinue
	if ($PC_Events)
	{
	write-output $PC_Events.TimeGenerated
	}
	else
	{
	#write-output "No Event Found"
	}
	}

	if (!($LastReboot_Time))
	{
	#Return value from invoke-command was null
	#write-debug "[FAILURE] GET-LastRebootInitiatedTime - invoke-command search for last 'The Event log service was stopped.' event returned NULL"
	$LastReboot_Time = $null
	$ErrorMsg = "Computer Is Online But Unresponsive"
	}
	else
	{
	#Return value from invoke-command was NOT null
	if($LastReboot_Time -eq "No Login event found")
	{
	#No Event 7001 logs found on computer
	#write-debug "[WARNING] GET-LastRebootInitiatedTime - invoke-command search for last 'The Event log service was stopped.' event returned 'No Event Found'"
	$LastReboot_Time = $null
	$ErrorMsg = "No reboot event was present on computer"
	}
	else
	{
	#SUCCESSFULLY Found last 7001 Event on computer
	#write-debug "[SUCCESS] GET-LastRebootInitiatedTime - invoke-command search for last 'The Event log service was stopped.' event returned acceptable range"
	#write-debug "[RESULT] GET-LastRebootInitiatedTime - $LastReboot_Time"
	}
	}
}
	}
	else
	{
	# PC is not online
	#write-debug "[FAILURE] GET-LastRebootInitiatedTime - Test-isonline returned false"
	$LastReboot_Time = $null
	$ErrorMsg = "Couldn't Contact Computer"
	}
	}
	else
	{
	#write-debug "[FAILURE] GET-LastRebootInitiatedTime - Initial parameter input was null"
	$ErrorMsg = "Get-LastLoginTime - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $LastReboot_Time;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Convert-To-TimeFromOccurance
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Time = [String] / [Datetime]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	Color = color to show output as
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Time
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# OPTIONAL CHECK (NULLS PASS) > BOOL TYPE CHECK
	#if(($isOnline) -and !($isOnline -is [boolean])){$Param_ErrorMsg = "wrong data type entered for parameter: isOnline"}

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Time)){$Param_ErrorMsg = "No value entered for: Time"}
	elseif(!($Time -is [string] -or $Time -is [Datetime])){$Param_ErrorMsg = "wrong data type entered for parameter: Time"}

	if($Time -is [string])
	{
	if(!($Time.Trim())){$Param_ErrorMsg = "Empty string for parameter: Time"}
	}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	[timespan]$Timespan = New-TimeSpan -Minutes 0
	[string]$strDays = $null
	[string]$strHours = $null
	[string]$strMinutes = $null
	[int]$intDays = $null
	[int]$intHours = $null
	[int]$intMinutes = $null
	[string]$strOutput = $null
	$OutputColor = [System.drawing.color]::White
	$Return_Object = $null


        $CHours =  $hours % 24
        $CMins = $mins % 60

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{   
	# Create Timespan        
	$Timespan = (Get-Date) - $Time

	# Find Days, Hours, and Minutes in [string] form from Timespan
	$intDays = [math]::Floor($($Timespan.TotalDays))
        $intHours = [math]::Floor($($Timespan.TotalHours))
        $intMinutes = [math]::Floor($($Timespan.TotalMinutes))

	# Convert Days to [int]
	if (!($intDays))
	{
	$intDays = 0
	}

	# Convert Hours to [int]
	if (!($intHours))
	{
	$intHours = 0
	}

	# Convert Minutes to [int]
	if (!($intMinutes))
	{
	$intMinutes = 0
	}            
	$intHours =  $intHours % 24
        $intMinutes = $intMinutes % 60
	#Add days output if more than 0
	if($intDays -gt 0)
	{
	$OutputColor = [System.drawing.color]::Red
	$strOutput += "$intDays Days "
	}
	#Add Hours output if more than 0
	if($intHours -gt 0)
	{
	if($intHours -gt 5 -and $intDays -lt 1)
	{
	$OutputColor = [System.drawing.color]::Yellow
	}
	elseif($intHours -lt 4 -and $intDays -lt 1)
	{
	$OutputColor = [System.drawing.color]::Green
	}
	$strOutput += "$intHours Hours "
	}
	if($intHours -gt 0 -or $intDays -gt 0)
	{
	$strOutput += "and "
	}
	#ALWAYS Add Minutes output 
	$strOutput += "$intMinutes Minutes"

	<# OLD METHOD (HOLD INCASE NEW ONE HAS ISSUES *needs aryRemove_From_Output added*)
	if ($aryRemove_From_Output.count -gt 0)
	{
	if ($aryRemove_From_Output[0] -eq "days")
	{
	if ($aryRemove_From_Output.count -gt 1)
	{
	$out_strLastUserLogon = "$strMinutes Minutes"
	}
	else
	{
	$strOutput = "$strHours Hours $strMinutes Minutes"                    
	}
	}
	else
	{
	$strOutput = "$strDays Days $strMinutes Minutes"
	}
	}
	else
	{
	$strOutput = "$strDays Days $strHours Hours $strMinutes Minutes"
	}
	#>

	$properties = @{'Output' = $strOutput;
	'Color' = $OutputColor
	'ErrorMsg' = $ErrorMsg;} #NO ERROR MESSAGE OUTPUT CURRENTLY FOR CONVERTING DATE/STRING TO OUTPUT
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
	}
}

Function Check-If-IP
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$isIP = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if ($Computername -like "*.*.*.*")
	{
	# Is an IP Address
	$isIP =  $true
	}
	else
	{
	# NOT an IP Address
	$isIP = $false
	}
	}
	else
	{
	#write-debug "[FAILURE] Check-If-IP - Initial parameter input was null"
	$ErrorMsg = "Check-If-IP - $Param_ErrorMsg"
	
	}
	$properties = @{'Output' = $isIP;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Format-User-Fullname($user)
{
	$fullname = $null
	$trmFirstname = $null
	$trmlastname = $null
	$trmMI = $null
	$firstnameOut = $null
	$lastnameOut = $null
	$MIout = $null

	$firstnameOut = $($user.firstname)
    $firstnameout = $firstnameout.replace("`'","`'`'")         
	$trmFirstname = $firstnameOut.trim()

	$lastnameOut = $($user.lastname)
    $lastnameOut = $lastnameOut.replace("`'","`'`'")
	$trmlastname = $lastnameOut.trim()
                    
    if ($($user.Initials) -eq $null -or $($user.Initials) -eq "")
    {
	$fullname = $trmFirstname + " " + $trmlastname
	}
	else
	{
	$fullname = $trmFirstname + " " + $user.Initials + " " + $trmlastname
	}
	return $fullname
}

Function Format-AD-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$Param_ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	#$Name = $null
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","*")
	}
	else
	{
	#write-debug "Could not format null valued name"
	}	
	}
	else
	{
	#write-debug "[FAILURE] Format-AD-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-AD-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function Format-String-User-Name
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Name = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Name
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Name)){$ErrorMsg = "No value entered for: Name"}
	elseif(!($Name -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Name"}
	elseif(!($Name.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Name"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	if($Name)
	{
	$Name = $Name.replace("`'","`'`'")
	$Name = $Name.trim() 
	}
	else
	{
	#write-debug "Could not format null valued name"
	}
	}
	else
	{
	#write-debug "[FAILURE] Format-String-User-Name - Initial parameter input was null"
	$ErrorMsg = "Format-String-User-Name - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $Name;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function FindUsersFullname-By-Username
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = Users fullname
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$ErrorMsg = $null
	$iUser = $null
	$User_Name = $null
	$Return_Object = $null

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
	$iUser = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "sAMAccountName -like '$UserIn'")
	if ($($iUser.count) -lt 1)
	{
	$iUser = @(get-ADUser -Server AFII -SearchBase "OU=Users,OU=Corp,DC=i,DC=ameriprise,DC=com"-Properties * -filter "sAMAccountName -like '$UserIn'")
	}

	if($($iUser))
	{
	if($($iUser.Initials))
	{
	if ($(($iUser.Initials).Trim()))
	{
	#write-debug "MI is null"
	$User_name = $($iUser.GivenName) + " " + $($iUser.SurName)
	}
	else
	{
	#write-debug "MI is NOT empty string"
	$User_name = $($iUser.GivenName) + " " + $($iUser.Initials) + " " + $($iUser.SurName)
	}
	}
	else
	{
	#write-debug "MI is null"
	$User_name = $($iUser.GivenName)+ " " + $($iUser.SurName)
	}
	}
	else
	{
	$ErrorMsg = "No Users found"
	}
	}
	else
	{
	#write-debug "[FAILURE] FindUser-By-Username - Initial parameter input was null"
	$ErrorMsg = "FindUser-By-Username - $Param_ErrorMsg"
	}
	$properties = @{'Output' = $User_name;
	                'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	return $Return_Object
}

Function FindUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	User_In = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$User_In
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------
    #write-debug "input: $User_In"
	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($User_In)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($User_In -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($User_In.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
	# NULL variables (just in case)
	#$User_FullNameArray = @()
    $Original = $null
	$ErrorMsg = $null
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$filtering_Lastname = $false
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
    $SearchingBase = "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
            $MainForm.Text = "Setting User LastName to: $User_LastName..."
	        #write-debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            #write-debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug " First Name: $User_FirstName"
                $MainForm.Text = "Setting User First Name to: $($User_FirstName)..."
                $User_MiddleName = $($User_FullNameArray[1])
	            #write-debug " Middle Name: $User_MiddleName"
                $MainForm.Text = "Setting User Middle Name to: $($User_MiddleName)..."
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                #write-debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
                $MainForm.Text = "Setting User MI to: $($User_MI)..."
	            #write-debug " Middle Initial Part 2 : $User_MI"
                #write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                $MainForm.Text = "Formating First Name for AD search..."
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                $MainForm.Text = "Formating Last Name for AD search..."
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
                        $MainForm.Text = "Comparing list of known non-name words to Last Name..."
	                    #write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
                            $MainForm.Text = "Found non-name Last Name, Setting different Last Name..."
	                        #write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
                                
	                            #write-debug "Index of filtered word is > 0"
                                if($User_MiddleName)
                                {
                                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 1)
                                    {
                                        $MainForm.Text = "Reconfiguring MI..."
                                        #write-debug "Index of filtered word is > 1"
                                        $User_MiddleName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_MiddleName) - 1)])
                                        $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                                        #write-debug "MI set to: $User_MI"
                                        $MainForm.Text = "Setting MI to: $User_MI..."
                                    }
                                    else
                                    {
                                        $MainForm.Text = "Nulling Middle Name do to not found..."
                                        #write-debug "Index of filtered word is NOT > 1"
                                        #write-debug "MI and Middle name set to NULL"
                                        $User_MiddleName = $null
                                        $User_MI = $null
                                    }
                                }
	                            #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                $MainForm.Text = "Setting Last Name to: $User_LastName..."
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            #write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
                                $MainForm.Text = "Last Name wasn't found..."
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
                            $MainForm.Text = "Filtering completed"
	                        #write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                            $MainForm.Text = "Setting Filtered Name to: $User_LastName"
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    #write-debug "Name not filtered"
                        $MainForm.Text = "Searching by First Name, Last Name, and MI..."
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            $MainForm.Text = "Searching by First Name and Last Name..."
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $MainForm.Text = "Searching by Last Name and MI..."
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    $MainForm.Text = "Searching by Last Name..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                }        
                            }
                        }
                    }
                    else
                    {
                        #write-debug "Name was filtered"
                        if(!($User_LastName -eq "Last Name not Found"))
                        {
                            #write-debug "Last Name was found"
                            if($User_MI)
                            {
                                #write-debug "Middle Name exists"
                                $MainForm.Text = "Searching by First Name, Last Name, and MI..."
	                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    $MainForm.Text = "Searching by First Name and Last Name..."
                                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        $MainForm.Text = "Searching by Last Name and MI..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                        if(!($AD_User))
                                        {
                                            $MainForm.Text = "Searching by Last Name..."
                                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                        }        
                                    }
                                }
                            }
                            else
                            {
                                #write-debug "Middle Name Doesn't exist"
                                $MainForm.Text = "Searching by First Name and Last Name..."
                                $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                                if(!($AD_User))
                                {
                                    $MainForm.Text = "Searching by First Name and Last Name with wildcarded firstname..."
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                                    if(!($AD_User))
                                    {
                                        $MainForm.Text = "Searching by Last Name..."
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }
                            }
                        }
                        else
                        {
                            #write-debug "No AD_User found do to no Last name found"
                            $AD_User = $null
                        }
                    }
                }
	            else
	            {
	                #write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    #write-debug "Last name was null"
	                }
	                else
	                {
	                    #write-debug "First name was null"
	                }
	                #write-debug "AD_User set to null"
	                $AD_User = $null
	            }

	            #write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    #write-debug "Less than 1 user found"                    
                }
            }
            else
            {
	            #write-debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
                    $MainForm.Text = "Filtering out non-name Words..."
	                #write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "(*)" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    #write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
                            $MainForm.Text = "Getting new index of Last Name..."
	                        #write-debug "Index of filtered word is > 0"
	                        #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            $MainForm.Text = "Setting Last Name to $User_LastName..."
                            $filteredName = $true
	                    }
	                    else
	                    {
                            $MainForm.Text = "Last Name wasn't found..."
	                        #write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
                        $MainForm.Text = "Filtering Completed..."
	                    #write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
                        $MainForm.Text = "Setting Last Name to $User_LastName..."
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                #write-debug "Last Name was found after filtering"
	                #write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    $MainForm.Text = "Searching by First and Last Name..."
                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                    if(!($AD_User))
                    {
                        $MainForm.Text = "Searching by First and Last Name wildcarded..."
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $MainForm.Text = "Searching by Last Name wildcarded..."
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                        }
                    }
	                #write-debug "Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
                    $MainForm.Text = "Last Name not found..."
	                #write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        #write-debug "Input has 1 word"
            #write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            #write-debug "Last Name set to $($User_LastName)"
            $MainForm.Text = "Formating Last Name for AD search..."
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            $MainForm.Text = "Search AD for users by Last Name..."
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                $mainform.text = "Seaching AAH users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
            $MainForm.Text = "No Valid input for users name detected..."
	        #write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        #write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
            $MainForm.Text = "Formatting User output..."
	        #write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
                
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);
                                'SSO' = $($entry.sAMAccountName);
                                'ID' = $($entry.EmployeeID)}
                $User_Object = New-Object �TypeName PSObject �Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($AD_User.Count) -gt 1)
	        {
                $MainForm.Text = "Selecting User..."
	            #write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
                @{Name="ID";Expression = { $_.ID }; Alignment="left" },
	            @{Name="Email";Expression = { $_.Email }; Alignment="left" }|out-null
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                }
                $MainForm.Text = "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
	        }
	        elseif ($($AD_User.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                #write-debug "AD FIRST NAME $($AD_User.Firstname)"
                #write-debug $ad_user.Lastname
                #write-debug $ad_user.Email
	            #write-debug "User count = 1"
                $MainForm.Text = "Formating User's First Name for AD Search..."
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
                $MainForm.Text = "Formating User's Last Name for AD Search..."
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                #write-debug $User_FirstName
                #write-debug $User_LastName
	            $MainForm.Text = "Formating User's full name to String output..."
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
	        }
	    }
	    else
	    {
	        #write-debug "No user found setting variables to null"
	        #write-debug "Searching Corperate Users"
	        $AD_User = (Get-CorpUser -UserIn $original)
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
    }
	else
	{
	    #write-debug "[FAILURE] FindUser - Initial parameter input was null"
	    $ErrorMsg = "FindUser - $Param_ErrorMsg"
	}

    $MainForm.Text = "Formating User output..."
	if($AD_User)
	{
	    $properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	                    'LastName' = $AD_User.LastName;
	                    'MI' = $AD_User.Initials;
	                    'Email' = $AD_User.Email;
	                    'SSO' = $AD_User.SSO;
                        'ID' = $AD_User.ID;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object �TypeName PSObject �Prop $properties
	}
	else
	{
	    $properties = [ordered]@{'FirstName' = $null;
	                    'LastName' = $null;
	                    'MI' = $null;
	                    'Email' = $null;
	                    'SSO' = $null;
                        'ID' = $null;
	                    'ErrorMsg' = $ErrorMsg;}
	    $Return_Object = New-Object �TypeName PSObject �Prop $properties
	}
    $MainForm.Text = "Returning User output..."
	return $Return_Object
}

Function Get-CorpUser
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

	# NULL variables (just in case)
	$original = $UserIn
	$User_FirstName = $null
	$User_LastName = $null
	$User_MiddleName = $null
	$User_MI = $null
	$AD_User = $null
	$selection = $null
	$User_Email = $null
	$User_SSO = $null
	$User_SID = $null
	$User_Name = $null
	$User_Formatted_FirstName = $null
	$User_Formatted_LastName = $null
	$filtering_Lastname = $false
	$lstUsers = $Null
	$select = $Null
	$User_Object = $null
	$Return_Object = $null
    $SearchingBase = "OU=Users,OU=CORP,DC=i,DC=ameriprise,DC=com"

	# Filter failed input to return errormsg and null output
	if(!($Param_ErrorMsg))
	{
        $original = $user_In

	    $User_FullNameArray = $User_In -Split " "
        $User_FullNameArrayTrimmed = @()
        for($i = 0; $i -lt $User_FullNameArray.count; $i++)
        {
            if(($User_FullNameArray[$i].trim()))
            {
                $User_FullNameArray[$i] = $User_FullNameArray[$i].trim()
                $User_FullNameArrayTrimmed += $User_FullNameArray[$i]
            }
            else
            {

            }
        }
        $User_FullNameArray = $User_FullNameArrayTrimmed
        $User_FullNameArrayTrimmed = $null
        if ($($User_FullNameArray.count) -gt 1)
        {
            $User_LastName = $User_FullNameArray[$User_FullNameArray.count -1]
	        #write-debug " Input for user to lookup contains at least 1 word"
            if ($($User_FullNameArray.count) -eq 3)
            {
	            #write-debug " Input for user to lookup contains 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug " First Name: $User_FirstName"
                $User_MiddleName = $($User_FullNameArray[1])
	            #write-debug " Middle Name: $User_MiddleName"
                $User_MI = $User_MiddleName.ToCharArray() | %{[string][char]$_}
                #write-debug " Middle Initial Part 1 : $User_MI"
                $User_MI = $($User_MI[0])
	            #write-debug " Middle Initial Part 2 : $User_MI"
                
                #write-debug " Last Name (input index = " + $($User_FullNameArray.count -1) + "): $User_LastName"
                $User_Formatted_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
                $User_Formatted_LastName = ((Format-AD-User-Name -name $User_LastName).output)
	            if($User_FirstName -and $User_LastName)
	            {

                    $filtering_Lastname = $true
                    $filteredName = $false
                    while($filtering_Lastname -eq $true)
	                {
	                    #write-debug "Filtering = true"
	                    if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1..9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                    {
	                        #write-debug "One of the words was flagged to filter out"
	                        if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                        {
	                            #write-debug "Index of filtered word is > 0"
	                            #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                            $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                                $filteredName = $true
	                        }
	                        else
	                        {
	                            #write-debug "Index of filtered word is !> 0"
	                            $User_LastName = "Last Name not Found"
	                            $filtering_Lastname = $false
	                        }
	                    }
	                    else
	                    {
	                        #write-debug "No words to be filtered found for $User_LastName"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                        $filtering_Lastname = $false
	                    }
	                }
        
                    if($filteredName -eq $false)
                    {
	                    #write-debug "First and Last name evaluated as not null"
	                    $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*' -and Initials -like '$User_MI*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                if(!($AD_User))
                                {
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and Initials -like '$User_MI*'")
                                    if(!($AD_User))
                                    {
                                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                    }
                                }        
                            }
                        }
                    }
                    else
                    {
                        $AD_User = @(Get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            }
                        }
                    }
                }
	            else
	            {
	                #write-debug "First or Last name was null"
	                if($User_FirstName)
	                {
	                    #write-debug "Last name was null"
	                }
	                else
	                {
	                    #write-debug "First name was null"
	                }
	                #write-debug "user set to null"
	                $AD_User = $null
	            }

	            #write-debug "`n Users matching input in AD = $($AD_User.count)"
                if($($AD_User.count) -lt 1)
                {
                    #write-debug "Less than 1 user found"
                    if($filteredName -eq $false)
                    {
                        #write-debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            #write-debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                                if(!($AD_User))
                                {
                                    $mainform.text = "Seaching Corp users by first name"
                                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                                }
                            }
                        }
                    }
                    else
                    {
                        #write-debug "searching by First and Last name"
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            #write-debug "Less than 1 user found searching by First and Last name wildcarded"
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '*$User_FirstName*'")
                        }

                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $mainform.text = "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }

                    
                }
            }
            else
            {
	            #write-debug "Input for user to lookup has more than 1 word but not 3 words"
                $User_FirstName = $($User_FullNameArray[0])
                #write-debug "First Name: $User_FirstName"
	            $filtering_Lastname = $true
                $filteredName = $false
                while($filtering_Lastname -eq $true)
	            {
	                #write-debug "Filtering = true"
	                if ($User_LastName -eq "BCP" -or $User_LastName -like "*[N-V][1-9]*" -or $User_LastName -like "*#*"  -or $User_LastName -eq "-" -or $User_LastName -eq "Test" -or $User_LastName -eq "Machine" -or $User_LastName -eq "III" -or $User_LastName -eq "II" -or $User_LastName -eq "I" -or $User_LastName -like "Jr" -or $User_LastName -like "Sr" -or $User_LastName -eq "Jr." -or $User_LastName -eq "Sr.")
	                {
	                    #write-debug "One of the words was flagged to filter out"
	                    if($($User_FullNameArray.Indexof($User_LastName)) -gt 0)
	                    {
	                        #write-debug "Index of filtered word is > 0"
	                        #write-debug "Index changed to [$($User_FullNameArray.Indexof($User_LastName) - 1)]"
	                        $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName) - 1)])
                            $filteredName = $true
	                    }
	                    else
	                    {
	                        #write-debug "Index of filtered word is !> 0"
	                        $User_LastName = "Last Name not Found"
	                        $filtering_Lastname = $false
	                    }
	                }
	                else
	                {
	                    #write-debug "No words to be filtered found for $User_LastName"
	                    $User_LastName = $($User_FullNameArray[$($User_FullNameArray.Indexof($User_LastName))])
	                    $filtering_Lastname = $false
	                }
	            }

	            if ($User_LastName -ne "Last Name not Found")
	            {
	                #write-debug "Last Name was found after filtering"
	                #write-debug "Last Name: $User_LastName"
	                $User_FirstName = ((Format-AD-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
                    if($filteredName -eq $true)
                    {
                        $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $mainform.text = "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
                    else
                    {
	                    $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*' -and GivenName -like '$User_FirstName*'")
                        if(!($AD_User))
                        {
                            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
                            if(!($AD_User))
                            {
                                $mainform.text = "Seaching Corp users by first name"
                                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
                            }
                        }
                    }
	                #write-debug " Users count after filtering last name = $($AD_User.count)"
	            }
	            else
	            {
	                #write-debug "Last Name was NOT found after filtering"
	                $AD_User = $null
	            }
            }
        }
        elseif ($($User_FullNameArray.count) -eq 1)
        {
	        #write-debug "Input has 1 word"
            #write-debug $User_FullNameArray[0]
            $User_LastName = $User_FullNameArray[0]
            #write-debug "Last Name set to $($User_LastName)"
            $User_LastName = ((Format-AD-User-Name -name $User_LastName).output)
            $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "Surname -like '*$User_LastName*'")
            if(!($AD_User))
            {
                $mainform.text = "Seaching Corp users by first name"
                $AD_User = @(get-ADUser -Server AFII -SearchBase $SearchingBase -Properties * -filter "GivenName  -like '*$User_LastName*'")
            }
        }
        else
        {
	        #write-debug "Input DOES NOT HAVE 1 word and IS NOT greater than 1 word"
	        #write-debug "user set to null"
           $AD_User = $null
        }
        if($AD_User -ne $null)
	    {
	        #write-debug "user validated as NOT null"
            $lstUsers=@()
            foreach ($entry in $AD_User)
            {
	            $properties = [ordered]@{'Selection'= $($AD_User.Indexof($entry) + 1);
                                'FirstName'=$($entry.GivenName);
                                'Initials' = $($entry.Initials);
                                'LastName' = $($entry.SurName);
                                'Email' = $($entry.UserPrincipalName);
                                'SSO' = $($entry.sAMAccountName);
                                'ID' = $($entry.EmployeeID)}
                $User_Object = New-Object �TypeName PSObject �Prop $properties
                $lstUsers += $User_Object
	        }
	        if($($AD_User.Count) -gt 1)
	        {
	            #write-debug "User count is greater than 1... Diplaying options to select"
	            #Write-Host -ForegroundColor Yellow " Too many Users"
	            #$User_Name = "Too many results returned"
	            $lstUsers| Format-Table -Autosize `
	            @{Name="Selection";Expression = { $_.Selection }; Alignment="left" },
	            @{Name="First Name";Expression = { $_.FirstName }; Alignment="left" },
	            @{Name="MI";Expression = { $_.Initials }; Alignment="left" },
	            @{Name="Last Name";Expression = { $_.LastName }; Alignment="left" },
	            @{Name="SSO";Expression = { $_.SSO }; Alignment="left" },
                @{Name="ID";Expression = { $_.ID }; Alignment="left" },
	            @{Name="Email";Expression = { $_.Email }; Alignment="left" }|out-null
                $results = $null
	            $results = Show-SelectionForm($lstUsers)
                if($results)
                {
	                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value $results |Select-Object *)
                    $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	                $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
	            }
                else
                {
                    $AD_User = $null
                    $User_FirstName = $null
	                $User_LastName = $null
                }

	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
            	$User_SSO = $($AD_User.sso)
	        }
	        elseif ($($AD_User.Count) -eq 1)
	        {
                $AD_User = ($lstUsers|Where-Object -Property Selection -eq -Value 1 |Select-Object *)
                #write-debug "AD FIRST NAME $($AD_User.Firstname)"
                #write-debug $ad_user.Lastname
                #write-debug $ad_user.Email
	            #write-debug "User count = 1"
	            $User_FirstName = ((Format-String-User-Name -name $User_FirstName).output)
	            $User_LastName = ((Format-String-User-Name -name $User_LastName).output)
                #write-debug $User_FirstName
                #write-debug $User_LastName
	
	            if ($($AD_User.Initials) -eq $null -or $($AD_User.Initials) -eq "")
	            {
	                #write-debug "MI is null or empty"
	                $User_Name = $User_FirstName + " " + $User_LastName
	            }
	            else
	            {
	                #write-debug "MI is NOT null or empty"
	                $User_Name = $User_FirstName + " " + $AD_User.Initials + " " + $User_LastName
	            }
	            $User_Email = $($AD_User.email)
	            $User_SSO = $($AD_User.sso)
	        }
	    }
	    else
	    {
	        #write-debug "No user found setting variables to null"
	        $AD_User = $null
	        if (!($AD_User))
	        {
	            $ErrorMsg = "No Users From AD"
	        }
	    }
	}
	else
	{
	#write-debug "[FAILURE] FindCorpUser - Initial parameter input was null"
	$ErrorMsg = "FindCorpUser - $Param_ErrorMsg"
	}


	if($AD_User)
	{
	$properties = [ordered]@{'FirstName' = $AD_User.FirstName;
	'LastName' = $AD_User.LastName;
	'MI' = $AD_User.MI;
	'Email' = $AD_User.Email;
	'SSO' = $AD_User.SSO;
    'ID' = $AD_User.ID;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	}
	else
	{
	$properties = [ordered]@{'FirstName' = $null;
	'LastName' = $null;
	'MI' = $null;
	'Email' = $null;
	'SSO' = $null;
    'ID' = $null;
	'ErrorMsg' = $ErrorMsg;}
	$Return_Object = New-Object �TypeName PSObject �Prop $properties
	}
	
	return $Return_Object
}

Function Get-PC-Model-Warning($In_Model)
{
	############ START HARD CODED PRESET VALUES #################################################################################
	#	#
	#	Add remove entries to arrays as needed to overwrite inherited display colors	#
	#---------------------------------------------------------------------------------------------------------------------------#
	$lstBadTypes = @() # Currently no bad types (IE: desktop or laptop) [change if needed]	#
	$lstBadCompanies = @() # Currently no bad companies (IE: Dell, Lenovo, etc) [change if needed]	#
	$lstBadModels = @("E5?4?", "E5?5?") # Currently no bad makes [change if needed]	#
	#	#
	$lstWarnTypes = @() # Currently no types to warn about (IE: desktop or laptop) [change if needed]	#
	$lstWarnCompanies = @() # Currently no companies to warn about (IE: Dell, Lenovo, etc) [change if needed]	#
	$lstWarnModels = @("E5???") # Currently no makes to warn about [change if needed]	#
	#	#
	$lstGoodTypes = @() # Currently no good types (IE: desktop or laptop) [change if needed]	#
	$lstGoodCompanies = @("Lenovo") # Currently EVERY Lenovo is considered good (IE: Dell, Lenovo, etc) [change if needed]	#
	$lstGoodModels = @("ThinkPad") # Currently EVERY ThinkPad is considered good [change if needed]	#
	#	#
	############ END HARD CODED PRESET VALUES ###################################################################################


	# START DEBUGGING ----------------------------------------------------------------------------
	if($lstBadTypes.Count -gt 0)
    {
        #write-debug "Bad Types Specified = $lstBadTypes"
    }
	if($lstBadCompanies.Count -gt 0)
    {
        #write-debug "Bad Companies Specified = $lstBadCompanies"
    }
	if($lstBadModels.Count -gt 0)
    {
        #write-debug "Bad Makes Specified = $lstBadModels"
    }

	if($lstWarnTypes.Count -gt 0)
    {
        #write-debug "Warn Types Specified = $lstWarnTypes"
    }
	if($lstWarnCompanies.Count -gt 0)
    {
        #write-debug "Warn Companies Specified = $lstWarnCompanies"
    }
	if($lstWarnModels.Count -gt 0)
    {
        #write-debug "Warn Makes Specified = $lstWarnModels"
    }

	if($lstGoodTypes.Count -gt 0)
    {
        #write-debug "Good Types Specified = $lstGoodTypes"
    }
	if($lstGoodCompanies.Count -gt 0)
    {
        #write-debug "Good Companies Specified = $lstGoodCompanies"
    }
	if($lstGoodModels.Count -gt 0)
    {
        #write-debug "Good Makes Specified = $lstGoodModels"
    }
	# END DEBUGGING ------------------------------------------------------------------------------
	

	# PROCESSING ORDER ###########################################################################################################################
	##	##
	##	Bad > Warn > Good	##
	##	##
	##------------------------------ Precidence goes to BAD first ------------------------------------------------------------------------------##
	##	 ___________________________________________________________________________________________________________________	##	| (IE: if Make is flagged BAD, Computer will be flagged as BAD)	|	##
	##	| (IE: if Type = GOOD, Company = WARN, and Model = BAD, Computer will be flagged AS BAD: BAD > GOOD and BAD > WARN)	|	##
	##	| (IE: if Type = GOOD, Company = WARN, and Model = GOOD, Computer will be flagged AS WARN: WARN > GOOD)	|	##
	##	| (IE: if Computer Type is in Both GOOD and BAD list of types it will be flagged BAD: BAD > GOOD)	|	##
	##	|___________________________________________________________________________________________________________________|
	##############################################################################################################################################
	

	# START Flagging Good ---------------------------------------------
	foreach ($type in $lstGoodTypes)
	{
	    if ($($In_Model.Type) -like $type)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Green
	    }
	}
	foreach ($company in $lstGoodCompanies)
	{
	    if ($($In_Model.Company) -like $company)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Green
	    }
	}
	foreach ($Model in $lstGoodModels)
	{
	    if ($($In_Model.Model) -like $Model)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Green
	    }
	}
	# END Flagging Good -----------------------------------------------

	# START Flagging Warn ---------------------------------------------
	foreach ($type in $lstWarnTypes)
	{
	    if ($($In_Model.Type) -like $type)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Yellow
	    }
	}
	foreach ($company in $lstWarnCompanies)
	{
	    if ($($In_Model.Company) -like $company)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Yellow
	    }
	}
	foreach ($Model in $lstWarnModels)
	{
	    if ($($In_Model.Model) -like $Model)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Yellow
	    }
	}
	# END Flagging Warn -----------------------------------------------

	# START Flagging BAD ----------------------------------------------
	foreach ($type in $lstBadTypes)
	{
	    if ($($In_Model.Type) -like $type)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Red
	    }
	}
	foreach ($company in $lstBadCompanies)
	{
	    if ($($In_Model.Company) -like $company)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Red
	    }
	}
	foreach ($Model in $lstBadModels)
	{
	    if ($($In_Model.Model) -like $Model)
	    {
	        $In_Model.outputcolor = [system.drawing.color]::Red
	    }
	}
	# END Flagging BAD ----------------------------------------------

	# START Defaults ------------------------------------------------
	#	If missing flags/warnings/colors fill in with defaults
	if(!($In_Model.Make))
	{
	    #write-debug "Make is null"
	    $In_Model.Make = "Unknown"
	}
	if(!($In_Model.Model))
	{
	    #write-debug "Model is null"
	    $In_Model.Model = "Unknown"
	}
	if(!($In_Model.Company))
	{
	    #write-debug "Company is null"
	    $In_Model.Company = "Unknown"
	}
	if(!($In_Model.Type))
	{
	    #write-debug "Type is null"
	    $In_Model.Type = "Unknown"
	}
	if(!($In_Model.OutputColor))
	{
	    #write-debug "OutputColor is null"
	    $In_Model.OutputColor = [System.drawing.color]::White
	}
	if(!($In_Model.Warning))
	{
	    #write-debug "Warning is null"
	    $In_Model.Warning = ""
	}
	if(!($In_Model.WarningColor))
	{
	    #write-debug "WarningColor is null"
	    $In_Model.WarningColor = [system.drawing.color]::White
	}
	# END Defaults --------------------------------------------------

	return $In_Model	
}

Function Get-PC-Model($PCModel)
{
	# NOTE LENOVOS DO NOT HAVE "LENOVO" OR "THINKPAD" IN THE MODEL SO THEY NEED TO BE PROCESSED TO DETERMINE WHAT THEY ARE

	if (($PCModel.Model -like "20JN*") -or ($PCModel.Model -like "20JM*") -or ($PCModel.Model -like "20HE*") -or ($PCModel.Model -like "20HD*"))
	{
	    #T470
	    $make = "ThinkPad"
	    $Company = "Lenovo"
	    $type = "Laptop"
	    $model = "T470"
	    $OutputColor = [System.drawing.color]::Green
	    $Warning = $null
	    $WarningColor = $null	
	}
	elseif (($PCModel.Model -like "20L5*") -or ($PCModel.Model -like "20L6*"))
	{
	    #T480
	    $make = "ThinkPad"
	    $Company = "Lenovo"
	    $type = "Laptop"
	    $model = "T480"
	    $OutputColor = [System.drawing.color]::Green
	    $Warning = $null
	    $WarningColor = $null
	}
	elseif (($PCModel.Model -like "20K6*") -or ($PCModel.Model -like "20HN*") -or ($PCModel.Model -like "20HM*"))
	{
	    #X270
	    $make = "ThinkPad"
	    $Company = "Lenovo"
	    $type = "Laptop"
	    $model = "X270"
	    $OutputColor = [System.drawing.color]::Green
	    $Warning = $null
	    $WarningColor = $null
	}
	elseif ($PCModel.Model -like "*OptiPlex*")
	{
	    # DELL OPTIPLEX DESKTOPS
	    $make = "OptiPlex"
	    $Company = "Dell"
	    $type = "Desktop"
	    if($PCModel.Model -like "*7040*")
	    {
	        # 7040 OPTIPLEX DESKTOP
	        $Model = "7040"
	        $OutputColor = [System.drawing.color]::White
	        $Warning = $null
	        $WarningColor = $null
	    }
	    elseif($PCModel.Model -like "*7020*")
	    {
	        # 7020 OPTIPLEX DESKTOP
	        $Model = "7020"
	        $OutputColor = [System.drawing.color]::White
	        $Warning = $null
	        $WarningColor = $null
	    }
	    elseif($PCModel.Model -like "*7010*")
	    {
	        # 7010 OPTIPLEX DESKTOP
	        $Model = "7010"
	        $OutputColor = [System.drawing.color]::White
	        $Warning = $null
	        $WarningColor = $null
	    }
	    else
	    {
	        # UNKNOWN MODEL OPTIPLEX DESKTOP 
	        $Model = $PCModel.Model
	        $OutputColor = [System.drawing.color]::Yellow
	        $Warning = "(PC is not a Standard Model)"
	        $WarningColor = [System.drawing.color]::Yellow
	    }
	}
	elseif($PCModel.Model -like "*Latitude*")
	{
	    # DELL LATITUDE LAPTOPS
	    $make = "Latitude"
	    $Company = "Dell"
	    $type = "Laptop"
	    $Model = $PCModel.Model.Substring($PCModel.Model.Length - 5, 5)
        if ($model -like "E5?[0..5]?")
        {
            $OutputColor = [System.drawing.color]::Yellow
	        $Warning = "PC Model needs to be replaced"
	        $WarningColor = [System.drawing.color]::Yellow
        }
        else
        {
	        $OutputColor = [System.drawing.color]::White
	        $Warning = $null
	        $WarningColor = $null
        }
	}
    elseif($PCModel.Model -like "VMware*")
    {
        $Model = $PCModel.Model
        $OutputColor = [System.drawing.color]::White
	    $Warning = ""
	    $WarningColor = [System.drawing.color]::White
    }
	else
	{
	# UNKNOWN MODEL
	if($PCModel)
	{
	    $model = $PCModel.Model
	    $OutputColor = [System.drawing.color]::Yellow
	    $Warning = "PC is not a Standard Model"
	    $WarningColor = [System.drawing.color]::Yellow
	}
	else
	{
	    $OutputColor = [System.drawing.color]::White
	    $Warning = ""
	    $WarningColor = [System.drawing.color]::White
	}
	if(!($model)){$model = ""}
	$Make = $null
	$Company = $null
	$Type = $null
	}
	$properties = @{'Make' = $make;
	                'Model' = $model;
	                'Company'= $Company;
	                'Type' = $type
	                'OutputColor' = $OutputColor;
	                'Warning' = $Warning;
	                'WarningColor' = $WarningColor}
	$object = New-Object �TypeName PSObject �Prop $properties
	$OutputObject = $null
	$OutputObject = Get-PC-Model-Warning($object)
	return $OutputObject
}

Function Show-PasswordsForm()
{
param
	(
        [Parameter(Mandatory=$false)]$SearchFor,
        [Parameter(Mandatory=$false)]$isPassword
	)
if(($isPassword) -and !($isPassword -is [boolean])){$isPassword = $false;$Param_ErrorMsg = "wrong data type entered for parameter: isPassword"}


	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($SearchFor)){$ErrorMsg = "No value entered for: Computername"}
	elseif(!($SearchFor -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($SearchFor.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}


if(!($Param_ErrorMsg))
{
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
 
$Form1 = New-Object System.Windows.Forms.Form
$Form1.Text = "$SearchFor"
$Form1.Size = New-Object System.Drawing.Size(300,200)
$Form1.StartPosition = "CenterScreen"
# Icon
$Form1.Icon = [Drawing.Icon]::ExtractAssociatedIcon((Get-Command powershell).Path)
 
$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Location = New-Object System.Drawing.Point(110,120)
$OKButton.Size = New-Object System.Drawing.Size(75,23)
$OKButton.Text = "OK"
$OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$Form1.AcceptButton = $OKButton
$Form1.Controls.Add($OKButton)
 
$CancelButton = New-Object System.Windows.Forms.Button
$CancelButton.Location = New-Object System.Drawing.Point(150,120)
$CancelButton.Size = New-Object System.Drawing.Size(75,23)
$CancelButton.Text = "Cancel"
$CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$Form1.CancelButton = $CancelButton
#$Form1.Controls.Add($CancelButton)
 
$Label1 = New-Object System.Windows.Forms.Label
$Label1.Location = New-Object System.Drawing.Point(10,20)
$Label1.Size = New-Object System.Drawing.Size(280,20)
$Label1.Text = "$($Searchfor):"
$Form1.Controls.Add($Label1)
if($isPassword -eq $true)
{
#write-debug "ispassword = true"
$textBox = New-Object System.Windows.Forms.MaskedTextBox
$textBox.PasswordChar = '*'
}
else
{
#write-debug "ispassword determined false"
$textBox = New-Object System.Windows.Forms.TextBox
}
$textBox.Location = New-Object System.Drawing.Point(10,40)
$textBox.Size = New-Object System.Drawing.Size(260,20)
$Form1.Controls.Add($textBox)
 
$Form1.Topmost = $True
 
$Form1.Add_Shown({$textBox.Select()})
$result = $Form1.ShowDialog()
 
if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
$x = $textBox.Text

 
if ($x -eq "") {[System.Windows.Forms.MessageBox]::Show("Invalid Entry!", "Test Title")}
else {return $x}
}
else{return $null}
}
else
{
$MainForm.text = "Failed due to $Param_ErrorMsg!"
return $null
}	
}

Function Show-SearchForm($SearchFor)
{
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
 
$Form1 = New-Object System.Windows.Forms.Form
$Form1.Text = "$SearchFor"
$Form1.Size = New-Object System.Drawing.Size(300,200)
$Form1.StartPosition = "CenterScreen"
# Icon
$Form1.Icon = [Drawing.Icon]::ExtractAssociatedIcon((Get-Command powershell).Path)
 
$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Location = New-Object System.Drawing.Point(75,120)
$OKButton.Size = New-Object System.Drawing.Size(75,23)
$OKButton.Text = "OK"
$OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$Form1.AcceptButton = $OKButton
$Form1.Controls.Add($OKButton)
 
$CancelButton = New-Object System.Windows.Forms.Button
$CancelButton.Location = New-Object System.Drawing.Point(150,120)
$CancelButton.Size = New-Object System.Drawing.Size(75,23)
$CancelButton.Text = "Cancel"
$CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$Form1.CancelButton = $CancelButton
$Form1.Controls.Add($CancelButton)
 
$Label1 = New-Object System.Windows.Forms.Label
$Label1.Location = New-Object System.Drawing.Point(10,20)
$Label1.Size = New-Object System.Drawing.Size(280,20)
$Label1.Text = "Search for $($Searchfor):"
$Form1.Controls.Add($Label1)
 
$textBox = New-Object System.Windows.Forms.TextBox
$textBox.Location = New-Object System.Drawing.Point(10,40)
$textBox.Size = New-Object System.Drawing.Size(260,20)
$Form1.Controls.Add($textBox)
 
$Form1.Topmost = $True
 
$Form1.Add_Shown({$textBox.Select()})
$result = $Form1.ShowDialog()
 
if ($result -eq [System.Windows.Forms.DialogResult]::OK)
{
$x = $textBox.Text

 
if ($x -eq "") {[System.Windows.Forms.MessageBox]::Show("Invalid Entry!", "Test Title")}
else {return $x}
}
else{return $null}	
}


Function Show-DGForm($lstSelections)
{
 
	#---------------------------------------------- 
	#region Import Assemblies 
	#---------------------------------------------- 
	[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	#endregion Import Assemblies  
 
	function DGForm($input1) 
	{ 
	    $Script:DGForm_RowIndex = $null
	    <# 
    	    .SYNOPSIS 
    	The Main function starts the project application. 
    	     
	        .PARAMETER Input1
	    $Input1 contains the complete argument string passed to the script packager executable. 
    	     
	        .NOTES 
	    Use this function to initialize your script and to call GUI forms. 
    	         
	        .NOTES 
	    To get the console output in the Packager (Forms Engine) use:  
	    $ConsoleOutput (Type: System.Collections.ArrayList) 
	    #> 
	     
	    #-------------------------------------------------------------------------- 
     
	    if((Call-DGForm_psf($input1)) -eq 'OK') 
	    { 
	        # ADD VALIDATION IF NEEDED
	    } 
	    $global:ExitCode = 0 #Set the exit code for the Packager 
	} 
 
	#endregion Source: Startup.pss 
 
	#region Source: MainForm.psf 
	function Call-DGForm_psf($input1) 
	{ 
    	#Datagrid click Function
	    Function dg_Selections_GridClick
	    {
	        #Set $Script:SelectionForm_RowIndex to index of the currently selected row
	        $Script:DGForm_RowIndex = $dg_Selections.CurrentRow.Index
	    }
    
	    #Add Data to Datagrid function
	    function Get-ProcessInfo($input1) 
	    {
	        $array = New-Object System.Collections.ArrayList
	        $array.AddRange($input1)
	        $dg_Selections.DataSource = $array
	        $DGform.refresh()
	        $dg_Selections.ClearSelection()
	    }
 
	    #---------------------------------------------- 
	    #region Import the Assemblies 
	    #---------------------------------------------- 
	    [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	    #endregion Import Assemblies 
    	 
    	#---------------------------------------------- 
    	#region Generated Form Objects 
    	#---------------------------------------------- 
    	[System.Windows.Forms.Application]::EnableVisualStyles() 
    	$DGForm = New-Object 'System.Windows.Forms.Form'
    	#$ButtonCancel = New-Object 'System.Windows.Forms.Button' 
    	$ButtonSelect = New-Object 'System.Windows.Forms.Button' 
    	$panel1 = New-Object 'System.Windows.Forms.Panel'
    	$panel2 = New-Object 'System.Windows.Forms.Panel'
    	$panel3 = New-Object 'System.Windows.Forms.Panel'
    	$panel4 = New-Object 'System.Windows.Forms.Panel'
    	$dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
    	$InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
    	#endregion Generated Form Objects 
 
	    #---------------------------------------------- 
	    # Form Object Functions
	    #---------------------------------------------- 
    
    	#Form Load function
    	$DGForm_Load =
    	{ 
        	get-processinfo($input1)         
	    }
    	
    	#Select Button clicked function
    	$ButtonSelect_Click = 
    	{     
        	$DGForm.Close()
	    } 

           <#        
	    #Cancel Button clicked function
	    $ButtonCancel_Click =
	    {
            #TODO: Place custom script here on canceling form
	        $DGForm.Close() 
	    }
        #>
        
     
            # --End Form Object Functions-- 
	    #---------------------------------------------- 
	    #region Generated Events 
	    #---------------------------------------------- 
	
	    #Fix Form Load function
	    $Form_StateCorrection_Load = 
	    { 
	        #Correct the initial state of the form to prevent the .Net maximized form issue 
	        $DGForm.WindowState = $InitialFormWindowState 
	    } 
     
	    #Store Values of form function
	    $Form_StoreValues_Closing = 
	    { 
	        #Store the control values here
	    } 
 
	    $Form_Cleanup_FormClosed = 
	    { 
	        #Remove all event handlers from the controls 
	        try 
	        { 
    	        #$ButtonCancel.remove_Click($buttonCancel_Click) 
	            $ButtonSelect.remove_Click($ButtonSelect_Click)
	            $DGForm.remove_Load($DGForm_Load) 
	            $DGForm.remove_Load($Form_StateCorrection_Load) 
	            $DGForm.remove_Closing($Form_StoreValues_Closing) 
	            $DGForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	        } 
	        catch [Exception] 
	        { } 
	    } 
	    #endregion Generated Events 
 
	    #---------------------------------------------- 
	    #region Form Setup Objects
	    #---------------------------------------------- 
	    #Suspend layouts
	    $DGForm.SuspendLayout()
	    #$panel4.SuspendLayout() 
	    $panel3.SuspendLayout() 
	    $panel2.SuspendLayout() 
	    $panel1.SuspendLayout()
    	 
    	# 
    	# SelectForm Attributes
    	# 
    	$DGForm.Controls.Add($panel1)
    	$DGForm.Controls.Add($panel2) 
    	$DGForm.AutoScaleDimensions = '6, 13' 
    	$DGForm.AutoScaleMode = 'Font' 
    	$DGForm.BackColor = 'White' 
    	$DGForm.ClientSize = '373, 329'   
    	$DGForm.MaximizeBox = $False 
    	$DGForm.MinimizeBox = $False 
    	$DGForm.Name = 'SelectForm' 
    	$DGForm.ShowIcon = $False 
    	$DGForm.ShowInTaskbar = $False 
    	$DGForm.StartPosition = 'CenterScreen' 
    	$DGForm.Text = 'PC Memberships'
    	$formsizex = $DGForm.ClientSize.Width + 100
    	$formsizey =  $DGForm.ClientSize.Height + 100
    	$DGForm.MinimumSize = "$formsizex,$formsizey"
    	$DGForm.MaximumSize = "$($formsizex + 600),$formsizey"
    	$DGForm.TopMost = $True 
    	$DGForm.add_Load($DGForm_Load)
        # 
	    # ButtonSelect Attributes
	    # 
	    $ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	    $ButtonSelect.ForeColor = 'Blue' 
	    $ButtonSelect.Location = '42, 50' 
	    $ButtonSelect.Name = 'ButtonSelect' 
	    $ButtonSelect.Size = '91, 45' 
	    $ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	    $ButtonSelect.Text = 'OK' 
	    $ButtonSelect.UseVisualStyleBackColor = $True 
	    $ButtonSelect.add_Click($ButtonSelect_Click)
	    $ButtonSelect.MaximumSize.Height = '60' 
	    $ButtonSelect.Dock = [System.Windows.Forms.DockStyle]::Left
	    # 
	    # Panel1 Attributes
	    #  
	    $panel1.Controls.Add($dg_Selections)
	    $panel1.Location = '0, 0' 
	    $panel1.Name = 'panel1' 
	    $panel1.Size = '375, 310' 
	    $panel1.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel1.BackColor = 'LightGray'
	    $panel1.Dock = [System.Windows.Forms.DockStyle]::Top
	    # 
	    # Panel3 Attributes
	    # 
	    $panel3.Controls.Add($ButtonSelect)  
	    $panel3.Location = '188, 310' 
	    $panel3.Name = 'panel2' 
	    $panel3.Size = '300, 80' 
	    $panel3.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel3.Padding = '180,20,0,20' 
	    $panel3.BackColor = 'LightSkyBlue'
	    $panel3.Dock = [System.Windows.Forms.DockStyle]::Left
	    # 
	    # Panel2 Attributes
	    # 
	    $panel2.Controls.Add($panel3)  
	    #$panel2.Controls.Add($panel4)  
	    $panel2.Location = '0, 310' 
	    $panel2.Name = 'panel2' 
	    $panel2.Size = '376, 80' 
	    $panel2.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel2.BackColor = 'LightSkyBlue'
	    $panel2.Dock = [System.Windows.Forms.DockStyle]::Bottom
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.Size = '375, 300'
	    $dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	    $dg_Selections.Name = "dg_Selections"
	    $dg_Selections.DataMember = ""
	    #$dg_Selections.TabIndex = 0 #TODO FIX TABINDEXES
	    $dg_Selections.Location = '0,0'
	    $dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	    $dg_Selections.AutoSizeRowsMode = "AllCells"
        #$dg_Selections.AutoSizeColumnsMode = 
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	    $dg_Selections.DefaultCellStyle.WrapMode = 'True'
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	    $dg_Selections.Margin = New-Object System.Windows.Forms.Padding(3, 3, 3, 3)
	    $dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::Fill
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	    $dg_Selections.RowHeadersVisible = $false
        $dg_Selections.ColumnHeadersVisible = $false
	    $dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	    #Resume Layouts
	    $panel1.ResumeLayout() 
	    $panel2.ResumeLayout()
	    $panel3.ResumeLayout() 
	    $panel4.ResumeLayout()  
	    $DGForm.ResumeLayout()
    	 
    	#endregion Form Setup Objects
    	#---------------------------------------------- 
    	
    	#Save the initial state of the form 
    	$InitialFormWindowState = $DGForm.WindowState 
    	#Init the OnLoad event to correct the initial state of the form 
    	$DGForm.add_Load($Form_StateCorrection_Load) 
    	#Clean up the control events 
    	$DGForm.add_FormClosed($Form_Cleanup_FormClosed) 
    	#Store the control values when form is closing 
    	$DGForm.add_Closing({
    	    #Add Closing code here
	    }) 

	    #Show the Form
        #$result = $DGForm.ShowDialog()
	    return $DGForm.ShowDialog()

	    #endregion Source: MainForm.psf 
	    $self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	}
	
	#Start the application
    $Finalresult = DGForm ($lstSelections)
    return $Script:DGForm_RowIndex
}

Function Show-SelectionForm($lstSelections)
{
	#---------------------------------------------- 
	#region Import Assemblies 
	#---------------------------------------------- 
	[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
    [void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

	#endregion Import Assemblies  
 
	function SelectForm($input1) 
	{ 
    	$Script:SelectionForm_RowIndex = $null
	    <# 
        	.SYNOPSIS 
    	The Main function starts the project application. 
        	     
	        .PARAMETER Input1
	    $Input1 contains the complete argument string passed to the script packager executable. 
        	     
	        .NOTES 
	    Use this function to initialize your script and to call GUI forms. 
        	         
	        .NOTES 
	    To get the console output in the Packager (Forms Engine) use:  
	    $ConsoleOutput (Type: System.Collections.ArrayList) 
	    #> 
	     
    	#-------------------------------------------------------------------------- 
        $SLFResult = (Call-SelectForm_psf($input1))
        return $SLFResult
        <#
	    if((Call-SelectForm_psf($input1)) -eq 'OK') 
    	{ 
	        # ADD VALIDATION IF NEEDED
	    } 
    	$global:ExitCode = 0 #Set the exit code for the Packager
        #> 
    } 
 
	#endregion Source: Startup.pss 
     
    #region Source: MainForm.psf 
    function Call-SelectForm_psf($input1) 
    { 
        #Datagrid click Function
    	Function dg_Selections_GridClick
        {
	        #Set $Script:SelectionForm_RowIndex to index of the currently selected row
	        $Script:SelectionForm_RowIndex = ($dg_Selections.CurrentRow.Index + 1)
	    }
    
        #Add Data to Datagrid function
	    function Get-ProcessInfo($input1) 
	    {
	        $array = New-Object System.Collections.ArrayList
	        $array.AddRange($input1)
	        $dg_Selections.DataSource = $array
            $dg_Selections.Refresh()
	        $dg_Selections.ClearSelection()
	    }
 
	    #---------------------------------------------- 
	    #region Import the Assemblies 
	    #---------------------------------------------- 
	    [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
	    [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
	    #endregion Import Assemblies 
	 
	    #---------------------------------------------- 
	    #region Generated Form Objects 
	    #---------------------------------------------- 
	    [System.Windows.Forms.Application]::EnableVisualStyles() 
	    $SelectForm = New-Object 'System.Windows.Forms.Form'
	    $ButtonCancel = New-Object 'System.Windows.Forms.Button' 
	    $ButtonSelect = New-Object 'System.Windows.Forms.Button' 
	    $panel1 = New-Object 'System.Windows.Forms.Panel'
	    $panel2 = New-Object 'System.Windows.Forms.Panel'
        $splitcontainer1 = New-Object 'System.windows.forms.splitcontainer'
        $splitcontainer2 = New-Object 'System.windows.forms.splitcontainer'
	    $panel3 = New-Object 'System.Windows.Forms.Panel'
	    $panel4 = New-Object 'System.Windows.Forms.Panel'
	    $dg_Selections = New-Object 'System.Windows.Forms.DataGridView'
	    $InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
	    #endregion Generated Form Objects 
 
	    #---------------------------------------------- 
	    # Form Object Functions
	    #---------------------------------------------- 
        
	    #Form Load function
        $SelectForm_Resize=
	    {   
            $splitcontainer1.SplitterDistance = ($Selectform.Height - 90)
        }

	    $SelectForm_Load =
	    { 
	        get-processinfo($input1)    
            $dgwidth = 0
            $dgheight = 0
            foreach ($col in $dg_Selections.Columns)
            {
                $dgwidth += $col.Width
            }

            foreach ($row in $dg_Selections.Rows)
            {
                $dgheight += $row.Height
            }
            if ($dg_Selections.RowCount -gt 8)
            {
                $Scrollbaractive = $true
                $dgwidth += 20
            }
            $Selectform.Width = $dgwidth + 20
            $Selectform.MinimumSize = "$($dgwidth + 20),$($Selectform.Height)"
            $Selectform.MaximumSize = "$($dgwidth + 20),$($dgheight + 130)"
            $selectform.Refresh()
            $dg_Selections.Refresh()
            $dg_Selections.Width = $dgwidth
            $dg_Selections.Height = $dgheight
            $splitcontainer1.SplitterDistance = ($Selectform.Height - 90)
            $splitcontainer1.Refresh()
            $splitcontainer2.SplitterDistance = ($splitcontainer1.size.width / 2)
            if($($ButtonSelect.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5)))) -lt 91)
            {
                $ButtonSelect.Size = "91, $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonSelect.Location = "$([math]::Round(($splitcontainer2.Size.Width / 4) - ($ButtonSelect.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            }
            else
            {
                $ButtonSelect.Size = "$($ButtonSelect.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonSelect.Location = "$([math]::Round((($splitcontainer2.Size.Width - 91) / 4) - ($ButtonSelect.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            }

            if($($ButtonCancel.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5)))) -lt 91)
            {
                $ButtonCancel.Size = "91, $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonCancel.Location = "$([math]::Round(($splitcontainer2.Size.Width / 4) - ($ButtonCancel.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            }
            else
            {
                $ButtonCancel.Size = "$($ButtonCancel.Size.Width), $([math]::Round((3 * ($splitcontainer2.Height / 5))))"
                $ButtonCancel.Location = "$([math]::Round((($splitcontainer2.Size.Width - 91) / 4) - ($ButtonCancel.Size.Width / 2))),$([math]::Round($splitcontainer2.Height / 5))"
            } 
	    }
	
	    #Select Button clicked function
	    $ButtonSelect_Click = 
	    {     
	        #Checks for input selected before allowing form close from select button click
	        if ($Script:SelectionForm_RowIndex)
	        {
                $Script:SelectForm_return = $Script:SelectionForm_RowIndex
	            $SelectForm.Close()
	        }
            else
            {
                $Script:SelectForm_return = $null
            }
	    } 

	    #Cancel Button clicked function
	    $ButtonCancel_Click =
	    {
            $Script:SelectionForm_RowIndex = $null
	        $SelectForm.Close() 
	    } 
     
        # --End Form Object Functions-- 
	    #---------------------------------------------- 
	    #region Generated Events 
	    #---------------------------------------------- 
	
	    #Fix Form Load function
	    $Form_StateCorrection_Load = 
	    { 
            if($Script:InitialFixesLocation)
            {
                if(test-path "$Script:InitialFixesLocation\Files\FormIcon.ico")
                {
                    $Icon = New-Object System.Drawing.icon("$Script:InitialFixesLocation\Files\FormIcon.ico")
                    $MainForm.Icon = $icon
                }
            }
                
    	    #Correct the initial state of the form to prevent the .Net maximized form issue 
            $SelectForm.WindowState = $InitialFormWindowState 
	    } 
     
	    #Store Values of form function
	    $Form_StoreValues_Closing = 
	    { 
	        #Store the control values here
	    } 
 
	    $Form_Cleanup_FormClosed = 
	    { 
    	    #Remove all event handlers from the controls 
        	try 
	        { 
    	        $ButtonCancel.remove_Click($buttonCancel_Click) 
	            $ButtonSelect.remove_Click($ButtonSelect_Click)
	            $SelectForm.remove_Load($SelectForm_Load) 
	            $SelectForm.remove_Load($Form_StateCorrection_Load) 
	            $SelectForm.remove_Closing($Form_StoreValues_Closing) 
	            $SelectForm.remove_FormClosed($Form_Cleanup_FormClosed) 
	        } 
	        catch [Exception] 
	        { } 
	    } 
	    #endregion Generated Events 
 
	    #---------------------------------------------- 
	    #region Form Setup Objects
	    #---------------------------------------------- 
	    #Suspend layouts
	    $SelectForm.SuspendLayout()
	    $panel4.SuspendLayout() 
	    $panel3.SuspendLayout() 
	    $panel2.SuspendLayout() 
	    $panel1.SuspendLayout()
        $splitcontainer1.SuspendLayout()
        $splitcontainer2.SuspendLayout()
	    # 
	    # SelectForm Attributes
	    # 
	    $SelectForm.Controls.Add($splitcontainer1)
	    $SelectForm.BackColor = 'White'   
	    $SelectForm.MaximizeBox = $False 
	    $SelectForm.MinimizeBox = $False 
	    $SelectForm.Name = 'SelectForm' 
	    $SelectForm.ShowIcon = $False 
	    $SelectForm.ShowInTaskbar = $False 
	    $SelectForm.StartPosition = 'CenterScreen' 
	    $SelectForm.Text = 'Select One'
	    $SelectForm.TopMost = $True 
	    $SelectForm.add_Load($SelectForm_Load)
        $SelectForm.Add_Resize($SelectForm_Resize)
	    # 
	    # ButtonCancel Attributes
	    # 
	    $ButtonCancel.Name = 'ButtonCancel' 
	    $ButtonCancel.TabIndex = 7 #TODO FIX TABINDEXES
	    $ButtonCancel.Text = 'Cancel' 
	    $ButtonCancel.UseVisualStyleBackColor = $True 
	    $ButtonCancel.add_Click($ButtonCancel_Click)
        $ButtonCancel.MaximumSize.Height = '60' 
        $ButtonCancel.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	    # 
	    # ButtonSelect Attributes
	    # 
	    $ButtonSelect.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
	    $ButtonSelect.ForeColor = 'Blue' 
	    $ButtonSelect.Name = 'ButtonSelect' 
	    $ButtonSelect.TabIndex = 0 #TODO FIX TABINDEXES
	    $ButtonSelect.Text = 'Select' 
	    $ButtonSelect.UseVisualStyleBackColor = $True 
	    $ButtonSelect.add_Click($ButtonSelect_Click)
	    $ButtonSelect.MaximumSize.Height = '60' 
        $ButtonSelect.Anchor = [System.Windows.Forms.AnchorStyles]::Top -bor [System.Windows.Forms.AnchorStyles]::Left -bor [System.Windows.Forms.AnchorStyles]::Right
	    # 
	    # Panel1 Attributes
	    #  
	    $panel1.Controls.Add($dg_Selections)
	    $panel1.Location = '0, 0' 
	    $panel1.Name = 'panel1' 
	    $panel1.Size = '375, 310'
	    $panel1.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel1.BackColor = 'LightGray'
	    $panel1.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # splitcontainer1 Attributes
	    # 
        $splitcontainer1.Panel1.size = '300, 745'
        $splitcontainer1.Location = '0, 0' 
        $splitcontainer1.Name = 'splitcontainer1'
        $splitcontainer1.Orientation = [System.Windows.Forms.Orientation]::Horizontal
        $splitcontainer1.SplitterDistance = '310'
        $splitcontainer1.IsSplitterFixed = $true
        $splitcontainer1.SplitterWidth = '1'
        $splitcontainer1.Panel2.Controls.Add($splitcontainer2)
        $splitcontainer1.Panel1.Controls.Add($panel1)
        $splitcontainer1.Dock = [System.Windows.Forms.DockStyle]::Fill
        # 
	    # Panel3 Attributes
	    # 
	    $panel3.Controls.Add($ButtonSelect)  
	    $panel3.Location = '0, 0' 
	    $panel3.Name = 'panel2' 
	    $panel3.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel3.BackColor = 'LightSkyBlue'
	    $panel3.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # Panel4 Attributes
	    # 
	    $panel4.Controls.Add($ButtonCancel)
	    $panel4.Location = '0, 0' 
	    $panel4.Name = 'panel2'
	    $panel4.TabIndex = 8 #TODO FIX TABINDEXES
	    $panel4.BackColor = 'LightSkyBlue'
	    $panel4.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # splitcontainer2 Attributes
	    # 
	    $splitcontainer2.Panel1.Controls.Add($panel3)  
	    $splitcontainer2.Panel2.Controls.Add($panel4)
	    $splitcontainer2.Location = '0, 310'
        $splitcontainer2.SplitterDistance = $splitcontainer2.Size.Width / 2
        $splitcontainer2.IsSplitterFixed = $true
        $splitcontainer2.SplitterWidth = '1' 
	    $splitcontainer2.Name = 'splitcontainer2' 
	    $splitcontainer2.TabIndex = 8 #TODO FIX TABINDEXES
	    $splitcontainer2.BackColor = 'LightSkyBlue'
	    $splitcontainer2.Dock = [System.Windows.Forms.DockStyle]::Fill
	    # 
	    # Datagrid Attributes
	    # 
	    $dg_Selections.DataBindings.DefaultDataSourceUpdateMode = 0	
	    $dg_Selections.Name = "dg_Selections"
	    $dg_Selections.DataMember = ""
	    $dg_Selections.Add_CellMouseClick({dg_Selections_GridClick})
	    $dg_Selections.AutoSizeRowsMode = "AllCells"
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230) 
	    $dg_Selections.SelectionMode = 'FullRowSelect'
	    $dg_Selections.ReadOnly = $true
	    $dg_Selections.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnMode]::AllCells
	    $dg_Selections.RowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,242,242,242)
	    $dg_Selections.AlternatingRowsDefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255,230,230,230)
	    $dg_Selections.RowHeadersVisible = $false
        $dg_Selections.MultiSelect = $false
	    $dg_selections.Dock = [System.Windows.Forms.DockStyle]::Fill
	    
	    #Resume Layouts
	    $panel1.ResumeLayout() 
	    $panel2.ResumeLayout()
	    $panel3.ResumeLayout() 
	    $panel4.ResumeLayout()  
        $splitcontainer1.ResumeLayout()
        $splitcontainer2.ResumeLayout()
	    $SelectForm.ResumeLayout()
	 
	    #endregion Form Setup Objects
	    #---------------------------------------------- 
        	
    	#Save the initial state of the form 
    	$InitialFormWindowState = $SelectForm.WindowState 
    	#Init the OnLoad event to correct the initial state of the form 
    	$SelectForm.add_Load($Form_StateCorrection_Load) 
    	#Clean up the control events 
    	$SelectForm.add_FormClosed($Form_Cleanup_FormClosed) 
    	#Store the control values when form is closing 
    	$SelectForm.add_Closing({
            #Add Closing code here
    	}) 

	    #Show the Form 
        $SelectFormResult = $SelectForm.ShowDialog()
        $return = $Script:SelectForm_return
        $Script:SelectForm_return = $null
        $Script:SelectionForm_RowIndex = $null
        return $return

	    #endregion Source: MainForm.psf 
	    $self = [System.Diagnostics.Process]::GetCurrentProcess() #TODO VERIFY THIS IS NEEDED
	}
	
	#Start the application 
	$Finalresult = SelectForm ($lstSelections)
        
    return $Finalresult
}

Function Search-By-User
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	UserIn = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	FirstName = Users FirstName
	#	LastName = Users LastName
	#	MI = Users MI
	#	Email = Users Email
	#	SSO = Users SSO
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
    [CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$UserIn
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($UserIn)){$Param_ErrorMsg = "No value entered for: UserIn"}
	elseif(!($UserIn -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: UserIn"}
	elseif(!($UserIn.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: UserIn"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------
    
    #Setting up Bools---------------
    $MainForm.Text = 'Setting Initial Bools...'
    $isOnline = $false
    $User_FromConnectedPC = $false
    $descfailed = $false
    $nousers = $false
    $filtering_Lastname = $false
    $Script:IPReady = $false
    #END Setting up Bools---------------

    #PYTHON/SELENIUM/CHROMEWEBDRIVER HARD HALT------------------------
    $MainForm.Text = 'Killing Old ChromeDriver...'
    &taskkill /im chromedriver.exe /f | Out-Null
    $MainForm.Text = 'Stopping Old Jobs...'
    Get-Job -Name "BackgroundJob" -ErrorAction SilentlyContinue | Stop-Job -ErrorAction SilentlyContinue
    $MainForm.Text = 'Removing Old Jobs...'
    Get-Job -Name "BackgroundJob" -ErrorAction SilentlyContinue | Remove-Job -ErrorAction SilentlyContinue
    #END PYTHON/SELENIUM/CHROMEWEBDRIVER HARD HALT------------------------

	# Filter failed input to return errormsg and null output
    $MainForm.Text = 'Checking for parameter errors...'
	if(!($Param_ErrorMsg))
	{
        #START GET USER--------------------------------------
        $MainForm.Text = 'Formating input...'
    	$UserIn = $UserIn.Trim()
        $MainForm.Text = 'Getting User from AD...'
	    $PSUser = (FindUser -User_In $UserIn)
        if($PSUser)
        {
            #FINDUSER FUNCTION RETURNED NOT NULL
	        $User_FirstName = ((Format-Ad-User-Name -name $($PSUser.Firstname)).output)
	        $User_LastName = ((Format-Ad-User-Name -name $($PSUser.LastName)).output)
            if($User_LastName -and $User_FirstName)
            {
                #USER_LASTNAME AND USER_FIRSTNAME NOT NULL

                #START LASTNAME FILTER SUFFIXES------------------------
                $filterArrysuffix = @("III", "II", "I", "jr", "jr.", "sr", "sr.")
                foreach ($suffix in $filterArrysuffix)
                {
                    if($User_LastName -like "* $suffix")
                    {
                        #USER_LASTNAME IS LIKE A SUFFIX IN ARRAY
                        $User_LastName = $User_Lastname -replace (" $suffix")
                    } 
                }
                #END LASTNAME FILTER SUFFIXES------------------------
                
                $searchbyDesc = $false

                #START FIRST SEARCH AD BY DESCRIPTION FIRST AND LAST NAME---------------------------------------
                $MainForm.Text = 'Getting PC from user first and last name in description from AD...'
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_FirstName*$User_LastName'")
                if(!($computer))
                {
                    #DESCRIPTION LIKE "*FIRSTNAME*LASTNAME"
                    $MainForm.Text = 'Expanding Search to find users Lastname in description of PC...'
                    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName'")
                    if(!($computer))
                    {
                        #DESCRIPTION LIKE "*LASTNAME"
                        $MainForm.Text = 'Expanding Search to find users Lastname anywhere in description of PC...'
                        $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName*'")
                        if(!($computer))
                        {
                            #DESCRIPTION LIKE "*FIRSTNAME"
                            $MainForm.Text = 'Expanding Search to find users Firstname anywhere in description of PC...'
                            $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_FirstName*'")
                        }
                    }
                }
                #END FIRST SEARCH AD BY DESCRIPTION FILTER FIRST AND LAST NAME---------------------------------------
            }
            elseif ($User_LastName)
            {
                #USER_FIRSTNAME IS NULL

                #START LASTNAME FILTER SUFFIXES------------------------
                $filterArrysuffix = @("III", "II", "I", "jr", "jr.", "sr", "sr.")
                foreach ($suffix in $filterArrysuffix)
                {
                    if($User_LastName -like "* $suffix")
                    {
                        $User_LastName = $User_Lastname -replace (" $suffix")
                    } 
                }
                #END LASTNAME FILTER SUFFIXES------------------------

                $User_FirstName = $null

                #START FIRST SEARCH AD BY DESCRIPTION FILTER LASTNAME ONLY---------------------------------------
                $MainForm.Text = 'Expanding Search to find users Lastname in description of PC...'
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName'")
                if(!($computer))
                {
                    $MainForm.Text = 'Expanding Search to find users Lastname anywhere in description of PC...'
                    $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_LastName*'")
                }
                #END FIRST SEARCH AD BY DESCRIPTION FILTER LASTNAME ONLY---------------------------------------
            }
            elseif ($User_FirstName)
            {
                #USER_LASTNAME IS NULL

                $User_LastName = $null

                #START FIRST SEARCH AD BY DESCRIPTION FILTER FIRSTNAME ONLY---------------------------------------
                $MainForm.Text = 'Expanding Search to find users Firstname anywhere in description of PC...'
                $computer = @(Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "Description -like '*$User_FirstName*'")
                #END FIRST SEARCH AD BY DESCRIPTION FILTER FIRSTNAME ONLY---------------------------------------
            }
            else
            {
                #FIRST AND LAST NAME ARE NULL
                $User_FirstName = $null
                $User_LastName = $null
                $computer = $null
            }
            
            #------------- AD COMPUTER DONE PROCESSING HERE ---------------------------
        
            $MainForm.Text = 'Setting Variable User Firstname...'
            $User_FirstName = $PSUser.Firstname
            if($PSUser.MI)
            {
                #MIDDLE INITIAL PRESENT
                $User_MI = $PSUser.MI
            }
            $MainForm.Text = 'Setting Variable User Lastname...'
	        $User_LastName = $PSUser.LastName
            
            #------------------- USER FIRST, MI, LAST NAME DONE PROCESSING HERE ----------------------------
	    }
        else
        {
            #FINDUSER FUNCTION RETURNED NULL
            $User_FirstName = $null
            $User_LastName = $null
            $computer = $null
        }
	    
	    if($computer -ne $null)
	    {
            #COMPUTER FOUND IN AD
	        $lstPCs = @() 
	        foreach ($entry in $computer)
	        {
	            $properties = [ordered]@{'Selection'= $($computer.Indexof($entry) + 1);
	                                        'Name'=$($entry.Name);
                                            'Description'= $($entry.Description)}
	            $object = New-Object �TypeName PSObject �Prop $properties
	            $lstPCs += $object
	        }

	        if($($computer.Count) -gt 1)
	        {
                #MORE THAN 1 COMPUTER FOUND
                #------open selection form
	            $selection = Show-SelectionForm($lstPCs)
	            if ($selection)
	            {
                    #SHOW-SELECTIONFORM RETURNED NOT NULL
                    $selection = $selection - 1
	                $computer = $lstPCs[$selection]
                    $Script:SelectionForm_RowIndex = $null
	                $selection = $null
                }
                else
                {
                    #SHOW-SELECTIONFORM RETURNED NULL
                    $computer = $null
                }
	        }
	        elseif ($($computer.Count) -eq 1)
	        {
                #ONLY 1 COMPUTER FOUND
                $computer = $lstPCs
	        }
	    }
	    else
	    {   
	        #NO COMPUTER FOUND IN AD
	        $computer = $null
	    }
	    $AD_Computer = $computer
        $MainForm.Text = 'Validating PC return from AD...'
	    if($AD_computer)
	    {
            if ($AD_computer.Name)
	        {
                $Script:LastSearchBY = "User"
                $Script:LastSearch = "$($AD_computer.Name)"
                $MainForm.Text = 'Setting PC Description Variable from AD description...'
	            $PC_description = $AD_computer.description
                $MainForm.Text = 'Setting PC Name Variable from AD Name...'
	            $PC_Name = $AD_computer.Name
	        }
	        else
	        {
	            #NULL COMPUTER NAME RETURNED
	            $ErrorMsg = "[POSSIBLE AD RECORD ISSUE] Computer Name From AD was invalid"
	        }
        }
        else
        {
	        #NULL COMPUTER RETURNED
	        $ErrorMsg = "[ALERT] Computer Name not found in AD"
        }

        $MainForm.Text = 'Setting PC Name...'

        $out_PC_Name = $PC_Name

        $MainForm.Text = 'Validating Description...'
	    if ($PC_description)
	    {
            #DESCRIPTION IS NOT NULL
	        if($PC_description -is [string])
	        {
                #DESCRIPTION IS A STRING
	            if($PC_description.trim())
	            {
                    #DESCRIPTION IS NOT EMPTY STRING

	                #BEGIN FIND USER FROM DESCRIPTION ATTEMPT-------------------------------------
	                $PC_description_PostReplace = $PC_description -replace "\*", "+"
	                if($PC_description_PostReplace -like "* - *")
	                {
                        #DESCRIPTION IS FORMATED CORRECTLY SO FAR
	                    $PC_description_PostReplace = $PC_description_PostReplace -split " - "
	                    if ($PC_description_PostReplace.count -gt 2)
	                    {
                            #DESCRIPTION HAS INCORRECT FORMAT
	                        #---User might still have a chance to be found from description
	                        
                            #START SECOND LAYER FIND USER FROM DESCRIPTION-----------------------
	                        $Username_from_PC_Desc = "$($PC_description_PostReplace[1])"
	                        if ($Username_from_PC_Desc)
	                        {
                                #SUBSTRING BETWEEN FIRST AND SECOND "-" IN DESCRIPTION IS NOT NULL
	                            if($Username_from_PC_Desc.trim())
	                            {
	                                #SUBSTRING BETWEEN FIRST AND SECOND "-" IN DESCRIPTION IS NOT EMPTY STRING
	                                $Username_from_PC_Desc = $Username_from_PC_Desc.trim()
	                            }
	                            else
	                            {
	                                #SUBSTRING BETWEEN FIRST AND SECOND "-" IN DESCRIPTION IS EMPTY STRING
	                                $Username_from_PC_Desc = $null
	                            }
	                        }
	                        else
	                        {
	                            #SUBSTRING BETWEEN FIRST AND SECOND "-" IN DESCRIPTION IS NULL
	                            $Username_from_PC_Desc = "$($PC_description_PostReplace[2])"
	                        }
                            #END SECOND LAYER FIND USER FROM DESCRIPTION-----------------------

                            #START THIRD LAYER FIND USER FROM DESCRIPTION-----------------------
	                        $MainForm.Text = 'Validating Description has user in it...'
	                        if ($Username_from_PC_Desc)
	                        {
                                #SUBSTRING AFTER SECOND "-" IN DESCRIPTION IS NOT NULL
	                            if($Username_from_PC_Desc.trim())
	                            {
                                    #SUBSTRING AFTER SECOND "-" IN DESCRIPTION IS NOT EMPTY STRING
                                    $MainForm.Text = 'Setting User from description...'
	                                $Username_from_PC_Desc = $Username_from_PC_Desc.trim()
	                            }
	                            else
	                            {
                                    #SUBSTRING AFTER SECOND "-" IN DESCRIPTION IS EMPTY STRING
                                    $MainForm.Text = 'Setting User Assigned...'
	                                $Username_from_PC_Desc = $null
	                                $out_User_Assigned = "Could not find User from PC AD description"
                                    $out_User_Email = ""
                                    $out_user_id = ""
	                            }
	                        }
	                        else
	                        {
	                            #SUBSTRING AFTER SECOND "-" IN DESCRIPTION IS NULL
                                $MainForm.Text = 'Setting User Assigned...'
	                            $out_User_Assigned = "Could not find User from PC AD description"
                                $out_User_Email = ""
                                $out_user_id = ""
	                        }
	                    }
	                    else
	                    {
	                        #DESCRIPTION IS CORRECT FORMAT
                            $MainForm.Text = 'Setting User from description...'
	                        $Username_from_PC_Desc = "$($PC_description_PostReplace[1])"
	                    }
	                }
	                else
	                {
                        #DESCRIPTION IS NOT LIKE "* - *"
                        if($PC_description_PostReplace -like "*NEW*unassigned*")
                        {
                            #DESCRIPTION MATCHES UNASSIGNED COMPUTER
                            $PC_description_PostReplace = $PC_description_PostReplace.replace('+', '*')
                            $PC_Description = $PC_description_PostReplace
                            $out_User_Assigned = "Unassigned"
                        }
                        else
                        {
                            #DESCRIPTION DOESNT MATCH UNASSIGNED COMPUTER
                            $PC_Description = "PC AD Description doesnt contain proper format ('* - *')"
                            $out_User_Assigned = "PC AD Description doesnt contain proper format ('* - *')"
                        }
                        $MainForm.Text = 'Setting User Assigned...'
	                    $out_user_id = ""
                        $out_User_Email = ""
	                }
	            }
	            else
	            {
                    #DESCRIPTION IS AN EMPTY STRING
                    $MainForm.Text = 'Setting User Assigned...'
	                $out_User_Assigned = "Computer AD Description is empty string"
                    $out_User_Email = ""
                    $out_user_id = ""
	                $PC_Description = "Computer AD Description is empty string"
	            }
	        }
	        else
	        {
                #DESCRIPTION IS NOT A STRING
                $MainForm.Text = 'Setting User Assigned...'
	            $out_User_Assigned = "Computer AD Description is wrong data type"
                $out_User_Email = ""
                $out_user_id = ""
	            $PC_Description = "Computer AD Description is wrong data type"
	        }

            $MainForm.Text = 'Validating User...'
            if($PSUser)
            {
                #USER OBJECT IS NOT NULL
	            if($($PSUser.MI))
	            {
                    #USER MIDDLE INITIAL IS NOT NULL
	                if (!($($PSUser.MI).Trim()))
	                {
                        #USER MIDDLE INITIAL IS NOT EMPTY STRING
                        $MainForm.Text = 'Setting User Assigned...'
	                    $out_User_Assigned = $($PSUser.FirstName) + " " + $($PSUser.LastName)
                        $out_User_Email = $($PSUser.Email)
                        $out_user_id = $($PSUser.ID)
	                }
	                else
	                {
                        #USER MIDDLE INITIAL IS EMPTY STRING
                        $MainForm.Text = 'Setting User Assigned...'
	                    $out_User_Assigned = $($PSUser.FirstName) + " " + $($PSUser.MI) + " " + $($PSUser.LastName)
                        $out_User_Email = $($PSUser.Email)
                        $out_user_id = $($PSUser.ID)
	                }
	            }
	            else
	            {
                    #USER MIDDLE INITIAL IS NULL
                    $MainForm.Text = 'Setting User Assigned...'
	                $out_User_Assigned = $($PSUser.FirstName) + " " + $($PSUser.LastName)
                    $out_User_Email = $($PSUser.Email)
                    $out_user_id = $($PSUser.ID)
                }
            }
            else
            {
                #USER OBJECT IS NULL
                $MainForm.Text = 'Setting User Assigned...'
                $out_User_Assigned= "Could not find User from PC AD description"
                $out_User_Email = ""
                $out_user_id = ""
            }
	    }
	    else
	    {
            #DESCRIPTION IS NULL, NO ATTEMPT TO FIND USER MADE
            $MainForm.Text = 'Setting User Assigned...'
	        $out_User_Assigned = "Could not find User from PC AD description"
            $out_User_Email = ""
            $out_user_id = ""
	        $PC_Description = "No AD Description"
	    }
        $out_PC_Description = $PC_description

        if($out_PC_Name)
        {
            # GET HOSTNAME FROM IP ADDRESS ---------------
            $MainForm.Text = "Getting IP Address From Hostname..."
            $OldErrorAction = $ErrorActionPreference
            $ErrorActionPreference = "silentlycontinue"
            try
            {
                $out_PC_IP = [System.Net.Dns]::GetHostAddresses("$out_PC_Name").IPAddressToString
            }
            catch
            {
                $out_PC_IP = $null
            }

            if($out_PC_IP)
            {
                # MAKE SURE IP ADDRESS WAS RETURNED
                $out_PC_IP = ExtractValidIPAddress "$out_PC_IP"
                if(!($out_PC_IP))
                {
                    #NO VALID IPv4 Address found in out_PC_IP
                    $out_PC_IP = "No Valid IP Address Found"
                    #IP ADDRESS CALLS CAN NOT BE USED
                    $Script:IPReady = $false
                }
                else
                {
                    #VALID IPv4 Address found in out_PC_IP
                    Setup-IP-Invoke($out_PC_IP)
                    #IP ADDRESS CALLS CAN BE USED
                    $Script:IPReady = $true
                    #SET DEFAULT AS IP ADDRESS
                    $PC_Name = $out_PC_IP
                }
            }
            else
            {
                # GetHostAddresses returned NULL

                #IP ADDRESS CALLS CAN NOT BE USED
                $Script:IPReady = $false
            }
            $ErrorActionPreference = $OldErrorAction
        }
        else
        {
            $Script:IPReady = $false
        }
        #----------------- MARKER PC NAME IS DONE PROCESSING ------------------------------

        if($Script:IPReady -eq $false)
        {
            #SET DEFAULT TO COMPUTER NAME
            $PC_Name = $out_PC_Name
        }
        else
        {
            $PC_Name = $out_PC_IP
        }
        
        #------------------- USER AND PC ARE DONE PROCESSING ------------------------
        if (!($out_user_id))
        {
            $scriptroot = $(((get-item $psscriptroot).parent).fullname)
            Get-Background-info -Computer $out_PC_Name -UserID "NONE" -ScriptRoot $scriptroot
        }
        else
        {
            $scriptroot = $(((get-item $psscriptroot).parent).fullname)
            Get-Background-info -Computer $out_PC_Name -UserID $out_user_id -scriptroot $scriptroot
        }
        

	    if($isOnline -eq $false)
	    {
            $MainForm.Text = 'Testing if PC is Online...'
            if($PC_Name)
            {
	            $isOnline = (((Test-IsOnline $PC_Name).online) -eq $true)
            }
            else
            {
                $isonline = $false
            }
            $MainForm.Text = 'Setting online status of pc...'
	    }
	
	     if($isOnline -eq $true)
	    {
            #GET MODEL-----------------------------------------------------
            $MainForm.Text = 'Getting Model from WMI...'
	        $objModel = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $PC_Name -Credential $Script:Credentials
            $MainForm.Text = 'Verifying Model returned...'
	        if($objModel)
	        {
                $MainForm.Text = 'Filtering based on Model...'
	            $PC_Model = (Get-PC-Model($objModel))
	            if($PC_Model)
	            {
                    #GET-PC-MODEL FUNCTION RETURNED VALUES
                    $MainForm.Text = 'Setting Model...'
	                if($PC_Model.ErrorMsg)
	                {
                        #GET-PC-MODEL FUNCTION RETURNED VALUES INCLUDE ERRORS
                        $MainForm.Text = 'Setting Model...'
	                    $out_PC_Model = $PC_Model.ErrorMsg
	                }
	                else
	                {
                        #GET-PC-MODEL FUNCTION RETURNED NO ERRORS
                        $MainForm.Text = 'Setting Model...'
	                    $out_PC_Model = $PC_Model.Model
                        $tbx_PC_Model.backcolor = $tbx_PC_AD_Desc.backcolor
                        if($PC_Model.warning)
                        {
                            #GET-PC-MODEL RETURNED WARNING FOR MODEL
                            $out_PC_Model = "$($PC_Model.model) ($($PC_Model.warning))"
                            if($PC_Model.warningcolor -ne [System.drawing.color]::White)
                            {
                                #SET COLOR OF MODEL TEXTBOX TO WARNING COLOR RETURNED
                                $tbx_PC_Model.backcolor = $PC_Model.warningcolor
                            }
    	                }	
	                }	
	            }
	            else
	            {
                    #GET-PC-MODEL FUNCTION RETURNED NULL
                    $MainForm.Text = 'Setting Model...'
	                $out_PC_Model = "Couldn't get Model"
	            }
	        }
	        else
	        {
                #WMI FUNCTION COULDN"T FIND MODEL
                $MainForm.Text = 'Setting Model...'
	            #write-debug "[FAILURE] SEARCH-BY-PC - Get-WmiObject Win32_ComputerSystem returned null value"
	            $out_PC_Model = "Couldn't get Model From PC"
	        }
            #END GET MODEL -----------------------------------------------------

            #START GET WINDOWS VERSION---------------------------------------------
            $MainForm.Text = 'Getting Windows Version info from WMI...'
	        $winver = Get-WinVer -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Windows Version info returned...'
	        if($winver)
	        {
                #WINDOWS VERSION RETURNED FROM WMI NOT NULL
	            if($winver.ErrorMsg)
	            {
                    #WINDOWS VERSION RETURNED FROM WMI HAD ERROR
                    $MainForm.Text = 'Setting Windows Version...'
	                $out_winver = $winver.Errormsg
	            }
	            else
	            {
                    #WINDOWS VERSION RETURNED FROM WMI HAD NO ERRORS
                    $MainForm.Text = 'Setting Windows Version...'
	                $out_winver = $winver.output
	            }
	        }
	        else
	        {
                #WINDOWS VERSION RETURNED FROM WMI NULL
                $MainForm.Text = 'Setting Windows Version...'
	            $out_winver = "Couldn't Get Windows Version"
	        }
            #END GET WINDOWS VERSION---------------------------------------------
            
            #START GET CIM SNAPSHOT/HOSTNAME --------------------------------------------------------
	        $MainForm.Text = 'Getting System info from CIM Instance...'
	        $OSBase = Get-WmiObject -Class win32_operatingsystem -ComputerName $PC_Name -Credential $Script:Credentials | select csname, freephysicalmemory, freevirtualmemory
            $MainForm.Text = 'Validating System info returned...'
	        if($OSBase)
	        {
                #CIM RETURNED NOT NULL

                #START LAST PC NAME VALIDATION ------------------------------------
	            if($($OSBase.csname))
	            {
                    #CIM CSNAME NOT NULL
                    $MainForm.Text = 'Setting PC Name from returned csname...'

                    #(MOST TRUSTWORTHY DATA IS THE SOURCE)
	                $out_PC_Name = "$($OSBase.csname)"
	            }
                else
                {
                    #OVERRIDE CODE IF CANT GET CSNAME HERE
                }
                #END LAST PC NAME VALIDATION ------------------------------------

                #START SNAPSHOT INFO ----------------------------------------------------
	            $MainForm.Text = 'Formatting Snapshot info...'
	            [double]$FreeRam = "{0:N2}" -f ($($OSBase.freephysicalmemory / 1mb))
	            [double]$FreeVirt = "{0:N2}" -f ($($OSBase.freevirtualmemory / 1mb))

	            if($FreeRam)
	            {
                    #FREE PHYSCIAL RAM IS NOT NULL
                    $MainForm.Text = 'Setting Free Ram info...'
	                $out_FreeRam = "$FreeRam GB"
	            }
	            else
	            {
                    #FREE PHYSCIAL RAM IS NULL
                    $MainForm.Text = 'Setting Free Ram info...'
	                $out_FreeRam = "Couldn't get Free Ram"
	            }

	            if($FreeVirt)
	            {
                    #FREE VIRTUAL RAM IS NOT NULL
                    $MainForm.Text = 'Setting Free Vitural memory info...'
	                $out_FreeVirt = "$FreeVirt GB"
	            }
	            else
	            {
                    #FREE VIRTUAL RAM IS NULL
                    $MainForm.Text = 'Setting Free Vitural memory info...'
	                $out_FreeVirt = "Couldn't get Free Virt"
	            }
                
                #END SNAPSHOT INFO ----------------------------------------------------

	        }
	        else
	        {
                $MainForm.Text = 'Setting Snapshot info...'
	            $out_FreeRam = "Couldn't get Free Ram"
	            $out_FreeVirt = "Couldn't get Free Virt"
	        }
            #END GET CIM SNAPSHOT/HOSTNAME --------------------------------------------------------

            #START GET WMI GRAPHICS INFO --------------------------------------------------------
	        $MainForm.Text = 'Getting Graphics info from WMI...'
            if($PC_Name -like "WIVGP*")
            {
                #SKIP VDI GRAPHICS (adds time and not necessary)
	            $out_GfxDriver = "VDI Graphics Skipped"
            }
            else
            {
                #NON VDI GRAPHICS
                $MainForm.Text = 'Getting Video Controller info from WMI...'
                $VideoControllerName = (Get-WmiObject win32_videocontroller -ComputerName $PC_Name -Credential $Script:Credentials | select caption).caption
                if ($videoControllerName)
                {
                    #WMI WIN_32VIDEOCONTROLLER RETURNED NOT NULL VALUE
                    $GfxDriver = $VideoControllerName
                }
                else
                {
                    #WMI WIN_32VIDEOCONTROLLER RETURNED NULL VALUE
                    $GfxDriver = "Couldn't get Graphics Info"
                }
                $out_GfxDriver = $GfxDriver
            }
            $out_GfxVer = "Not Initially Loaded" #Getting Graphics Version added fair amount of time to loading so its been subsidized to a load on button click
            #END GET WMI GRAPHICS INFO --------------------------------------------------------

            #START GET QUERY USERS --------------------------------------------------------
                #(CODE MODIFIED/ADAPTED FROM PRE-EXISTING DUE TO LACK OF quser.exe KNOWLEDGE)
            $MainForm.Text = 'Getting User Sessions info from query users...'
	        $quserOut = quser.exe /SERVER:$PC_Name 2>&1
	        $out_User_Sessions = @()
	        if ($quserOut -match "No user exists")
	        {
                #NO USERS FROM QUERY
	            $nousers = $true
	        }
	        $MainForm.Text = 'Formating User Sessions info...'
	        $users = $quserOut -replace '\s{2,}', ',' |
	        ConvertFrom-CSV -Header 'username', 'sessionname', 'id', 'state', 'idleTime', 'logonTime' |
	        Add-Member -MemberType NoteProperty -Name ComputerName -Value $PC_Name -PassThru
	        $users = $users[1..$users.count]
	        for ($i = 0; $i -lt $users.count; $i++)
	        {
	            if ($users[$i].sessionname -match '^\d+$')
	            {
	                $users[$i].logonTime = $users[$i].idleTime
	                $users[$i].idleTime = $users[$i].STATE
	                $users[$i].STATE = $users[$i].ID
	                $users[$i].ID = $users[$i].SESSIONNAME
	                $users[$i].SESSIONNAME = $null
	            }
	
	            # cast the correct datatypes
	            $users[$i].ID = [int]$users[$i].ID
	
	            $idleString = $users[$i].idleTime
	            if ($idleString -eq '.') { $users[$i].idleTime = 0 }
	
	            # if it's just a number by itself, insert a '0:' in front of it. Otherwise [timespan] cast will interpret the value as days rather than minutes
	            if ($idleString -match '^\d+$')
	            {
                    $users[$i].idleTime = "0:$($users[$i].idleTime)"
                }
	            
	            # if it has a '+', change the '+' to a colon and add ':0' to the end
	            if ($idleString -match "\+")
	            {
	                $newIdleString = $idleString -replace "\+", ":"
	                $newIdleString = $newIdleString + ':0'
	                $users[$i].idleTime = $newIdleString
	            }

	            if($users[$i].idleTime -ne "none")
	            {
	                $users[$i].idleTime = [timespan]$users[$i].idleTime
	            }
	            $users[$i].logonTime = [datetime]$users[$i].logonTime
	        }
	        $users = $users | Sort-Object -Property idleTime

            $MainForm.Text = 'Setting User Sessions info...'
	        Try
	        {
                #TRY ADDING $users TO ARRAY
	            $out_User_Sessions += $users
	        }
	        catch
	        {
                #CANT ADD $users TYPE TO ARRAY, SETTING VAR TO $users INSTEAD
	            $out_User_Sessions = $users
	        }
            #END GET QUERY USERS --------------------------------------------------------

            #START GET CURRENT USER-----------------------------------------------------
            $MainForm.Text = 'Getting Current user info from WMI...'
            $PC_CurrentUser = Get-WMIObject -class Win32_ComputerSystem -ComputerName $PC_Name -Credential $Script:credentials | select username
            $MainForm.Text = 'Validating Current user info returned...'
	        if ($PC_CurrentUser)
	        {
                #WMI RETURNED NOT NULL
	            if ($PC_CurrentUser.username)
	            {
                    #USERNAME IS NOT NULL
                    $MainForm.Text = 'Formating Username...'
	                [string]$strPC_CurrentUser = $PC_CurrentUser.username.toString()
	                $out_PC_CurrentUserSSO = $strPC_CurrentUser.Replace("AFII\", "")
                    $MainForm.Text = 'Getting Users Full Name by username...'
	                $out_PC_CurrentUserName = (FindUsersFullname-By-Username -userin $out_PC_CurrentUserSSO)
	                if (!($out_PC_CurrentUserName.errormsg))
	                {
                        #FINDUSERSFULLNAME-BY-USERNAME FUNCTION RETURNED ERROR
                        $MainForm.Text = 'Setting current user...'
	                    $out_PC_CurrentUserName = $out_PC_CurrentUserName.output
	                }
	                else
	                {
                        #FINDUSERSFULLNAME-BY-USERNAME FUNCTION RETURNED NO ERRORS
                        $MainForm.Text = 'Setting current user...'
	                    $out_PC_CurrentUserName = $out_PC_CurrentUserName.errormsg
	                }
	                $User_FromConnectedPC = $true
	            }
	            else
	            {
                    #USERNAME IS NULL
	                $User_FromConnectedPC = $false
	            }
	        }
	        else
	        {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting current user...'
	            $out_PC_CurrentUserSSO = "No Current Users Found"
	            $out_PC_CurrentUserName = "No Current Users Found"
	        }
            #END GET CURRENT USER-----------------------------------------------------

            #START GET BIOS-----------------------------------------------------------
            $MainForm.Text = 'Getting Bios info from WMI...'
	        $OS = Get-WmiObject Win32_bios -ComputerName $PC_Name -Credential $Script:Credentials
            $MainForm.Text = 'Validating Bios info returned...'
	        if ($OS)
	        {
                #WMI RETUNED NOT NULL
	            $Bios_Ver = $($OS.SMBIOSBIOSVersion)
	            if($Bios_Ver)
	            {
                    #SMBIOSBIOSVERISON IS NOT NULL
                    $MainForm.Text = 'Setting Bios info...'
	                $out_Bios_Ver = $Bios_Ver
	            }
	            else
	            {
                    #SMBIOSBIOSVERSION IS NULL
                    $MainForm.Text = 'Setting Bios info...'
	                $out_Bios_Ver = "Couldn't Retreive Bios"
	            }
	        }
	        else
	        {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting Bios info returned...'
	            $out_Bios_Ver = "Couldn't Retreive Bios"
	        }
            #END GET BIOS-----------------------------------------------------------
            
            #START GET RAM AMOUNT (GB)-----------------------------------------------
            $MainForm.Text = 'Getting Ram amount info from WMI...'
            $arryRamModules = @()
            #$PC_Ram_Amount_GB = (Get-WMIObject -class Win32_PhysicalMemory -computername $PC_Name -Credential $Script:Credentials | Measure-Object -Property capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
            $PC_Ram_Amount_GB = (Get-WMIObject -class Win32_PhysicalMemory -computername $PC_Name -Credential $Script:Credentials | %{$arryRamModules += [Math]::Round(($_.capacity / 1GB), 2)}); foreach($i in $arryRamModules){$PC_Ram_Amount_GB += $i}
            $MainForm.Text = 'Validating Ram amount info...'
            if ($PC_Ram_Amount_GB)
            {
                #WMI RETURNED NOT NULL
                $MainForm.Text = 'Setting Ram amount info...'
                $strRamModules = ""
                if($arryRamModules.count -gt 1)
                {
                        $ramgrid = $arryRamModules |Group-object -noelement
                        $ramcount = 0
                        foreach($count in $ramgrid){$ramcount = $ramcount + 1}
                        if($ramcount -gt 1)
                        {
                            # multiple different rams in pc
                            foreach($i in $($ramgrid)){$strRamModules += " ($($i.count) X $($i.name) GB)"}

                        }
                        else
                        {
                            #same type of ram
                            $strRamModules = " ($($ramgrid.count) X $($ramgrid.name) GB)"
                        }   
                }
                $out_PC_Ram_Amount = "$PC_Ram_Amount_GB GB" + $strRamModules
            }
            else
            {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting Ram amount info...'
                $out_PC_Ram_Amount = "Couldn't get RAM info"
            }
            #END GET RAM AMOUNT (GB)-----------------------------------------------

            #START GET LAST LOGIN EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Login Event from WMI...'
	        $PC_LastUserLogon_Timestamp = Get-LastloginTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Login Event from WMI...'
	        if($PC_LastUserLogon_Timestamp.Errormsg)
	        {
                #GET-LASTLOGINTIME FUNCTION RETURNED ERROR
                $MainForm.Text = 'Setting Last Login Event from WMI...'
	            $out_PC_LastUserLogon_Timestamp = $PC_LastUserLogon_Timestamp.Errormsg
                $out_PC_Session_Length = $out_PC_LastUserLogon_Timestamp.Errormsg
	        }
	        else
	        {
                #GET-LASTLOGINTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Login Event from WMI...'
	            $out_PC_LastUserLogon_Timestamp = $PC_LastUserLogon_Timestamp.output
                $out_PC_Session_Length = ((Convert-To-TimeFromOccurance -time $($PC_LastUserLogon_Timestamp.output)).output)
	        }
            #END GET LAST LOGIN EVENT -----------------------------------------------
	        
            #START GET LAST BOOT EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Boot Event from WMI...'
	        $PC_LastBoot_Time = Get-LastbootupTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Boot Event from WMI...'
	        if($PC_LastBoot_Time.Errormsg)
	        {
                #GET-LASTBOOTUPTIME FUNCTION RETURNED ERRORS
                $MainForm.Text = 'Setting Last Boot Event from WMI...'
	            $out_PC_LastBoot_Time = $PC_LastBoot_Time.Errormsg
	            $out_PC_Time_Since_LastBoot = $out_PC_LastBoot_Time
	        }
	        else
	        {
                #GET-LASTBOOTUPTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Boot Event from WMI...'
                $out_PC_LastBoot_Time = $PC_LastBoot_Time.output
	            $out_PC_Time_Since_LastBoot = ((Convert-To-TimeFromOccurance -time $($PC_LastBoot_Time.output)).output)
	        }
            #END GET LAST BOOT EVENT -----------------------------------------------
	
            #START GET LAST REBOOT EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Reboot Event from WMI...'
	        $PC_LastReboot_Time = Get-LastRebootInitiatedTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Reboot Event from WMI...'
	        if($PC_LastReboot_Time.Errormsg)
	        {
                #GET-LASTREBOOTINITIATEDTIME FUNCTION RETURNED ERRORS
                $MainForm.Text = 'Setting Last Reboot Event from WMI...'
	            $out_PC_LastReboot_Time = $PC_LastReboot_Time.Errormsg
	        }
	        else
	        {
                #GET-LASTREBOOTINITIATEDTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Reboot Event from WMI...'
	            $out_PC_LastReboot_Time = ((Convert-To-TimeFromOccurance -time $($PC_LastReboot_Time.output)).output)
	        }
            #END GET LAST REBOOT EVENT -----------------------------------------------

            #START GET REBOOT PENDING --------------------------------------------------
            $MainForm.Text = 'Getting Reboot Pending from WMI...'
	        $out_rebootPending = (Invoke-WmiMethod -ComputerName $PC_Name -Namespace root\ccm\clientsdk -Class CCM_ClientUtilities -Name DetermineIfRebootPending).RebootPending
            $MainForm.Text = 'Validating Reboot pending info...'
	        if ($out_rebootPending -eq $null)
	        {
                #WMI RETURNED NOT NULL
                $MainForm.Text = 'Setting Reboot pending info...'
	            $out_RebootPending = "Couldn't Contact Computer"
	        }
            #END GET REBOOT PENDING --------------------------------------------------
	    }
        else
        {
            #isOnline is false

            $MainForm.Text = 'Setting vars on no connection...'
	        $out_PC_Time_Since_LastBoot = "Couldn't Contact Computer"
	        $out_rebootPending = "Couldn't Contact Computer"
	        $out_PC_LastReboot_Time = "Couldn't Contact Computer"
	        $out_PC_LastUserLogon_Timestamp = "Couldn't Contact Computer"
	        $out_Bios_Ver = "Couldn't Contact Computer"
	        $out_PC_CurrentUserSSO = "Couldn't Contact Computer"
	        $out_PC_CurrentUserName = "Couldn't Contact Computer"
	        $out_User_Sessions = "Couldn't Contact Computer"
	        $out_FreeRam = "Couldn't Contact Computer"
	        $out_FreeVirt = "Couldn't Contact Computer"
	        $out_GfxVer = "Couldn't Contact Computer"
	        $out_GfxDriver = "Couldn't Contact Computer"
	        $out_winver = "Couldn't Contact Computer"
	        $out_PC_Model = "Couldn't Contact Computer"
            $out_PC_Ram_Amount = "Couldn't Contact Computer"
            $out_PC_Session_Length = "Couldn't Contact Computer"
        }

        if($nousers -eq $true)
        {
            $MainForm.Text = 'Setting vars on current users...'
            $out_PC_CurrentUserSSO = "No Users Currently Logged in"
	        $out_PC_CurrentUserName = "No Users Currently Logged in"
        }
	    if(!($out_User_Sessions))
	    {
	        $properties = @{'username' = "Couldn't Get Sessions";
	                        'SESSIONNAME' = "Couldn't Get Sessions";
	                        'STATE' = "Couldn't Get Sessions";
	                        'idleTime' = "Couldn't Get Sessions";
	                        'logonTime' = "Couldn't Get Sessions";
                            }
	        $out_User_Sessions = New-Object �TypeName PSObject �Prop $properties
	    }
    
        #START SET TEXTBOX VISIBILITY -------------------------------
        $tbx_PC_AD_Desc.Visible = $true
        $tbx_User_AD_Name.visible = $true
        $tbx_User_AD_ID.Visible = $true
        $lbl_User_AD_ID.Visible = $true
        $tbx_User_AD_Email.Visible = $true
        $lbl_User_AD_Email.Visible = $true
        #PC INFO
        $tbx_PC_Name.Visible = $true
        $tbx_PC_IP.Visible = $True
        $lbl_PC_IP.Visible = $True
        $tbx_PC_Model.Visible = $true
        $tbx_PC_LastRestart_Time.Visible = $true
        $tbx_PC_Gfx_Driver.Visible = $true
        $tbx_PC_Gfx_Ver.Visible = $true
        $tbx_PC_Bios_Ver.Visible = $true
        $tbx_PC_Win_Ver.Visible = $true
        $tbx_PC_Ram_Amount.Visible = $true
        #Snapshot
        $tbx_PC_FreeRam.Visible = $true
        $tbx_PC_FreeVirtMem.Visible = $true
        #Current Users
        $tbx_PC_User_SSO.Visible = $true
        $tbx_PC_User_Name.Visible = $true
        #Current Sessions
        $tbx_PC_Session_UserName.Visible = $true
        $tbx_PC_Session_Type.Visible = $true
        $tbx_PC_Session_State.Visible = $true
        $tbx_PC_Session_IdleTime.Visible = $true
        $tbx_PC_Session_LogonTime.Visible = $true
        #MISC Info
        $tbx_Misc_Last_LoginTime.Visible = $true
        $tbx_Misc_User_Session_Length.Visible = $true
        $tbx_Misc_PC_RebootPending.Visible = $true
        #Service-now info
        $tbx_SN_PC_Asset_Function.Visible = $true
        $tbx_SN_PC_Substate.Visible = $true
        $tbx_SN_PC_State.Visible = $true
        $tbx_SN_User_Dept.Visible = $true
        $tbx_SN_User_Location.Visible = $true
        $tbx_SN_User_Assigned.Visible = $true
        #Meraki Info
        $tbx_Meraki_IP.Visible = $true
        $tbx_Meraki_User_Address.Visible = $true
        $tbx_Meraki_Serial.Visible = $true
        Set-Display-Controls
        #END SET TEXTBOX VISIBILITY -------------------------------
    
        #START SET TEXTBOX VALUES -------------------------------
	    #AD INFO
        $MainForm.Text = 'Setting form objects...'
        $MainForm.Text = 'Updating AD Info Textboxes'
        $tbx_PC_AD_Desc.text = $out_PC_description 
        $tbx_User_AD_Name.text = $out_User_Assigned
        $tbx_User_AD_Email.text = $out_User_Email
        $tbx_User_AD_ID.text = $out_User_ID
        #PC INFO
        $tbx_PC_Name.text = $out_PC_Name
        $tbx_PC_IP.text = $out_PC_IP
        $MainForm.Text = 'Updating PC Info Textboxes'
        $tbx_PC_Model.text = $out_PC_Model
        $tbx_PC_LastBoot_Time.text = $out_PC_Time_Since_LastBoot
        $tbx_PC_LastRestart_Time.text = $out_PC_LastReboot_Time
        $tbx_PC_Gfx_Driver.text = $out_GfxDriver
        $tbx_PC_Gfx_Ver.text = $out_GfxVer
        $tbx_PC_Bios_Ver.text = $out_Bios_Ver
        $tbx_PC_Win_Ver.text = $out_winver
        $tbx_PC_Ram_Amount.text = $out_PC_Ram_Amount
        #Snapshot
        $MainForm.Text = 'Updating Snapshot Textboxes'
        $tbx_PC_FreeRam.text = $out_FreeRam
        $tbx_PC_FreeVirtMem.text = $out_FreeVirt
        #Current Users
        $tbx_PC_User_SSO.text = $out_PC_CurrentUserSSO
        $tbx_PC_User_Name.text = $out_PC_CurrentUserName
        #Current Sessions
	    $MainForm.Text = 'Updating Session Textboxes'
        $tbx_PC_Session_UserName.text = $out_User_Sessions.username
        $tbx_PC_Session_Type.text = $out_User_Sessions.SESSIONNAME
        $tbx_PC_Session_State.text = $out_User_Sessions.STATE
        $tbx_PC_Session_IdleTime.text = $out_User_Sessions.idleTime
        $tbx_PC_Session_LogonTime.text = $out_User_Sessions.logonTime
        #MISC Info
        $MainForm.Text = 'Updating MISC Textboxes'
        $tbx_Misc_Last_LoginTime.text = $out_PC_LastUserLogon_Timestamp
        $tbx_Misc_User_Session_Length.text = $out_PC_Session_Length
        $tbx_Misc_PC_RebootPending.text = $out_rebootPending
        #END SET TEXTBOX VALUES -------------------------------
        $MainForm.Text = 'Done!'
	}
	else
	{
        $MainForm.Text = $Param_ErrorMsg
	}
}

Function Search-By-IP-Refresh
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	[CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

    #START BOOL SETUP-----------------------------
    $MainForm.Text = 'Setting Up Bools...'
    $isOnline = $false
    $User_FromConnectedPC = $false
    $descfailed = $false
    $nousers = $false
    $Script:IPReady = $false
    $Script:PC_Name_Failed = $false
    #END BOOL SETUP-----------------------------



	# Filter failed input to return errormsg and null output
    $MainForm.Text = 'Checking for parameter errors...'
	if(!($Param_ErrorMsg))
	{
        #TEST IF PC IS IP ADDRESS OR HOSTNAME
        $MainForm.Text = 'Check if IP Address...'

        #OLD METHOD
	    #$isIPaddress = (Check-If-IP -computername $Computername).output
	    #if ($isIPAddress -eq $false)

        $out_PC_IP = $null
        $out_PC_IP = ExtractValidIPAddress "$Computername"

            #-------------------- INPUT WAS IP ADDRESS --------------------------
            #INPUT VAR: $computername
            $MainForm.Text = 'Setting up IP Invoke Trusted Host settings...'
            Setup-IP-Invoke($out_PC_IP)
            $Script:LastSearchBY = "IP"
            $Script:LastSearch = "$Computername"
            #IP ADDRESS CALLS CAN BE USED
            $Script:IPReady = $true
            #-------------------- END INPUT WAS IP ADDRESS --------------------------
        

        if($Script:LastSearchBY -eq "IP")
        {
            #SET PC_NAME TO INPUT IF INPUT WAS DETERMINED TO BE IP ADDRESS
            $PC_Name = $out_PC_IP
        }
        else
        {
            # INPUT WAS DETERMINED TO BE COMPUTERNAME
            if($Script:IPReady -eq $true)
            {
                #FINAL CHECK OF IP IS NOT NULL
                if($out_PC_IP)
                {
                    #VALID IP
                    #SET IP ADDRESS AS DEFAULT FOR REMOTE COMMANDS
                    $PC_Name = $out_PC_IP
                }
                else
                {
                    #CHECK IF PC NAME IS NULL
                    if($out_PC_Name)
                    {
                        #VALID NAME, INVALID IP
                        #SET PC NAME AS DEFAULT FOR REMOTE COMMANDS
                        $PC_Name = $out_PC_Name
                    }
                    else
                    {
                        #INVALID NAME AND IP
                        $PC_Name = $null
                    }
                }
            }
            else
            {
                #CHECK IF PC NAME IS NULL
                if($out_PC_Name)
                {
                    #VALID NAME, INVALID IP
                    #SET PC NAME AS DEFAULT FOR REMOTE COMMANDS
                    $PC_Name = $out_PC_Name
                }
                else
                {
                    #INVALID NAME AND IP
                    $PC_Name = $null
                }
            }
        }

        #------- BEGIN REMOTE COMMANDS ------------------------------------------------------
        #REMOTE PC VAR: $PC_Name
        
        if($PC_Name)
        {
            # $PC_Name IS EITHER VALID IP ADDRESS OR VALID COMPUTER NAME FOUND FROM AD

            $MainForm.Text = 'Testing if PC is online...'
	        if (((Test-IsOnline $PC_Name).online) -eq $true)
	        {
                
                #GET MODEL-----------------------------------------------------
            $MainForm.Text = 'Getting Model from WMI...'
	        $objModel = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $PC_Name -Credential $Script:Credentials
            $MainForm.Text = 'Verifying Model returned...'
	        if($objModel)
	        {
                $MainForm.Text = 'Filtering based on Model...'
	            $PC_Model = (Get-PC-Model($objModel))
	            if($PC_Model)
	            {
                    #GET-PC-MODEL FUNCTION RETURNED VALUES
                    $MainForm.Text = 'Setting Model...'
	                if($PC_Model.ErrorMsg)
	                {
                        #GET-PC-MODEL FUNCTION RETURNED VALUES INCLUDE ERRORS
                        $MainForm.Text = 'Setting Model...'
	                    $out_PC_Model = $PC_Model.ErrorMsg
	                }
	                else
	                {
                        #GET-PC-MODEL FUNCTION RETURNED NO ERRORS
                        $MainForm.Text = 'Setting Model...'
	                    $out_PC_Model = $PC_Model.Model
                        $tbx_PC_Model.backcolor = $tbx_PC_AD_Desc.backcolor
                        if($PC_Model.warning)
                        {
                            #GET-PC-MODEL RETURNED WARNING FOR MODEL
                            $out_PC_Model = "$($PC_Model.model) ($($PC_Model.warning))"
                            if($PC_Model.warningcolor -ne [System.drawing.color]::White)
                            {
                                #SET COLOR OF MODEL TEXTBOX TO WARNING COLOR RETURNED
                                $tbx_PC_Model.backcolor = $PC_Model.warningcolor
                            }
    	                }	
	                }	
	            }
	            else
	            {
                    #GET-PC-MODEL FUNCTION RETURNED NULL
                    $MainForm.Text = 'Setting Model...'
	                $out_PC_Model = "Couldn't get Model"
	            }
	        }
	        else
	        {
                #WMI FUNCTION COULDN"T FIND MODEL
                $MainForm.Text = 'Setting Model...'
	            #write-debug "[FAILURE] SEARCH-BY-PC - Get-WmiObject Win32_ComputerSystem returned null value"
	            $out_PC_Model = "Couldn't get Model From PC"
	        }
            #END GET MODEL -----------------------------------------------------

            #START GET WINDOWS VERSION---------------------------------------------
            $MainForm.Text = 'Getting Windows Version info from WMI...'
	        $winver = Get-WinVer -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Windows Version info returned...'
	        if($winver)
	        {
                #WINDOWS VERSION RETURNED FROM WMI NOT NULL
	            if($winver.ErrorMsg)
	            {
                    #WINDOWS VERSION RETURNED FROM WMI HAD ERROR
                    $MainForm.Text = 'Setting Windows Version...'
	                $out_winver = $winver.Errormsg
	            }
	            else
	            {
                    #WINDOWS VERSION RETURNED FROM WMI HAD NO ERRORS
                    $MainForm.Text = 'Setting Windows Version...'
	                $out_winver = $winver.output
	            }
	        }
	        else
	        {
                #WINDOWS VERSION RETURNED FROM WMI NULL
                $MainForm.Text = 'Setting Windows Version...'
	            $out_winver = "Couldn't Get Windows Version"
	        }
            #END GET WINDOWS VERSION---------------------------------------------
            
            #START GET CIM SNAPSHOT/HOSTNAME --------------------------------------------------------
	        $MainForm.Text = 'Getting System info from CIM Instance...'
	        $OSBase = Get-WmiObject -Class win32_operatingsystem -ComputerName $PC_Name -Credential $Script:Credentials | select csname, freephysicalmemory, freevirtualmemory
            $MainForm.Text = 'Validating System info returned...'
	        if($OSBase)
	        {
                #CIM RETURNED NOT NULL

                #START LAST PC NAME VALIDATION ------------------------------------
	            if($($OSBase.csname))
	            {
                    #CIM CSNAME NOT NULL
                    $MainForm.Text = 'Setting PC Name from returned csname...'

                    #(MOST TRUSTWORTHY DATA IS THE SOURCE)
	                $out_PC_Name = "$($OSBase.csname)"
	            }
                else
                {
                    #OVERRIDE CODE IF CANT GET CSNAME HERE
                }
                #END LAST PC NAME VALIDATION ------------------------------------

                #START SNAPSHOT INFO ----------------------------------------------------
	            $MainForm.Text = 'Formatting Snapshot info...'
	            [double]$FreeRam = "{0:N2}" -f ($($OSBase.freephysicalmemory / 1mb))
	            [double]$FreeVirt = "{0:N2}" -f ($($OSBase.freevirtualmemory / 1mb))
	            #[double]$FreePaging = "{0:N2}" -f ($($cim.freespaceinpagingfiles / 1mb)) #FREE PAGING FOUND TO BE UNNECESSARY

	            if($FreeRam)
	            {
                    #FREE PHYSCIAL RAM IS NOT NULL
                    $MainForm.Text = 'Setting Free Ram info...'
	                $out_FreeRam = "$FreeRam GB"
	            }
	            else
	            {
                    #FREE PHYSCIAL RAM IS NULL
                    $MainForm.Text = 'Setting Free Ram info...'
	                $out_FreeRam = "Couldn't get Free Ram"
	            }

	            if($FreeVirt)
	            {
                    #FREE VIRTUAL RAM IS NOT NULL
                    $MainForm.Text = 'Setting Free Vitural memory info...'
	                $out_FreeVirt = "$FreeVirt GB"
	            }
	            else
	            {
                    #FREE VIRTUAL RAM IS NULL
                    $MainForm.Text = 'Setting Free Vitural memory info...'
	                $out_FreeVirt = "Couldn't get Free Virt"
	            }
                
                #END SNAPSHOT INFO ----------------------------------------------------

	        }
	        else
	        {
                $MainForm.Text = 'Setting Snapshot info...'
	            $out_FreeRam = "Couldn't get Free Ram"
	            $out_FreeVirt = "Couldn't get Free Virt"
	        }
            #END GET CIM SNAPSHOT/HOSTNAME --------------------------------------------------------

            #START GET WMI GRAPHICS INFO --------------------------------------------------------
	        $MainForm.Text = 'Getting Graphics info from WMI...'
            if($PC_Name -like "WIVGP*")
            {
                #SKIP VDI GRAPHICS (adds time and not necessary)
	            $out_GfxDriver = "VDI Graphics Skipped"
            }
            else
            {
                #NON VDI GRAPHICS
                $MainForm.Text = 'Getting Video Controller info from WMI...'
                $VideoControllerName = (Get-WmiObject win32_videocontroller -ComputerName $PC_Name -Credential $Script:Credentials | select caption).caption
                if ($videoControllerName)
                {
                    #WMI WIN_32VIDEOCONTROLLER RETURNED NOT NULL VALUE
                    $GfxDriver = $VideoControllerName
                }
                else
                {
                    #WMI WIN_32VIDEOCONTROLLER RETURNED NULL VALUE
                    $GfxDriver = "Couldn't get Graphics Info"
                }
                $out_GfxDriver = $GfxDriver
            }
            $out_GfxVer = "Not Initially Loaded" #Getting Graphics Version added fair amount of time to loading so its been subsidized to a load on button click
            #END GET WMI GRAPHICS INFO --------------------------------------------------------

            #START GET QUERY USERS --------------------------------------------------------
                #(CODE MODIFIED/ADAPTED FROM PRE-EXISTING DUE TO LACK OF quser.exe KNOWLEDGE)
            $MainForm.Text = 'Getting User Sessions info from query users...'
	        $quserOut = quser.exe /SERVER:$PC_Name 2>&1
	        $out_User_Sessions = @()
	        if ($quserOut -match "No user exists")
	        {
                #NO USERS FROM QUERY
	            $nousers = $true
	        }
	        $MainForm.Text = 'Formating User Sessions info...'
	        $users = $quserOut -replace '\s{2,}', ',' |
	        ConvertFrom-CSV -Header 'username', 'sessionname', 'id', 'state', 'idleTime', 'logonTime' |
	        Add-Member -MemberType NoteProperty -Name ComputerName -Value $PC_Name -PassThru
	        $users = $users[1..$users.count]
	        for ($i = 0; $i -lt $users.count; $i++)
	        {
	            if ($users[$i].sessionname -match '^\d+$')
	            {
	                $users[$i].logonTime = $users[$i].idleTime
	                $users[$i].idleTime = $users[$i].STATE
	                $users[$i].STATE = $users[$i].ID
	                $users[$i].ID = $users[$i].SESSIONNAME
	                $users[$i].SESSIONNAME = $null
	            }
	
	            # cast the correct datatypes
	            $users[$i].ID = [int]$users[$i].ID
	
	            $idleString = $users[$i].idleTime
	            if ($idleString -eq '.') { $users[$i].idleTime = 0 }
	
	            # if it's just a number by itself, insert a '0:' in front of it. Otherwise [timespan] cast will interpret the value as days rather than minutes
	            if ($idleString -match '^\d+$')
	            {
                    $users[$i].idleTime = "0:$($users[$i].idleTime)"
                }
	            
	            # if it has a '+', change the '+' to a colon and add ':0' to the end
	            if ($idleString -match "\+")
	            {
	                $newIdleString = $idleString -replace "\+", ":"
	                $newIdleString = $newIdleString + ':0'
	                $users[$i].idleTime = $newIdleString
	            }

	            if($users[$i].idleTime -ne "none")
	            {
	                $users[$i].idleTime = [timespan]$users[$i].idleTime
	            }
	            $users[$i].logonTime = [datetime]$users[$i].logonTime
	        }
	        $users = $users | Sort-Object -Property idleTime

            $MainForm.Text = 'Setting User Sessions info...'
	        Try
	        {
                #TRY ADDING $users TO ARRAY
	            $out_User_Sessions += $users
	        }
	        catch
	        {
                #CANT ADD $users TYPE TO ARRAY, SETTING VAR TO $users INSTEAD
	            $out_User_Sessions = $users
	        }
            #END GET QUERY USERS --------------------------------------------------------

            #START GET CURRENT USER-----------------------------------------------------
            $MainForm.Text = 'Getting Current user info from WMI...'
            $PC_CurrentUser = Get-WMIObject -class Win32_ComputerSystem -ComputerName $PC_Name -Credential $Script:credentials | select username
            $MainForm.Text = 'Validating Current user info returned...'
	        if ($PC_CurrentUser)
	        {
                #WMI RETURNED NOT NULL
	            if ($PC_CurrentUser.username)
	            {
                    #USERNAME IS NOT NULL
                    $MainForm.Text = 'Formating Username...'
	                [string]$strPC_CurrentUser = $PC_CurrentUser.username.toString()
	                $out_PC_CurrentUserSSO = $strPC_CurrentUser.Replace("AFII\", "")
                    $MainForm.Text = 'Getting Users Full Name by username...'
	                $out_PC_CurrentUserName = (FindUsersFullname-By-Username -userin $out_PC_CurrentUserSSO)
	                if (!($out_PC_CurrentUserName.errormsg))
	                {
                        #FINDUSERSFULLNAME-BY-USERNAME FUNCTION RETURNED ERROR
                        $MainForm.Text = 'Setting current user...'
	                    $out_PC_CurrentUserName = $out_PC_CurrentUserName.output
	                }
	                else
	                {
                        #FINDUSERSFULLNAME-BY-USERNAME FUNCTION RETURNED NO ERRORS
                        $MainForm.Text = 'Setting current user...'
	                    $out_PC_CurrentUserName = $out_PC_CurrentUserName.errormsg
	                }
	                $User_FromConnectedPC = $true
	            }
	            else
	            {
                    #USERNAME IS NULL
	                $User_FromConnectedPC = $false
	            }
	        }
	        else
	        {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting current user...'
	            $out_PC_CurrentUserSSO = "No Current Users Found"
	            $out_PC_CurrentUserName = "No Current Users Found"
	        }
            #END GET CURRENT USER-----------------------------------------------------

            #START GET BIOS-----------------------------------------------------------
            $MainForm.Text = 'Getting Bios info from WMI...'
	        $OS = Get-WmiObject Win32_bios -ComputerName $PC_Name -Credential $Script:Credentials
            $MainForm.Text = 'Validating Bios info returned...'
	        if ($OS)
	        {
                #WMI RETUNED NOT NULL
	            $Bios_Ver = $($OS.SMBIOSBIOSVersion)
	            if($Bios_Ver)
	            {
                    #SMBIOSBIOSVERISON IS NOT NULL
                    $MainForm.Text = 'Setting Bios info...'
	                $out_Bios_Ver = $Bios_Ver
	            }
	            else
	            {
                    #SMBIOSBIOSVERSION IS NULL
                    $MainForm.Text = 'Setting Bios info...'
	                $out_Bios_Ver = "Couldn't Retreive Bios"
	            }
	        }
	        else
	        {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting Bios info returned...'
	            $out_Bios_Ver = "Couldn't Retreive Bios"
	        }
            #END GET BIOS-----------------------------------------------------------
            
            #START GET RAM AMOUNT (GB)-----------------------------------------------
            $MainForm.Text = 'Getting Ram amount info from WMI...'
            $arryRamModules = @()
            #$PC_Ram_Amount_GB = (Get-WMIObject -class Win32_PhysicalMemory -computername $PC_Name -Credential $Script:Credentials | Measure-Object -Property capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
            $PC_Ram_Amount_GB = (Get-WMIObject -class Win32_PhysicalMemory -computername $PC_Name -Credential $Script:Credentials | %{$arryRamModules += [Math]::Round(($_.capacity / 1GB), 2)}); foreach($i in $arryRamModules){$PC_Ram_Amount_GB += $i}
            $MainForm.Text = 'Validating Ram amount info...'
            if ($PC_Ram_Amount_GB)
            {
                #WMI RETURNED NOT NULL
                $MainForm.Text = 'Setting Ram amount info...'
                $strRamModules = ""
                if($arryRamModules.count -gt 1)
                {
                        $ramgrid = $arryRamModules |Group-object -noelement
                        $ramcount = 0
                        foreach($count in $ramgrid){$ramcount = $ramcount + 1}
                        if($ramcount -gt 1)
                        {
                            # multiple different rams in pc
                            foreach($i in $($ramgrid)){$strRamModules += " ($($i.count) X $($i.name) GB)"}

                        }
                        else
                        {
                            #same type of ram
                            $strRamModules = " ($($ramgrid.count) X $($ramgrid.name) GB)"
                        }   
                }
                $out_PC_Ram_Amount = "$PC_Ram_Amount_GB GB" + $strRamModules
            }
            else
            {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting Ram amount info...'
                $out_PC_Ram_Amount = "Couldn't get RAM info"
            }
            #END GET RAM AMOUNT (GB)-----------------------------------------------

            #START GET LAST LOGIN EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Login Event from WMI...'
	        $PC_LastUserLogon_Timestamp = Get-LastloginTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Login Event from WMI...'
	        if($PC_LastUserLogon_Timestamp.Errormsg)
	        {
                #GET-LASTLOGINTIME FUNCTION RETURNED ERROR
                $MainForm.Text = 'Setting Last Login Event from WMI...'
	            $out_PC_LastUserLogon_Timestamp = $PC_LastUserLogon_Timestamp.Errormsg
                $out_PC_Session_Length = $out_PC_LastUserLogon_Timestamp.Errormsg
	        }
	        else
	        {
                #GET-LASTLOGINTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Login Event from WMI...'
	            $out_PC_LastUserLogon_Timestamp = $PC_LastUserLogon_Timestamp.output
                $out_PC_Session_Length = ((Convert-To-TimeFromOccurance -time $($PC_LastUserLogon_Timestamp.output)).output)
	        }
            #END GET LAST LOGIN EVENT -----------------------------------------------
	        
            #START GET LAST BOOT EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Boot Event from WMI...'
	        $PC_LastBoot_Time = Get-LastbootupTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Boot Event from WMI...'
	        if($PC_LastBoot_Time.Errormsg)
	        {
                #GET-LASTBOOTUPTIME FUNCTION RETURNED ERRORS
                $MainForm.Text = 'Setting Last Boot Event from WMI...'
	            $out_PC_LastBoot_Time = $PC_LastBoot_Time.Errormsg
	            $out_PC_Time_Since_LastBoot = $out_PC_LastBoot_Time
	        }
	        else
	        {
                #GET-LASTBOOTUPTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Boot Event from WMI...'
                $out_PC_LastBoot_Time = $PC_LastBoot_Time.output
	            $out_PC_Time_Since_LastBoot = ((Convert-To-TimeFromOccurance -time $($PC_LastBoot_Time.output)).output)
	        }
            #END GET LAST BOOT EVENT -----------------------------------------------
	
            #START GET LAST REBOOT EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Reboot Event from WMI...'
	        $PC_LastReboot_Time = Get-LastRebootInitiatedTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Reboot Event from WMI...'
	        if($PC_LastReboot_Time.Errormsg)
	        {
                #GET-LASTREBOOTINITIATEDTIME FUNCTION RETURNED ERRORS
                $MainForm.Text = 'Setting Last Reboot Event from WMI...'
	            $out_PC_LastReboot_Time = $PC_LastReboot_Time.Errormsg
	        }
	        else
	        {
                #GET-LASTREBOOTINITIATEDTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Reboot Event from WMI...'
	            $out_PC_LastReboot_Time = ((Convert-To-TimeFromOccurance -time $($PC_LastReboot_Time.output)).output)
	        }
            #END GET LAST REBOOT EVENT -----------------------------------------------

            #START GET REBOOT PENDING --------------------------------------------------
            $MainForm.Text = 'Getting Reboot Pending from WMI...'
	        $out_rebootPending = (Invoke-WmiMethod -ComputerName $PC_Name -Namespace root\ccm\clientsdk -Class CCM_ClientUtilities -Name DetermineIfRebootPending).RebootPending
            $MainForm.Text = 'Validating Reboot pending info...'
	        if ($out_rebootPending -eq $null)
	        {
                #WMI RETURNED NOT NULL
                $MainForm.Text = 'Setting Reboot pending info...'
	            $out_RebootPending = "Couldn't Contact Computer"
	        }
            #END GET REBOOT PENDING --------------------------------------------------
   
	        }
	        else
	        {
	            # Computer is Offline and cannot be contacted
                if ($Script:LastSearchBY -eq "IP")
                {
                    $PC_Name_Error = "Computer Could Not Be Contacted"
                    $Script:PC_Name_Failed = $true
                }
                elseif($Script:LastSearchBY -eq "PC")
                {
                    $out_PC_IP = "Computer Could Not Be Contacted"
                    $Script:IPReady = $false
                }
                $MainForm.Text = 'Setting vars on no connection...'
	            $out_PC_Time_Since_LastBoot = "Couldn't Contact Computer"
	            $out_rebootPending = "Couldn't Contact Computer"
	            $out_PC_LastReboot_Time = "Couldn't Contact Computer"
	            $out_PC_LastUserLogon_Timestamp = "Couldn't Contact Computer"
	            $out_Bios_Ver = "Couldn't Contact Computer"
	            $out_PC_CurrentUserSSO = "Couldn't Contact Computer"
	            $out_PC_CurrentUserName = "Couldn't Contact Computer"
	            $out_User_Sessions = "Couldn't Contact Computer"
	            $out_FreeRam = "Couldn't Contact Computer"
	            $out_FreeVirt = "Couldn't Contact Computer"
	            $out_GfxVer = "Couldn't Contact Computer"
	            $out_GfxDriver = "Couldn't Contact Computer"
	            $out_winver = "Couldn't Contact Computer"
	            $out_PC_Model = "Couldn't Contact Computer"
                $out_PC_Ram_Amount = "Couldn't Contact Computer"
                $out_PC_Session_Length = "Couldn't Contact Computer"
	        }
            if($nousers -eq $true)
            {
                $MainForm.Text = 'Setting vars on current users...'
                $out_PC_CurrentUserSSO = "No Users Currently Logged in"
	            $out_PC_CurrentUserName = "No Users Currently Logged in"
            }
	        if(!($out_User_Sessions))
	        {
	            $properties = @{'username' = "Couldn't Get Sessions";
	                            'SESSIONNAME' = "Couldn't Get Sessions";
	                            'STATE' = "Couldn't Get Sessions";
	                            'idleTime' = "Couldn't Get Sessions";
	                            'logonTime' = "Couldn't Get Sessions";
                                }
	            $out_User_Sessions = New-Object �TypeName PSObject �Prop $properties
	        }

        #START SET TEXTBOX VALUES -------------------------------

        #PC INFO
        $MainForm.Text = 'Updating PC Info Textboxes'
        $tbx_PC_Model.text = $out_PC_Model
        $tbx_PC_LastBoot_Time.text = $out_PC_Time_Since_LastBoot
        $tbx_PC_LastRestart_Time.text = $out_PC_LastReboot_Time
        $tbx_PC_Gfx_Driver.text = $out_GfxDriver
        $tbx_PC_Gfx_Ver.text = $out_GfxVer
        $tbx_PC_Bios_Ver.text = $out_Bios_Ver
        $tbx_PC_Win_Ver.text = $out_winver
        $tbx_PC_Ram_Amount.text = $out_PC_Ram_Amount
        #Snapshot
        $MainForm.Text = 'Updating Snapshot Textboxes'
        $tbx_PC_FreeRam.text = $out_FreeRam
        $tbx_PC_FreeVirtMem.text = $out_FreeVirt
        #Current Users
        $tbx_PC_User_SSO.text = $out_PC_CurrentUserSSO
        $tbx_PC_User_Name.text = $out_PC_CurrentUserName
        #Current Sessions
	    $MainForm.Text = 'Updating Session Textboxes'
        $tbx_PC_Session_UserName.text = $out_User_Sessions.username
        $tbx_PC_Session_Type.text = $out_User_Sessions.SESSIONNAME
        $tbx_PC_Session_State.text = $out_User_Sessions.STATE
        $tbx_PC_Session_IdleTime.text = $out_User_Sessions.idleTime
        $tbx_PC_Session_LogonTime.text = $out_User_Sessions.logonTime
        #MISC Info
        $MainForm.Text = 'Updating MISC Textboxes'
        $tbx_Misc_Last_LoginTime.text = $out_PC_LastUserLogon_Timestamp
        $tbx_Misc_User_Session_Length.text = $out_PC_Session_Length
        $tbx_Misc_PC_RebootPending.text = $out_rebootPending
        #END SET TEXTBOX VALUES -------------------------------
        $MainForm.Text = 'Done!'
        }
        else
        {
            # NO VALID IP ADDRESS OR COMPUTER NAME FROM AD
            $MainForm.Text = "PC IP/Name was invalid!"
            $timerJobTracker.Stop()
        }
	}
	else
	{
        $MainForm.Text = $Param_ErrorMsg
	}
}

#START SEARCH-BY-PC--------------------------------------------------------------------------------------------------------------------------------------------------
Function Search-By-PC
{
	#---------------------------------------------------------------------------------------------------------------
	#	Inputs:
	#	Computername = [String]
	# --------------------------------------------------------------------------------------------------------------
	#	Returns a PSobject with properties:
	#	Output = returned value (will be null if error occurs)
	#	ErrorMsg = handled error that occured when attempting to execute
	#---------------------------------------------------------------------------------------------------------------
	[CmdletBinding()]
	param
	(
        [Parameter(Mandatory=$false)]$Computername
	)
	# START Manual Parameter Error handling --------------------------------------------------------------------------------

	# MANDATORY CHECK (NULLS FAIL) > STRING TYPE CHECK > EMPTY STRING CHECK
	if(!($Computername)){$Param_ErrorMsg = "No value entered for: Computername"}
	elseif(!($Computername -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: Computername"}
	elseif(!($Computername.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: Computername"}

	# END Manual Parameter Error handling ----------------------------------------------------------------------------------

    #START BOOL SETUP-----------------------------
    $MainForm.Text = 'Setting Up Bools...'
    $isOnline = $false
    $User_FromConnectedPC = $false
    $descfailed = $false
    $nousers = $false
    $Script:IPReady = $false
    $Script:PC_Name_Failed = $false
    #END BOOL SETUP-----------------------------

    #START PYTHON/SELENIUM/CHROMEWEBDRIVER HARD HAULT------------
    $MainForm.Text = 'Killing Old ChromeDriver...'
    &taskkill /im chromedriver.exe /f | Out-Null
    $MainForm.Text = 'Stopping Old Jobs...'
    Get-Job -Name "BackgroundJob" -ErrorAction SilentlyContinue | Stop-Job -ErrorAction SilentlyContinue
    $MainForm.Text = 'Removing Old Jobs...'
    Get-Job -Name "BackgroundJob" -ErrorAction SilentlyContinue | Remove-Job -ErrorAction SilentlyContinue
    #END PYTHON/SELENIUM/CHROMEWEBDRIVER HARD HAULT------------

	# Filter failed input to return errormsg and null output
    $MainForm.Text = 'Checking for parameter errors...'
	if(!($Param_ErrorMsg))
	{
        #TEST IF PC IS IP ADDRESS OR HOSTNAME
        $MainForm.Text = 'Check if IP Address...'

        #OLD METHOD
	    #$isIPaddress = (Check-If-IP -computername $Computername).output
	    #if ($isIPAddress -eq $false)

        $out_PC_IP = $null
        $out_PC_IP = ExtractValidIPAddress "$Computername"
        if(!($out_PC_IP))
	    {
            #----------------- INPUT WAS COMPUTERNAME -------------------------------
            #INPUT VAR: $computername
            #ASSUMING INPUT WAS COMPUTER NAME
            $MainForm.Text = 'Getting PC from AD By Name...'	
	        $AD_computer = Get-PC-By_PCName($Computername)
            write-host $ad_computer.name
            $MainForm.Text = 'Validating PC returned from AD'
	        if($AD_computer)
	        {
                #AD OBJECT RETURN WAS NOT NULL
	            if ($AD_computer.Name)
	            {
                    #VALID INPUT TYPE: COMPUTER NAME
                    $Script:LastSearchBY = "PC"
                    $Script:LastSearch = "$($AD_computer.Name)"
                    $MainForm.Text = 'Getting Description and Computername from PC in AD...'
	                $PC_description = $AD_computer.description
	                $PC_Name = $AD_computer.Name
                    $out_PC_Name = $PC_Name
                    $MainForm.Text = 'Verifying PC Description...'
	                if ($PC_description)
	                {
                        #AD PC DESCRIPTION IS NOT NULL
	                    if($PC_description -is [string])
	                    {
                            #PC DESCRIPTION IS STRING (CHECK NOT REALLY NEEDED)
	                        if($PC_description.trim())
	                        {
                                #PC DESCRIPTION IS NOT AN EMPTY STRING

                                # -------------- START FIRST FILTER TO FIND USER FROM AD DESCRIPTION -----------
	                            $PC_description_PostReplace = $PC_description -replace "\*", "+"
	                            if($PC_description_PostReplace -like "* - *")
	                            {
                                    #DESCRIPTION FORMAT IS CORRECT SO FAR
	                                $PC_description_PostReplace = $PC_description_PostReplace -split " - "
	                                if ($PC_description_PostReplace.count -gt 2)
	                                {
                                        #DESCRIPTION HAS INCORRECT FORMAT

                                        # -------------- START SECOND FILTER TO FIND USER FROM AD DESCRIPTION -----------	
                                        #Test Substring after the first "-" in Description
	                                    $Username_from_PC_Desc = "$($PC_description_PostReplace[1])"
	                                    if ($Username_from_PC_Desc)
	                                    {
                                            #SUBSTRING TEST 2 IS NOT NULL
	                                        if($Username_from_PC_Desc.trim())
	                                        {
                                                #SUBSTRING TEST 2 IS NOT EMPTY STRING - (NO STRING TYPE CHECK NEEDED)
	                                            $Username_from_PC_Desc = $Username_from_PC_Desc.trim()
	                                        }
	                                        else
	                                        {
                                                #SUBSTRING TEST 2 IS EMPTY STRING - (NO STRING TYPE CHECK NEEDED)
	                                            $Username_from_PC_Desc = $null
	                                        }	
	                                    }
	                                    else
	                                    {
                                            #SUBSTRING TEST 2 IS NULL
	                                        $Username_from_PC_Desc = "$($PC_description_PostReplace[2])"
	                                    }
                                        #---------------- END SECOND FILTER TO FIND USER FROM AD DESCRIPTION -----------


                                        #-------------- START THIRD FILTER TO FIND USER FROM AD DESCRIPTION -----------
                                        #Test Substring after the Second "-" in Description
	                                    if ($Username_from_PC_Desc)
	                                    {
                                            #SUBSTRING TEST 3 IS NOT NULL
	                                        if($Username_from_PC_Desc.trim())
	                                        {
                                                #SUBSTRING TEST 3 IS NOT EMPTY STRING
	                                            $Username_from_PC_Desc = $Username_from_PC_Desc.trim()
	                                        }
	                                        else
	                                        {
	                                            #SUBSTRING TEST 3 IS EMPTY STRING
	                                            $Username_from_PC_Desc = $null
	                                        }
	                                    }
	                                    else
	                                    {
                                            #SUBSTRING TEST 3 IS NULL
	                                        $Username_from_PC_Desc = $null
	                                    }
                                        #-------------- END THIRD FILTER TO FIND USER FROM AD DESCRIPTION -----------
	                                }
	                                else
	                                {
                                        #DESCRIPTION HAS CORRECT FORMAT
	                                    $Username_from_PC_Desc = "$($PC_description_PostReplace[1])"
	                                }
                                                        
                                    #BEGIN POTENTIAL USERNAME FROM DESCRIPTION CHECK
                                    if($Username_from_PC_Desc)
                                    {
                                        $MainForm.Text = 'Getting User from Description...'
	                                    $AD_User = (FindUser -User_In $Username_from_PC_Desc)
	                                    if(!($($AD_User.ErrorMsg)))
	                                    {
    	                                    if($($AD_User.MI))
	                                        {
                                                #MIDDLE INITIAL FOUND
    	                                        if (!($(($AD_User.MI).Trim())))
	                                            {
                                                    #USER FOUND
                                                    #MIDDLE INITIAL IS EMPTY STRING (HAPPENS MORE THAN YOU WOULD IMAGINE)
                                                    $MainForm.Text = 'Formating User for empty MI...'
	                                                $User_name = $($AD_User.FirstName) + " " + $($AD_User.LastName)
                                                    $out_User_Email = $($AD_User.Email)
                                                    $out_user_id = $($AD_User.ID)
	                                            }
	                                            else
	                                            {
                                                    #USER FOUND
                                                    #MIDDLE INITIAL NOT EMPTY STRING
                                                    $MainForm.Text = 'Formating User with MI...'
	                                                $User_name = $($AD_User.FirstName) + " " + $($AD_User.MI) + " " + $($AD_User.LastName)
                                                    $out_User_Email = $($AD_User.Email)
                                                    $out_user_id = $($AD_User.ID)
	                                            }
	                                        }
	                                        else
	                                        {
                                                #USER FOUND
                                                #MIDDLE INITIAL NOT FOUND
                                                $MainForm.Text = 'Formating User for no MI...'
	                                            $User_name = $($AD_User.FirstName)+ " " + $($AD_User.LastName)
                                                $out_User_Email = $($AD_User.Email)
                                                $out_user_id = $($AD_User.ID)
	                                        }
	                                    }
	                                    else
	                                    {
                                            #ERRORMSG RETURNED FROM FINDUSER FUNCTION
	                                        $User_name = $AD_User.ErrorMsg
                                            $out_User_Email = ""
                                            $out_user_id = ""
	                                    }
                                    }
                                    else
                                    {
                                        #NO POTENTIAL USER FROM FILTERS
                                        $User_Name = "User Not Found from Description"
                                        $out_User_Email = ""
                                        $out_user_id = ""
                                    }
	                            }
	                            else
	                            {
	                                #DESCRIPTION IS NOT FORMATTED CORRECTLY (DOES NOT CONTAIN " - ")
                                    if($PC_description_PostReplace -like "*NEW*unassigned*")
                                    {
                                        #PC HAS UNASSIGNED DESCRIPTION
                                        $PC_description_PostReplace = $PC_description_PostReplace.replace('+', '*')
                                        $PC_Description = $PC_description_PostReplace
                                        $User_name = "Unassigned"
                                    }
                                    else
                                    {
                                        #PC DOESNT HAVE UNASSIGNED DESCRIPTION
                                        $PC_Description = "PC AD Description doesnt contain proper format ('* - *')"
                                        $User_name = "PC AD Description doesnt contain proper format ('* - *')"
                                    }
                                    $out_User_Email = ""
                                    $out_user_id = ""
	                            }
	                        }
	                        else
	                        {
	                            #DESCRIPTION IS EMPTY STRING
	                            $PC_Description = "Computer AD Description is empty string"
	                            $User_name = "Computer AD Description is empty string"
                                $out_User_Email = ""
                                $out_user_id = ""
	                        }
	                    }
	                    else
	                    {
	                        #DESCRIPTION IS NOT A STRING
	                        $PC_Description = "Computer AD Description is wrong data type"
	                        $User_name = "Computer AD Description is wrong data type"
                            $out_User_Email = ""
                            $out_user_id = ""
	                    }
	                }
	                else
	                {
	                    #DESCRIPTION IS NULL
	                    $PC_Description = "No AD Description"
	                    $User_name = "Computer AD Description is null!"
                        $out_User_Email = ""
                        $out_user_id = ""
	                }
                    $out_User_Assigned = $User_name
                    $out_PC_Description = $PC_description
                    #------------DESCRIPTION FINISHED PROCESSING FOR COMPUTER NAME INPUT HERE--------------
                    #------------USER EMAIL FINISHED PROCESSING FOR COMPUTER NAME INPUT HERE--------------
                    #------------USER ID FINISHED PROCESSING FOR COMPUTER NAME INPUT HERE--------------
                    #------------USER NAME FINISHED PROCESSING FOR COMPUTER NAME INPUT HERE--------------
	            }
	            else
	            {
	                #NULL COMPUTER NAME RETURNED
	                $PC_Name_Error = "[AD RECORD ISSUE] Computer Name From AD was invalid"
                    $Script:PC_Name_Failed = $true
	            }
            }
            else
            {
    	        #NULL COMPUTER RETURNED
	            $PC_Name_Error = "Computer Name not found in AD"
                $Script:PC_Name_Failed = $true
            }
            #-------------------- END INPUT WAS COMPUTERNAME --------------------------
	    }
	    else
	    {
            #-------------------- INPUT WAS IP ADDRESS --------------------------
            #INPUT VAR: $computername
            $MainForm.Text = 'Setting up IP Invoke Trusted Host settings...'
            Setup-IP-Invoke($out_PC_IP)
            $Script:LastSearchBY = "IP"
            $Script:LastSearch = "$Computername"
            #IP ADDRESS CALLS CAN BE USED
            $Script:IPReady = $true
            #-------------------- END INPUT WAS IP ADDRESS --------------------------
        }

        if($Script:LastSearchBY -eq "IP")
        {
            #SET PC_NAME TO INPUT IF INPUT WAS DETERMINED TO BE IP ADDRESS
            $PC_Name = $out_PC_IP
        }
        else
        {
            # INPUT WAS DETERMINED TO BE COMPUTERNAME
            if($Script:IPReady -eq $true)
            {
                #FINAL CHECK OF IP IS NOT NULL
                if($out_PC_IP)
                {
                    #VALID IP
                    #SET IP ADDRESS AS DEFAULT FOR REMOTE COMMANDS
                    $PC_Name = $out_PC_IP
                }
                else
                {
                    #CHECK IF PC NAME IS NULL
                    if($out_PC_Name)
                    {
                        #VALID NAME, INVALID IP
                        #SET PC NAME AS DEFAULT FOR REMOTE COMMANDS
                        $PC_Name = $out_PC_Name
                    }
                    else
                    {
                        #INVALID NAME AND IP
                        $PC_Name = $null
                    }
                }
            }
            else
            {
                #CHECK IF PC NAME IS NULL
                if($out_PC_Name)
                {
                    #VALID NAME, INVALID IP
                    #SET PC NAME AS DEFAULT FOR REMOTE COMMANDS
                    $PC_Name = $out_PC_Name
                }
                else
                {
                    #INVALID NAME AND IP
                    $PC_Name = $null
                }
            }
        }

        #------- BEGIN REMOTE COMMANDS ------------------------------------------------------
        #REMOTE PC VAR: $PC_Name
        
        if($PC_Name)
        {
            # $PC_Name IS EITHER VALID IP ADDRESS OR VALID COMPUTER NAME FOUND FROM AD

            $MainForm.Text = 'Testing if PC is online...'
	        if (((Test-IsOnline $PC_Name).online) -eq $true)
	        {
                # Computer is Online and can be contacted
	            $isOnline = $true
                #-------------------------- BEGIN INPUT WAS IP ADDRESS AND PC IS ONLINE ---------------------
                if($Script:LastSearchBY -eq "IP")
                {
                    # GET HOSTNAME FROM IP ADDRESS IF SEARCHED BY IP ADDRESS
                    $MainForm.Text = 'Getting Hostname from IP Address...'
	                $aryHostname = wmic /node: $PC_Name computersystem get name
	                if ($aryHostname)
	                {
	                    # Returned PC Hostname from IP address
	                    $strHostname = $($($aryHostname[2]).tostring())
                        $MainForm.Text = 'Verifying Hostname from IP Address...'
	                    if ($strHostname)
	                    {
	                        # Hostname from IP was NOT null
	                        if ($strHostname -is [string])
	                        {
	                            # Hostname from IP is a string
	                            if ($strHostname.trim())
	                            {
                                    # Hostname from IP is not an empty string
                                    $strHostname = $strHostname.trim()
                                    $MainForm.Text = 'Getting AD Computer Using Hostname from IP...' 
	                                $AD_Computer_FromIP = Get-PC-By_PCName($strHostname)
	                                if ($AD_Computer_FromIP)
	                                {
	                                    # Found AD entry using Hostname from IP
                                        $MainForm.Text = 'Getting Description and Name from AD Computer...'
	                                    $PC_description = $AD_Computer_FromIP.description
	                                    $out_PC_Name = $AD_Computer_FromIP.Name
                                        $MainForm.Text = 'Verifying PC Description...'
	                                    if ($PC_description)
	                                    {
                                            #AD PC DESCRIPTION IS NOT NULL
	                                        if($PC_description -is [string])
	                                        {
                                                #PC DESCRIPTION IS STRING (CHECK NOT REALLY NEEDED)
	                                            if($PC_description.trim())
	                                            {
                                                    #PC DESCRIPTION IS NOT AN EMPTY STRING

                                                    # -------------- START FIRST FILTER TO FIND USER FROM AD DESCRIPTION -----------
	                                                $PC_description_PostReplace = $PC_description -replace "\*", "+"
	                                                if($PC_description_PostReplace -like "* - *")
	                                                {
                                                        #DESCRIPTION FORMAT IS CORRECT SO FAR
	                                                    $PC_description_PostReplace = $PC_description_PostReplace -split " - "
	                                                    if ($PC_description_PostReplace.count -gt 2)
	                                                    {
                                                            #DESCRIPTION HAS INCORRECT FORMAT

                                                            # -------------- START SECOND FILTER TO FIND USER FROM AD DESCRIPTION -----------	
                                                            #Test Substring after the first "-" in Description
	                                                        $Username_from_PC_Desc = "$($PC_description_PostReplace[1])"
	                                                        if ($Username_from_PC_Desc)
	                                                        {
                                                                #SUBSTRING TEST 2 IS NOT NULL
	                                                            if($Username_from_PC_Desc.trim())
	                                                            {
                                                                    #SUBSTRING TEST 2 IS NOT EMPTY STRING - (NO STRING TYPE CHECK NEEDED)
	                                                                $Username_from_PC_Desc = $Username_from_PC_Desc.trim()
	                                                            }
	                                                            else
	                                                            {
                                                                    #SUBSTRING TEST 2 IS EMPTY STRING - (NO STRING TYPE CHECK NEEDED)
	                                                                $Username_from_PC_Desc = $null
	                                                            }	
	                                                        }
	                                                        else
	                                                        {
                                                                #SUBSTRING TEST 2 IS NULL
	                                                            $Username_from_PC_Desc = "$($PC_description_PostReplace[2])"
	                                                        }
                                                            #---------------- END SECOND FILTER TO FIND USER FROM AD DESCRIPTION -----------


                                                            #-------------- START THIRD FILTER TO FIND USER FROM AD DESCRIPTION -----------
                                                            #Test Substring after the Second "-" in Description
	                                                        if ($Username_from_PC_Desc)
	                                                        {
                                                                #SUBSTRING TEST 3 IS NOT NULL
	                                                            if($Username_from_PC_Desc.trim())
	                                                            {
                                                                    #SUBSTRING TEST 3 IS NOT EMPTY STRING
	                                                                $Username_from_PC_Desc = $Username_from_PC_Desc.trim()
	                                                            }
	                                                            else
	                                                            {
	                                                                #SUBSTRING TEST 3 IS EMPTY STRING
	                                                                $Username_from_PC_Desc = $null
	                                                            }
	                                                        }
	                                                        else
	                                                        {
                                                                #SUBSTRING TEST 3 IS NULL
	                                                            $Username_from_PC_Desc = $null
	                                                        }
                                                            #-------------- END THIRD FILTER TO FIND USER FROM AD DESCRIPTION -----------
	                                                    }
	                                                    else
	                                                    {
                                                            #DESCRIPTION HAS CORRECT FORMAT
	                                                        $Username_from_PC_Desc = "$($PC_description_PostReplace[1])"
	                                                    }
                                                        
                                                        #BEGIN POTENTIAL USERNAME FROM DESCRIPTION CHECK
                                                        if($Username_from_PC_Desc)
                                                        {
                                                            $MainForm.Text = 'Getting User from Description...'
	                                                        $AD_User = (FindUser -User_In $Username_from_PC_Desc)
	                                                        if(!($($AD_User.ErrorMsg)))
	                                                        {
    	                                                        if($($AD_User.MI))
	                                                            {
                                                                    #MIDDLE INITIAL FOUND
    	                                                            if (!($(($AD_User.MI).Trim())))
	                                                                {
                                                                        #USER FOUND
                                                                        #MIDDLE INITIAL IS EMPTY STRING (HAPPENS MORE THAN YOU WOULD IMAGINE)
                                                                        $MainForm.Text = 'Formating User for empty MI...'
	                                                                    $User_name = $($AD_User.FirstName) + " " + $($AD_User.LastName)
                                                                        $out_User_Email = $($AD_User.Email)
                                                                        $out_user_id = $($AD_User.ID)
	                                                                }
	                                                                else
	                                                                {
                                                                        #USER FOUND
                                                                        #MIDDLE INITIAL NOT EMPTY STRING
                                                                        $MainForm.Text = 'Formating User with MI...'
	                                                                    $User_name = $($AD_User.FirstName) + " " + $($AD_User.MI) + " " + $($AD_User.LastName)
                                                                        $out_User_Email = $($AD_User.Email)
                                                                        $out_user_id = $($AD_User.ID)
	                                                                }
	                                                            }
	                                                            else
	                                                            {
                                                                    #USER FOUND
                                                                    #MIDDLE INITIAL NOT FOUND
                                                                    $MainForm.Text = 'Formating User for no MI...'
	                                                                $User_name = $($AD_User.FirstName)+ " " + $($AD_User.LastName)
                                                                    $out_User_Email = $($AD_User.Email)
                                                                    $out_user_id = $($AD_User.ID)
	                                                            }
	                                                        }
	                                                        else
	                                                        {
                                                                #ERRORMSG RETURNED FROM FINDUSER FUNCTION
	                                                            $User_name = $AD_User.ErrorMsg
                                                                $out_User_Email = ""
                                                                $out_user_id = ""
	                                                        }
                                                        }
                                                        else
                                                        {
                                                            #NO POTENTIAL USER FROM FILTERS
                                                            $User_Name = "User Not Found from Description"
                                                            $out_User_Email = ""
                                                            $out_user_id = ""
                                                        }
	                                                }
	                                                else
	                                                {
	                                                    #DESCRIPTION IS NOT FORMATTED CORRECTLY (DOES NOT CONTAIN " - ")
                                                        if($PC_description_PostReplace -like "*NEW*unassigned*")
                                                        {
                                                            #PC HAS UNASSIGNED DESCRIPTION
                                                            $PC_description_PostReplace = $PC_description_PostReplace.replace('+', '*')
                                                            $PC_Description = $PC_description_PostReplace
                                                            $User_name = "Unassigned"
                                                        }
                                                        else
                                                        {
                                                            #PC DOESNT HAVE UNASSIGNED DESCRIPTION
                                                            $PC_Description = "PC AD Description doesnt contain proper format ('* - *')"
                                                            $User_name = "PC AD Description doesnt contain proper format ('* - *')"
                                                        }
                                                        $out_User_Email = ""
                                                        $out_user_id = ""
	                                                }
	                                            }
	                                            else
	                                            {
	                                                #DESCRIPTION IS EMPTY STRING
	                                                $PC_Description = "Computer AD Description is empty string"
	                                                $User_name = "Computer AD Description is empty string"
                                                    $out_User_Email = ""
                                                    $out_user_id = ""
	                                            }
	                                        }
	                                        else
	                                        {
	                                            #DESCRIPTION IS NOT A STRING
	                                            $PC_Description = "Computer AD Description is wrong data type"
	                                            $User_name = "Computer AD Description is wrong data type"
                                                $out_User_Email = ""
                                                $out_user_id = ""
	                                        }
	                                    }
	                                    else
	                                    {
	                                        #DESCRIPTION IS NULL
	                                        $PC_Description = "No AD Description"
	                                        $User_name = "Computer AD Description is null!"
                                            $out_User_Email = ""
                                            $out_user_id = ""
	                                    }
                                        $out_User_Assigned = $User_name
                                        $out_PC_Description = $PC_description
                                        #------------DESCRIPTION FINISHED PROCESSING FOR IP ADDRESS INPUT HERE--------------
                                        #------------USER EMAIL FINISHED PROCESSING FOR IP ADDRESS INPUT HERE--------------
                                        #------------USER ID FINISHED PROCESSING FOR IP ADDRESS INPUT HERE--------------
                                        #------------USER NAME FINISHED PROCESSING FOR IP ADDRESS INPUT HERE--------------
	                                }
	                                else
	                                {
                                        #NO AD COMPUTER FOUND USING HOSTNAME FROM IP
	                                    $PC_Name_Error = "Hostname from IP not found in AD"
	                                }
	                            }
	                            else
	                            {
                                    #HOSTNAME FROM IP IS EMPTY STRING
	                                $PC_Name_Error = "Hostname from IP was Empty String"
	                            }
	                        }
	                        else
	                        {
	                            #HOSTNAME FROM IP IS NOT A STRING
	                            $PC_Name_Error = "Hostname rom IP was not a String"
	                        }	
	                    }
	                    else
	                    {
	                        #ARRAY FROM IP HAD NULL HOSTNAME
	                        $PC_Name_Error = "No Hostname Returned From IP Address"
	                    }
	                }
	                else
	                {
	                    #HOSTNAME FROM IP RETURNED NULL
	                    $PC_Name_Error = "No Hostname was found from IP Address"
	                }
                    
                    if($PC_Name_Error)
                    {
                        #PC HOSTNAME HAS ERROR
                        $Script:PC_Name_Failed = $true
                    }
                    else
                    {
                        # - INPUT WAS IP ADDRESS
                        # - PC NAME FOUND (FROM IP ADDRESS) AND IS VALID
                        # - PC IS ONLINE
                        # Trigger Events per above conditions
                    }
                }
                #-------------------------- END INPUT WAS IP ADDRESS AND PC IS ONLINE ---------------------

                #-------------------------- BEGIN INPUT WAS COMPUTER NAME AND PC IS ONLINE ---------------------
                elseif($Script:LastSearchBY -eq "PC")
                {
                    #----INPUT WAS HOSTNAME----
                    # - PC IS ONLINE

                    # GET HOSTNAME FROM IP ADDRESS ---------------
                    $MainForm.Text = "Getting IP Address From Hostname..."
                    $OldErrorAction = $ErrorActionPreference
                    $ErrorActionPreference = "silentlycontinue"
                    try
                    {
                        $out_PC_IP = [System.Net.Dns]::GetHostAddresses("$out_PC_Name").IPAddressToString
                    }
                    catch
                    {
                        $out_PC_IP = $null
                    }

                    if($out_PC_IP)
                    {
                        # MAKE SURE IP ADDRESS WAS RETURNED
                        $out_PC_IP = ExtractValidIPAddress "$out_PC_IP"
                        if(!($out_PC_IP))
                        {
                            #NO VALID IPv4 Address found in out_PC_IP
                            $out_PC_IP = "No Valid IP Address Found"
                            #IP ADDRESS CALLS CAN NOT BE USED
                            $Script:IPReady = $false
                        }
                        else
                        {
                            #VALID IPv4 Address found in out_PC_IP
                            Setup-IP-Invoke($out_PC_IP)
                            #IP ADDRESS CALLS CAN BE USED
                            $Script:IPReady = $true
                            #SET DEFAULT AS IP ADDRESS
                            $PC_Name = $out_PC_IP
                        }
                    }
                    else
                    {
                        # GetHostAddresses returned NULL

                        #IP ADDRESS CALLS CAN NOT BE USED
                        $Script:IPReady = $false
                    }
                    $ErrorActionPreference = $OldErrorAction
                }     
	        }
	        else
	        {
	            # Computer is Offline and cannot be contacted
                if ($Script:LastSearchBY -eq "IP")
                {
                    $PC_Name_Error = "Computer Could Not Be Contacted"
                    $Script:PC_Name_Failed = $true
                }
                elseif($Script:LastSearchBY -eq "PC")
                {
                    $out_PC_IP = "Computer Could Not Be Contacted"
                    $Script:IPReady = $false
                }
	        }

            #USER ID FINAL VALIDITY CHECK (For Background Jobs)
            if($out_User_ID)
            {
                #USER ID IS NOT NULL
                if($out_User_ID.trim())
                {
                    #USER ID IS NOT AN EMPTY STRING
                    $User_IDReady = $true
                }
                else
                {
                    #USER ID IS AN EMPTY STRING
                    $User_IDReady = $false
                }
            }
            else
            {
                #USER ID IS NULL
                $User_IDReady = $false
            }
            
            # - Finished checking if PC is online
            # - Finished IP or Computer Name checks/setups
            # - $Script:IPReady set:
                # if true out_PC_IP is valid and ready to output (will be an errormsg if failed a check)
            # - out_PC_Description Ready to output (will be null if PC failed, will be an errormsg if failed a check)
            # - out_User_Assigned Ready to output (will be null if Description failed, Will be error if failed a check)
            # - out_User_ID Ready to output (will be empty string if failed a check)
            # - out_User_Email Ready to output (will be empty string if failed a check)
            #------------ CONVERANCE OF ABOVE CONDITIONS HERE ------------------------------------------

            if($Script:PC_Name_Failed -eq $true)
            {
                # HOSTNAME FAILED TO BE FOUND
                # - Setting PC_Name output to ErrorMsg

                $out_PC_Name = $PC_Name_Error

                 #-------------------- SET TEXTBOXES TEXT THAT BACKGROUND JOB FILLS TO ERROR--------------------
            }
            else
            {
                # - Finished checking if PC is online
                # - Finished IP or Computer Name checks/setups
                # - out_PC_Name is valid and ready to output
                # - $Script:IPReady set:
                    # if true out_PC_IP is valid and ready to output (will be an errormsg if failed a check)
                # - out_PC_Description Ready to output (will be null if PC failed, will be an errormsg if failed a check)
                # - out_User_Assigned Ready to output (will be null if Description failed, Will be error if failed a check)
                # - out_User_ID Ready to output (will be empty string if failed a check)
                # - out_User_Email Ready to output (will be empty string if failed a check)
                #------------ CONVERANCE OF ABOVE CONDITIONS HERE ------------------------------------------

                #--------------- TRIGGER EVENTS THAT REQUIRE PC NAME REGARDLESS IF PC IS ONLINE HERE--------------
                if($User_IDReady)
                {
                    $MainForm.Text = 'Starting Background Jobs...'
                    if (!($out_user_id))
                    {
                        $scriptroot = $(((get-item $psscriptroot).parent).fullname)
                        Get-Background-info -Computer $out_PC_Name -UserID "NONE" -scriptroot $scriptroot
                    }
                    else
                    {
                        $scriptroot = $(((get-item $psscriptroot).parent).fullname)
                        Get-Background-info -Computer $out_PC_Name -UserID $out_user_id -scriptroot $scriptroot
                    }
                }
                else
                {
                    $scriptroot = $(((get-item $psscriptroot).parent).fullname)
                    Get-Background-info -Computer $out_PC_Name -UserID "NONE" -scriptroot $scriptroot
                    #-------------------- SET TEXTBOXES TEXT THAT BACKGROUND JOB FILLS TO ERROR--------------------
                }
            }
	
        #isOnline already determined
	    if($isOnline -eq $true)
	    {
            #GET MODEL-----------------------------------------------------
            $MainForm.Text = 'Getting Model from WMI...'
	        $objModel = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $PC_Name -Credential $Script:Credentials
            $MainForm.Text = 'Verifying Model returned...'
	        if($objModel)
	        {
                $MainForm.Text = 'Filtering based on Model...'
	            $PC_Model = (Get-PC-Model($objModel))
	            if($PC_Model)
	            {
                    #GET-PC-MODEL FUNCTION RETURNED VALUES
                    $MainForm.Text = 'Setting Model...'
	                if($PC_Model.ErrorMsg)
	                {
                        #GET-PC-MODEL FUNCTION RETURNED VALUES INCLUDE ERRORS
                        $MainForm.Text = 'Setting Model...'
	                    $out_PC_Model = $PC_Model.ErrorMsg
	                }
	                else
	                {
                        #GET-PC-MODEL FUNCTION RETURNED NO ERRORS
                        $MainForm.Text = 'Setting Model...'
	                    $out_PC_Model = $PC_Model.Model
                        $tbx_PC_Model.backcolor = $tbx_PC_AD_Desc.backcolor
                        if($PC_Model.warning)
                        {
                            #GET-PC-MODEL RETURNED WARNING FOR MODEL
                            $out_PC_Model = "$($PC_Model.model) ($($PC_Model.warning))"
                            if($PC_Model.warningcolor -ne [System.drawing.color]::White)
                            {
                                #SET COLOR OF MODEL TEXTBOX TO WARNING COLOR RETURNED
                                $tbx_PC_Model.backcolor = $PC_Model.warningcolor
                            }
    	                }	
	                }	
	            }
	            else
	            {
                    #GET-PC-MODEL FUNCTION RETURNED NULL
                    $MainForm.Text = 'Setting Model...'
	                $out_PC_Model = "Couldn't get Model"
	            }
	        }
	        else
	        {
                #WMI FUNCTION COULDN"T FIND MODEL
                $MainForm.Text = 'Setting Model...'
	            #write-debug "[FAILURE] SEARCH-BY-PC - Get-WmiObject Win32_ComputerSystem returned null value"
	            $out_PC_Model = "Couldn't get Model From PC"
	        }
            #END GET MODEL -----------------------------------------------------

            #START GET WINDOWS VERSION---------------------------------------------
            $MainForm.Text = 'Getting Windows Version info from WMI...'
	        $winver = Get-WinVer -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Windows Version info returned...'
	        if($winver)
	        {
                #WINDOWS VERSION RETURNED FROM WMI NOT NULL
	            if($winver.ErrorMsg)
	            {
                    #WINDOWS VERSION RETURNED FROM WMI HAD ERROR
                    $MainForm.Text = 'Setting Windows Version...'
	                $out_winver = $winver.Errormsg
	            }
	            else
	            {
                    #WINDOWS VERSION RETURNED FROM WMI HAD NO ERRORS
                    $MainForm.Text = 'Setting Windows Version...'
	                $out_winver = $winver.output
	            }
	        }
	        else
	        {
                #WINDOWS VERSION RETURNED FROM WMI NULL
                $MainForm.Text = 'Setting Windows Version...'
	            $out_winver = "Couldn't Get Windows Version"
	        }
            #END GET WINDOWS VERSION---------------------------------------------
            
            #START GET CIM SNAPSHOT/HOSTNAME --------------------------------------------------------
	        $MainForm.Text = 'Getting System info from CIM Instance...'
	        $OSBase = Get-WmiObject -Class win32_operatingsystem -ComputerName $PC_Name -Credential $Script:Credentials | select csname, freephysicalmemory, freevirtualmemory
            $MainForm.Text = 'Validating System info returned...'
	        if($OSBase)
	        {
                #CIM RETURNED NOT NULL

                #START LAST PC NAME VALIDATION ------------------------------------
	            if($($OSBase.csname))
	            {
                    #CIM CSNAME NOT NULL
                    $MainForm.Text = 'Setting PC Name from returned csname...'

                    #(MOST TRUSTWORTHY DATA IS THE SOURCE)
	                $out_PC_Name = "$($OSBase.csname)"
	            }
                else
                {
                    #OVERRIDE CODE IF CANT GET CSNAME HERE
                }
                #END LAST PC NAME VALIDATION ------------------------------------

                #START SNAPSHOT INFO ----------------------------------------------------
	            $MainForm.Text = 'Formatting Snapshot info...'
	            [double]$FreeRam = "{0:N2}" -f ($($OSBase.freephysicalmemory / 1mb))
	            [double]$FreeVirt = "{0:N2}" -f ($($OSBase.freevirtualmemory / 1mb))
	            #[double]$FreePaging = "{0:N2}" -f ($($cim.freespaceinpagingfiles / 1mb)) #FREE PAGING FOUND TO BE UNNECESSARY

	            if($FreeRam)
	            {
                    #FREE PHYSCIAL RAM IS NOT NULL
                    $MainForm.Text = 'Setting Free Ram info...'
	                $out_FreeRam = "$FreeRam GB"
	            }
	            else
	            {
                    #FREE PHYSCIAL RAM IS NULL
                    $MainForm.Text = 'Setting Free Ram info...'
	                $out_FreeRam = "Couldn't get Free Ram"
	            }

	            if($FreeVirt)
	            {
                    #FREE VIRTUAL RAM IS NOT NULL
                    $MainForm.Text = 'Setting Free Vitural memory info...'
	                $out_FreeVirt = "$FreeVirt GB"
	            }
	            else
	            {
                    #FREE VIRTUAL RAM IS NULL
                    $MainForm.Text = 'Setting Free Vitural memory info...'
	                $out_FreeVirt = "Couldn't get Free Virt"
	            }
                
                #END SNAPSHOT INFO ----------------------------------------------------

	        }
	        else
	        {
                $MainForm.Text = 'Setting Snapshot info...'
	            $out_FreeRam = "Couldn't get Free Ram"
	            $out_FreeVirt = "Couldn't get Free Virt"
	        }
            #END GET CIM SNAPSHOT/HOSTNAME --------------------------------------------------------

            #START GET WMI GRAPHICS INFO --------------------------------------------------------
	        $MainForm.Text = 'Getting Graphics info from WMI...'
            if($PC_Name -like "WIVGP*")
            {
                #SKIP VDI GRAPHICS (adds time and not necessary)
	            $out_GfxDriver = "VDI Graphics Skipped"
            }
            else
            {
                #NON VDI GRAPHICS
                $MainForm.Text = 'Getting Video Controller info from WMI...'
                $VideoControllerName = (Get-WmiObject win32_videocontroller -ComputerName $PC_Name -Credential $Script:Credentials | select caption).caption
                if ($videoControllerName)
                {
                    #WMI WIN_32VIDEOCONTROLLER RETURNED NOT NULL VALUE
                    $GfxDriver = $VideoControllerName
                }
                else
                {
                    #WMI WIN_32VIDEOCONTROLLER RETURNED NULL VALUE
                    $GfxDriver = "Couldn't get Graphics Info"
                }
                $out_GfxDriver = $GfxDriver
            }
            $out_GfxVer = "Not Initially Loaded" #Getting Graphics Version added fair amount of time to loading so its been subsidized to a load on button click
            #END GET WMI GRAPHICS INFO --------------------------------------------------------

            #START GET QUERY USERS --------------------------------------------------------
                #(CODE MODIFIED/ADAPTED FROM PRE-EXISTING DUE TO LACK OF quser.exe KNOWLEDGE)
            $MainForm.Text = 'Getting User Sessions info from query users...'
	        $quserOut = quser.exe /SERVER:$PC_Name 2>&1
	        $out_User_Sessions = @()
	        if ($quserOut -match "No user exists")
	        {
                #NO USERS FROM QUERY
	            $nousers = $true
	        }
	        $MainForm.Text = 'Formating User Sessions info...'
	        $users = $quserOut -replace '\s{2,}', ',' |
	        ConvertFrom-CSV -Header 'username', 'sessionname', 'id', 'state', 'idleTime', 'logonTime' |
	        Add-Member -MemberType NoteProperty -Name ComputerName -Value $PC_Name -PassThru
	        $users = $users[1..$users.count]
	        for ($i = 0; $i -lt $users.count; $i++)
	        {
	            if ($users[$i].sessionname -match '^\d+$')
	            {
	                $users[$i].logonTime = $users[$i].idleTime
	                $users[$i].idleTime = $users[$i].STATE
	                $users[$i].STATE = $users[$i].ID
	                $users[$i].ID = $users[$i].SESSIONNAME
	                $users[$i].SESSIONNAME = $null
	            }
	
	            # cast the correct datatypes
	            $users[$i].ID = [int]$users[$i].ID
	
	            $idleString = $users[$i].idleTime
	            if ($idleString -eq '.') { $users[$i].idleTime = 0 }
	
	            # if it's just a number by itself, insert a '0:' in front of it. Otherwise [timespan] cast will interpret the value as days rather than minutes
	            if ($idleString -match '^\d+$')
	            {
                    $users[$i].idleTime = "0:$($users[$i].idleTime)"
                }
	            
	            # if it has a '+', change the '+' to a colon and add ':0' to the end
	            if ($idleString -match "\+")
	            {
	                $newIdleString = $idleString -replace "\+", ":"
	                $newIdleString = $newIdleString + ':0'
	                $users[$i].idleTime = $newIdleString
	            }

	            if($users[$i].idleTime -ne "none")
	            {
	                $users[$i].idleTime = [timespan]$users[$i].idleTime
	            }
	            $users[$i].logonTime = [datetime]$users[$i].logonTime
	        }
	        $users = $users | Sort-Object -Property idleTime

            $MainForm.Text = 'Setting User Sessions info...'
	        Try
	        {
                #TRY ADDING $users TO ARRAY
	            $out_User_Sessions += $users
	        }
	        catch
	        {
                #CANT ADD $users TYPE TO ARRAY, SETTING VAR TO $users INSTEAD
	            $out_User_Sessions = $users
	        }
            #END GET QUERY USERS --------------------------------------------------------

            #START GET CURRENT USER-----------------------------------------------------
            $MainForm.Text = 'Getting Current user info from WMI...'
            $PC_CurrentUser = Get-WMIObject -class Win32_ComputerSystem -ComputerName $PC_Name -Credential $Script:credentials | select username
            $MainForm.Text = 'Validating Current user info returned...'
	        if ($PC_CurrentUser)
	        {
                #WMI RETURNED NOT NULL
	            if ($PC_CurrentUser.username)
	            {
                    #USERNAME IS NOT NULL
                    $MainForm.Text = 'Formating Username...'
	                [string]$strPC_CurrentUser = $PC_CurrentUser.username.toString()
	                $out_PC_CurrentUserSSO = $strPC_CurrentUser.Replace("AFII\", "")
                    $MainForm.Text = 'Getting Users Full Name by username...'
	                $out_PC_CurrentUserName = (FindUsersFullname-By-Username -userin $out_PC_CurrentUserSSO)
	                if (!($out_PC_CurrentUserName.errormsg))
	                {
                        #FINDUSERSFULLNAME-BY-USERNAME FUNCTION RETURNED ERROR
                        $MainForm.Text = 'Setting current user...'
	                    $out_PC_CurrentUserName = $out_PC_CurrentUserName.output
	                }
	                else
	                {
                        #FINDUSERSFULLNAME-BY-USERNAME FUNCTION RETURNED NO ERRORS
                        $MainForm.Text = 'Setting current user...'
	                    $out_PC_CurrentUserName = $out_PC_CurrentUserName.errormsg
	                }
	                $User_FromConnectedPC = $true
	            }
	            else
	            {
                    #USERNAME IS NULL
	                $User_FromConnectedPC = $false
	            }
	        }
	        else
	        {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting current user...'
	            $out_PC_CurrentUserSSO = "No Current Users Found"
	            $out_PC_CurrentUserName = "No Current Users Found"
	        }
            #END GET CURRENT USER-----------------------------------------------------

            #START GET BIOS-----------------------------------------------------------
            $MainForm.Text = 'Getting Bios info from WMI...'
	        $OS = Get-WmiObject Win32_bios -ComputerName $PC_Name -Credential $Script:Credentials
            $MainForm.Text = 'Validating Bios info returned...'
	        if ($OS)
	        {
                #WMI RETUNED NOT NULL
	            $Bios_Ver = $($OS.SMBIOSBIOSVersion)
	            if($Bios_Ver)
	            {
                    #SMBIOSBIOSVERISON IS NOT NULL
                    $MainForm.Text = 'Setting Bios info...'
	                $out_Bios_Ver = $Bios_Ver
	            }
	            else
	            {
                    #SMBIOSBIOSVERSION IS NULL
                    $MainForm.Text = 'Setting Bios info...'
	                $out_Bios_Ver = "Couldn't Retreive Bios"
	            }
	        }
	        else
	        {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting Bios info returned...'
	            $out_Bios_Ver = "Couldn't Retreive Bios"
	        }
            #END GET BIOS-----------------------------------------------------------
            
            #START GET RAM AMOUNT (GB)-----------------------------------------------
            $MainForm.Text = 'Getting Ram amount info from WMI...'
            $arryRamModules = @()
            #$PC_Ram_Amount_GB = (Get-WMIObject -class Win32_PhysicalMemory -computername $PC_Name -Credential $Script:Credentials | Measure-Object -Property capacity -Sum | % {[Math]::Round(($_.sum / 1GB),2)})
            $PC_Ram_Amount_GB = (Get-WMIObject -class Win32_PhysicalMemory -computername $PC_Name -Credential $Script:Credentials | %{$arryRamModules += [Math]::Round(($_.capacity / 1GB), 2)}); foreach($i in $arryRamModules){$PC_Ram_Amount_GB += $i}
            $MainForm.Text = 'Validating Ram amount info...'
            if ($PC_Ram_Amount_GB)
            {
                #WMI RETURNED NOT NULL
                $MainForm.Text = 'Setting Ram amount info...'
                $strRamModules = ""
                if($arryRamModules.count -gt 1)
                {
                        $ramgrid = $arryRamModules |Group-object -noelement
                        $ramcount = 0
                        foreach($count in $ramgrid){$ramcount = $ramcount + 1}
                        if($ramcount -gt 1)
                        {
                            # multiple different rams in pc
                            foreach($i in $($ramgrid)){$strRamModules += " ($($i.count) X $($i.name) GB)"}

                        }
                        else
                        {
                            #same type of ram
                            $strRamModules = " ($($ramgrid.count) X $($ramgrid.name) GB)"
                        }   
                }
                $out_PC_Ram_Amount = "$PC_Ram_Amount_GB GB" + $strRamModules
            }
            else
            {
                #WMI RETURNED NULL
                $MainForm.Text = 'Setting Ram amount info...'
                $out_PC_Ram_Amount = "Couldn't get RAM info"
            }
            #END GET RAM AMOUNT (GB)-----------------------------------------------

            #START GET LAST LOGIN EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Login Event from WMI...'
	        $PC_LastUserLogon_Timestamp = Get-LastloginTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Login Event from WMI...'
	        if($PC_LastUserLogon_Timestamp.Errormsg)
	        {
                #GET-LASTLOGINTIME FUNCTION RETURNED ERROR
                $MainForm.Text = 'Setting Last Login Event from WMI...'
	            $out_PC_LastUserLogon_Timestamp = $PC_LastUserLogon_Timestamp.Errormsg
                $out_PC_Session_Length = $out_PC_LastUserLogon_Timestamp.Errormsg
	        }
	        else
	        {
                #GET-LASTLOGINTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Login Event from WMI...'
	            $out_PC_LastUserLogon_Timestamp = $PC_LastUserLogon_Timestamp.output
                $out_PC_Session_Length = ((Convert-To-TimeFromOccurance -time $($PC_LastUserLogon_Timestamp.output)).output)
	        }
            #END GET LAST LOGIN EVENT -----------------------------------------------
	        
            #START GET LAST BOOT EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Boot Event from WMI...'
	        $PC_LastBoot_Time = Get-LastbootupTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Boot Event from WMI...'
	        if($PC_LastBoot_Time.Errormsg)
	        {
                #GET-LASTBOOTUPTIME FUNCTION RETURNED ERRORS
                $MainForm.Text = 'Setting Last Boot Event from WMI...'
	            $out_PC_LastBoot_Time = $PC_LastBoot_Time.Errormsg
	            $out_PC_Time_Since_LastBoot = $out_PC_LastBoot_Time
	        }
	        else
	        {
                #GET-LASTBOOTUPTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Boot Event from WMI...'
                $out_PC_LastBoot_Time = $PC_LastBoot_Time.output
	            $out_PC_Time_Since_LastBoot = ((Convert-To-TimeFromOccurance -time $($PC_LastBoot_Time.output)).output)
	        }
            #END GET LAST BOOT EVENT -----------------------------------------------
	
            #START GET LAST REBOOT EVENT -----------------------------------------------
            $MainForm.Text = 'Getting Last Reboot Event from WMI...'
	        $PC_LastReboot_Time = Get-LastRebootInitiatedTime -ComputerName $PC_Name -isOnline $true
            $MainForm.Text = 'Validating Last Reboot Event from WMI...'
	        if($PC_LastReboot_Time.Errormsg)
	        {
                #GET-LASTREBOOTINITIATEDTIME FUNCTION RETURNED ERRORS
                $MainForm.Text = 'Setting Last Reboot Event from WMI...'
	            $out_PC_LastReboot_Time = $PC_LastReboot_Time.Errormsg
	        }
	        else
	        {
                #GET-LASTREBOOTINITIATEDTIME FUNCTION RETURNED NO ERRORS
                $MainForm.Text = 'Setting Last Reboot Event from WMI...'
	            $out_PC_LastReboot_Time = ((Convert-To-TimeFromOccurance -time $($PC_LastReboot_Time.output)).output)
	        }
            #END GET LAST REBOOT EVENT -----------------------------------------------

            #START GET REBOOT PENDING --------------------------------------------------
            $MainForm.Text = 'Getting Reboot Pending from WMI...'
	        $out_rebootPending = (Invoke-WmiMethod -ComputerName $PC_Name -Namespace root\ccm\clientsdk -Class CCM_ClientUtilities -Name DetermineIfRebootPending).RebootPending
            $MainForm.Text = 'Validating Reboot pending info...'
	        if ($out_rebootPending -eq $null)
	        {
                #WMI RETURNED NOT NULL
                $MainForm.Text = 'Setting Reboot pending info...'
	            $out_RebootPending = "Couldn't Contact Computer"
	        }
            #END GET REBOOT PENDING --------------------------------------------------
	    }
        else
        {
            #isOnline is false

            $MainForm.Text = 'Setting vars on no connection...'
	        $out_PC_Time_Since_LastBoot = "Couldn't Contact Computer"
	        $out_rebootPending = "Couldn't Contact Computer"
	        $out_PC_LastReboot_Time = "Couldn't Contact Computer"
	        $out_PC_LastUserLogon_Timestamp = "Couldn't Contact Computer"
	        $out_Bios_Ver = "Couldn't Contact Computer"
	        $out_PC_CurrentUserSSO = "Couldn't Contact Computer"
	        $out_PC_CurrentUserName = "Couldn't Contact Computer"
	        $out_User_Sessions = "Couldn't Contact Computer"
	        $out_FreeRam = "Couldn't Contact Computer"
	        $out_FreeVirt = "Couldn't Contact Computer"
	        $out_GfxVer = "Couldn't Contact Computer"
	        $out_GfxDriver = "Couldn't Contact Computer"
	        $out_winver = "Couldn't Contact Computer"
	        $out_PC_Model = "Couldn't Contact Computer"
            $out_PC_Ram_Amount = "Couldn't Contact Computer"
            $out_PC_Session_Length = "Couldn't Contact Computer"
        }

        if($nousers -eq $true)
        {
            $MainForm.Text = 'Setting vars on current users...'
            $out_PC_CurrentUserSSO = "No Users Currently Logged in"
	        $out_PC_CurrentUserName = "No Users Currently Logged in"
        }
	    if(!($out_User_Sessions))
	    {
	        $properties = @{'username' = "Couldn't Get Sessions";
	                        'SESSIONNAME' = "Couldn't Get Sessions";
	                        'STATE' = "Couldn't Get Sessions";
	                        'idleTime' = "Couldn't Get Sessions";
	                        'logonTime' = "Couldn't Get Sessions";
                            }
	        $out_User_Sessions = New-Object �TypeName PSObject �Prop $properties
	    }
    
        #START SET TEXTBOX VISIBILITY -------------------------------
        $tbx_PC_AD_Desc.Visible = $true
        $tbx_User_AD_Name.visible = $true
        $tbx_User_AD_ID.Visible = $true
        $lbl_User_AD_ID.Visible = $true
        $tbx_User_AD_Email.Visible = $true
        $lbl_User_AD_Email.Visible = $true
        #PC INFO
        $tbx_PC_Name.Visible = $true
        $tbx_PC_IP.Visible = $True
        $lbl_PC_IP.Visible = $True
        $tbx_PC_Model.Visible = $true
        $tbx_PC_LastBoot_Time.Visible = $true
        $tbx_PC_LastRestart_Time.Visible = $true
        $tbx_PC_Gfx_Driver.Visible = $true
        $tbx_PC_Gfx_Ver.Visible = $true
        $tbx_PC_Bios_Ver.Visible = $true
        $tbx_PC_Win_Ver.Visible = $true
        $tbx_PC_Ram_Amount.Visible = $true
        #Snapshot
        $tbx_PC_FreeRam.Visible = $true
        $tbx_PC_FreeVirtMem.Visible = $true
        #Current Users
        $tbx_PC_User_SSO.Visible = $true
        $tbx_PC_User_Name.Visible = $true
        #Current Sessions
        $tbx_PC_Session_UserName.Visible = $true
        $tbx_PC_Session_Type.Visible = $true
        $tbx_PC_Session_State.Visible = $true
        $tbx_PC_Session_IdleTime.Visible = $true
        $tbx_PC_Session_LogonTime.Visible = $true
        #MISC Info
        $tbx_Misc_Last_LoginTime.Visible = $true
        $tbx_Misc_User_Session_Length.Visible = $true
        $tbx_Misc_PC_RebootPending.Visible = $true
        #Service-now info
        $tbx_SN_PC_Asset_Function.Visible = $true
        $tbx_SN_PC_Substate.Visible = $true
        $tbx_SN_PC_State.Visible = $true
        $tbx_SN_User_Dept.Visible = $true
        $tbx_SN_User_Location.Visible = $true
        $tbx_SN_User_Assigned.Visible = $true
        #Meraki Info
        $tbx_Meraki_IP.Visible = $true
        $tbx_Meraki_User_Address.Visible = $true
        $tbx_Meraki_Serial.Visible = $true
        Set-Display-Controls
        #END SET TEXTBOX VISIBILITY -------------------------------
    
        #START SET TEXTBOX VALUES -------------------------------
	    #AD INFO
        $MainForm.Text = 'Setting form objects...'
        $MainForm.Text = 'Updating AD Info Textboxes'
        $tbx_PC_AD_Desc.text = $out_PC_description 
        $tbx_User_AD_Name.text = $out_User_Assigned
        $tbx_User_AD_Email.text = $out_User_Email
        $tbx_User_AD_ID.text = $out_User_ID
        #PC INFO
        $tbx_PC_Name.text = $out_PC_Name
        $tbx_PC_IP.text = $out_PC_IP
        $MainForm.Text = 'Updating PC Info Textboxes'
        $tbx_PC_Model.text = $out_PC_Model
        $tbx_PC_LastBoot_Time.text = $out_PC_Time_Since_LastBoot
        $tbx_PC_LastRestart_Time.text = $out_PC_LastReboot_Time
        $tbx_PC_Gfx_Driver.text = $out_GfxDriver
        $tbx_PC_Gfx_Ver.text = $out_GfxVer
        $tbx_PC_Bios_Ver.text = $out_Bios_Ver
        $tbx_PC_Win_Ver.text = $out_winver
        $tbx_PC_Ram_Amount.text = $out_PC_Ram_Amount
        #Snapshot
        $MainForm.Text = 'Updating Snapshot Textboxes'
        $tbx_PC_FreeRam.text = $out_FreeRam
        $tbx_PC_FreeVirtMem.text = $out_FreeVirt
        #Current Users
        $tbx_PC_User_SSO.text = $out_PC_CurrentUserSSO
        $tbx_PC_User_Name.text = $out_PC_CurrentUserName
        #Current Sessions
	    $MainForm.Text = 'Updating Session Textboxes'
        $tbx_PC_Session_UserName.text = $out_User_Sessions.username
        $tbx_PC_Session_Type.text = $out_User_Sessions.SESSIONNAME
        $tbx_PC_Session_State.text = $out_User_Sessions.STATE
        $tbx_PC_Session_IdleTime.text = $out_User_Sessions.idleTime
        $tbx_PC_Session_LogonTime.text = $out_User_Sessions.logonTime
        #MISC Info
        $MainForm.Text = 'Updating MISC Textboxes'
        $tbx_Misc_Last_LoginTime.text = $out_PC_LastUserLogon_Timestamp
        $tbx_Misc_User_Session_Length.text = $out_PC_Session_Length
        $tbx_Misc_PC_RebootPending.text = $out_rebootPending
        #END SET TEXTBOX VALUES -------------------------------
        $MainForm.Text = 'Done!'
        }
        else
        {
            write-host "PC_Name: $PC_Name"
            # NO VALID IP ADDRESS OR COMPUTER NAME FROM AD
            $MainForm.Text = "PC IP/Name was invalid!"
            $timerJobTracker.Stop()
        }
	}
	else
	{
        $MainForm.Text = $Param_ErrorMsg
	}
}
#END SEARCH-BY-PC--------------------------------------------------------------------------------------------------------------------------------------------------

#HIDE CONSOLE IMPORTS---------------------------------------------------------------------------------------------------------
#---------------------------------------------- 
#region Import Assemblies 
#---------------------------------------------- 
[void][Reflection.Assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
[void][Reflection.Assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
[void][Reflection.Assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a')

Add-Type -Name Window -Namespace Console -MemberDefinition '
[DllImport("Kernel32.dll")]
public static extern IntPtr GetConsoleWindow();

[DllImport("user32.dll")]
public static extern bool ShowWindow(IntPtr hWnd, Int32 nCmdShow);
'
#HIDE CONSOLE IMPORTS---------------------------------------------------------------------------------------------------------
function Show-Console
{
    $Script:ShowConsole = $true
    $consolePtr = [Console.Window]::GetConsoleWindow()

    # Hide = 0,
    # ShowNormal = 1,
    # ShowMinimized = 2,
    # ShowMaximized = 3,
    # Maximize = 3,
    # ShowNormalNoActivate = 4,
    # Show = 5,
    # Minimize = 6,
    # ShowMinNoActivate = 7,
    # ShowNoActivate = 8,
    # Restore = 9,
    # ShowDefault = 10,
    # ForceMinimized = 11

    [Console.Window]::ShowWindow($consolePtr, 4)
}

function Hide-Console
{
    $Script:ShowConsole = $false
    $consolePtr = [Console.Window]::GetConsoleWindow()
    #0 hide
    [Console.Window]::ShowWindow($consolePtr, 0)
}

#endregion Import Assemblies 

#MAIN GUI FORM FUNCTION
function Main { 
<# 
    .SYNOPSIS 
        The Main function starts the project application. 
     
    .PARAMETER Commandline 
        $Commandline contains the complete argument string passed to the script packager executable. 
     
    .NOTES 
        Use this function to initialize your script and to call GUI forms. 
         
    .NOTES 
        To get the console output in the Packager (Forms Engine) use:  
        $ConsoleOutput (Type: System.Collections.ArrayList) 
#> 
    Param ([String]$Commandline) 
         
    #-------------------------------------------------------------------------- 
    #TODO: Add initialization script here (Load modules and check requirements) 
     
     
    #-------------------------------------------------------------------------- 
     
    if((Call-MainForm_psf) -eq 'OK') 
    { 
         
    } 
     
    $global:ExitCode = 0 #Set the exit code for the Packager 
} 
 
#endregion Source: Startup.pss 
 
#region Source: MainForm.psf 
function Call-MainForm_psf 
{ 
    #---------------------------------------------- 
    #region Import the Assemblies 
    #---------------------------------------------- 
    [void][reflection.assembly]::Load('System.Windows.Forms, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
    [void][reflection.assembly]::Load('System.Data, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089') 
    [void][reflection.assembly]::Load('System.Drawing, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a') 
    #endregion Import Assemblies 
 
    #---------------------------------------------- 
    #region Generated Form Objects 
    #---------------------------------------------- 
    [System.Windows.Forms.Application]::EnableVisualStyles() 




    #MainForm
    #$MainForm = New-Object 'System.Windows.Forms.Form'
    $MainForm = New-Object DoubleBufferedForm

    #Splitcontainers
    $splitcontainer = New-Object 'System.windows.forms.splitcontainer'

    #Panels
    $panelLeft = New-Object 'System.Windows.Forms.Panel'
    $panelRight = New-Object 'System.Windows.Forms.Panel'
    $panel8 = New-Object 'System.Windows.Forms.Panel'
    $panel7 = New-Object 'System.Windows.Forms.Panel'
    $panel6 = New-Object 'System.Windows.Forms.Panel'
    $panel5 = New-Object 'System.Windows.Forms.Panel'
    $panel4 = New-Object 'System.Windows.Forms.Panel'
    $panel3 = New-Object 'System.Windows.Forms.Panel'
    $panel2 = New-Object 'System.Windows.Forms.Panel'
    $panel1 = New-Object 'System.Windows.Forms.Panel'

    #Buttons 
    $ButtonExit = New-Object 'System.Windows.Forms.Button' 
    $ButtonSearchByPC = New-Object 'System.Windows.Forms.Button'
	$ButtonSearchByUser = New-Object 'System.Windows.Forms.Button'
	$ButtonRDP = New-Object 'System.Windows.Forms.Button'
	$ButtonMSRA = New-Object 'System.Windows.Forms.Button'
	$ButtonShowFixes = New-Object 'System.Windows.Forms.Button'
	$ButtonRefresh = New-Object 'System.Windows.Forms.Button'      
    $ButtonRestartNow = New-Object 'System.Windows.Forms.Button'
    $ButtonSetupAutomation = New-Object 'System.Windows.Forms.Button' 
    $ButtonChangeFixFolder = New-Object 'System.Windows.Forms.Button' 
	$ButtonShowMain = New-Object 'System.Windows.Forms.Button'
    $ButtonShowConsole = New-Object 'System.Windows.Forms.Button'
    $ButtonShowEUC = New-Object 'System.Windows.Forms.Button'
    $ButtonChangeEUCFolder = New-Object 'System.Windows.Forms.Button'
    $ButtonReturnToEUC = New-Object 'System.Windows.Forms.Button'
    $ButtonCShare  = New-Object 'System.Windows.Forms.Button'
    $ButtonLoadGfx  = New-Object 'System.Windows.Forms.Button'

    #AD INFO
    $lbl_AD_Info = New-Object 'System.Windows.Forms.Label' 
    $lbl_PC_AD_Desc = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_AD_Desc = New-Object 'System.Windows.forms.Textbox'  
    $lbl_User_AD_Name = New-Object 'System.Windows.Forms.Label'
    $tbx_User_AD_Name = New-Object 'System.Windows.Forms.Textbox'
    $lbl_User_AD_ID = New-Object 'System.Windows.Forms.Label'
    $tbx_User_AD_ID = New-Object 'System.Windows.Forms.Textbox'
    $lbl_User_AD_Email = New-Object 'System.Windows.Forms.Label'
    $tbx_User_AD_Email = New-Object 'System.Windows.Forms.Textbox'
    #PC INFO
    $lbl_PC_Info = New-Object 'System.Windows.Forms.Label'
    $lbl_PC_Name = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Name = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_IP = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_IP = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Model = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Model = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_LastBoot_Time = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_LastBoot_Time = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_LastRestart_Time = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_LastRestart_Time = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Gfx_Driver = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Gfx_Driver = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Gfx_Ver = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Gfx_Ver = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Bios_Ver = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Bios_Ver = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Win_Ver = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Win_Ver = New-Object 'System.Windows.forms.Textbox'
	$lbl_PC_Ram_Amount = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Ram_Amount = New-Object 'System.Windows.forms.Textbox'
    #Snapshot
    $lbl_Snapshot = New-Object 'System.Windows.Forms.Label' 
    $lbl_PC_FreeRam = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_FreeRam = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_FreeVirtMem = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_FreeVirtMem = New-Object 'System.Windows.forms.Textbox'
    #Current Users
    $lbl_CurrentUsers = New-Object 'System.Windows.Forms.Label' 
    $lbl_PC_User_SSO = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_User_SSO = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_User_Name = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_User_Name = New-Object 'System.Windows.forms.Textbox'
    #Current Sessions
    $lbl_CurrentSessions = New-Object 'System.Windows.Forms.Label' 
    $lbl_PC_Session_UserName = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Session_UserName = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Session_Type = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Session_Type = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Session_State = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Session_State = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Session_IdleTime = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Session_IdleTime = New-Object 'System.Windows.forms.Textbox'
    $lbl_PC_Session_LogonTime = New-Object 'System.Windows.Forms.Label'  
    $tbx_PC_Session_LogonTime = New-Object 'System.Windows.forms.Textbox'
    #MISC Info
    $lbl_Misc = New-Object 'System.Windows.Forms.Label' 
    $lbl_Misc_Last_LoginTime = New-Object 'System.Windows.Forms.Label'  
    $tbx_Misc_Last_LoginTime = New-Object 'System.Windows.forms.Textbox'
    $lbl_Misc_User_Session_Length = New-Object 'System.Windows.Forms.Label'  
    $tbx_Misc_User_Session_Length = New-Object 'System.Windows.forms.Textbox'
    $lbl_Misc_PC_RebootPending = New-Object 'System.Windows.Forms.Label'  
    $tbx_Misc_PC_RebootPending = New-Object 'System.Windows.forms.Textbox'
    #SN Info
    $lbl_SN_Title = New-Object 'System.Windows.Forms.Label' 
    $lbl_SN_User_Assigned = New-Object 'System.Windows.Forms.Label'  
    $tbx_SN_User_Assigned = New-Object 'System.Windows.forms.Textbox'
    $lbl_SN_User_Dept = New-Object 'System.Windows.Forms.Label'  
    $tbx_SN_User_Dept = New-Object 'System.Windows.forms.Textbox'
    $lbl_SN_PC_State = New-Object 'System.Windows.Forms.Label'  
    $tbx_SN_PC_State = New-Object 'System.Windows.forms.Textbox'
    $lbl_SN_PC_Substate = New-Object 'System.Windows.Forms.Label'  
    $tbx_SN_PC_Substate = New-Object 'System.Windows.forms.Textbox'
    $lbl_SN_PC_Asset_Function = New-Object 'System.Windows.Forms.Label'  
    $tbx_SN_PC_Asset_Function = New-Object 'System.Windows.forms.Textbox'
    $lbl_SN_User_Location = New-Object 'System.Windows.Forms.Label' 
    $tbx_SN_User_Location = New-Object 'System.Windows.forms.Textbox'
    #Meraki info
    $lbl_Meraki = New-Object 'System.Windows.Forms.Label' 
    $lbl_Meraki_Serial = New-Object 'System.Windows.Forms.Label'  
    $tbx_Meraki_Serial = New-Object 'System.Windows.forms.Textbox'
    $lbl_Meraki_User_Address = New-Object 'System.Windows.Forms.Label'  
    $tbx_Meraki_User_Address = New-Object 'System.Windows.forms.Textbox'
    $lbl_Meraki_IP = New-Object 'System.Windows.Forms.Label'  
    $tbx_Meraki_IP = New-Object 'System.Windows.forms.Textbox'
    $tt = New-Object 'System.Windows.Forms.ToolTip'
    $labelSecondsLeftToRestart = New-Object 'System.Windows.Forms.Label' 
    $labelTime = New-Object 'System.Windows.Forms.Label' 
    $labelInOrderToApplySecuri = New-Object 'System.Windows.Forms.Label' 
    $timerJobTracker = New-Object 'System.Windows.Forms.Timer' 
    $InitialFormWindowState = New-Object 'System.Windows.Forms.FormWindowState' 
    $JobTrackerList = New-Object System.Collections.ArrayList
    $tt.InitialDelay = 1500
    $tt.IsBalloon = $true
    #endregion Generated Form Objects 
 
    #---------------------------------------------- 
    # User Generated Script 
    #---------------------------------------------- 
     
    $MainForm_Load=
    { 
        Hide-Console
        $timerJobtracker.Stop()
    } 
      
    $ButtonRestartNow_Click =
    { 
        # Restart the computer immediately
        #NEEDS TO CHANGE TO REBOOT GUI
	    Reboot-PC -computername $($tbx_PC_Name.text) 
    } 
     
    $ButtonSearchByPC_Click=
    {
        if(!($JobTrackerList))
        {
            $JobTrackerList = New-Object System.Collections.ArrayList
        }

        #DISABLE BUTTONS UNTIL DONE PROCESSING
        foreach ($btn in $panelRight.Controls)
        {
            $btn.enabled = $False
        }

        #SET CONTROLS VISIBLE
        foreach ($CTL in $panel1.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel2.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel3.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel4.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel5.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel6.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel7.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel8.Controls)
        {
            $CTL.visible = $true
        }
        
        $timerJobTracker.Start()

        #AD INFO
        $tbx_PC_AD_Desc.text = ""
        $tbx_User_AD_Name.text = ""
        $tbx_User_AD_Email.text = ""
        $tbx_User_AD_ID.text = ""
        #PC INFO
        $tbx_PC_Name.text = ""
        $tbx_PC_IP.text = ""
        $tbx_PC_Model.text = ""
        $tbx_PC_LastBoot_Time.text = ""
        $tbx_PC_LastRestart_Time.text = ""
        $tbx_PC_Gfx_Driver.text = ""
        $tbx_PC_Gfx_Ver.text = ""
        $tbx_PC_Bios_Ver.text = ""
        $tbx_PC_Win_Ver.text = ""
        $tbx_PC_Ram_Amount.text = ""
        #Snapshot
        $tbx_PC_FreeRam.text = ""
        $tbx_PC_FreeVirtMem.text = ""
        #Current Users
        $tbx_PC_User_SSO.text = ""
        $tbx_PC_User_Name.text = ""
        #Current Sessions
        $tbx_PC_Session_UserName.text = ""
        $tbx_PC_Session_Type.text = ""
        $tbx_PC_Session_State.text = ""
        $tbx_PC_Session_IdleTime.text = ""
        $tbx_PC_Session_LogonTime.text = ""
        #MISC Info
        $tbx_Misc_Last_LoginTime.text = ""
        $tbx_Misc_User_Session_Length.text = ""
        $tbx_Misc_PC_RebootPending.text = ""
        #SN Info
        $tbx_SN_User_Assigned.text = "Loading..."
        $tbx_SN_User_Dept.text = "Loading..."
        $tbx_SN_User_Location.text = "Loading..."
        $tbx_SN_PC_State.text = "Loading..."
        $tbx_SN_PC_Substate.text = "Loading..."
        $tbx_SN_PC_Asset_Function.text = "Loading..."
        #Meraki Info
        $tbx_Meraki_IP.text = "Loading..."
        $tbx_Meraki_Serial.text = "Loading..."
        $tbx_Meraki_User_Address.text = "Loading..."
    
	    $result = $null
	    $result = Show-SearchForm("Search PC")
        $Script:LastSearchBy = $null
        $Script:LastSearch = $null
        $MainForm.text = "Starting Search..."
        $tbx_PC_Model.BackColor = $tbx_PC_Name.BackColor
        if($result)
        {
	        Search-By-PC -computername $result
        }
        else
        {
            $MainForm.text = "Aborted Search"
            $timerJobTracker.Stop()
        }
        [System.Windows.Forms.Application]::DoEvents()
        foreach ($btn in $panelRight.Controls)
        {
            $btn.enabled = $true
        }
    } 

	$ButtonSearchByUser_Click=
    {
        if(!($JobTrackerList))
        {
            $JobTrackerList = New-Object System.Collections.ArrayList
        }

        #DISABLE BUTTONS UNTIL DONE PROCESSING
        foreach ($btn in $panelRight.Controls)
        {
            $btn.enabled = $false
        }

        #SET CONTROLS VISIBLE
        foreach ($CTL in $panel1.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel2.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel3.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel4.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel5.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel6.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel7.Controls)
        {
            $CTL.visible = $true
        }
        foreach ($CTL in $panel8.Controls)
        {
            $CTL.visible = $true
        }

        $timerJobTracker.Start()

        #AD INFO
        $tbx_PC_AD_Desc.text = ""
        $tbx_User_AD_Name.text = ""
        $tbx_User_AD_Email.text = ""
        $tbx_User_AD_ID.text = ""
        #PC INFO
        $tbx_PC_Name.text = ""
        $tbx_PC_IP.text = ""
        $tbx_PC_Model.text = ""
        $tbx_PC_LastBoot_Time.text = ""
        $tbx_PC_LastRestart_Time.text = ""
        $tbx_PC_Gfx_Driver.text = ""
        $tbx_PC_Gfx_Ver.text = ""
        $tbx_PC_Bios_Ver.text = ""
        $tbx_PC_Win_Ver.text = ""
        $tbx_PC_Ram_Amount.text = ""
        #Snapshot
        $tbx_PC_FreeRam.text = ""
        $tbx_PC_FreeVirtMem.text = ""
        #Current Users
        $tbx_PC_User_SSO.text = ""
        $tbx_PC_User_Name.text = ""
        #Current Sessions
        $tbx_PC_Session_UserName.text = ""
        $tbx_PC_Session_Type.text = ""
        $tbx_PC_Session_State.text = ""
        $tbx_PC_Session_IdleTime.text = ""
        $tbx_PC_Session_LogonTime.text = ""
        #MISC Info
        $tbx_Misc_Last_LoginTime.text = ""
        $tbx_Misc_User_Session_Length.text = ""
        $tbx_Misc_PC_RebootPending.text = ""
        #SN Info 
        $tbx_SN_User_Assigned.text = "Loading..."
        $tbx_SN_User_Dept.text = "Loading..."
        $tbx_SN_User_Location.text = "Loading..."
        $tbx_SN_PC_State.text = "Loading..."
        $tbx_SN_PC_Substate.text = "Loading..."
        $tbx_SN_PC_Asset_Function.text = "Loading..."
        #Meraki Info
        $tbx_Meraki_IP.text = "Loading..."
        $tbx_Meraki_Serial.text = "Loading..."
        $tbx_Meraki_User_Address.text = "Loading..."

	    $result = $null
	    $result = Show-SearchForm("Search User")
        $Script:LastSearchBy = $null
        $Script:LastSearch = $null
        $MainForm.text = "Starting Search..."
        $tbx_PC_Model.BackColor = $tbx_PC_Name.BackColor
        if($result)
        {
	        Search-By-User -userin $result      
        }
        else
        {
            $MainForm.text = "Aborted Search"
            $timerJobTracker.Stop()
        }
        [System.Windows.Forms.Application]::DoEvents()
        foreach ($btn in $panelRight.Controls)
        {
            $btn.enabled = $true
        }
    } 

	$ButtonRDP_Click=
    {
	    Run-RDP -computername $($tbx_PC_Name.text)
    } 

	$ButtonMSRA_Click=
    {
        #MSRA NEEDS TO BE FIXED YET
	    Run-MSRA -computername $($tbx_PC_Name.text)
    }

    $ButtonLoadGfx_Click=
    {
        $MainForm.text = "Checking if $($tbx_PC_Name.text) is online"
        if (((Test-IsOnline $tbx_PC_Name.text).online) -eq $true)
        {
            $obj_Gfx = Load-Gfx-Info($($tbx_PC_Name.Text))
            if($obj_Gfx.GfxDriver)
            {
                $tbx_PC_Gfx_Driver.text = $obj_Gfx.GfxDriver
            }
            else
            {
                $tbx_PC_Gfx_Driver.text = $obj_Gfx.Errormsg
            }

            if($obj_Gfx.GfxVersion)
            {
                $tbx_PC_Gfx_Ver.text = $obj_Gfx.GfxVersion
            }
            else
            {
                $tbx_PC_Gfx_Ver.text = $obj_Gfx.Errormsg
            }
        }
        else
        {
        $MainForm.text = "$($tbx_PC_Name.text) is not Online!"
        }
    }

    $ButtonShowEUC_Click=
    {

        $panelRight.Controls.Clear()
        if(!($Script:EUCLocation))
        {
            #if no location in script is set
            $folder = Find-Folders
            if($folder)
            {
                Set-EUCLocation($folder)
                $lstEUCScripts = Get-SubfoldersInLocation($folder)
                if($lstEUCScripts)
                {
                    Set-EUCButtons($lstEUCScripts)
                }
            }
        }
        else
        {
            if(Test-Path "$Script:EUCLocation")
            {
                $lstEUCScripts = Get-SubfoldersInLocation($Script:EUCLocation)
                if($lstEUCScripts)
                {
                    Set-EUCButtons($lstEUCScripts)
                }
            }
            else
            {
                $folder = Find-Folders
                if($folder)
                {
                    Set-EUCLocation($folder)
                    $lstEUCScripts = Get-SubfoldersInLocation($folder)
                    if($lstEUCScripts)
                    {
                        Set-EUCButtons($lstEUCScripts)
                    }
                }
            }
        }
        if($Script:InitialUserStarted = "bwienk1")
        {
            #DEBUG FOR CREATOR
            $panelRight.Controls.Add($ButtonShowConsole)
        }
        $panelRight.Controls.Add($ButtonChangeEUCFolder)
	    $panelRight.Controls.Add($ButtonShowMain)

	    #$MainForm.Refresh()
    }

	$ButtonShowFixes_Click=
    {
        

	    $panelRight.Controls.Clear()
        if(!($Script:FixesLocation))
        {
            #if no location in script is set
            $folder = Find-Folders
            if($folder)
            {
                Set-FixesLocation($folder)
                $lstFixScripts = Get-FixesInLocation-NoRecure($folder)
                if($lstFixScripts)
                {
                    Set-FixButtons($lstFixScripts)
                }
            }
        }
        else
        {
            if(Test-Path "$Script:FixesLocation")
            {
                $lstFixScripts = Get-FixesInLocation-NoRecure($Script:FixesLocation)
                if($lstFixScripts)
                {
                    Set-FixButtons($lstFixScripts)
                }
            }
            else
            {
                $folder = Find-Folders
                if($folder)
                {
                    Set-FixesLocation($folder)
                    $lstFixScripts = Get-FixesInLocation-NoRecure($folder)
                    if($lstFixScripts)
                    {
                        Set-FixButtons($lstFixScripts)
                    }
                }
            }
        }
        if($Script:InitialUserStarted = "bwienk1")
        {
            #DEBUG FOR CREATOR
            $panelRight.Controls.Add($ButtonShowConsole)
        }
        $panelRight.Controls.Add($ButtonChangeFixFolder)
	    $panelRight.Controls.Add($ButtonShowMain)

	    #$MainForm.Refresh()
    }

    $ButtonChangeEUCFolder_Click=
    {
        #change EUC folder button
        $folder = Find-Folders
        if($folder)
        {
           Set-EUCLocation($folder)
           $lstEUCScripts = Get-SubfoldersInLocation($folder)
           if($lstEUCScripts)
           {
                Set-EUCButtons($lstEUCScripts)

           }
        }
    }

    $ButtonChangeFixFolder_Click=
    {
        #change fix folder button
        $folder = Find-Folders
        if($folder)
        {
           Set-FixesLocation($folder)
           $lstFixScripts = Get-FixesInLocation-NoRecure($folder)
           if($lstFixScripts)
           {

                Set-FixButtons($lstFixScripts)

           }
        }
    }

    $ButtonShowConsole_Click=
    {
        if($Script:ShowConsole -eq $true)
        {
            Hide-Console
            $Script:SchowConsole = $false
        }
        elseif($Script:ShowConsole -eq $false)
        {
            Show-Console
            $Script:SchowConsole = $true
        }
    }

	$ButtonShowMain_Click=
    {
        $panelRight.Controls.Clear()
        $mainform.suspendLayout()
        $splitcontainer.suspendLayout()
        $panelRight.suspendLayout()
        
        
	    
        if($Script:InitialUserStarted = "bwienk1")
        {
            #DEBUG FOR CREATOR
            $panelRight.Controls.Add($ButtonShowConsole)
        }
        $panelRight.Controls.Add($ButtonSetupAutomation)
	    $panelRight.Controls.Add($ButtonRDP)
	    $panelRight.Controls.Add($ButtonMSRA)
        $panelRight.Controls.add($ButtonShowEUC)
	    $panelRight.Controls.Add($ButtonShowFixes)
        $panelRight.Controls.Add($ButtonCShare)
        $panelRight.Controls.add($ButtonLoadGfx)
	    $panelRight.Controls.Add($ButtonRefresh)
	    $panelRight.Controls.Add($ButtonRestartNow)
	    $panelRight.Controls.Add($ButtonSearchByUser)
	    $panelRight.Controls.Add($ButtonSearchByPC)
        $panelRight.resumeLayout()
        $splitcontainer.resumeLayout()
        $mainform.resumelayout()

	}

    $ButtonSetupAutomation_Click=
    {
        $panelRight.controls.clear()
        $mainform.suspendLayout()
        $splitcontainer.suspendLayout()
        $panelRight.suspendLayout()
        $buttons_functionslist = @("Change Admin Creds", "Change Normal Creds", "Change Meraki Creds")
        
        $buttons_functionslist = $buttons_functionslist | sort -Descending
        $buttons_functionbuttoncount = $buttons_functionslist.count
        $loop = 0
        while($loop -lt $buttons_functionbuttoncount)
	    {
	        $thisbutton = New-Object System.Windows.Forms.Button
            $thisbutton.Size = '77, 45' 
            [string]$calling = $buttons_functionslist[$loop]
            $thisbutton.tag=@{Script=$calling}
            $thisbutton.UseVisualStyleBackColor = $True 
	        $thisbutton.Dock = [System.Windows.Forms.DockStyle]::Top
            
            #BUTTON CLICK
	        $thisbutton.Add_Click({param($Sender)
                $Script:EnabledButtons = $false
                $ButtonLoadGfx.Enabled = $Script:EnabledButtons
                $ButtonCShare.Enabled = $Script:EnabledButtons
                $ButtonSearchByUser.Enabled = $Script:EnabledButtons
                $ButtonSearchByPC.Enabled = $Script:EnabledButtons
                $ButtonRestartNow.Enabled = $Script:EnabledButtons
                $ButtonRefresh.Enabled = $Script:EnabledButtons
                $ButtonShowFixes.Enabled = $Script:EnabledButtons
                $ButtonShowEUC.Enabled = $Script:EnabledButtons
                $ButtonReturnToEUC.Enabled = $Script:EnabledButtons
                $ButtonMSRA.Enabled = $Script:EnabledButtons
                $ButtonRDP.Enabled = $Script:EnabledButtons
                $ButtonShowMain.Enabled = $Script:EnabledButtons
                $ButtonChangeFixFolder.Enabled = $Script:EnabledButtons
                $ButtonChangeEUCFolder.Enabled = $Script:EnabledButtons
                #$mainform.Refresh()
                $mappingsuccess = $false

                #SETUP BUTTONS FOR PASSWORD CHANGES
                [string]$thisbuttonname = $($Sender.Tag.script)
                if($thisbuttonname -eq "Change Admin Creds")
                {
                    $Acredsresult = $null
                    $result = $null
                    $result = Show-PasswordsForm -Searchfor "Enter Admin Username"
                    if($result)
                    {
                        $MainForm.Text = "Checking input..."
                        if($result -like "*-a")
                        {
                            if($result -like 'afii\*')
                            {
                                $result = $result -replace "afii\"
                            }
                            $MainForm.Text = "Formatting input..."
                            $admin_user = $result
                            $admin_user.trim() | out-file C:\Temp\A_User.txt
                            $MainForm.Text = "Waiting for Admin password user input..."
                            $Acredsresult = Show-PasswordsForm -Searchfor "Enter Admin Password" -isPassword $true
                            if(!(test-path -Path "C:\Temp\CKey.key"))
                            {
                                $Key = New-Object Byte[] 16
                                $key | out-file C:\Temp\CKey.key
                            }
                            else
                            {
                                [Byte[]]$key = gc C:\Temp\CKey.key
                            }
                        }
                        if($Acredsresult)
                        {
                            $MainForm.Text = "Formatting Admin SSO input..."
                            $Acredsresult = $Acredsresult.trim()
                            $MainForm.Text = "Creating Admin Credentials..."
                            $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "AFII\$Admin_User",($Acredsresult | convertto-securestring -AsPlainText -Force)
                            $MainForm.Text = "Storing As Secured Admin Credentials..."
                            $password = $Acredsresult| convertto-securestring -AsPlainText -Force 
                            $password | ConvertFrom-SecureString -key $Key | out-file C:\Temp\ACreds_ss.txt
                            $Acredsresult = $null
                            $mappingsuccess -eq $true
                            $MainForm.Text = "Updated Admin Credentials!"
                        }
                        else
                        {
                            $MainForm.Text = "Failed to update Admin Creds!"
                        }
                    }
                    else
                    {
                        $MainForm.Text = "Failed to update Admin Creds!"
                    }
                }
                elseif($thisbuttonname -eq "Change Normal Creds")
                {
                    $credsresult = $null
                    $result = $null
                    $result = Show-PasswordsForm -Searchfor "Enter REGULAR Username"
                    if($result)
                    {
                        $MainForm.Text = "Checking input..."
                        if($result -like 'afii\*')
                        {
                            $result = $result -replace "afii\"
                        }
                        $MainForm.Text = "Formatting input..."
                        $nonAdmin_user = $result
                        $nonAdmin_user | out-file C:\temp\NA_User.txt
                        $MainForm.Text = "Waiting for REGULAR password user input..."
                        $Credsresult = Show-PasswordsForm -Searchfor "Enter REGULAR Password" -isPassword $true
                        if(!(test-path -Path "C:\Temp\CKey.key"))
                        {
                            $Key = New-Object Byte[] 16
                            $key | out-file C:\Temp\CKey.key
                        }
                        else
                        {
                            [Byte[]]$key = gc C:\Temp\CKey.key
                        }
                        
                        if($Credsresult)
                        {
                            $MainForm.Text = "Formatting Regular SSO input..."
                            $Credsresult = $Credsresult.trim()
                            $MainForm.Text = "Creating Regular Credentials..."
                            $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "AFII\$NonAdmin_User",($Credsresult | convertto-securestring -AsPlainText -Force)

                                    #success
                                    #TODO CATCH ACCESS DENIED EXCEPTION
                                    $mappingsuccess = $true
                                    $MainForm.Text = "Storing As Secured Credentials..."
                                    $password2 = $Credsresult| convertto-securestring -AsPlainText -Force 
                                    $password2 | ConvertFrom-SecureString -key $Key | out-file C:\Temp\Creds_ss.txt
                                    $Credsresult = $null
                                    $MainForm.Text = "Updated Regular Credentials!"
                        }
                        else
                        {
                            $MainForm.Text = "Failed to update Regular Credentials!"
                        }
                    }
                }
                elseif($thisbuttonname -eq "Change Meraki Creds")
                {
                    $MerakiEmail = $null
                    $MerakiResult = $null
                    $result = $null
                    $result = Show-PasswordsForm -Searchfor "Enter Meraki Login Email Address"
                    if($result)
                    {
                        $MainForm.Text = "Checking input..."
                        if($result -like '*@ampf.com')
                        {
                            #correct
                            $MerakiEmail = $result
                            $MerakiEmail.trim() | Out-File C:\Temp\M_Email.txt
                        }
                        else
                        {
                            #incorrect
                            $MerakiEmail = $null
                        }
                            
                        if($MerakiEmail)
                        {
                            $MainForm.Text = "Waiting for Meraki Login Password user input..."
                            $MerakiResult = Show-PasswordsForm -Searchfor "Enter Meraki Login Password" -isPassword $true
                            if(!(test-path -Path "C:\Temp\CKey.key"))
                            {
                                $Key = New-Object Byte[] 16
                                $key | out-file C:\Temp\CKey.key
                            }
                            else
                            {
                                [Byte[]]$key = gc C:\Temp\CKey.key
                            }
                        
                            if($MerakiResult)
                            {
                                $mappingsuccess = $true
                                $MainForm.Text = "Formatting Meraki input..."
                                $MerakiResult = $MerakiResult.trim()
                                $MainForm.Text = "Creating Meraki Credentials..."
                                #TODO CATCH ACCESS DENIED EXCEPTION
                                $MainForm.Text = "Storing As Secured Credentials..."
                                $password3 = $MerakiResult| convertto-securestring -AsPlainText -Force 
                                $password3 | ConvertFrom-SecureString -key $Key | out-file C:\Temp\M_Creds_ss.txt
                                $MerakiResult = $null
                                $MainForm.Text = "Updated Meraki Credentials!"
                            }
                        }
                        else
                        {
                            $MainForm.Text = "Failed to update Meraki Credentials!"
                        }
                    }
                    else
                    {
                        $MainForm.Text = "Failed to update Meraki Credentials!"
                    }
                }
                if($mappingsuccess -eq $true)
                {
                    Set-HDriveLocation
                    $Script:EnabledButtons = $true
                    $ButtonLoadGfx.Enabled = $Script:EnabledButtons
                    $ButtonCShare.Enabled = $Script:EnabledButtons
                    $ButtonSearchByUser.Enabled = $Script:EnabledButtons
                    $ButtonSearchByPC.Enabled = $Script:EnabledButtons
                    $ButtonRestartNow.Enabled = $Script:EnabledButtons
                    $ButtonRefresh.Enabled = $Script:EnabledButtons
                    $ButtonShowFixes.Enabled = $Script:EnabledButtons
                    $ButtonShowEUC.Enabled = $Script:EnabledButtons
                    $ButtonReturnToEUC.Enabled = $Script:EnabledButtons
                    $ButtonMSRA.Enabled = $Script:EnabledButtons
                    $ButtonRDP.Enabled = $Script:EnabledButtons
                    $ButtonShowMain.Enabled = $Script:EnabledButtons
                    $ButtonChangeFixFolder.Enabled = $Script:EnabledButtons
                    $ButtonChangeEUCFolder.Enabled = $Script:EnabledButtons
                    $ButtonSetupAutomation.text = "Change Passwords..."
                    #$mainform.Refresh()
                }
		    })
            [string]$thisbuttonname = $buttons_functionslist[$loop]
            $thisbutton.Text = $thisbuttonname
            $panelRight.controls.add($thisbutton)
	        $loop += 1
	    }

        if($Script:InitialUserStarted = "bwienk1")
        {
            #DEBUG FOR CREATOR
            $panelRight.Controls.Add($ButtonShowConsole)
        }
        $panelRight.Controls.Add($ButtonShowMain)
        $panelRight.resumeLayout()
        $splitcontainer.resumeLayout()
        $mainform.resumelayout()

	}

	$ButtonRefresh_Click=
    {
        foreach ($btn in $panelRight.Controls)
                {
                    $btn.enabled = $false
                }
        if($Script:LastSearchBy)
        {
    	    if($Script:LastSearch)
            {
                
                #Set Service-now textboxes
                $tbx_SN_User_Assigned.text = "Loading..."
                $tbx_SN_User_Dept.text = "Loading..."
                $tbx_SN_User_Location.text = "Loading..."
                $tbx_SN_PC_State.text = "Loading..."
                $tbx_SN_PC_Substate.text = "Loading..."
                $tbx_SN_PC_Asset_Function.text = "Loading..."
                #set Meraki Textboxes
                $tbx_Meraki_IP.text = "Loading..."
                $tbx_Meraki_Serial.text = "Loading..."
                $tbx_Meraki_User_Address.text = "Loading..."
                $tbx_PC_Model.BackColor = $tbx_PC_Name.BackColor

                #Set Search
                $search = $null
                $search = $Script:LastSearch
                $Script:LastSearchBy = $null
                $Script:LastSearch = $null
                
                #Start Timer
                $timerJobTracker.Start()

                $MainForm.text = "Refreshing..."
                Search-By-PC -computername $search
            }
            else
            {
                $MainForm.text = "Can't Refresh"
            }
        }
        else
        {
            $MainForm.text = "Can't Refresh"
        }
        [System.Windows.Forms.Application]::DoEvents()
        foreach ($btn in $panelRight.Controls)
        {
            $btn.enabled = $true
        }
    }       
     
    $ButtonExit_Click=
    {
        $MainForm.Close() 
    } 

    $ButtonCShare_Click=
    {
        if($tbx_PC_Name.text)
        {
            Open-CShare($tbx_PC_Name.text)
        }    
    }

    $tbx_PC_IP_TextChanged=
    {
        if($tbx_PC_IP.Text)
        {
            $ipaddress = $null
            $ipaddress = ExtractValidIPAddress($tbx_PC_IP.Text)
            if($ipaddress)
            {
                if($tbx_PC_Model.text -eq "Couldn't Contact Computer")
                {
                    if(!($JobTrackerList))
                    {
                        $JobTrackerList = New-Object System.Collections.ArrayList
                    }


                    $tbx_PC_Model.text = "Loading..."
                    $tbx_PC_LastBoot_Time.text = "Loading..."
                    $tbx_PC_LastRestart_Time.text = "Loading..."
                    $tbx_PC_Gfx_Driver.text = "Loading..."
                    $tbx_PC_Gfx_Ver.text = "Loading..."
                    $tbx_PC_Bios_Ver.text = "Loading..."
                    $tbx_PC_Win_Ver.text = "Loading..."
                    $tbx_PC_Ram_Amount.text = "Loading..."
                    #Snapshot
                    $tbx_PC_FreeRam.text = "Loading..."
                    $tbx_PC_FreeVirtMem.text = "Loading..."
                    #Current Users
                    $tbx_PC_User_SSO.text = "Loading..."
                    $tbx_PC_User_Name.text = "Loading..."
                    #Current Sessions
                    $tbx_PC_Session_UserName.text = "Loading..."
                    $tbx_PC_Session_Type.text = "Loading..."
                    $tbx_PC_Session_State.text = "Loading..."
                    $tbx_PC_Session_IdleTime.text = "Loading..."
                    $tbx_PC_Session_LogonTime.text = "Loading..."
                    #MISC Info
                    $tbx_Misc_Last_LoginTime.text = "Loading..."
                    $tbx_Misc_User_Session_Length.text = "Loading..."
                    $tbx_Misc_PC_RebootPending.text = "Loading..."
                    $Script:LastSearchBy = $null
                    $Script:LastSearch = $null
                    $MainForm.text = "Starting Search Via IP..."
                    $tbx_PC_Model.BackColor = $tbx_PC_Name.BackColor
                    [System.Windows.Forms.Application]::DoEvents()
	                Search-By-IP-Refresh -computername $($tbx_PC_IP.text)
                    [System.Windows.Forms.Application]::DoEvents()
                    if($tbx_PC_IP.Text)
                    {
                        $tbx_Meraki_IP.text = $tbx_PC_IP.Text
                    }
                    
                    
                }
            }
        }
    }

    $timerJobTracker_Tick=
    {
        write-host "Tick" #Just Because.... Debugging
        Update-JobTracker
        if($Script:BackgroundInfo)
        {
            $job = get-job -Name $Script:BackgroundInfo -ErrorAction SilentlyContinue
            if ($job.State -eq "Completed")
            {
                $Results = $job | Receive-job
                if($Results.Errormsg)
                {
                    $tbx_Meraki_IP.text = $Results.Errormsg
                    $tbx_Meraki_Serial.text = $Results.Errormsg
                    $tbx_Meraki_User_Address.text = $Results.Errormsg
                    $tbx_SN_User_Assigned.text = $Results.Errormsg
                    $tbx_SN_User_Dept.text = $Results.Errormsg
                    $tbx_SN_PC_State.text = $Results.Errormsg
                    $tbx_SN_PC_Substate.text = $Results.Errormsg
                    $tbx_SN_PC_Asset_Function.text = $Results.Errormsg
                    $tbx_SN_User_Location.text = $Results.Errormsg
                }
                else
                {
                    $tbx_Meraki_IP.text = $Results.Meraki_IP
                    if(!($tbx_PC_IP.text -like "*.*.*.*") -and $tbx_Meraki_IP.text -like "*.*.*.*")
                    {
                        $tbx_PC_IP.text = $tbx_Meraki_IP.text
                    }
                    $tbx_Meraki_Serial.text = $Results.Meraki_Serial
                    $tbx_Meraki_User_Address.text = $Results.User_Address
                    $tbx_SN_User_Assigned.text = $Results.User_Assigned
                    $tbx_SN_User_Dept.text = $Results.User_Dept
                    $tbx_SN_PC_State.text = $Results.Asset_State
                    $tbx_SN_PC_Substate.text = $Results.Asset_Substate
                    $tbx_SN_PC_Asset_Function.text = $Results.Asset_Function
                    $tbx_SN_User_Location.text = $Results.User_Location
                    if($tbx_PC_Model.text -eq "Couldn't Contact Computer" -or $tbx_PC_Model.text -eq $null)
                    {
                        if($Results.PC_Model -eq "LENOVO ThinkPad T480 (new)")
                        {
                            $tbx_PC_Model.text = "LENOVO ThinkPad T480"
                        }
                        else
                        {
                            $tbx_PC_Model.text = $Results.PC_Model
                        }
                    }
                }
                $job | Stop-Job
                $job | Remove-job
                $Script:BackgroundInfo = $null
                $timerJobTracker.Stop()
            }
            else
            {
                #ADD CODE FOR BACKGROUND JOB NOT COMPLETED YET
            }
        }
    } 
     
    #PAINT SETUP--------------------------------------------
    $panel2_Paint=[System.Windows.Forms.PaintEventHandler]{ 
    #Event Argument: $_ = [System.Windows.Forms.PaintEventArgs] 
        #TODO: Place custom script here  
    }
    $panel3_Paint=[System.Windows.Forms.PaintEventHandler]{ 
    #Event Argument: $_ = [System.Windows.Forms.PaintEventArgs] 
        #TODO: Place custom script here  
    } 
    $panel4_Paint=[System.Windows.Forms.PaintEventHandler]{ 
    #Event Argument: $_ = [System.Windows.Forms.PaintEventArgs] 
        #TODO: Place custom script here   
    } 
    $panel5_Paint=[System.Windows.Forms.PaintEventHandler]{ 
    #Event Argument: $_ = [System.Windows.Forms.PaintEventArgs] 
        #TODO: Place custom script here  
    } 
    $panel6_Paint=[System.Windows.Forms.PaintEventHandler]{ 
    #Event Argument: $_ = [System.Windows.Forms.PaintEventArgs] 
        #TODO: Place custom script here 
    }
    #END PAINT SETUP--------------------------------------------

    #---------------------------------------------- 
    #region Generated Events 
    #---------------------------------------------- 
     
    $Form_StateCorrection_Load= 
    { 
        #Correct the initial state of the form to prevent the .Net maximized form issue 
        $MainForm.WindowState = $InitialFormWindowState 
    } 
     
    $Form_StoreValues_Closing= 
    { 
        #Store the control values 
    } 
     
    $Form_Cleanup_FormClosed= 
    { 
        #Remove all event handlers from the controls 
        try 
        { 
            if ($Script:TrustedHosts)
            {
                Teardown-IP-Invoke
            }
            #REMOVE CLICKS ---------
            $ButtonLoadGfx.remove_click($ButtonLoadGfx_Click)
            $ButtonCShare.Remove_click($ButtonCShare_Click)
            $ButtonReturnToEUC.Remove_click($ButtonShowEUC_Click)
            $ButtonChangeEUCFolder.remove_Click($ButtonChangeEUCFolder_Click) 
            $ButtonChangeFixFolder.remove_Click($ButtonChangeFixFolder_Click) 
            $ButtonShowEUC.remove_Click($ButtonShowEUC_Click) 
	        $ButtonShowMain.remove_Click($ButtonShowMain_Click) 
        	$ButtonSearchByUser.remove_Click($ButtonSearchByUser_Click)
	        $ButtonRDP.remove_Click($ButtonRDP_Click)
	        $ButtonMSRA.remove_Click($ButtonMSRA_Click)
	        $ButtonShowFixes.remove_Click($ButtonShowFixes_Click)
	        $ButtonRefresh.remove_Click($ButtonRefresh_Click)
            $ButtonShowConsole.remove_Click($ButtonShowConsole_Click)
            $ButtonSetupAutomation.remove_Click($ButtonSetupAutomation_Click) 
            $ButtonExit.remove_Click($ButtonExit_Click) 
            $ButtonSearchByPC.remove_Click($ButtonSearchByPC_Click) 
            $ButtonRestartNow.remove_Click($ButtonRestartNow_Click)
            $timerJobTracker.remove_Tick($timerJobTracker_Tick)
            $panel6.remove_Paint($panel6_Paint)
            $panel5.remove_Paint($panel5_Paint)
            $panel4.remove_Paint($panel4_Paint) 
            $panel2.remove_Paint($panel2_Paint) 
            $panel1.remove_Paint($panel1_Paint)
            $panel3.remove_Paint($panel3_Paint)  
            $MainForm.remove_Load($MainForm_Load) 
            $MainForm.remove_Load($Form_StateCorrection_Load) 
            $MainForm.remove_Closing($Form_StoreValues_Closing) 
            $MainForm.remove_FormClosed($Form_Cleanup_FormClosed) 
            #END REMOVE CLICKS ---------
        } 
        catch [Exception] 
        { } 
    } 
    #endregion Generated Events 
 
    #---------------------------------------------- 
    #region Generated Form Code 
    #---------------------------------------------- 

    #SUSPEND LAYOUTS---------
    $MainForm.SuspendLayout()
    $splitcontainer.SuspendLayout()
    $panelLeft.SuspendLayout()
    $panelRight.SuspendLayout()
    $panel8.SuspendLayout()
    $panel7.SuspendLayout() 
    $panel6.SuspendLayout() 
    $panel5.SuspendLayout() 
    $panel4.SuspendLayout() 
    $panel3.SuspendLayout() 
    $panel2.SuspendLayout() 
    $panel1.SuspendLayout() 
    #END SUSPEND LAYOUTS---------

    # 
    # MainForm 
    # 
    $MainForm.Controls.add($splitcontainer)
    $MainForm.AutoScaleDimensions = '6, 13' 
    $MainForm.AutoScaleMode = 'Font' 
    $MainForm.BackColor = 'White' 
    $MainForm.ClientSize = '650, 830' 
    $MainForm.MaximizeBox = $False 
    $MainForm.MinimizeBox = $True 
    $MainForm.Name = 'MainForm' 
    $MainForm.ShowIcon = $true
    $MainForm.ShowInTaskbar = $true
    $MainForm.StartPosition = 'CenterScreen' 
    $MainForm.Text = 'Systems Maintenance' 
    if($Script:InitialFixesLocation)
    {
        if(test-path "$Script:InitialFixesLocation\Files\FormIcon.ico")
        {
            $Icon = New-Object System.Drawing.icon("$Script:InitialFixesLocation\Files\FormIcon.ico")
            $MainForm.Icon = $icon
        }
    }
    $MainForm.add_Load($MainForm_Load)
    
    $ButtonLoadGfx
    # 
    # ButtonLoadGfx 
    # 
    $ButtonLoadGfx.Name = 'ButtonLoadGfx' 
    $ButtonLoadGfx.Size = '77, 45' 
    $ButtonLoadGfx.TabIndex = 105
    $ButtonLoadGfx.Text = 'Load Graphics Info' 
    $ButtonLoadGfx.UseVisualStyleBackColor = $True 
    $ButtonLoadGfx.add_Click($ButtonLoadGfx_Click) 
	$ButtonLoadGfx.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonLoadGfx, "Will populate the Graphic driver version of the current PC displayed") 
    # 
    # ButtonChangeEUCFolder 
    # 
    $ButtonChangeEUCFolder.Name = 'ButtonChangeEUCFolder' 
    $ButtonChangeEUCFolder.Size = '77, 45' 
    $ButtonChangeEUCFolder.TabIndex = 201
    $ButtonChangeEUCFolder.Text = 'Change Folder...' 
    $ButtonChangeEUCFolder.UseVisualStyleBackColor = $True 
    $ButtonChangeEUCFolder.add_Click($ButtonChangeEUCFolder_Click) 
	$ButtonChangeEUCFolder.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $tt.SetToolTip($ButtonChangeEUCFolder, "Change the Folder the scripts are located in")
    # 
    # ButtonChangeFixFolder 
    # 
    $ButtonChangeFixFolder.Name = 'ButtonChangeFixFolder' 
    $ButtonChangeFixFolder.Size = '77, 45' 
    $ButtonChangeFixFolder.TabIndex = 201
    $ButtonChangeFixFolder.Text = 'Change Folder...' 
    $ButtonChangeFixFolder.UseVisualStyleBackColor = $True 
    $ButtonChangeFixFolder.add_Click($ButtonChangeFixFolder_Click) 
	$ButtonChangeFixFolder.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $tt.SetToolTip($ButtonChangeFixFolder, "Change the Folder the scripts are located in")
    # 
    # ButtonSetupAutomation 
    # 
    $ButtonSetupAutomation.Name = 'ButtonSetupAutomation' 
    $ButtonSetupAutomation.Size = '77, 45' 
    $ButtonSetupAutomation.TabIndex = 190
    $ButtonSetupAutomation.Text = $Script:Setupbutton 
    $ButtonSetupAutomation.UseVisualStyleBackColor = $True 
    $ButtonSetupAutomation.add_Click($ButtonSetupAutomation_Click) 
	$ButtonSetupAutomation.Dock = [System.Windows.Forms.DockStyle]::Bottom
	# 
    # ButtonShowMain 
    # 
    $ButtonShowMain.Name = 'ButtonShowMain' 
    $ButtonShowMain.Size = '77, 45' 
    $ButtonShowMain.TabIndex = 201
    $ButtonShowMain.Text = 'Main Menu'
    
    $tt.SetToolTip($ButtonShowMain, "Return to the Main Menu (for buttons)")
    

    $ButtonShowMain.UseVisualStyleBackColor = $True 
    $ButtonShowMain.add_Click($ButtonShowMain_Click) 
	$ButtonShowMain.Dock = [System.Windows.Forms.DockStyle]::Bottom
    # 
    # ButtonShowConsole 
    # 
    $ButtonShowConsole.Name = 'ButtonShowConsole' 
    $ButtonShowConsole.Size = '77, 45' 
    $ButtonShowConsole.TabIndex = 199
    $ButtonShowConsole.Text = 'Debug' 
    $ButtonShowConsole.UseVisualStyleBackColor = $True 
    $ButtonShowConsole.add_Click($ButtonShowConsole_Click) 
	$ButtonShowConsole.Dock = [System.Windows.Forms.DockStyle]::Bottom
    $tt.SetToolTip($ButtonShowConsole, "Shows the Powershell console running the gui for debugging") 
	# 
    # ButtonRDP 
    # 
    $ButtonRDP.Name = 'ButtonRDP' 
    $ButtonRDP.Size = '77, 45' 
    $ButtonRDP.TabIndex = 110
    $ButtonRDP.Text = 'RDP' 
    $ButtonRDP.UseVisualStyleBackColor = $True 
    $ButtonRDP.add_Click($ButtonRDP_Click) 
	$ButtonRDP.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonRDP, "Remotely connect to currently displayed PC") 
	# 
    # ButtonMSRA 
    # 
    $ButtonMSRA.Name = 'ButtonMSRA' 
    $ButtonMSRA.Size = '77, 45' 
    $ButtonMSRA.TabIndex = 109
    $ButtonMSRA.Text = 'MSRA to PC' 
    $ButtonMSRA.UseVisualStyleBackColor = $True 
    $ButtonMSRA.add_Click($ButtonMSRA_Click) 
	$ButtonMSRA.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonMSRA, "Offer Remote Assistance to currently displayed PC") 
    # 
    # ButtonReturnToEUC
    # 
    $ButtonReturnToEUC.Name = 'ButtonReturnToEUC' 
    $ButtonReturnToEUC.Size = '77, 45' 
    $ButtonReturnToEUC.TabIndex = 800
    $ButtonReturnToEUC.Text = 'Back' 
    $ButtonReturnToEUC.UseVisualStyleBackColor = $True
    $ButtonReturnToEUC.tag=@{Script=$Script:EUCLocation} 
    $ButtonReturnToEUC.add_Click($ButtonShowEUC_Click) 
	$ButtonReturnToEUC.Dock = [System.Windows.Forms.DockStyle]::Bottom
    # 
    # ButtonShowEUC
    # 
    $ButtonShowEUC.Name = 'ButtonShowEUC' 
    $ButtonShowEUC.Size = '77, 45' 
    $ButtonShowEUC.TabIndex = 108
    $ButtonShowEUC.Text = 'EUC Tools...' 
    $ButtonShowEUC.UseVisualStyleBackColor = $True
    $ButtonShowEUC.tag=@{Script=$Script:EUCLocation} 
    $ButtonShowEUC.add_Click($ButtonShowEUC_Click) 
	$ButtonShowEUC.Dock = [System.Windows.Forms.DockStyle]::Top 
    $tt.SetToolTip($ButtonShowEUC, "Show EUC Specific Tools/fixes") 
	# 
    # ButtonShowFixes 
    # 
    $ButtonShowFixes.Name = 'ButtonShowFixes' 
    $ButtonShowFixes.Size = '77, 45' 
    $ButtonShowFixes.TabIndex = 107
    $ButtonShowFixes.Text = 'Show Fixes...' 
    $ButtonShowFixes.UseVisualStyleBackColor = $True
    $ButtonShowFixes.tag=@{Script=$Script:FixesLocation} 
    $ButtonShowFixes.add_Click($ButtonShowFixes_Click) 
	$ButtonShowFixes.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonShowFixes, "Shows common fix scripts to run for displayed PC")  
	# 
    # ButtonRefresh 
    # 
    $ButtonRefresh.Name = 'ButtonRefresh' 
    $ButtonRefresh.Size = '77, 45' 
    $ButtonRefresh.TabIndex = 104
    $ButtonRefresh.Text = 'Refresh' 
    $ButtonRefresh.UseVisualStyleBackColor = $True 
    $ButtonRefresh.add_Click($ButtonRefresh_Click) 
	$ButtonRefresh.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonRefresh, "Refresh the Displayed information")   
    # 
    # ButtonSearchByUser 
    # 
    $ButtonSearchByUser.Name = 'ButtonSearchByUser' 
	$ButtonSearchByUser.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
    $ButtonSearchByUser.Size = '77, 45' 
    $ButtonSearchByUser.TabIndex = 101
    $ButtonSearchByUser.Text = 'Search By User' 
    $ButtonSearchByUser.UseVisualStyleBackColor = $True 
    $ButtonSearchByUser.add_Click($ButtonSearchByUser_Click) 
	$ButtonSearchByUser.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonSearchByUser, "Search for PC and User by: First Name, Last Name, Middle Name, or combination of these")
    # 
    # ButtonCShare 
    #  
    $ButtonCShare.Name = 'ButtonCShare' 
    $ButtonCShare.Size = '77, 45' 
    $ButtonCShare.TabIndex = 106 
    $ButtonCShare.Text = 'C Share' 
    $ButtonCShare.UseVisualStyleBackColor = $True 
    $ButtonCShare.add_Click($ButtonCShare_Click) 
	$ButtonCShare.Dock = [System.Windows.Forms.DockStyle]::TOP
    $tt.SetToolTip($ButtonCShare, "C$ directly to currently displayed PC")
    # 
    # ButtonExit 
    #  
    $ButtonExit.Name = 'ButtonExit' 
    $ButtonExit.Size = '77, 45' 
    $ButtonExit.TabIndex = 900
    $ButtonExit.Text = 'Exit' 
    $ButtonExit.UseVisualStyleBackColor = $True 
    $ButtonExit.add_Click($ButtonExit_Click) 
	$ButtonExit.Dock = [System.Windows.Forms.DockStyle]::Bottom
    # 
    # $ButtonSearchByPC 
    # 
    $ButtonSearchByPC.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
    $ButtonSearchByPC.Name = 'ButtonSearchByPC' 
    $ButtonSearchByPC.Size = '105, 45' 
    $ButtonSearchByPC.TabIndex = 100
    $ButtonSearchByPC.Text = 'Search By PC' 
    $ButtonSearchByPC.UseVisualStyleBackColor = $True 
    $ButtonSearchByPC.add_Click($ButtonSearchByPC_Click)
    $ButtonSearchByPC.Dock = [System.Windows.Forms.DockStyle]::Top 
    $tt.SetToolTip($ButtonSearchByPC, "Search by: Serial, Full PC Name, or IP Address")
    # 
    # ButtonRestartNow 
    # 
    $ButtonRestartNow.Font = 'Microsoft Sans Serif, 8.25pt, style=Bold' 
    $ButtonRestartNow.ForeColor = 'DarkRed' 
    $ButtonRestartNow.Name = 'ButtonRestartNow' 
    $ButtonRestartNow.Size = '91, 45' 
    $ButtonRestartNow.TabIndex = 103
    $ButtonRestartNow.Text = 'Restart Computer' 
    $ButtonRestartNow.UseVisualStyleBackColor = $True 
    $ButtonRestartNow.add_Click($ButtonRestartNow_Click) 
    $ButtonRestartNow.Dock = [System.Windows.Forms.DockStyle]::Top
    $tt.SetToolTip($ButtonRestartNow, "Restarts the currently displayed PC (NO WARNINGS GIVEN TO USER!)")
    #
    # Set Button enabled or not
    #
    $ButtonLoadGfx.Enabled = $Script:EnabledButtons
    $ButtonCShare.Enabled = $Script:EnabledButtons
    $ButtonSearchByUser.Enabled = $Script:EnabledButtons
    $ButtonSearchByPC.Enabled = $Script:EnabledButtons
    $ButtonRestartNow.Enabled = $Script:EnabledButtons
    $ButtonRefresh.Enabled = $Script:EnabledButtons
    $ButtonShowFixes.Enabled = $Script:EnabledButtons
    $ButtonShowEUC.Enabled = $Script:EnabledButtons
    $ButtonReturnToEUC.Enabled = $Script:EnabledButtons
    $ButtonMSRA.Enabled = $Script:EnabledButtons
    $ButtonRDP.Enabled = $Script:EnabledButtons
    $ButtonShowMain.Enabled = $Script:EnabledButtons
    $ButtonChangeFixFolder.Enabled = $Script:EnabledButtons
    $ButtonChangeEUCFolder.Enabled = $Script:EnabledButtons
    # 
    # Split container 
    # 
    $splitcontainer.Panel1.size = '300, 745'
    $splitcontainer.Location = '0, 0' 
    $splitcontainer.Name = 'splitcontainer'
    $splitcontainer.SplitterDistance = '100'
    $splitcontainer.Panel2.Location =  '375, 0'
    $splitcontainer.Panel2.Controls.Add($panelright)
    $splitcontainer.Panel1.Controls.Add($panelLeft)
    $splitcontainer.Dock = [System.Windows.Forms.DockStyle]::Fill
    # 
    # Left Side Panel 
    #
    $panelLeft.Controls.Add($panel8) 
    $panelLeft.Controls.Add($panel7) 
    $panelLeft.Controls.Add($panel6) 
    $panelLeft.Controls.Add($panel5) 
    $panelLeft.Controls.Add($panel4) 
    $panelLeft.Controls.Add($panel3) 
    $panelLeft.Controls.Add($panel2) 
    $panelLeft.Controls.Add($panel1) 
    $panelLeft.Location = '0, 0' 
    $panelLeft.Name = 'panelLeft' 
    $panelLeft.Size = '299, 745' 
    $panelLeft.TabIndex = 1
    $panelLeft.BackColor = 'LightSkyBlue'
    $panelLeft.Dock = [System.Windows.Forms.DockStyle]::Fill
    # 
    # Right Side Panel 
    # 
    #if($Script:InitialUserStarted -eq "bwienk1")
    #{
        $panelRight.Controls.Add($ButtonShowConsole)
    #}
    $panelRight.Controls.Add($ButtonSetupAutomation)
	$panelRight.Controls.Add($ButtonRDP)
	$panelRight.Controls.Add($ButtonMSRA)
	$panelRight.Controls.Add($ButtonShowEUC)
	$panelRight.Controls.Add($ButtonShowFixes)
    
    $panelRight.Controls.Add($ButtonLoadGfx) 
    $panelRight.Controls.Add($ButtonRefresh)
    $panelRight.Controls.Add($ButtonRestartNow)
	$panelRight.Controls.Add($ButtonSearchByUser)
	$panelRight.Controls.Add($ButtonSearchByPC)
    $panelRight.Location = '0, 0' 
    $panelRight.Name = 'panelRight' 
    $panelRight.Size = '179, 745' 
    $panelRight.TabIndex = 30

    #if($Script:InitialUserStarted -eq "jgisch1" -or $Script:InitialUserStarted -eq "jgisch1-a" -or $Script:InitialUserStarted -eq "mjung11" -or $Script:InitialUserStarted -eq "mjung11-a")
    #{
        #$ImageB = [system.drawing.image]::FromFile("$Script:FixesLocation\Files\Background.jpg")
        #$panelRight.BackgroundImage = $ImageB
        #$panelRight.BackgroundImageLayout = "Stretch"
    #}
    #else
    #{
        $panelRight.BackColor = 'gray'
    #}
    $panelRight.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panelRight.Padding = '20,10,20,10'
    # 
    # panel1 Active Directory Info
    #
    $panel1_Display_Lines = 5
    $panel1_Display_Height = ($panel1_Display_Lines * 23 + 1)
    $NextPanel_Y_Location = $($panel1_Display_Height + 1)
    $panel1.Controls.Add($lbl_AD_Info)
    $panel1.Controls.Add($lbl_PC_AD_Desc) 
    $panel1.Controls.Add($tbx_PC_AD_Desc)
    $panel1.Controls.Add($lbl_User_AD_Name)
    $panel1.Controls.Add($tbx_User_AD_Name)
    $panel1.Controls.Add($lbl_User_AD_Email)
    $panel1.Controls.Add($tbx_User_AD_Email)
    $panel1.Controls.Add($lbl_User_AD_ID)
    $panel1.Controls.Add($tbx_User_AD_ID)
    $panel1.Location = '0, 0' 
    $panel1.Name = 'panel1' 
    $panel1.Size = "378, $panel1_Display_Height"
    $panel1.TabIndex = 1
    $panel1.BackColor = 'LightSkyBlue'
    $panel1.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel2 PC Info
    #
    $panel2_Display_Lines = 12
    $panel2_Display_Height = ($panel2_Display_Lines * 23 + 1)
    $panel2.Controls.Add($lbl_PC_Name)
    $panel2.Controls.Add($lbl_PC_IP)
    $panel2.Controls.Add($tbx_PC_IP)
    $panel2.Controls.Add($lbl_PC_Model) 
    $panel2.Controls.Add($lbl_PC_LastBoot_Time) 
    $panel2.Controls.Add($lbl_PC_LastRestart_Time) 
    $panel2.Controls.Add($lbl_PC_Gfx_Driver) 
    $panel2.Controls.Add($lbl_PC_Gfx_Ver)
	$panel2.Controls.Add($lbl_PC_Bios_Ver) 
    $panel2.Controls.Add($lbl_PC_Win_Ver)
	$panel2.Controls.Add($lbl_PC_Ram_Amount)
    $panel2.Controls.Add($tbx_PC_Name)
    $panel2.Controls.Add($tbx_PC_Model) 
    $panel2.Controls.Add($tbx_PC_LastBoot_Time) 
    $panel2.Controls.Add($tbx_PC_LastRestart_Time) 
    $panel2.Controls.Add($tbx_PC_Gfx_Driver) 
    $panel2.Controls.Add($tbx_PC_Gfx_Ver) 
	$panel2.Controls.Add($tbx_PC_Bios_Ver) 
    $panel2.Controls.Add($tbx_PC_Win_Ver)
	$panel2.Controls.Add($tbx_PC_Ram_Amount)
    $panel2.Controls.Add($lbl_PC_Info)
    $panel2.BackColor = 'LightCyan'
    $panel2.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel2_Display_Height  + 1)
    $panel2.Name = 'panel2' 
    $panel2.Size = "378, $panel2_Display_Height" 
    $panel2.TabIndex = 2
    $panel2.add_Paint($panel2_Paint) 
    $panel2.Text = "PC Info"
    $panel2.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel3 SnapShot
    #
    $panel3_Display_Lines = 3
    $panel3_Display_Height = ($panel3_Display_Lines * 23 + 1)
    $panel3.Controls.Add($lbl_Snapshot)
    $panel3.Controls.Add($tbx_PC_FreeRam)
    $panel3.Controls.Add($tbx_PC_FreeVirtMem)
    $panel3.Controls.Add($lbl_PC_FreeRam)
    $panel3.Controls.Add($lbl_PC_FreeVirtMem)
    $panel3.BackColor = 'LightSkyBlue'
    $panel3.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel3_Display_Height  + 1)
    $panel3.Name = 'panel3' 
    $panel3.Size = "378, $panel3_Display_Height"
    $panel3.TabIndex = 3
    $panel3.add_Paint($panel3_Paint) 
    $panel3.Text = "PC Info"
    $panel3.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel4 Current Users
    #
    $panel4_Display_Lines = 3
    $panel4_Display_Height = ($panel4_Display_Lines * 23 + 1)
    $panel4.Controls.Add($lbl_CurrentUsers)
    $panel4.Controls.Add($tbx_PC_User_SSO)
    $panel4.Controls.Add($tbx_PC_User_Name)
    $panel4.Controls.Add($lbl_PC_User_Name)
    $panel4.Controls.Add($lbl_PC_User_SSO)
    $panel4.BackColor = 'Lightcyan'
    $panel4.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel4_Display_Height  + 1)
    $panel4.Name = 'panel4' 
    $panel4.Size = "378, $panel4_Display_Height" 
    $panel4.TabIndex = 4
    $panel4.add_Paint($panel4_Paint) 
    $panel4.Text = "PC Info"
    $panel4.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel5 PC Sessions Inof
    # 
    $panel5_Display_Lines = 6
    $panel5_Display_Height = ($panel5_Display_Lines * 23 + 1)
    $panel5.Controls.Add($lbl_CurrentSessions)
    $panel5.Controls.Add($tbx_PC_Session_UserName)
    $panel5.Controls.Add($tbx_PC_Session_Type)
    $panel5.Controls.Add($tbx_PC_Session_State)
    $panel5.Controls.Add($tbx_PC_Session_IdleTime)
    $panel5.Controls.Add($tbx_PC_Session_LogonTime)
    $panel5.Controls.Add($lbl_PC_Session_UserName)
    $panel5.Controls.Add($lbl_PC_Session_Type)
    $panel5.Controls.Add($lbl_PC_Session_State)
    $panel5.Controls.Add($lbl_PC_Session_IdleTime)
    $panel5.Controls.Add($lbl_PC_Session_LogonTime)
    $panel5.BackColor = 'LightSkyBlue'
    $panel5.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel5_Display_Height  + 1)
    $panel5.Name = 'panel5' 
    $panel5.Size = "378, $panel5_Display_Height"
    $panel5.TabIndex = 5
    $panel5.add_Paint($panel5_Paint) 
    $panel5.Text = "PC Info"
    $panel5.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel6 MISC Info
    #
    $panel6_Display_Lines = 4
    $panel6_Display_Height = ($panel6_Display_Lines * 23 + 1)
    $panel6.Controls.Add($lbl_MISc)
    $panel6.Controls.Add($tbx_Misc_Last_LoginTime)
    $panel6.Controls.Add($tbx_Misc_User_Session_Length)
    $panel6.Controls.Add($tbx_Misc_PC_RebootPending)
    $panel6.Controls.Add($lbl_Misc_Last_LoginTime)
    $panel6.Controls.Add($lbl_Misc_User_Session_Length)
    $panel6.Controls.Add($lbl_Misc_PC_RebootPending)
    $panel6.BackColor = 'Lightcyan'
    $panel6.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel6_Display_Height  + 1) 
    $panel6.Name = 'panel6' 
    $panel6.Size = "378, $panel6_Display_Height" 
    $panel6.TabIndex = 6
    $panel6.add_Paint($panel6_Paint) 
    $panel6.Text = "PC Info"
    $panel6.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel7 Service-Now Info
    #
    $panel7_Display_Lines = 6
    $panel7_Display_Height = ($panel7_Display_Lines * 23 + 1)
    $panel7.Controls.Add($lbl_SN_Title)
    $panel7.Controls.Add($tbx_SN_User_Assigned)
    $panel7.Controls.Add($tbx_SN_User_Dept)
    $panel7.Controls.Add($lbl_SN_User_Assigned)
    $panel7.Controls.Add($lbl_SN_User_Dept)
    $panel7.Controls.Add($tbx_SN_PC_State)
    $panel7.Controls.Add($lbl_SN_PC_State)
    $panel7.Controls.Add($tbx_SN_PC_Substate)
    $panel7.Controls.Add($lbl_SN_PC_Substate)
    $panel7.Controls.Add($tbx_SN_PC_Asset_Function)
    $panel7.Controls.Add($lbl_SN_PC_Asset_Function)
    $panel7.Controls.Add($tbx_SN_User_Location)
    $panel7.Controls.Add($lbl_SN_User_Location)
    $panel7.Controls.Add($tbx_SN_User_Dept)
    $panel7.Controls.Add($lbl_SN_User_Dept)
    $panel7.BackColor = 'LightSkyBlue'
    $panel7.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel7_Display_Height  + 1) 
    $panel7.Name = 'panel6' 
    $panel7.Size = "378, $panel7_Display_Height" 
    $panel7.TabIndex = 6
    $panel7.add_Paint($panel6_Paint) 
    $panel7.Text = "Service-Now"
    $panel7.Dock = [System.Windows.Forms.DockStyle]::Top
    # 
    # panel8 Meraki Info
    #
    $panel8_Display_Lines = 3
    $panel8_Display_Height = ($panel8_Display_Lines * 23 + 1)
    $panel8.Controls.Add($lbl_Meraki)
    $panel8.Controls.Add($tbx_Meraki_Serial)
    $panel8.Controls.Add($lbl_Meraki_Serial)
    $panel8.Controls.Add($tbx_Meraki_User_Address)
    $panel8.Controls.Add($lbl_Meraki_User_Address)
    $panel8.Controls.Add($tbx_Meraki_IP)
    $panel8.Controls.Add($lbl_Meraki_IP)
    $panel8.BackColor = 'LightSkyBlue'
    $panel8.Location = "0, $NextPanel_Y_Location"
    $NextPanel_Y_Location = $($NextPanel_Y_Location + $panel8_Display_Height  + 1) 
    $panel8.Name = 'panel6' 
    $panel8.Size = "378, $panel8_Display_Height" 
    $panel8.TabIndex = 6
    $panel8.add_Paint($panel6_Paint) 
    $panel8.Text = "Meraki"
    $panel8.Dock = [System.Windows.Forms.DockStyle]::Top

    $MainForm.ClientSize = "620, $NextPanel_Y_Location"
    
    #LABEL CONTROLS ARRAYS
    $Script:aryDisplayLblControls1 = @()
    $Script:aryDisplayLblControls2 = @()
    $Script:aryDisplayLblControls3 = @()
    $Script:aryDisplayLblControls4 = @()
    $Script:aryDisplayLblControls5 = @()
    $Script:aryDisplayLblControls6 = @()
    $Script:aryDisplayLblControls7 = @()
    $Script:aryDisplayLblControls8 = @()

#-------------------------- START LABELS --------------------------#

    # ----- ACTIVE DIRECTORY INFO - PANEL 1
        # START-----------Header Label
    $x = 0
    $lbl_AD_Info.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_AD_Info.Location = "1, 0" 
    $lbl_AD_Info.Name = 'lbl_AD_Info' 
    $lbl_AD_Info.Text = '--- AD Info -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_AD_Info.Size = '378, 20'
    #$position = ($x)
    $Script:aryDisplayLblControls1 += $lbl_AD_Info
        # END-------------Header Label

        # START-----------Field Labels
    $x = 22
    $lbl_PC_AD_Desc.Location = "3, $x" 
    $lbl_PC_AD_Desc.Name = 'lbl_PC_AD_Desc' 
    $lbl_PC_AD_Desc.Size = '100, 18' 
    $lbl_PC_AD_Desc.Text = 'PC Description:' 
    $lbl_PC_AD_Desc.TextAlign = 'MiddleLeft'
    $lbl_PC_AD_Desc.Font = 'Microsoft Sans Serif, 9pt' 
    $lbl_PC_AD_Desc.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls1 += $lbl_PC_AD_Desc

    $x = $x + 22
    $lbl_User_AD_Name.Font = 'Microsoft Sans Serif, 9pt' 
    $lbl_User_AD_Name.Location = "3, $x" 
    $lbl_User_AD_Name.Name = 'lbl_User_AD_Name' 
    $lbl_User_AD_Name.Text = 'User Assigned:'
    $lbl_User_AD_Name.Size = '100, 18' 
    $lbl_User_AD_Name.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls1 += $lbl_User_AD_Name

    $x = $x + 22
    $lbl_User_AD_Email.Font = 'Microsoft Sans Serif, 9pt' 
    $lbl_User_AD_Email.Location = "3, $x" 
    $lbl_User_AD_Email.Name = 'lbl_User_AD_Email' 
    $lbl_User_AD_Email.Text = 'User Email:'
    $lbl_User_AD_Email.Size = '100, 18' 
    $lbl_User_AD_Email.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls1 += $lbl_User_AD_Email

    $x = $x + 22
    $lbl_User_AD_ID.Font = 'Microsoft Sans Serif, 9pt' 
    $lbl_User_AD_ID.Location = "3, $x" 
    $lbl_User_AD_ID.Name = 'lbl_User_AD_ID' 
    $lbl_User_AD_ID.Text = 'User ID:'
    $lbl_User_AD_ID.Size = '100, 18' 
    $lbl_User_AD_ID.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls1 += $lbl_User_AD_ID
        # END-------------Field Labels
   
    # ----- PC INFO - PANEL 2
        # START-----------Header Label
    $x = 0
    $lbl_PC_Info.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_PC_Info.Location = "1, 0" 
    $lbl_PC_Info.Name = 'lbl_PC_Info' 
    $lbl_PC_Info.Text = '--- PC Info -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_PC_Info.Dock = [System.Windows.Forms.DockStyle]::Top
    $lbl_PC_Info.Size = '378, 20'
    $Script:aryDisplayLblControls2 += $lbl_PC_Info
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_PC_Name.Location = "3, $x" 
    $lbl_PC_Name.Name = 'lbl_PC_Name' 
    $lbl_PC_Name.AutoSize = 'True'
    $lbl_PC_Name.Text = 'PC Name:' 
    $lbl_PC_Name.TextAlign = 'MiddleLeft'
    $lbl_PC_Name.Size = '100, 18' 
    $lbl_PC_Name.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Name

    $x = $x + 22
    $lbl_PC_IP.Location = "3, $x" 
    $lbl_PC_IP.Name = 'lbl_PC_IP' 
    $lbl_PC_IP.AutoSize = 'True'
    $lbl_PC_IP.Text = 'IP Address:' 
    $lbl_PC_IP.TextAlign = 'MiddleLeft'
    $lbl_PC_IP.Size = '100, 18' 
    $lbl_PC_IP.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_IP

    $x = $x + 22
    $lbl_PC_Model.Location = "3, $x" 
    $lbl_PC_Model.Name = 'lbl_PC_Model' 
    $lbl_PC_Model.AutoSize = 'True'
    $lbl_PC_Model.Text = 'PC Model:' 
    $lbl_PC_Model.TextAlign = 'MiddleLeft'
    $lbl_PC_Model.Size = '100, 18' 
    $lbl_PC_Model.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Model
        
    $x = $x + 22
    $lbl_PC_LastBoot_Time.Location = "3, $x" 
    $lbl_PC_LastBoot_Time.Name = 'lbl_PC_LastBoot_Time' 
    $lbl_PC_LastBoot_Time.AutoSize = 'True'
    $lbl_PC_LastBoot_Time.Text = 'Time Since Last Boot:' 
    $lbl_PC_LastBoot_Time.TextAlign = 'MiddleLeft'
    $lbl_PC_LastBoot_Time.Size = '100, 18' 
    $lbl_PC_LastBoot_Time.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_LastBoot_Time
            
    $x = $x + 22
    $lbl_PC_LastRestart_Time.Location = "3, $x" 
    $lbl_PC_LastRestart_Time.Name = 'lbl_PC_LastRestart_Time' 
    $lbl_PC_LastRestart_Time.AutoSize = 'True' 
    $lbl_PC_LastRestart_Time.Text = 'Rebooted Last:' 
    $lbl_PC_LastRestart_Time.TextAlign = 'MiddleLeft' 
    $lbl_PC_LastRestart_Time.Size = '100, 18' 
    $lbl_PC_LastRestart_Time.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_LastRestart_Time
        
    $x = $x + 22
    $lbl_PC_Gfx_Driver.Location = "3, $x" 
    $lbl_PC_Gfx_Driver.Name = 'lbl_PC_Gfx_Driver' 
    $lbl_PC_Gfx_Driver.AutoSize = 'True'
    $lbl_PC_Gfx_Driver.Text = 'Graphics Driver:' 
    $lbl_PC_Gfx_Driver.TextAlign = 'MiddleLeft'
    $lbl_PC_Gfx_Driver.Size = '100, 18' 
    $lbl_PC_Gfx_Driver.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Gfx_Driver
        
    $x = $x + 22
    $lbl_PC_Gfx_Ver.Location = "3, $x" 
    $lbl_PC_Gfx_Ver.Name = 'lbl_PC_Gfx_Ver'  
    $lbl_PC_Gfx_Ver.AutoSize = 'True'
    $lbl_PC_Gfx_Ver.Text = 'Graphics Version:' 
    $lbl_PC_Gfx_Ver.TextAlign = 'MiddleLeft' 
    $lbl_PC_Gfx_Ver.Size = '100, 18' 
    $lbl_PC_Gfx_Ver.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Gfx_Ver
        
	$x = $x + 22
    $lbl_PC_Bios_Ver.Location = "3, $x" 
    $lbl_PC_Bios_Ver.Name = '$lbl_PC_Bios_Ver'  
    $lbl_PC_Bios_Ver.AutoSize = 'True'
    $lbl_PC_Bios_Ver.Text = 'Bios Version:' 
    $lbl_PC_Bios_Ver.TextAlign = 'MiddleLeft'
    $lbl_PC_Bios_Ver.Size = '100, 18' 
    $lbl_PC_Bios_Ver.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Bios_Ver
        
    $x = $x + 22
    $lbl_PC_Win_Ver.Location = "3, $x" 
    $lbl_PC_Win_Ver.Name = 'lbl_PC_Win_Ver' 
    $lbl_PC_Win_Ver.AutoSize = 'True'
    $lbl_PC_Win_Ver.Text = 'Windows Version:' 
    $lbl_PC_Win_Ver.TextAlign = 'MiddleLeft'
    $lbl_PC_Win_Ver.Size = '100, 18' 
    $lbl_PC_Win_Ver.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Win_Ver
        
	$x = $x + 22 
	$lbl_PC_Ram_Amount.Location = "3, $x" 
    $lbl_PC_Ram_Amount.Name = '$lbl_PC_Ram_Amount' 
    $lbl_PC_Ram_Amount.AutoSize = 'True'
    $lbl_PC_Ram_Amount.Text = 'Amount of RAM:' 
    $lbl_PC_Ram_Amount.TextAlign = 'MiddleLeft'
    $lbl_PC_Ram_Amount.Size = '100, 18' 
    $lbl_PC_Ram_Amount.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls2 += $lbl_PC_Ram_Amount
        # END-------------Field Labels

    # ----- SNAPSHOT - PANEL 3
        # START-----------Header Label
    $x = 0
    $lbl_Snapshot.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_Snapshot.Location = "1, 0" 
    $lbl_Snapshot.Name = 'lbl_Snapshot' 
    $lbl_Snapshot.Text = '--- Snap Shot ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_Snapshot.Dock = [System.Windows.Forms.DockStyle]::Top
    $lbl_Snapshot.Size = '378, 20'
    $Script:aryDisplayLblControls3 += $lbl_Snapshot
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_PC_FreeRam.Location = "3, $x" 
    $lbl_PC_FreeRam.Name = 'lbl_PC_FreeRam'  
    $lbl_PC_FreeRam.AutoSize = 'True'
    $lbl_PC_FreeRam.Text = 'Free RAM:' 
    $lbl_PC_FreeRam.TextAlign = 'MiddleLeft'
    $lbl_PC_FreeRam.Size = '100, 18' 
    $lbl_PC_FreeRam.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls3 += $lbl_PC_FreeRam
        
    $x = $x + 22
    $lbl_PC_FreeVirtMem.Location = "3, $x" 
    $lbl_PC_FreeVirtMem.Name = 'lbl_PC_FreeVirtMem' 
    $lbl_PC_FreeVirtMem.AutoSize = 'True'
    $lbl_PC_FreeVirtMem.Text = 'Free Virtual Memory:' 
    $lbl_PC_FreeVirtMem.TextAlign = 'MiddleLeft'
    $lbl_PC_FreeVirtMem.Size = '100, 18' 
    $lbl_PC_FreeVirtMem.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls3 += $lbl_PC_FreeVirtMem
        # END-------------Field Labels

    # ----- CURRENT USERS - PANEL 4
        # START-----------Header Label
    $x = 0
    $lbl_CurrentUsers.Location = "1, 0" 
    $lbl_CurrentUsers.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_CurrentUsers.Name = 'lbl_CurrentUsers' 
    $lbl_CurrentUsers.Text = '--- Current Users ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_CurrentUsers.Size = '378, 20'
    $lbl_CurrentUsers.Dock = [System.Windows.Forms.DockStyle]::Top
    $Script:aryDisplayLblControls4 += $lbl_CurrentUsers
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_PC_User_SSO.Location = "3, $x" 
    $lbl_PC_User_SSO.Name = 'lbl_PC_User_SSO' 
    $lbl_PC_User_SSO.AutoSize = 'True'
    $lbl_PC_User_SSO.Text = 'SSO:' 
    $lbl_PC_User_SSO.TextAlign = 'MiddleLeft'
    $lbl_PC_User_SSO.Size = '100, 18' 
    $lbl_PC_User_SSO.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls4 += $lbl_PC_User_SSO

    $x = $x + 22
    $lbl_PC_User_Name.Location = "3, $x" 
    $lbl_PC_User_Name.Name = 'lbl_PC_User_Name' 
    $lbl_PC_User_Name.AutoSize = 'True'
    $lbl_PC_User_Name.Text = 'Name:' 
    $lbl_PC_User_Name.TextAlign = 'MiddleLeft'
    $lbl_PC_User_Name.Size = '100, 18' 
    $lbl_PC_User_Name.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls4 += $lbl_PC_User_Name
        # END-------------Field Labels

    # ----- CURRENT SESSIONS - PANEL 5
        # START-----------Header Label
    $x = 0
    $lbl_CurrentSessions.Location = "1, 0" 
    $lbl_CurrentSessions.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_CurrentSessions.Name = 'lbl_CurrentSessions' 
    $lbl_CurrentSessions.Text = '--- Current Sessions --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_CurrentSessions.Dock = [System.Windows.Forms.DockStyle]::Top
    $lbl_CurrentSessions.Size = '378, 20'
    $position = ($x)
    $Script:aryDisplayLblControls5 += $lbl_CurrentSessions
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_PC_Session_UserName.Location = "3, $x" 
    $lbl_PC_Session_UserName.Name = 'lbl_PC_Session_UserName'
    $lbl_PC_Session_UserName.AutoSize = 'True'
    $lbl_PC_Session_UserName.Text = 'Username:' 
    $lbl_PC_Session_UserName.TextAlign = 'MiddleLeft'
    $lbl_PC_Session_UserName.Size = '100, 18' 
    $lbl_PC_Session_UserName.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls5 += $lbl_PC_Session_UserName
        
    $x = $x + 22
    $lbl_PC_Session_Type.Location = "3, $x" 
    $lbl_PC_Session_Type.Name = 'lbl_PC_Session_Type'
    $lbl_PC_Session_Type.AutoSize = 'True'
    $lbl_PC_Session_Type.Text = 'Session:' 
    $lbl_PC_Session_Type.TextAlign = 'MiddleLeft'
    $lbl_PC_Session_Type.Size = '100, 18' 
    $lbl_PC_Session_Type.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls5 += $lbl_PC_Session_Type

    $x = $x + 22
    $lbl_PC_Session_State.Location = "3, $x" 
    $lbl_PC_Session_State.Name = 'lbl_PC_Session_State'
    $lbl_PC_Session_State.AutoSize = 'True'
    $lbl_PC_Session_State.Text = 'State:' 
    $lbl_PC_Session_State.TextAlign = 'MiddleLeft'
    $lbl_PC_Session_State.Size = '100, 18' 
    $lbl_PC_Session_State.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls5 += $lbl_PC_Session_State
        
    $x = $x + 22
    $lbl_PC_Session_IdleTime.Location = "3, $x" 
    $lbl_PC_Session_IdleTime.Name = 'lbl_PC_Session_IdleTime'
    $lbl_PC_Session_IdleTime.AutoSize = 'True'
    $lbl_PC_Session_IdleTime.Text = 'Idle Time:' 
    $lbl_PC_Session_IdleTime.TextAlign = 'MiddleLeft'
    $lbl_PC_Session_IdleTime.Size = '100, 18' 
    $lbl_PC_Session_IdleTime.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls5 += $lbl_PC_Session_IdleTime
        
    $x = $x + 22
    $lbl_PC_Session_LogonTime.Location = "3, $x" 
    $lbl_PC_Session_LogonTime.Name = 'lbl_PC_Session_LogonTime'
    $lbl_PC_Session_LogonTime.AutoSize = 'True'
    $lbl_PC_Session_LogonTime.Text = 'Logon Time:' 
    $lbl_PC_Session_LogonTime.TextAlign = 'MiddleLeft'
    $lbl_PC_Session_LogonTime.Size = '100, 18' 
    $lbl_PC_Session_LogonTime.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls5 += $lbl_PC_Session_LogonTime
        # END-------------Field Labels

    # ----- MISC INFO - PANEL 6
        # START-----------Header Label
    $x = 0
    $lbl_MISc.Location = "1, 0" 
    $lbl_MISc.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_MISc.Name = 'lbl_MISc' 
    $lbl_MISc.Text = '--- MISC -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_MISc.Size = '378, 20'
    $lbl_MISc.Dock = [System.Windows.Forms.DockStyle]::Top
    $Script:aryDisplayLblControls6 += $lbl_MISc
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_Misc_Last_LoginTime.Location = "3, $x"
    $lbl_Misc_Last_LoginTime.Name = 'lbl_Misc_Last_LoginTime'  
    $lbl_Misc_Last_LoginTime.AutoSize = 'True'
    $lbl_Misc_Last_LoginTime.Text = 'Last User Login Time:' 
    $lbl_Misc_Last_LoginTime.TextAlign = 'MiddleLeft'
    $lbl_Misc_Last_LoginTime.Size = '100, 18' 
    $lbl_Misc_Last_LoginTime.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls6 += $lbl_Misc_Last_LoginTime
        
    $x = $x + 22
    $lbl_Misc_User_Session_Length.Location = "3, $x" 
    $lbl_Misc_User_Session_Length.Name = 'lbl_Misc_User_Session_Length' 
    $lbl_Misc_User_Session_Length.AutoSize = 'True'
    $lbl_Misc_User_Session_Length.Text = 'User Session Length:' 
    $lbl_Misc_User_Session_Length.TextAlign = 'MiddleLeft'
    $lbl_Misc_User_Session_Length.Size = '100, 18' 
    $lbl_Misc_User_Session_Length.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls6 += $lbl_Misc_User_Session_Length 

    $x = $x + 22
    $lbl_Misc_PC_RebootPending.Location = "3, $x" 
    $lbl_Misc_PC_RebootPending.Name = 'lbl_Misc_PC_RebootPending' 
    $lbl_Misc_PC_RebootPending.AutoSize = 'True'
    $lbl_Misc_PC_RebootPending.Text = 'Reboot Pending:' 
    $lbl_Misc_PC_RebootPending.TextAlign = 'MiddleLeft'
    $lbl_Misc_PC_RebootPending.Size = '100, 18' 
    $lbl_Misc_PC_RebootPending.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls6 += $lbl_Misc_PC_RebootPending
        # END-------------Field Labels

    # ----- SERVICE-NOW INFO - PANEL 7
        # START-----------Header Label
    $x = 0
    $lbl_SN_Title.Location = "1, 0" 
    $lbl_SN_Title.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_SN_Title.Name = 'lbl_SN_Title' 
    $lbl_SN_Title.Text = '--- Service Now Info -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_SN_Title.Size = '378, 20'
    $lbl_SN_Title.Dock = [System.Windows.Forms.DockStyle]::Top
    $Script:aryDisplayLblControls7 += $lbl_SN_Title
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_SN_User_Assigned.Location = "3, $x"
    $lbl_SN_User_Assigned.Name = 'lbl_SN_User_Assigned'  
    $lbl_SN_User_Assigned.AutoSize = 'True'
    $lbl_SN_User_Assigned.Text = 'User Assigned:' 
    $lbl_SN_User_Assigned.TextAlign = 'MiddleLeft'
    $lbl_SN_User_Assigned.Size = '100, 18' 
    $lbl_SN_User_Assigned.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls7 += $lbl_SN_User_Assigned

    $x = $x + 22
    $lbl_SN_User_Dept.Location = "3, $x" 
    $lbl_SN_User_Dept.Name = 'lbl_SN_User_Dept' 
    $lbl_SN_User_Dept.AutoSize = 'True'
    $lbl_SN_User_Dept.Text = 'User Dept:' 
    $lbl_SN_User_Dept.TextAlign = 'MiddleLeft'
    $lbl_SN_User_Dept.Size = '100, 18' 
    $lbl_SN_User_Dept.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls7 += $lbl_SN_User_Dept

    $x = $x + 22
    $lbl_SN_User_Location.Location = "3, $x" 
    $lbl_SN_User_Location.Name = 'lbl_SN_User_Location' 
    $lbl_SN_User_Location.AutoSize = 'True'
    $lbl_SN_User_Location.Text = 'User Location:' 
    $lbl_SN_User_Location.TextAlign = 'MiddleLeft'
    $lbl_SN_User_Location.Size = '100, 18' 
    $lbl_SN_User_Location.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $lbl_SN_User_Location.Visible = $true
    $Script:aryDisplayLblControls7 += $lbl_SN_User_Location     

    $x = $x + 22
    $lbl_SN_PC_State.Location = "3, $x" 
    $lbl_SN_PC_State.Name = 'lbl_Misc_PC_RebootPending' 
    $lbl_SN_PC_State.AutoSize = 'True'
    $lbl_SN_PC_State.Text = 'Asset State:' 
    $lbl_SN_PC_State.TextAlign = 'MiddleLeft'
    $lbl_SN_PC_State.Size = '100, 18' 
    $lbl_SN_PC_State.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls7 += $lbl_SN_PC_State

    $x = $x + 22
    $lbl_SN_PC_Substate.Location = "3, $x" 
    $lbl_SN_PC_Substate.Name = 'lbl_SN_PC_Substate' 
    $lbl_SN_PC_Substate.AutoSize = 'True'
    $lbl_SN_PC_Substate.Text = 'Asset Substate:' 
    $lbl_SN_PC_Substate.TextAlign = 'MiddleLeft'
    $lbl_SN_PC_Substate.Size = '100, 18' 
    $lbl_SN_PC_Substate.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls7 += $lbl_SN_PC_Substate

    $x = $x + 22
    $lbl_SN_PC_Asset_Function.Location = "3, $x" 
    $lbl_SN_PC_Asset_Function.Name = 'lbl_SN_PC_Asset_Function' 
    $lbl_SN_PC_Asset_Function.AutoSize = 'True'
    $lbl_SN_PC_Asset_Function.Text = 'Asset Function:' 
    $lbl_SN_PC_Asset_Function.TextAlign = 'MiddleLeft'
    $lbl_SN_PC_Asset_Function.Size = '100, 18' 
    $lbl_SN_PC_Asset_Function.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls7 += $lbl_SN_PC_Asset_Function 
        # END-------------Field Labels

    # ----- Meraki INFO - PANEL 8
        # START-----------Header Label
    $x = 0
    $lbl_Meraki.Location = "1, 0" 
    $lbl_Meraki.Font = 'Microsoft Sans Serif, 12pt' 
    $lbl_Meraki.Name = 'lbl_Meraki' 
    $lbl_Meraki.Text = '--- Meraki Info -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------'
    $lbl_Meraki.Size = '378, 20'
    $lbl_Meraki.Dock = [System.Windows.Forms.DockStyle]::Top
    $Script:aryDisplayLblControls8 += $lbl_Meraki
        # END-------------Header Label

        # START-----------Field Labels
    $x = $x + 22
    $lbl_Meraki_IP.Location = "3, $x"
    $lbl_Meraki_IP.Name = 'lbl_Meraki_IP'  
    $lbl_Meraki_IP.AutoSize = 'True'
    $lbl_Meraki_IP.Text = 'PC IP Address:' 
    $lbl_Meraki_IP.TextAlign = 'MiddleLeft'
    $lbl_Meraki_IP.Size = '100, 18' 
    $lbl_Meraki_IP.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls8 += $lbl_Meraki_IP 

    $x = $x + 22
    $lbl_Meraki_Serial.Location = "3, $x" 
    $lbl_Meraki_Serial.Name = 'lbl_Meraki_Serial' 
    $lbl_Meraki_Serial.AutoSize = 'True'
    $lbl_Meraki_Serial.Text = 'Meraki Serial:' 
    $lbl_Meraki_Serial.TextAlign = 'MiddleLeft'
    $lbl_Meraki_Serial.Size = '100, 18' 
    $lbl_Meraki_Serial.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls8 += $lbl_Meraki_Serial

    $x = $x + 22
    $lbl_Meraki_User_Address.Location = "3, $x" 
    $lbl_Meraki_User_Address.Name = 'lbl_Meraki_User_Address' 
    $lbl_Meraki_User_Address.AutoSize = 'True'
    $lbl_Meraki_User_Address.Text = 'User Address:' 
    $lbl_Meraki_User_Address.TextAlign = 'MiddleLeft'
    $lbl_Meraki_User_Address.Size = '100, 18' 
    $lbl_Meraki_User_Address.Padding = [System.Windows.Forms.Padding]::Add(0,1)
    $Script:aryDisplayLblControls8 += $lbl_Meraki_User_Address
        # END-------------Field Labels

#-------------------------- END LABELS --------------------------#

#----------------------- START TEXTBOXES ------------------------#

    #TEXTBOX CONTROLS ARRAYS
    $Script:aryDisplaytbxControls1 = @()
    $Script:aryDisplaytbxControls2 = @()
    $Script:aryDisplaytbxControls3 = @()
    $Script:aryDisplaytbxControls4 = @()
    $Script:aryDisplaytbxControls5 = @()
    $Script:aryDisplaytbxControls6 = @()
    $Script:aryDisplaytbxControls7 = @()
    $Script:aryDisplaytbxControls8 = @()

    # ----- ACTIVE DIRECTORY INFO - PANEL 1
    $x = 22
    $y = 50
    $tabindex = 0
    $tbx_PC_AD_Desc.Location = "120, $x" 
    $tbx_PC_AD_Desc.Name = 'tbx_PC_AD_Desc' 
    $tbx_PC_AD_Desc.Size = '230, 18' 
    $tbx_PC_AD_Desc.TabIndex = $tabindex
	$tbx_PC_AD_Desc.ReadOnly = 'True'
    $tbx_PC_AD_Desc.Visible = $false
    $Script:aryDisplaytbxControls1 += $tbx_PC_AD_Desc
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_User_AD_Name.Location = "120, $x" 
    $tbx_User_AD_Name.Name = 'tbx_User_AD_Name' 
    $tbx_User_AD_Name.Size = '230, 18'
    $tbx_User_AD_Name.TabIndex = $tabindex
	$tbx_User_AD_Name.ReadOnly = 'True'
    $tbx_User_AD_Name.Visible = $false
    $Script:aryDisplaytbxControls1 += $tbx_User_AD_Name
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_User_AD_Email.Location = "120, $x" 
    $tbx_User_AD_Email.Name = 'tbx_User_AD_Email' 
    $tbx_User_AD_Email.Size = '230, 18' 
    $tbx_User_AD_Email.TabIndex = $tabindex
	$tbx_User_AD_Email.ReadOnly = 'True'
    $tbx_User_AD_Email.Visible = $false
    $Script:aryDisplaytbxControls1 += $tbx_User_AD_Email
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_User_AD_ID.Location = "120, $x" 
    $tbx_User_AD_ID.Name = 'tbx_User_AD_ID' 
    $tbx_User_AD_ID.Size = '230, 18' 
    $tbx_User_AD_ID.TabIndex = $tabindex
	$tbx_User_AD_ID.ReadOnly = 'True'
    $tbx_User_AD_ID.Visible = $false
    $Script:aryDisplaytbxControls1 += $tbx_User_AD_ID
    $tabindex = $tabindex + 1

    # ----- PC INFO - PANEL 2
    $x = 22
    $tbx_PC_Name.Location = "120, $x" 
    $tbx_PC_Name.Name = 'tbx_PC_Name' 
    $tbx_PC_Name.Size = '230, 18' 
    $tbx_PC_Name.TabIndex = $tabindex
	$tbx_PC_Name.ReadOnly = 'True'
    $tbx_PC_Name.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_Name
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_IP.Location = "120, $x" 
    $tbx_PC_IP.Name = 'tbx_PC_IP' 
    $tbx_PC_IP.Size = '230, 18' 
    $tbx_PC_IP.TabIndex = $tabindex
	$tbx_PC_IP.ReadOnly = 'True'
    $tbx_PC_IP.Visible = $false
    $tbx_PC_IP.add_TextChanged($tbx_PC_IP_TextChanged)
    $Script:aryDisplaytbxControls2 += $tbx_PC_IP
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Model.Location = "120, $x" 
    $tbx_PC_Model.Name = 'tbx_PC_Model' 
    $tbx_PC_Model.Size = '230, 18' 
    $tbx_PC_Model.TabIndex = $tabindex
	$tbx_PC_Model.ReadOnly = 'True'
    $tbx_PC_Model.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_Model
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_LastBoot_Time.Location = "120, $x" 
    $tbx_PC_LastBoot_Time.Name = 'tbx_PC_LastBoot_Time' 
    $tbx_PC_LastBoot_Time.Size = '230,718' 
    $tbx_PC_LastBoot_Time.TabIndex = $tabindex
	$tbx_PC_LastBoot_Time.ReadOnly = 'True'
    $tbx_PC_LastBoot_Time.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_LastBoot_Time
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_LastRestart_Time.Location = "120, $x" 
    $tbx_PC_LastRestart_Time.Name = 'tbx_PC_LastRestart_Time' 
    $tbx_PC_LastRestart_Time.Size = '230, 18' 
    $tbx_PC_LastRestart_Time.TabIndex = $tabindex
	$tbx_PC_LastRestart_Time.ReadOnly = 'True'
    $tbx_PC_LastRestart_Time.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_LastRestart_Time
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Gfx_Driver.Location = "120, $x" 
    $tbx_PC_Gfx_Driver.Name = 'tbx_PC_Gfx_Driver' 
    $tbx_PC_Gfx_Driver.Size = '230, 18' 
    $tbx_PC_Gfx_Driver.TabIndex = $tabindex
	$tbx_PC_Gfx_Driver.ReadOnly = 'True'
    $tbx_PC_Gfx_Driver.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_Gfx_Driver
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Gfx_Ver.Location = "120, $x" 
    $tbx_PC_Gfx_Ver.Name = 'tbx_PC_Gfx_Ver' 
    $tbx_PC_Gfx_Ver.Size = '230, 18' 
    $tbx_PC_Gfx_Ver.TabIndex = $tabindex
	$tbx_PC_Gfx_Ver.ReadOnly = 'True'
    $tbx_PC_Gfx_Ver.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_Gfx_Ver
    $tabindex = $tabindex + 1

	$x = $x + 22
    $tbx_PC_Bios_Ver.Location = "120, $x" 
    $tbx_PC_Bios_Ver.Name = '$tbx_PC_Bios_Ver' 
    $tbx_PC_Bios_Ver.Size = '230, 18' 
    $tbx_PC_Bios_Ver.TabIndex = $tabindex
	$tbx_PC_Bios_Ver.ReadOnly = 'True'
    $tbx_PC_Bios_Ver.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_Bios_Ver
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Win_Ver.Location = "120, $x" 
    $tbx_PC_Win_Ver.Name = 'tbx_PC_Win_Ver' 
    $tbx_PC_Win_Ver.Size = '230, 18' 
    $tbx_PC_Win_Ver.TabIndex = $tabindex
	$tbx_PC_Win_Ver.ReadOnly = 'True'
    $tbx_PC_Win_Ver.Visible = $false
    $Script:aryDisplaytbxControls2 += $tbx_PC_Win_Ver
    $tabindex = $tabindex + 1
	
	$x = $x + 22
    $tbx_PC_Ram_Amount.Location = "120, $x" 
    $tbx_PC_Ram_Amount.Name = '$tbx_PC_Ram_Amount' 
    $tbx_PC_Ram_Amount.Size = '230, 18' 
    $tbx_PC_Ram_Amount.TabIndex = $tabindex
	$tbx_PC_Ram_Amount.ReadOnly = 'True'
    $tbx_PC_Ram_Amount.Visible = $false    
    $Script:aryDisplaytbxControls2 += $tbx_PC_Ram_Amount
    $tabindex = $tabindex + 1

    # ----- SNAPSHOT - PANEL 3
    $x = 22
    $tbx_PC_FreeRam.Location = "180, $x" 
    $tbx_PC_FreeRam.Name = 'tbx_PC_FreeRam' 
    $tbx_PC_FreeRam.Size = '180, 18' 
    $tbx_PC_FreeRam.TabIndex = $tabindex
	$tbx_PC_FreeRam.ReadOnly = 'True'
    $tbx_PC_FreeRam.Visible = $false
    $Script:aryDisplaytbxControls3 += $tbx_PC_FreeRam
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_FreeVirtMem.Location = "180, $x" 
    $tbx_PC_FreeVirtMem.Name = 'tbx_PC_FreeVirtMem' 
    $tbx_PC_FreeVirtMem.Size = '180, 18' 
    $tbx_PC_FreeVirtMem.TabIndex = $tabindex
	$tbx_PC_FreeVirtMem.ReadOnly = 'True'
    $tbx_PC_FreeVirtMem.Visible = $false    
    $Script:aryDisplaytbxControls3 += $tbx_PC_FreeVirtMem
    $tabindex = $tabindex + 1

    # ----- CURRENT USERS - PANEL 4
    $x = 22
    $tbx_PC_User_SSO.Location = "60, $x" 
    $tbx_PC_User_SSO.Name = 'tbx_PC_User_SSO' 
    $tbx_PC_User_SSO.Size = '180, 18' 
    $tbx_PC_User_SSO.TabIndex = $tabindex
	$tbx_PC_User_SSO.ReadOnly = 'True'
    $tbx_PC_User_SSO.Visible = $false
    $Script:aryDisplaytbxControls4 += $tbx_PC_User_SSO
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_User_Name.Location = "60, $x" 
    $tbx_PC_User_Name.Name = 'tbx_PC_User_Name' 
    $tbx_PC_User_Name.Size = '180, 18' 
    $tbx_PC_User_Name.TabIndex = $tabindex
	$tbx_PC_User_Name.ReadOnly = 'True'
    $tbx_PC_User_Name.Visible = $false
    $Script:aryDisplaytbxControls4 += $tbx_PC_User_Name
    $tabindex = $tabindex + 1

    # ----- CURRENT SESSIONS - PANEL 5
    $x = 22
    $tbx_PC_Session_UserName.Location = "120, $x" 
    $tbx_PC_Session_UserName.Name = 'tbx_PC_Session_UserName' 
    $tbx_PC_Session_UserName.Size = '180, 18' 
    $tbx_PC_Session_UserName.TabIndex = $tabindex
	$tbx_PC_Session_UserName.ReadOnly = 'True'
    $tbx_PC_Session_UserName.Visible = $false
    $Script:aryDisplaytbxControls5 += $tbx_PC_Session_UserName
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Session_Type.Location = "120, $x" 
    $tbx_PC_Session_Type.Name = 'tbx_PC_Session_Type' 
    $tbx_PC_Session_Type.Size = '180, 18' 
    $tbx_PC_Session_Type.TabIndex = $tabindex
	$tbx_PC_Session_Type.ReadOnly = 'True'
    $tbx_PC_Session_Type.Visible = $false
    $Script:aryDisplaytbxControls5 += $tbx_PC_Session_Type
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Session_State.Location = "120, $x" 
    $tbx_PC_Session_State.Name = 'tbx_PC_Session_State' 
    $tbx_PC_Session_State.Size = '180, 18' 
    $tbx_PC_Session_State.TabIndex = $tabindex
	$tbx_PC_Session_State.ReadOnly = 'True'
    $tbx_PC_Session_State.Visible = $false
    $Script:aryDisplaytbxControls5 += $tbx_PC_Session_State
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Session_IdleTime.Location = "120, $x" 
    $tbx_PC_Session_IdleTime.Name = 'tbx_PC_Session_IdleTime' 
    $tbx_PC_Session_IdleTime.Size = '180, 18' 
    $tbx_PC_Session_IdleTime.TabIndex = $tabindex
	$tbx_PC_Session_IdleTime.ReadOnly = 'True'
    $tbx_PC_Session_IdleTime.Visible = $false
    $Script:aryDisplaytbxControls5 += $tbx_PC_Session_IdleTime
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_PC_Session_LogonTime.Location = "120, $x" 
    $tbx_PC_Session_LogonTime.Name = 'tbx_PC_Session_LogonTime' 
    $tbx_PC_Session_LogonTime.Size = '180, 18' 
    $tbx_PC_Session_LogonTime.TabIndex = $tabindex
	$tbx_PC_Session_LogonTime.ReadOnly = 'True'
    $tbx_PC_Session_LogonTime.Visible = $false
    $Script:aryDisplaytbxControls5 += $tbx_PC_Session_LogonTime
    $tabindex = $tabindex + 1

    # ----- MISC INFO - PANEL 6
    $x = 22
    $tbx_Misc_Last_LoginTime.Location = "120, $x" 
    $tbx_Misc_Last_LoginTime.Name = 'tbx_Misc_Last_LoginTime' 
    $tbx_Misc_Last_LoginTime.Size = '180, 18' 
    $tbx_Misc_Last_LoginTime.TabIndex =  $tabindex
	$tbx_Misc_Last_LoginTime.ReadOnly = 'True'
    $tbx_Misc_Last_LoginTime.Visible = $false
    $Script:aryDisplaytbxControls6 += $tbx_Misc_Last_LoginTime
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_Misc_User_Session_Length.Location = "120, $x" 
    $tbx_Misc_User_Session_Length.Name = 'tbx_Misc_User_Session_Length' 
    $tbx_Misc_User_Session_Length.Size = '180, 18' 
    $tbx_Misc_User_Session_Length.TabIndex =  $tabindex
	$tbx_Misc_User_Session_Length.ReadOnly = 'True'
    $tbx_Misc_User_Session_Length.Visible = $false
    $Script:aryDisplaytbxControls6 += $tbx_Misc_User_Session_Length
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_Misc_PC_RebootPending.Location = "120, $x" 
    $tbx_Misc_PC_RebootPending.Name = 'tbx_Misc_PC_RebootPending' 
    $tbx_Misc_PC_RebootPending.Size = '180, 18' 
    $tbx_Misc_PC_RebootPending.TabIndex =  $tabindex
	$tbx_Misc_PC_RebootPending.ReadOnly = 'True'
    $tbx_Misc_PC_RebootPending.Visible = $false
    $Script:aryDisplaytbxControls6 += $tbx_Misc_PC_RebootPending
    $tabindex = $tabindex + 1

    # ----- Service-Now INFO - PANEL 7
    $x = 22
    $tbx_SN_User_Assigned.Location = "120, $x" 
    $tbx_SN_User_Assigned.Name = 'tbx_SN_User_Assigned' 
    $tbx_SN_User_Assigned.Size = '270, 18' 
    $tbx_SN_User_Assigned.TabIndex =  $tabindex
	$tbx_SN_User_Assigned.ReadOnly = 'True'
    $tbx_SN_User_Assigned.Visible = $false
    $Script:aryDisplaytbxControls7 += $tbx_SN_User_Assigned
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_SN_User_Dept.Location = "120, $x" 
    $tbx_SN_User_Dept.Name = 'tbx_SN_User_Dept' 
    $tbx_SN_User_Dept.Size = '270, 18' 
    $tbx_SN_User_Dept.TabIndex =  $tabindex
	$tbx_SN_User_Dept.ReadOnly = 'True'
    $tbx_SN_User_Dept.Visible = $false
    $Script:aryDisplaytbxControls7 += $tbx_SN_User_Dept
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_SN_User_Location.Location = "120, $x" 
    $tbx_SN_User_Location.Name = 'tbx_SN_User_Location' 
    $tbx_SN_User_Location.Size = '270, 18' 
    $tbx_SN_User_Location.TabIndex =  $tabindex
	$tbx_SN_User_Location.ReadOnly = 'True'
    $tbx_SN_User_Location.Visible = $false
    $Script:aryDisplaytbxControls7 += $tbx_SN_User_Location
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_SN_PC_State.Location = "120, $x" 
    $tbx_SN_PC_State.Name = 'tbx_SN_PC_State' 
    $tbx_SN_PC_State.Size = '270, 18' 
    $tbx_SN_PC_State.TabIndex =  $tabindex
	$tbx_SN_PC_State.ReadOnly = 'True'
    $tbx_SN_PC_State.Visible = $false
    $Script:aryDisplaytbxControls7 += $tbx_SN_PC_State
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_SN_PC_Substate.Location = "120, $x" 
    $tbx_SN_PC_Substate.Name = 'tbx_SN_PC_Substate' 
    $tbx_SN_PC_Substate.Size = '270, 18' 
    $tbx_SN_PC_Substate.TabIndex =  $tabindex
	$tbx_SN_PC_Substate.ReadOnly = 'True'
    $tbx_SN_PC_Substate.Visible = $false
    $Script:aryDisplaytbxControls7 += $tbx_SN_PC_Substate
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_SN_PC_Asset_Function.Location = "120, $x" 
    $tbx_SN_PC_Asset_Function.Name = 'tbx_SN_PC_Asset_Function' 
    $tbx_SN_PC_Asset_Function.Size = '270, 18' 
    $tbx_SN_PC_Asset_Function.TabIndex =  $tabindex
	$tbx_SN_PC_Asset_Function.ReadOnly = 'True'
    $tbx_SN_PC_Asset_Function.Visible = $false
    $Script:aryDisplaytbxControls7 += $tbx_SN_PC_Asset_Function
    $tabindex = $tabindex + 1

    # ----- Meraki INFO - PANEL 8
    $x = 22
    $tbx_Meraki_IP.Location = "120, $x" 
    $tbx_Meraki_IP.Name = 'tbx_Meraki_IP' 
    $tbx_Meraki_IP.Size = '270, 18' 
    $tbx_Meraki_IP.TabIndex =  $tabindex
	$tbx_Meraki_IP.ReadOnly = 'True'
    $tbx_Meraki_IP.Visible = $false
    $Script:aryDisplaytbxControls8 += $tbx_Meraki_IP
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_Meraki_Serial.Location = "120, $x" 
    $tbx_Meraki_Serial.Name = 'tbx_Meraki_Serial' 
    $tbx_Meraki_Serial.Size = '270, 18' 
    $tbx_Meraki_Serial.TabIndex =  $tabindex
	$tbx_Meraki_Serial.ReadOnly = 'True'
    $tbx_Meraki_Serial.Visible = $false
    $Script:aryDisplaytbxControls8 += $tbx_Meraki_Serial
    $tabindex = $tabindex + 1

    $x = $x + 22
    $tbx_Meraki_User_Address.Location = "120, $x" 
    $tbx_Meraki_User_Address.Name = 'tbx_Meraki_User_Address' 
    $tbx_Meraki_User_Address.Size = '270, 18' 
    $tbx_Meraki_User_Address.TabIndex =  $tabindex
	$tbx_Meraki_User_Address.ReadOnly = 'True'
    $tbx_Meraki_User_Address.Visible = $false
    $Script:aryDisplaytbxControls8 += $tbx_Meraki_User_Address
    $tabindex = $tabindex + 1

#------------------------- END TEXTBOXES ------------------------#

#------------------------ START TIMER -------------------------------#
    $timerJobTracker.Enabled = $True
	$timerJobTracker.Interval = 1000
	$timerJobTracker.add_Tick($timerJobTracker_Tick)
#------------------------ END TIMER ---------------------------------#

    $splitcontainer.ResumeLayout()
    $panelLeft.ResumeLayout()
    $panelRight.ResumeLayout()
    $panel1.ResumeLayout() 
    $panel2.ResumeLayout() 
    $panel3.ResumeLayout()
    $panel4.ResumeLayout() 
    $panel5.ResumeLayout() 
    $panel6.ResumeLayout() 
    $panel7.ResumeLayout()
    $panel8.ResumeLayout()  
    $MainForm.ResumeLayout() 
    #endregion Generated Form Code 

    $tbx_PC_AD_Desc.Select()
    #---------------------------------------------- 
 
    #Save the initial state of the form 
    $InitialFormWindowState = $MainForm.WindowState 
    #Init the OnLoad event to correct the initial state of the form 
    $MainForm.add_Load($Form_StateCorrection_Load) 
    #Clean up the control events 
    $MainForm.add_FormClosed($Form_Cleanup_FormClosed) 
    #Store the control values when form is closing 
    $global:shouldcancel = $true
    $MainForm.add_Closing({
        #ADD CODE FOR FORM CLOSING EVENT
    })

    #Show the Form 
    return $MainForm.ShowDialog() 
    
} 
#endregion Source: MainForm.psf 

#Start the application
$Script:LastSearchBy = $null
$Script:LastSearch = $null

$Script:InitialFixesLocation = "$(((get-item "$psscriptroot").parent).fullname)"
$Script:FixesLocation = $Script:InitialFixesLocation
$Script:InitialEUCLocation = "$(((get-item "$psscriptroot").parent).fullname)"
$Script:EUCLocation = $Script:InitialEUCLocation
$Script:HDriveLocation = '\\wgpif001Users.aah.local\Users\bwienk1'
$Script:InitialUserStarted = 'bwienk1'

#IMPORT USERS FROM CSV VALUES
$data=@(Import-CSV "$psscriptroot\Config\Users.csv")
$index = -1

foreach($entry in $data)
{
    if($entry.USER_SSO -eq "$env:USERNAME" -or $entry.USER_ADMIN -eq "$env:USERNAME")
    {
        $index = $data.IndexOf($entry)
    }
}

if($index -ne -1)
{
    write-host "$($data[$index].USER_SSO) setup"; $Script:HDriveLocation = $data[$index].USER_H_DRIVE
    $Script:USER_SSO = $data[$index].USER_SSO
    $Script:USER_ADMIN = $data[$index].USER_ADMIN
    $Script:USER_CITRIX_SSO = $data[$index].USER_CITRIX_SSO
    $Script:USER_VSPHERE_SSO = $data[$index].USER_VSPHERE_SSO
    $Script:USER_AD_SSO = $data[$index].USER_AD_SSO
}
else
{
    write-host -ForegroundColor Yellow "USER NOT FOUND!`nPLEASE CHECK - $psscriptroot\Config\Users.csv!"
    read-host "Press Enter to Exit"
    exit
}

$Script:CredentialsLoaded = $false
$Script:AryFixButtons = $null
$Script:AryEUCButtons1 = $null
$Script:credentials = $null
$Script:credentials2 = $null
Check-Credentials

$Script:Setupbutton = "Initial Setup..."
if($Script:HDriveLocation)
{
    Set-CredentialsLoaded
    $Script:Setupbutton = "Change Passwords..."
    $Script:EnabledButtons = $true
}
else
{
    $Script:Setupbutton = "Initial Setup..."
    $Script:EnabledButtons = $false
}
Main ($CommandLine)
 
}
else 
{
    #************************************************************************
    #-----------------------START ADMIN PS-----------------------------------
    $content = $null
    #$scriptname = Split-Path "$($Script:MyInvocation.PSCommandPath)" -leaf
    $content = (get-content "$($script:MyInvocation.MyCommand.Path)")
    if ($content -ne $null -and $content -ne "")
    {
        $content2 = ($content | Where-Object {$_ -like '$Script:InitialUserStarted = *'}|% {$i = $i + 1;$index = $content.IndexOf($_)})

        if($content2.count -gt 1)
        {
            #REPLACING MORE LINES OF CODE AS VARIABLE WAS USED AGAIN!!!!
        }
        else
        {
            $content[$index] = "`$Script:InitialUserStarted = `'$env:USERNAME`'"
            $content |Set-Content "$($script:MyInvocation.MyCommand.Path)"
        }
    }
    $Script:InitialUserStarted = $env:USERNAME
    Start-Sleep -Seconds 1
    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";
    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";

    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
    #-----------------------START ADMIN PS-----------------------------------
    #************************************************************************
}
