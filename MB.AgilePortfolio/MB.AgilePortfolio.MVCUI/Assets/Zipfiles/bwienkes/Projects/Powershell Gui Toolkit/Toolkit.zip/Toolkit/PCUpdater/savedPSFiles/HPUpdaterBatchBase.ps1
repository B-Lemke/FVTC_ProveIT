Param(
[String]$line,
[String]$PCList,
[String]$out_PCLogsFolderPath,
[String]$CompletedList,
[String]$PCLogs,
[String]$ScriptRoot,
[String]$Model,
[switch]$changeADdesc
)

#****************************************
#-------------- Inital Setup ------------

$QuickEditCodeSnippet=@" 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.InteropServices;


public static class DisableConsoleQuickEdit
{

const uint ENABLE_QUICK_EDIT = 0x0040;

// STD_INPUT_HANDLE (DWORD): -10 is the standard input device.
const int STD_INPUT_HANDLE = -10;

[DllImport("kernel32.dll", SetLastError = true)]
static extern IntPtr GetStdHandle(int nStdHandle);

[DllImport("kernel32.dll")]
static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

[DllImport("kernel32.dll")]
static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

public static bool SetQuickEdit(bool SetEnabled)
{

    IntPtr consoleHandle = GetStdHandle(STD_INPUT_HANDLE);

    // get current console mode
    uint consoleMode;
    if (!GetConsoleMode(consoleHandle, out consoleMode))
    {
        // ERROR: Unable to get console mode.
        return false;
    }

    // Clear the quick edit bit in the mode flags
    if (SetEnabled)
    {
        consoleMode &= ~ENABLE_QUICK_EDIT;
    }
    else
    {
        consoleMode |= ENABLE_QUICK_EDIT;
    }

    // set the new mode
    if (!SetConsoleMode(consoleHandle, consoleMode))
    {
        // ERROR: Unable to set console mode
        return false;
    }

    return true;
}
}

"@

$QuickEditMode=add-type -TypeDefinition $QuickEditCodeSnippet -Language CSharp


function Set-QuickEdit() 
{
[CmdletBinding()]
param(
[Parameter(Mandatory=$false, HelpMessage="This switch will disable Console QuickEdit option")]
    [switch]$DisableQuickEdit=$false
)


    if([DisableConsoleQuickEdit]::SetQuickEdit($DisableQuickEdit))
    {
        Write-Output "QuickEdit settings has been updated."
    }
    else
    {
        Write-Output "Something went wrong."
    }
}

function Check-Credentials
{
    $Script:CredentialsLoaded = $false
    $Script:credentials = $null
    $Script:credentials2 = $null
    if(test-path "C:\Temp\CKey.key")
    {
        $failedcreds = $false
        [Byte[]]$key = gc C:\Temp\CKey.key
        if(test-path 'C:\Temp\A_User.txt')
        {
            $Admin_User = gc 'C:\Temp\A_User.txt'
            $Admin_User = $Admin_User.trim()
            $Admin_User1 = "AFII\$($Admin_User)"
            if(test-path 'C:\Temp\ACreds_ss.txt')
            {
                $Script:credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",(Get-Content 'C:\Temp\ACreds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }
        if(test-path 'C:\Temp\NA_User.txt')
        {
            $Script:NonAdmin_User = gc 'C:\Temp\NA_User.txt'
            $Script:NonAdmin_User = $Script:NonAdmin_User.trim()
            $Script:NonAdmin_User1 = "AFII\$($Script:NonAdmin_User)"
            if(test-path 'C:\Temp\Creds_ss.txt')
            {

                $SecurePass =  (Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
                $BSTR = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecurePass)
                $Script:Password = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
                $Script:credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Script:NonAdmin_User1",(Get-Content 'C:\Temp\Creds_ss.txt' | ConvertTo-SecureString -key $key )
            }
            else
            {
                $failedcreds = $True
            }
        }
        else
        {
            $failedcreds = $True
        }

        if($failedcreds -eq $false)
        {
            $Script:CredentialsLoaded = $true
        }
    }
}

cls
write-output "------------ Started UpdaterBase Script at $((Get-Date).ToString()) -------------------`n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "------------ Started UpdaterBase Script at $((Get-Date).ToString()) -------------------`n" 

if ($changeADdesc -eq $true)
{
write-host "Will be changing AD Description"
}
else
{
write-host "Won't be changing AD Description"
}




Set-QuickEdit -DisableQuickEdit

$scriptRoot2 = "$PSScriptRoot"
$ParentFullName = (get-item $scriptRoot2).Parent.FullName


$PCRunningScript = hostname
$EUCPCs = @()
$EUCUsers = @()
$EUC = @{bwienk1 = "WILG00MP18YWSB";mjung11 = "WILG00PF0RCUKC"}
foreach ($key in $EUC.Keys)
{
    if ($EUC[$key] -eq $PCRunningScript)
    {

    }
    else
    {
    $EUCPCs += $EUC[$key]
    $EUCUsers += $key
    }
}

import-module ActiveDirectory




Check-Credentials

#-------------- Inital Setup ------------
#****************************************

#-----------------------------------------------------------------------------------------------
#Write-output "********** Automated Driver/Bios update for newly imaged PC's ***********" 
#Write-output "--------------------------Created By Brenton Wienkes---------------------------------" 
#Write-output ""
#-----------------------------------------------------------------------------------------------

#*************************************************
$FileRoots = @("C:\Temp\HPBiosConfig")

$computer = $line
$Host.UI.RawUI.WindowTitle = "Running HPUpdaterBatchBase for $computer"
$out_UpdateADConnectList = "$($ScriptRoot)\RecentlyImagedList.txt"
#$sourceBios2 = Split-Path $sourceBios -Leaf
#*****************************************************************
#----------------------Installation------------------------------
#Start-Transcript -Path $($PCLogs) -Append
write-host "Starting remote processes on $computer"

$s2 = New-PSSession -computer $computer
$n = Invoke-Command -Session $s2 -ScriptBlock {

#$powershellArguments2 = "C:\Temp\dellclient.ps1 -Name $args[0] -Root $args[1] -CMD $args[2]" 
#Start-Process "powershell.exe" -verb runas -ArgumentList $powershellArguments2 -Wait



<#     BITLOCKER CODE
$OSVolumeEncypted = if ((Manage-Bde -Status C:) -match "Protection On") { Write-host $true } else { Write-host $false }


	

#NEEDS TO BE SETUP FOR DELL
		# Supend Bitlocker if $OSVolumeEncypted is $true
		if ($OSVolumeEncypted -eq $true) {
			Write-output "Suspending BitLocker protected volume: C:" -Severity 1
            Write-host "Suspending BitLocker protected volume: C:"
			$a = Manage-Bde -Protectors -Disable C:
            write-output $a

		}

$b =Suspend-BitLocker -MountPoint "C:" -RebootCount 1
write-output $b
#>

write-host -ForegroundColor Cyan "Starting Bios Settings Update..."
	$output = (C:\temp\HPBiosConfig\biosconfigutility.exe /set:"C:\temp\HPBiosConfig\HPBios.txt")
#XML CREATION
$xmlDoc = [xml]@"
<xml>
$output
</xml>
"@

	$RebootMsg = $xmldoc.xml.biosconfig.reboot.msg
	$hadErrors = $xmldoc.xml.biosconfig.success.msg
    if(!($hadErrors -like "No errors*"))
    {
        #no errors
        
        write-output "SET BIOS SETTING ERROR: $hadErrors"
        write-host -foregroundcolor red "ERROR: $hadErrors"
    }
        else
    {
        write-output "SUCCESSFULLY set bios settings!"
        write-host -foregroundcolor green $hadErrors
    }
    
	Write-Output "Reboot: $RebootMsg"





}

Remove-PSSession $s2
write-output $n | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append


#Stop-Transcript
#----------------------Installation------------------------------
#*****************************************************************

#wait 10 secs to be sure bios updater is ready
Start-Sleep -s 10 
#Restart no.2 timeout after 5 mins
$timedout = $null # reset any previously set timeout
restart-computer $computer -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
if ($timedout)
{
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out, but pc is still responsive"
write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
Start-Sleep -s 60
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out post bios, waited 60 secs and now pc is responsive"
write-output "$($computer) restart timed out waited post bios, 60 secs and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
write-host "$($computer) restart timed out, please check pc"
write-output "$($computer) restart timed out, please check pc $((Get-Date).ToString())" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-Host "adding $($computer) back to list and ending script on this pc"
write-output "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 

$readdList = 1
Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
write-output "#####################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#####################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "#####################################################################"
write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
write-host "#####################################################################" 
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}

<#
foreach ($EUC in $EUCPCs)
{
if (Test-Connection $EUC -Quiet)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {
        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {
    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>
Remove-Item $path -force -recurse
exit
}
}

}
<#    BITLOCKER CODE
$EncryptionStatus=(manage-bde -status -computername "$computer" C: | where {$_ -match 'Protection Status'})
if ($EncryptionStatus)
{
    $EncryptionStatus=$EncryptionStatus.Split(":")[1].trim()
    if ($EncryptionStatus -like "Protection On")
    {
    Write-host "Bitlocker is on"
    Write-Output "Bitlocker is on" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    }
    else
    {
    Write-host "Bitlocker is off"
    Write-Output "Bitlocker is off" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    
        $p = New-PSSession -computerName $computer
        $pt = Invoke-Command -Session $p -Scriptblock {
        #manage-bde -Protectors -Enable C:
        $a1 = manage-bde -on C:
        Write-Output $a1
        $a = manage-bde -status
        write-host "$a"
         write-output $a
        }
        Write-Output $pt | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
        Remove-PSSession $p
       
    }
}
#>
               

Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "Cleaning up Temp Files"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

#import-module $biosroot\dellbiosprovider.psm1 -verbose

#*****************************************************************
#-------------------------- Cleanup -----------------------------


$U = Invoke-Command -Computer $computer -ScriptBlock {

$pc = hostname
#Files/Folder names that were pushed to C:\Temp
$fileList = @()


$filelist += "HPBiosConfig"


#$fileList = @("t470client.ps1", "Invoke-LenovoBIOSUpdate.ps1", "PMDriver", "ME", "IntelVGA", "n1quj15w")

    #-----------------------Array Loop-----------------------------
foreach ($file in $fileList)
    {
    $newfilepath = "C:\Temp\$($file)"
        #------------Path Test and verify-----------
 if (test-path $newfilepath)
                {
                    Write-Host "$newfilepath file exists"
                    Write-output "$newfilepath file exists"
                    try
                    {
                        #We try to remove...
                        Remove-Item $newfilepath -force -recurse -ErrorAction Stop
                    }
                    catch
                    {
                        #And there will be an error message if it fails
                        Write-Host "Error while deleting $newfilepath on $pc.`n$($Error[0].Exception.Message)"
                        Write-output "Error while deleting $newfilepath on $pc.`n$($Error[0].Exception.Message)"
                        #We skip the rest and go back to the next object in the loop
                        continue
                    }
                    #On sucessful deletion of file...
                    Write-Host  "$newfilepath file deleted"
                    Write-output  "$newfilepath file deleted"
                }
        #------------Path Test and verify-----------

    }
    #-----------------------Array Loop-----------------------------
    }
    write-output $u | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append

    
#-------------------------- Cleanup -----------------------------
#*****************************************************************

#Wait for 2 seconds to be sure it's ready
 Start-Sleep -s 2 
#$computer2 = Read-Host -Prompt "Type Full PC name or Serial to begin update"

<#
#Restart no 3 to besure bitlocker is not suspended
$timedout = $null # reset any previously set timeout
restart-computer $computer -force -wait -for PowerShell -Timeout 500 -Delay 2 -ev timedout
if ($timedout)
{
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out, but pc is still responsive"
write-output "$($computer) restart timed out, but pc is still responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
Start-Sleep -s 60
if (test-connection $computer -Quiet)
{
#Connection is good
write-Host "$($computer) restart timed out post bios, waited 60 secs and now pc is responsive"
write-output "$($computer) restart timed out waited post bios, 60 secs and now pc is responsive" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
else{
write-host "$($computer) restart timed out, please check pc"
write-output "$($computer) restart timed out, please check pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-Host "adding $($computer) back to list and ending script on this pc"
write-output "$($computer) is not found in AD" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 
write-Host "adding $($computer) back to list and ending script on this pc" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append 

$readdList = 1
Write-output "$($computer)"| Out-File -FilePath $PCList -Encoding ascii -Append
Write-output "$($computer) Failed due restart timedout post bios update $((Get-Date).ToString())`n"| Out-File -FilePath $out_CompletedList -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
write-host "################################################################" 
$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}

foreach ($EUC in $EUCPCs)
{
if (Test-Connection $EUC -Quiet)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {
        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {
    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}

Remove-Item $path -force -recurse
exit
}
}

}
#>

#************************************************************************
#---------------------- Set AD ------------------------------------------
$ADcomputer = Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '*$computer'"
$Desc = "**NEW** Unassigned $($Model)"
Write-output "" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
if ($changeADdesc -eq $true)
{
     Write-host "Setting $($ADcomputer.Name) Description in Active Directory... `n" 
    Write-output "Setting $($ADcomputer.Name) Description in Active Directory... `n" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "Old Description: $($ADcomputer.Description)"  | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output "New Description: $($Desc)" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-host "Old Description: $($ADcomputer.Description)"
    Write-host "New Description: $($Desc)"
    Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Set-ADComputer $computer -Description $Desc
}
else
{
    Write-host "Description: $($ADcomputer.Description)" 
    Write-output "Description: $($ADcomputer.Description)"  | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
    Write-output ""| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
}
#Write-output ""| Out-File -FilePath $CompletedList -Encoding ascii -Append
Write-output "$($computer) Completed $((Get-Date).ToString())"| Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
Write-output "$($computer) Completed $((Get-Date).ToString())"| Out-File -FilePath $CompletedList -Encoding ascii -Append
Write-output "$($computer)"| Out-File -FilePath $out_UpdateADConnectList -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "#---------------------------- END $((Get-Date).ToString()) -----------------------------#" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-output "################################################################" | Out-File -FilePath "$($PCLogs)" -Encoding ascii -Append
write-host "################################################################"
write-host "#---------------------------- END $((Get-Date).ToString()) -----------------------------#"
write-host "################################################################" 

$path = $PCLogs
$PCLogs = "$($out_PCLogsFolderPath)\$($computer).txt"
if (test-path $PCLogs)
{
(Get-Content $path -Raw) + (Get-Content $PCLogs -Raw) | Set-Content $PCLogs
}
else
{
(Get-Content $path -Raw) | Out-File -FilePath "$($PCLogs)" -Encoding ascii
}

<#
foreach ($EUC in $EUCPCs)
{

if (Test-Connection $EUC -Quiet -Count 1)
{
$index = $EUCPCs.IndexOf($EUC)
    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {

        Copy-Item -Path $PCLogs -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
    {

    write-output $PCLogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii -Append
    }

}
}
#>
Remove-Item $path -force -recurse





<#
$logstopush = gc "$PSScriptroot\NeedtoPushlogs.txt"
$readdlogs = New-Object System.Collections.ArrayList
foreach ($log in $logstopush)
{
if ($log)
{
if($log.trim())
{
$log = $log.trim()
if (Test-Path "$log")
    {
foreach ($EUC in $EUCPCs)
{

if (Test-Connection $EUC -Quiet -Count 1)
{

$index = $EUCPCs.IndexOf($EUC)

    If (Test-Path "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User")
    {

        Copy-Item -Path $log -Recurse -Destination "\\$EUC\C$\users\$($EUCUsers[$index])\Desktop\Script Fixes\PCUpdater\EUCLogs\$Script:NonAdmin_User\$($computer).txt" -Container -Force
    }
    else
        {
            $readdlogs.Add("$log") > $null
        }
        

}

}

}

}

}

}

write-output $readdlogs | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs.txt" -Encoding ascii


write-output "" | Out-File -FilePath "$PSScriptroot\NeedtoPushlogs2.txt" -Encoding ascii
$hash = @{}                 # Define an empty hashtable
gc "$PSScriptroot\NeedtoPushlogs.txt" |        # Send the content of the file into the pipeline...
% {                             # For each object in the pipeline...
                                      # note '%' is an alias of 'foreach-object'          
if ($hash.$_ -eq $null) {    # if that line is not a key in our hashtable...
                                      # note -eq means 'equals'
                                      # note $_ means 'the data we got from the pipe'
                                     # note $null means NULL
         $_                       # ... send that line further along the pipe
     };
     $hash.$_ = 1                 # Add that line to the hash (so we won't send it again)
                                      # note that the value isn't important here,
                                      # only the key. ;-)
  } > "$PSScriptroot\NeedtoPushlogs2.txt"              # finally... redirect the pipe into a new file.
  gc "$PSScriptroot\NeedtoPushlogs2.txt" -Raw | Set-Content -Path "$PSScriptroot\NeedtoPushlogs.txt"
  Remove-Item "$PSScriptroot\NeedtoPushlogs2.txt" -force -recurse > $null
#>
exit
#---------------------- Set AD ------------------------------------------
#************************************************************************
#}

