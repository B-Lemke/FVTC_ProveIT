﻿param
(
[Parameter(Mandatory=$false)] $computer
)
if(!($computer)){$Param_ErrorMsg = "No value entered for: computer"}
elseif(!($computer -is [string])){$Param_ErrorMsg = "wrong data type entered for parameter: computer"}
elseif(!($computer.Trim())){$Param_ErrorMsg = "Requires a string that is not empty for parameter: computer"}
if(!($Param_ErrorMsg))
{

$cs = New-CimSession -ComputerName $computer
$monitors =  Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorId -Filter "Active = '$true'" -CimSession $cs
$objAry = @()
foreach ($monitor in $monitors) {
$in = ($monitor.InstanceName).Replace('\', '\\')
Write-Verbose -Message $in
$dp = Get-CimInstance -Namespace root\wmi -ClassName WmiMonitorBasicDisplayParams -Filter "InstanceName = '$in'" -CimSession $cs
$name = ''
foreach ($c in $monitor.UserFriendlyName){
if ($c -ne '00'){$name += [char]$c}
}
$type = 'Unknown'
switch ($dp.VideoInputType){
0 {$type = 'Analog'}
1 {$type = 'Digital'}
}
if (!($name))
{
        $lenovo = get-wmiobject win32_Desktopmonitor -ComputerName $computer | select MonitorManufacturer |Where-object -property MonitorManufacturer -like "lenovo"
        if ($lenovo)
        {
            $name = "Built-in Display"
        }
}

$obj = New-Object -TypeName PSObject -Property @{
Name = $name
Type = $type
}
$objAry += $obj
}
$objAry |Out-Host
Remove-CimSession -CimSession $cs
read-host "Press enter to exit"
exit
}

else
{
write-host "Get-monitors: $Param_ErrorMsg"
Read-Host "`nPress Enter to exit"
exit
}

