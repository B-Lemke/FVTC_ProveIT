import sys, getopt, re, time, string, datetime, os
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException

#scriptpath = 'C:/Users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver'
scriptpath = os.path.dirname(os.path.realpath(__file__))

OldComputerFullname = ["WILG0009FYJH72"]
LoginUsername = sys.argv[1]
LoginUserPassword = sys.argv[2]

StockroomLocation = 'AAH Green Bay'

OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"

#   SETUP CHROME DRIVER
options = Options()
#options.add_argument("--disable-logging")
#options.add_argument('log-level=3')
#options.headless = True
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
#driver = webdriver.Chrome(options=options, executable_path= scriptpath)
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")

wait = WebDriverWait(driver, 5)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

Universal_SN_iframe = "gsft_main"

OldPCiframe = Universal_SN_iframe

stateID = "alm_hardware.install_status"
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"
#<option value="BCP">BCP</option>
#<option value="Call Center">Call Center</option>
#<option value="Disaster Recovery">Disaster Recovery</option>
#<option value="Lab Device">Lab Device</option>
#<option value="Loaner">Loaner</option>
#<option value="Monitoring">Monitoring</option>
#<option value="Primary Device">Primary Device</option>
#<option value="Secondary Device">Secondary Device</option>
#<option value="Security">Security</option>
#<option value="Shared Device">Shared Device</option>
#<option value="Testing">Testing</option>
#<option value="Training">Training</option>
#<option value="Development">Development</option>
#<option value="Spare">Spare</option>
#<option value="Hot-Spare" selected="SELECTED">Hot-Spare</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"

userAssignedID = "sys_display.alm_hardware.assigned_to"
departmentid = "sys_user.department_label"

DateAssignedID = "alm_hardware.assigned"

RequestMembershipPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
memberUserID = "sys_display.IO:3cd7f12a903da80087a863f119b63795"
memberModGroupID = "IO:cc7033214fd84f806f4d3e1ca310c75c"
memberTargetGroupID = "IO:94390d824fdc03006f4d3e1ca310c72f"
memberActionID = "IO:1f34c9844fecdb406f4d3e1ca310c7f7"
memberMembershipID = "sys_display.IO:42e078f74f8c0780c8e7e57d0210c77b"
memberPCtbxID = "computer_list_cmdb_ci_computer"
membership_PC_List_Hidden_ID = "cmdb_ci_computer.computer_list"
#memberPCHiddenListID
memberShowAvailablePCEvent = "\"return checkEnter(event, 'cmdb_ci_computer.computer_list')\""
membership_Element_PC_List_select_ID = "computer_list_select_0"
#memberPClistID = "computer_list_select_0"
memberReasonID = "IO:96695c1d311df0404c72ad13d18ba9f0"
memberSubmitBtnCode = "\"if ($$('.order_buttons .disabled_order_button').length == 0) { orderNow(); } else { alert('Please wait - price being updated'); };\""

#Begin Webpage navigation to Old PC record first
driver.get(OldPCWebpage)

#   INITIAL LOGIN PAGE
#SET ELEMENTS IN LOGIN PAGE
print(" ________________________________________________")
print("|             Logging in As user                 |")
print("|________________________________________________|")
print(" ")
userid = driver.find_element_by_id('userID')
password = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id("loginbtn")

#SEND KEYS TO ELEMENTS IN LOGIN PAGE
userid.send_keys(LoginUsername)
password.send_keys(LoginUserPassword)
btnLogin.click()


PCState = None
PCSubState = None
PCAssetFunction = None
viewuserinfo_element = None
outputary = []
#pcary = []
#expectedwindows = 2
print(" ________________________________________________")
print("|        Getting PC Info from Service-now        |")
print("|________________________________________________|")
print(" ")

for pc in OldComputerFullname:
    #Find Old PC Serial
    PC = pc
    if "WILG000" in PC: pc = PC.replace("WILG000","")
    elif "WILG00" in PC: pc = PC.replace("WILG00","")
    elif "WIDG000" in PC: pc = PC.replace("WIDG000","")
    elif "WIDG00" in PC: pc = PC.replace("WIDG00","")
    elif "AZLG000" in PC: pc = PC.replace("AZLG000","")
    elif "AZLG00" in PC: pc = PC.replace("AZLG00","")
    elif "AZDG000" in PC: pc = PC.replace("AZDG000","")
    elif "AZDG00" in PC: pc = PC.replace("AZDG00","")
    elif "NVLG000" in PC: pc = PC.replace("NVLG000","")
    elif "NVLG00" in PC: pc = PC.replace("NVLG00","")
    elif "NVDG000" in PC: pc = PC.replace("NVDG000","")
    elif "NVDG00" in PC: pc = PC.replace("NVDG00","")
    elif "MILG000" in PC: pc = PC.replace("MILG000","")
    elif "MILG00" in PC: pc = PC.replace("MILG00","")
    elif "MIDG000" in PC: pc = PC.replace("MIDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "MNLG000" in PC: pc = PC.replace("MNLG000","")
    elif "MNLG00" in PC: pc = PC.replace("MNLG00","")
    elif "MNDG000" in PC: pc = PC.replace("MNDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "WIVGP" in PC:
        #PC is VDI (different functions required)
        pc = PC
        isVDI_Old_PC = True
    else:
        pc = PC
    
    PCState = None
    PCSubState = None
    PCAssetFunction = None
    viewuserinfo_element = None
    OldUserAssigned = None
    print("Getting values for " + pc + "...")
    pcary = None
    OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + pc
    #windows_before  = driver.current_window_handle
    #driver.execute_script("window.open('" + OldPCWebpage + "')")
    #WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    #windows_after = driver.window_handles
    #driver.switch_to.window(windows_after[expectedwindows - 1])
    #expectedwindows = expectedwindows + 1
    driver.get(OldPCWebpage)
    
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    

    try:
        Element = driver.find_element_by_id(stateID)
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        select = Select(driver.find_element_by_id(stateID))
        select.select_by_value('6')
        #PCState = selected_option.text
        try:
            wait.until(EC.visibility_of_element_located((By.ID, StockRoomID)))
            Element = driver.find_element_by_id(StockRoomID)
            Element.click()
            Element.send_keys(Keys.CONTROL, 'a')
            Element.send_keys(StockroomLocation)
            #Element.click()
            wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
            Element = driver.find_element_by_id(SecondaryStateID)
            select = Select(driver.find_element_by_id(SecondaryStateID))
            select.select_by_value('pending_disposal')
            #PCSubState = selected_option.text
            #if PCSubState == "Reserved":
                ##no user will be assigned
                #assigned = "NOT ASSIGNED"
        except:
            #No PC SubState found
            print("STATE NOT FOUND")
    except:
        #No PC State found
        print("STATE NOT FOUND")
        print("SUBSTATE NOT FOUND")
        
    try:
        Element = driver.find_element_by_id(AssetFunctionID)
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        select = Select(driver.find_element_by_id(AssetFunctionID))
        select.select_by_value('Spare')
        #PCAssetFunction = selected_option.text
    except:
        #No PC Asset Function found
        print("ASSET FUNCTION NOT FOUND")

    wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
    driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")

    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()


print("Service Now is complete")
print("Starting Ticket Creation")
requestwebsite = "https://ameriprise.service-now.com/ameriprise/catalog.do?sysparm_document_key=sc_cat_item,fa836e94c5bdf040457ea01dc7fdb54e"

for pc in OldComputerFullname:
    #Find Old PC Serial
    PC = pc
    if "WILG000" in PC: pc = PC.replace("WILG000","")
    elif "WILG00" in PC: pc = PC.replace("WILG00","")
    elif "WIDG000" in PC: pc = PC.replace("WIDG000","")
    elif "WIDG00" in PC: pc = PC.replace("WIDG00","")
    elif "AZLG000" in PC: pc = PC.replace("AZLG000","")
    elif "AZLG00" in PC: pc = PC.replace("AZLG00","")
    elif "AZDG000" in PC: pc = PC.replace("AZDG000","")
    elif "AZDG00" in PC: pc = PC.replace("AZDG00","")
    elif "NVLG000" in PC: pc = PC.replace("NVLG000","")
    elif "NVLG00" in PC: pc = PC.replace("NVLG00","")
    elif "NVDG000" in PC: pc = PC.replace("NVDG000","")
    elif "NVDG00" in PC: pc = PC.replace("NVDG00","")
    elif "MILG000" in PC: pc = PC.replace("MILG000","")
    elif "MILG00" in PC: pc = PC.replace("MILG00","")
    elif "MIDG000" in PC: pc = PC.replace("MIDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "MNLG000" in PC: pc = PC.replace("MNLG000","")
    elif "MNLG00" in PC: pc = PC.replace("MNLG00","")
    elif "MNDG000" in PC: pc = PC.replace("MNDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "WIVGP" in PC:
        #PC is VDI (different functions required)
        pc = PC
        isVDI_Old_PC = True
    else:
        pc = PC

    #Input
    ShortDescElementID = "IO:f2836e94c5bdf040457ea01dc7fdb593"
    ShortDesc = "Deban and Retire PC: " + str(pc)
    #TextArea
    LongDescElementID = "IO:f6836e94c5bdf040457ea01dc7fdb592"
    LongDesc = "Remove " + str(pc) + " from AD, update service-now records, DBAN " + str(pc) + ", and remove any bios passwords from " + str(pc)
    #Input
    AssignedGroupElementID = "sys_display.IO:f68322d4c5bdf040457ea01dc7fdb530"
    AssignedGroup = "AAH Tech Ops - Infr Ops EUC"
    #submit button
    SubmitButtonElementID = "submit_button"
    
    driver.get(requestwebsite)
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    
    inputelement = driver.find_element(By.ID, ShortDescElementID)
    inputelement.send_keys(ShortDesc)
    
    driver.execute_script("arguments[0].value = arguments[1]", driver.find_element_by_id(LongDescElementID), LongDesc)
    
    inputelement = driver.find_element(By.ID, AssignedGroupElementID)
    inputelement.send_keys(AssignedGroup)
    time.sleep(1)
    inputelement.send_keys(Keys.TAB)
    
    
    buttonclick = driver.find_element(By.ID, 'submit_button')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()
    
    #file.write("Getting Request Number..." + "|")
    wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@id='dropzone10']/div[3]/div/div[1]/p")))
    Element = driver.find_element_by_xpath("//*[@id='dropzone10']/div[3]/div/div[1]/p")
    RequestNumber = Element.text
    if not RequestNumber is None:
        RequestNumber = RequestNumber.split()
        RITM = RequestNumber[2]
        #file.write("Request String array item 3: " + RITM + "|")
        if not RITM is None:
            #Add Note for Cert request
            print("RITM: " + str(RITM))
            #TicketNotes += ["Cert request: " + RITM]
            #file.write("Adding to Ticket Notes Array: " + RITM + "|")
    #file.write("Request String: " + RequestNumber + "|")
    time.sleep(2)
    print("Navigating to RITM page...")
    taskurl = "https://ameriprise.service-now.com/sc_req_item.do?uri=&sysparm_query=number=" + str(RITM)
    driver.get(taskurl)
    try:
        Universal_SN_iframe = "gsft_main"
        #wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
        print("iframe found")
    except:
        print("iframe not found")
    
    #relatedrecordsclick = driver.find_element(By.XPATH, "//*[@id='tabs2_section']/span[3]/span/span[2]")
    #actions = ActionChains(driver)
    #actions.move_to_element(relatedrecordsclick)
    #actions.click(relatedrecordsclick)
    #actions.perform()
    time.sleep(2)
    print("Getting Task number from RITM...")
    try:
        wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")))
        print("wait for table success")
    except:
        print("wait for table timed out, sleeping 2 secs")
        try:
            print("attempting element get...")
            taskelement = driver.find_element_by_xpath("//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")
            print("element get SUCCESS")
        except:
            print("element get FAILED, sleeping 2 secs")
            time.sleep(2)
            try:
                print("attempting element get...")
                taskelement = driver.find_element_by_xpath("//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")
                print("element get SUCCESS")
            except:
                print("element get FAILED")

    try:
        taskelement = driver.find_element_by_xpath("//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")
    except:
        driver.get(taskurl)
        time.sleep(2)
        print("Getting Task number from RITM...")
        try:
            wait.until(EC.visibility_of_element_located((By.XPATH, "//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")))
            print("wait for table success")
        except:
            print("wait for table timed out, sleeping 2 secs")
            try:
                print("attempting element get...")
                taskelement = driver.find_element_by_xpath("//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")
                print("element get SUCCESS")
            except:
                print("element get FAILED, sleeping 2 secs")
                time.sleep(2)
                try:
                    print("attempting element get...")
                    taskelement = driver.find_element_by_xpath("//*[@id='sc_req_item.sc_task.request_item_table']/tbody/tr/td[3]/a")
                    print("element get SUCCESS")
                except:
                    print("element get FAILED")
    StrTask = taskelement.text
    print("TASK: " + str(StrTask))
    print("Navigating to Task created by request page...")
    ticketurl = "https://ameriprise.service-now.com/sc_task.do?uri=&sysparm_query=number=" + str(StrTask)
    driver.get(ticketurl)
    time.sleep(2)
        
    assignedtoElementID = "sys_display.sc_task.assigned_to"
    StateElementID = "sc_task.state"
    
    assignedtoElement = driver.find_element(By.ID, assignedtoElementID)
    print("Assigning ticket to User")
    actions = ActionChains(driver)
    actions.move_to_element(assignedtoElement).click(assignedtoElement).pause(1).perform()
    assignedtoElement.send_keys("brenton.wienkes@ampf.com")
    assignedtoElement.send_keys(Keys.TAB)
    time.sleep(1)

    print("Setting To work in progress")
    #set to work in progress
    select = Select(driver.find_element_by_id(StateElementID))
    select.select_by_value('2')
    print("Setting Priority to 4")
    #set to low priority
    select = Select(driver.find_element_by_id('sc_task.priority'))
    select.select_by_value('4')

    try:
        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    except:
        print("Iframe not found")
        
    try:
        element = driver.find_element(By.ID, 'sc_task.short_description')
        element.send_keys(Keys.CONTROL, 'a')
        element.send_keys(Keys.DELETE)
        element.send_keys(ShortDesc)
    except:
        print("Error occured changing the Short Desc of ticket")

    print("Saving Ticket")
    #SUBMIT CHANGES TO TICKET
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()

    print("Adding Notes")
    Element = driver.find_element_by_id("activity-stream-textarea")
    driver.execute_script("arguments[0].scrollIntoView();", Element)
    actions = ActionChains(driver)
    actions.move_to_element(Element).pause(.1).click(Element).pause(.1).send_keys('Removed From AD and Updated SN').pause(.1).send_keys(Keys.ENTER).pause(.1).perform()
    
    #actions = ActionChains(driver)
    #actions.send_keys("Removed From AD and Updated SN").pause(.1).send_keys(Keys.ENTER).pause(.1).perform()
    
    #SUBMIT CHANGES TO TICKET
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()

    time.sleep(.5)

    try:
        print("Setting to Pending User State")
        #set to Pending User Input
        wait.until(EC.visibility_of_element_located((By.ID, StateElementID)))
        select = Select(driver.find_element_by_id(StateElementID))
        select.select_by_value('-2')

        print("Saving Ticket")
        #SUBMIT CHANGES TO TICKET
        buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
        actions = ActionChains(driver)
        actions.move_to_element(buttonclick)
        actions.click(buttonclick)
        actions.perform()
        print("DONE!")
    except:
        print("Couldn't Set to Pending user info state")
    
driver.quit()
