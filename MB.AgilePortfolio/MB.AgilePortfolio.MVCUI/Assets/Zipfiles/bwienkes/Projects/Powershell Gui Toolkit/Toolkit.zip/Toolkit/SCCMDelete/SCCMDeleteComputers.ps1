﻿#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
################## Retire VDI ############################################################################################################################################


#site configuration
$SiteCode = "MSP"
$ProviderMachineName = "mspcsc12sccm01"

#customizations
$initParams = @{}
#$initParams.Add("Verbose", $true) #uncomment to enable verbose logging
#$initParams.Add("ErrorAction", "Stop") # uncomment to stop the script on any errors

# Do not change anything below this line
#import ConfigurationManager.psd1 module
if((Get-Module ConfigurationManager) -eq $null){import-module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams}

#connect to the site's drive if it is not already present
if((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null){New-PSDrive -name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams}

#set the current location to be the site code
set-Location "$($SiteCode):\" @initParams



$FolderFilePath = "C:\users\bwienk1\desktop\SCCMDelete"
$PCList = "$FolderFilePath\pc_list.txt"
$DeleteLogFileName = "$FolderFilePath/DeleteLog - $(((Get-Date).Month).tostring())-$(((Get-Date).Day).tostring())-$(((Get-Date).Year).tostring()).txt"

if(Test-Path "$PCList" -ErrorAction SilentlyContinue)
{
#pc_list exists
}
else
{
    while($PCList = $null)
    {
        $PCList = read-host "Enter full Filepath for PC list .txt file"
        if($PCList)
        {
            if($PCList.Trim())
            {
                $PCList = $PCList.Trim()
                if($PCList.Contains(".txt"))
                {
                    if(Test-path "$PCList" -ErrorAction SilentlyContinue)
                    {
                        break
                    }
                    else{write-host -ForegroundColor Yellow "Invalid Filepath" $PCList = $null}
                }
                else{write-host -ForegroundColor Yellow "Invalid FileType" $PCList = $null}
            }
            else{write-host -ForegroundColor Yellow "Invalid Filepath" $PCList = $null}
        }
        else{write-host -ForegroundColor Yellow "Invalid Filepath" $PCList = $null}
    }
}

if(Test-Path "$FolderFilePath" -ErrorAction SilentlyContinue)
{
#pc_list exists
}
else
{
    while($FolderFilePath = $null)
    {
        $FolderFilePath = read-host "Enter Folder path to save logfile to"
        if($FolderFilePath)
        {
            if($FolderFilePath.Trim())
            {
                $FolderFilePath = $FolderFilePath.Trim()
                if(Test-path "$FolderFilePath" -ErrorAction SilentlyContinue)
                {
                    break
                }
                else{write-host -ForegroundColor Yellow "Invalid Filepath" $FolderFilePath = $null}
            }
            else{write-host -ForegroundColor Yellow "Invalid Filepath" $FolderFilePath = $null}
        }
        else{write-host -ForegroundColor Yellow "Invalid Filepath" $FolderFilePath = $null}
    }
}


(gc $PCList) | ? {$_.trim() -ne "" } | set-content $PCList
    write-output "" | Out-File -FilePath "$($PCList)" -Encoding ascii -Append 
    $computers = Get-Content $PCList

$stringout = @()
$sccmpcs = @()
$stringout += " "
write-host -ForegroundColor Cyan "------- START Checking if computers are in AD ------------"
$stringout += "------- START Checking if computers are in AD ------------"
foreach($pc in $computers)
{
    if($pc)
    {
        if($pc.trim())
        {
            $pc = $pc.trim()
            write-host -ForegroundColor Cyan "Checking: " -NoNewline
            write-host "$pc" -NoNewline
            write-host -ForegroundColor Cyan "..." -NoNewline
            $iPC = $null
            $iPC = Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$pc'"
            if($iPC)
            {
                write-host "$($iPC.Name)" -nonewline
                write-host -ForegroundColor Yellow " was found in AD!"
                $stringout += "$($iPC.Name) was found in AD!"
                $stringout += "    PROMPT: Remove from SCCM anyways?(y/n)"
                $removestill = read-host "Remove from SCCM anyways?(y/n)"
                $stringout +=  "        USER INPUT: $removestill" 
                if($removestill -like "y")
                {
                    $stringout +=  "           INPUT translated to: Yes" 
                    write-host -ForegroundColor Cyan "Added " -NoNewline
                    write-host "$($IPC.name)" -NoNewline
                    write-host -ForegroundColor Cyan " to the list"
                    $cmdevice = $null
                    $cmdevice = (get-CMDevice -CollectionID "MSP010f6" -name $($pc))
                    if($cmdevice)
                    {
                        write-host "$($IPC.name)" -NoNewline
                        write-host -ForegroundColor Cyan " found in SCCM!"
                        $stringout +=  " $($IPC.name) found in SCCM!"
                        $sccmpcs += $cmdevice
                    }
                    else
                    {
                        write-host "$($IPC.name)" -NoNewline
                        write-host -ForegroundColor Yellow " NOT IN SCCM!"
                        $stringout +=  "[WARNING] $($IPC.name) NOT IN SCCM!"
                    }
                    
                }
                else
                {
                    write-host -ForegroundColor Cyan "Skipping " -NoNewline
                    write-host "$($IPC.name)"
                    $stringout +=  "           INPUT translated to: No" 
                }
            }
            else
            {
                $stringout += "$($pc) was NOT in AD"
                write-host -ForegroundColor Green "Not in AD"
                $cmdevice = $null
                 $cmdevice = (get-CMDevice -CollectionID "MSP010f6" -name $($pc))
                if($cmdevice)
                {
                    write-host "$($pc)" -NoNewline
                    write-host -ForegroundColor Cyan " found in SCCM!"
                    $stringout +=  " $($pc) found in SCCM!"
                    $sccmpcs += $cmdevice
                }
                else
                {
                    write-host "$($IPC.name)" -NoNewline
                    write-host -ForegroundColor Yellow " NOT IN SCCM!"
                    $stringout +=  "[WARNING] $($IPC.name) NOT IN SCCM!"
                }
            }
        }
    }
    $cmdevice = $null
}
write-host -ForegroundColor Cyan "------- END Checking if computers are in AD ------------"
$stringout += "------- END Checking if computers are in AD ------------"
$stringout += " "

#Set-Location -Path "C:\"
Write-Output "Date: $(get-date)"  | out-file -FilePath "$DeleteLogFileName" -Encoding ascii
Write-Output "Total Computers found in SCCM: $($sccmpcs.Count)"  | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
Write-Output " "  | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
for($i = 0; $i -lt $stringout.count;$i++)
{
Write-Output "$($stringout[$i])"  | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
}
$stringout = $null
Write-Host -ForegroundColor Cyan "`nTotal Computers found in SCCM: " -NoNewline
write-host "$($sccmpcs.Count)" 
Write-Output " "  | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
write-host -ForegroundColor Cyan "============================================================" 
Write-Output "============================================================" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
write-host -ForegroundColor Cyan "List of computers that will be Deleted:"
Write-Output "List of computers that will be Deleted:"| out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
write-host -ForegroundColor Cyan "------------------------------------"  
Write-Output "------------------------------------"  | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
foreach($p in $sccmpcs)
{
write-host $p.Name
write-output $p.Name | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
}
write-host -ForegroundColor Cyan "------------------------------------`n" 
write-output "------------------------------------`n" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append

write-output "    PROMPT: Are You sure you want to delete these computers?(Y/N)" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
$certainDelete = read-host "Are You sure you want to delete these computers?(Y/N)"
write-output "        USER INPUT: $certainDelete" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
if($certainDelete -like "y")
        {
            write-output  "           INPUT translated to: Yes" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
            write-host -ForegroundColor Cyan "`n---------------- START DELETE ----------------------" 
            write-output " " | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
            write-output "DELETE LOG" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
            write-output "--------------------------------------" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
            foreach($p in $sccmpcs)
            {
                $tempname = $null
                $tempname = $p.Name
                $p | Remove-CMDevice -Force
                write-output "        Deleting: $tempname" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
                write-host -ForegroundColor Cyan "Verifying " -NoNewline
                write-host "$tempname" -NoNewline
                write-host -ForegroundColor Cyan " deleted..." -NoNewline
                
                if(get-CMDevice -CollectionID "MSP010f6" -name $($tempname))
                {
                    write-output "[FAILED] Verify $tempname deleted" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
                    write-host -ForegroundColor red "FAILED TO DELETE!"
                }
                else
                {
                    write-output "[SUCCESS] Verify $tempname deleted" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
                   write-host -ForegroundColor green "SUCCESSFULLY DELETED!"
                }
            }
            write-host -ForegroundColor Cyan "---------------- END DELETE ----------------------`n" 
            write-output "--------------------------------------" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
        }
        else
        {
            write-output  "           INPUT translated to: No" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
        }

        write-host "=====================================================" 
        write-host "|                  END OF SCRIPT                     |" 
        write-host "=====================================================" 
        write-output "=====================================================" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
        write-output "|                  END OF SCRIPT                     |" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append
        write-output "=====================================================" | out-file -FilePath "$DeleteLogFileName" -Encoding ascii -Append

        read-host "Press enter to exit"
        exit
}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}





        <#
foreach($p in $sccmpcs)
{
$pcname = $null
$pcname = $p.Name
$iPC = Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$pcname'"
if($iPC)
{
Write-Output " " | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii
Write-Output "Computer: $($p.name)" | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii
write-output "----------------------------------------------------------" | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii
write-output "Last Active Time: $($p.LastActiveTime)" | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii
write-output "Last Policy Request: $($p.LastPolicyRequest)" | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii
write-output "Last Hardware Scan: $($p.LastHardwareScan)" | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii
write-output "Last Software Scan: $($p.LastSoftwareScan)" | out-file -FilePath "$DeleteLogFileName" -Append -Encoding ascii



if($p.Username)
{
$inuser = $Null
$inuser = $p.Username
$iUser = get-ADUser -Server AFII -SearchBase "OU=Users,OU=AAH,DC=i,DC=ameriprise,DC=com" -Properties * -filter "sAMAccountName -like '$inuser'"
if($iuser)
{
$User_name = $($iUser.GivenName) + " " + $($iUser.SurName)
}
else
{
$user_name = "NOT IN AD: $inuser"
}
}
else
{
$inuser = $null
$User_name = "NO USER"
}
write-output "User: $User_name" | out-file -FilePath "$FolderFilePath\SCCMDelete.txt" -Append -Encoding ascii
write-output "AD Description: $($iPC.Description)" | out-file -FilePath "$FolderFilePath\SCCMDelete.txt" -Append -Encoding ascii
write-output "----------------------------------------------------------" | out-file -FilePath "$FolderFilePath\SCCMDelete.txt" -Append -Encoding ascii
}
}
#>