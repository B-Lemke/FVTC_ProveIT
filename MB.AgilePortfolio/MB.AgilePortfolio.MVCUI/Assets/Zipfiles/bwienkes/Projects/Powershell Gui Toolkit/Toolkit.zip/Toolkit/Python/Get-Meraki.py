import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

scriptpath = os.path.dirname(os.path.realpath(__file__))


MerakiLoginEmail = str(sys.argv[1])
MerakiLoginPassword = str(sys.argv[2])
SN_Login_Username = str(sys.argv[3])
SN_Login_Password = str(sys.argv[4])
ComputerFullname = str(sys.argv[5])
UserID = str(sys.argv[6])
try:
    #Try Opening file
    file = codecs.open(sys.argv[7],"w", "utf-8")
except:
    #failed to open file
    file = codecs.open(sys.argv[7] + '(1).txt',"w", "utf-8")
file2 = open(sys.argv[8], "w")
file2.write('"NAME","HAS_MERAKI","MERAKI_IP_ADDRESS","MERAKI_SERIAL","USER_ADDRESS","USER_ASSIGNED","USER_DEPT","STATE","SECONDARY_STATE","ASSET_FUNCTION","USER_LOCATION","PC_MODEL"\n')
outName = ''
#MERAKI------
outHasMeraki = ''
outMerakiIP = ''
outMerakiSerial = ''
outUserAddress = ''
#MERAKI------
outUserAssigned = ''
outUserDept = ''
outState = ''
outSecondaryState = ''
outAssetFunction = ''
#TicketNumber = sys.argv[9]
TicketNumber = None
TicketNotes = []

InitialWebpage = "https://n164.meraki.com/AAH-Separation-G/n/M0r1JbKc/manage/organization/overview"

now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"
file.write("started Script at " + str(nowoutput) + '|')


Universal_SN_iframe = "gsft_main"
StockroomLocation = 'AAH Green Bay'

stateID = "alm_hardware.install_status"
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"
#<option value="BCP">BCP</option>
#<option value="Call Center">Call Center</option>
#<option value="Disaster Recovery">Disaster Recovery</option>
#<option value="Lab Device">Lab Device</option>
#<option value="Loaner">Loaner</option>
#<option value="Monitoring">Monitoring</option>
#<option value="Primary Device">Primary Device</option>
#<option value="Secondary Device">Secondary Device</option>
#<option value="Security">Security</option>
#<option value="Shared Device">Shared Device</option>
#<option value="Testing">Testing</option>
#<option value="Training">Training</option>
#<option value="Development">Development</option>
#<option value="Spare">Spare</option>
#<option value="Hot-Spare" selected="SELECTED">Hot-Spare</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"

userAssignedID = "sys_display.alm_hardware.assigned_to"
departmentid = "sys_user.department_label"
userlocationid = "sys_user.u_space_id"
DateAssignedID = "alm_hardware.assigned"

stringout = "ComputerFullname set to: " + ComputerFullname + '|'
file.write(stringout)
stringout = "UserID set to: " + UserID + '|'
file.write(stringout)
stringout = "TicketNumber set to: " + str(TicketNumber) + '|'
file.write(stringout)

if TicketNumber:
    if TicketNumber.startswith('INC'):
        stringout = str(TicketNumber) + " detected as: INC|"
        file.write(stringout)
        ticketurl = "https://ameriprise.service-now.com/incident.do?uri=&sysparm_query=number=" + TicketNumber
        stringout = "ticketurl set to: " + str(ticketurl) + '|'
        file.write(stringout)
    elif TicketNumber.startswith('TASK'):
        stringout = TicketNumber + " detected as: TASK|"
        file.write(stringout)
        ticketurl = "https://ameriprise.service-now.com/sc_task.do?uri=&sysparm_query=number=" + TicketNumber
        stringout = "ticketurl set to: " + ticketurl + '|'
        file.write(stringout)
    elif TicketNumber.startswith('ITASK'):
        stringout = TicketNumber + " detected as: ITASK|"
        file.write(stringout)
        ticketurl = "https://ameriprise.service-now.com/u_incident_task.do?uri=&sysparm_query=number=" + TicketNumber
        stringout = "ticketurl set to: " + ticketurl + '|'
        file.write(stringout)
    else:
        stringout = TicketNumber + " NOT SUPPORTED|"
        file.write(stringout)
        print("Ticket Type not supported (ONLY ITASK, TASK, and INC are supported at this time")
        TicketNumber = None


#   SETUP CHROME DRIVER
options = Options()
#Headless needs work yet.... not sure if possible due to popup menus having issues
options.headless = True
options.add_argument('log-level=3')
options.add_argument('--window-size=1920x1080')
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")
wait = WebDriverWait(driver, 10)

driver.get(InitialWebpage)      
if driver.title == "Login":
    #login
    userid = driver.find_element_by_id('userID')
    password = driver.find_element_by_id('password')
    btnLogin = driver.find_element_by_id("loginbtn")

    #SEND KEYS TO ELEMENTS IN LOGIN PAGE
    userid.send_keys(SN_Login_Username)
    password.send_keys(SN_Login_Password)
    btnLogin.click()
    if driver.title == "Password is about expire":
        Element = driver.find_element_by_id("proceedWebsite")
        actions = ActionChains(driver)
        actions.move_to_element(Element)
        actions.click(Element)
        actions.perform()
        Element = driver.find_element_by_id("passwordToExpire")
        Element.click()
        
loginid = driver.find_element_by_id('email')
passwordid = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id('commit')

loginid.send_keys(MerakiLoginEmail)
passwordid.send_keys(MerakiLoginPassword)
btnLogin.click()
erroroccured = False
if driver.title == 'Organization overview - Meraki Dashboard':
    file.write('Found Organization Overview page|')
    file.write("Waiting for presence of element //*[@id='search_holder']/input...")
    wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='search_holder']/input")))
    file.write("Done|")
    file.write("Getting Element //*[@id='search_holder']/input...")
    searchid = driver.find_element_by_xpath("//*[@id='search_holder']/input")
    file.write("Done|")
    file.write("Sending input: " + str(UserID) + "to Element //*[@id='search_holder']/input...")
    searchid.send_keys(UserID)
    file.write("Done|")

    #implict table load wait
    time.sleep(1)

    #try no meraki devices found, except if found
    try:
        file.write('-------- START Checking if no meraki device ---------|')
        file.write("Getting element //*[@id='network_table']/div...")
        searchtable_element = driver.find_element_by_xpath("//*[@id='network_table']/div")
        file.write("Done|")
        file.write("Getting attribute 'class' from element //*[@id='network_table']/div...")
        table_class = searchtable_element.get_attribute("class")
        file.write("Done|")
        print('table Class: ' + str(table_class))
        if table_class == "no_items_html":
            file.write('No meraki device Found|')
            #no meraki device found
            #MERAKI------
            outHasMeraki = 'FALSE'
            outMerakiIP = ''
            outMerakiSerial = ''
            outUserAddress = ''
            #MERAKI------
            print('No Meraki Devices')
        else:
            file.write('Unexpected condition from website, search didnt return no results, yet found dynamic element created when search returns no results|')
            file.write("DEBUG: Found searchtable_element and table_class... and table_class != no_items_html|")
            #unforseen website change that didn't result in search bringing back no results
            print("Unexpected condition from website, search didn't return no results, yet found dynamic element created when search returns no results")
            print("DEBUG: Found searchtable_element and table_class... and table_class != no_items_html")
            #MERAKI------
            outHasMeraki = 'Unknown'
            outMerakiIP = ''
            outMerakiSerial = ''
            outUserAddress = ''
            #MERAKI------
    except:
        file.write('Meraki Found|')
        #Meraki Device found
        #MERAKI------
        outHasMeraki = 'TRUE'
        outMerakiIP = ''
        outMerakiSerial = ''
        outUserAddress = ''
        #MERAKI------
        unreachableMeraki = False
        
        file.write("Meraki reachable check|")
        try:
            file.write("Getting element //*[@id='row_0']/td[3]...")
            firstoption = driver.find_element_by_xpath("//*[@id='row_0']/td[3]")
            file.write("Done|")
            time.sleep(1)
            file.write("Clicking element //*[@id='row_0']/td[3]...")
            firstoption.click()
            file.write("Done|")
            time.sleep(1)
            try:
                file.write("Waiting for Title to contain 'Security Appliances - Meraki Dashboard'...")
                wait.until(EC.title_contains('Security Appliances - Meraki Dashboard'))
                file.write("Done|")
            except:
                file.write("ERROR OCCURED WAITING FOR Security Applicances PAGE TO LOAD|")
                try:
                    file.write("Waiting for Title to contain 'Clients - Meraki Dashboard'...")
                    wait.until(EC.title_contains('Clients - Meraki Dashboard'))
                    element = driver.find_element_by_xpath("//*[@id='tab_menu_react']/ul/li[2]/div/a/span")
                    actions = ActionChains(driver)
                    actions.move_to_element(element)
                    actions.perform()
                    time.sleep(1)
                    element = driver.find_element_by_xpath("//*[@id='tab_menu_react']/ul/li[2]/div[2]/ul[1]/li[1]/a/span")
                    actions = ActionChains(driver)
                    actions.move_to_element(element)
                    actions.click(element)
                    actions.perform()
                    try:
                        file.write("Waiting for Title to contain 'Security Appliances - Meraki Dashboard'...")
                        wait.until(EC.title_contains('Security Appliances - Meraki Dashboard'))
                        file.write("Done|")
                    except:
                        file.write("ERROR OCCURED WAITING FOR Security Applicances PAGE TO LOAD|")
                    #file.write("Unreachable Meraki!|")
                    #outMerakiIP = "Meraki Unreachable"
                    #outMerakiSerial = "Meraki Unreachable"
                    #outUserAddress = "Meraki Unreachable"
                    #outHasMeraki = "Currently Unreachable"
                    unreachableMeraki = False
                except:
                    file.write("ERROR OCCURED WAITING FOR Clients - Meraki Dashboard PAGE TO LOAD |")
                    unreachableMeraki = True
        except:
            file.write("ERROR OCCURED TRYING TO SELECT, AND CLICK, FIRST OPTION FROM TABLE|")
            unreachableMeraki = True
            
        try:
            if unreachableMeraki == False:
                wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='NodesListAndDetails']/div/section/section[1]/section/section[1]/ul/li/div/span")))
                alert = driver.find_element_by_xpath("//*[@id='NodesListAndDetails']/div/section/section[1]/section/section[1]/ul/li/div/span")
                if "Unreachable" in alert.text:
                    #meraki is unreachable currently
                    AlertOut = alert.text
                    outHasMeraki = "Unknown"
                    outMerakiSerial = str(AlertOut)
                    outUserAddress = str(AlertOut)
                    outMerakiIP = str(AlertOut)
                    file.write("Meraki Unreachable, ALERT FOUND: " + str(AlertOut) + "|")
                    unreachableMeraki = True
                else:
                    #Meraki can be reached
                    file.write("Meraki reachable|")
                    unreachableMeraki = False
        except:
            #no alert element found
            unreachableMeraki = False
            file.write("No Alert found|")
            
        file.write('-------- END Checking if no meraki device ---------| |')
        
        
        try:
            file.write('-------- START Getting Info from Meraki ---------|')
            file.write("Getting Address element...")
            address_element = driver.find_element_by_xpath("//*[@id='NodesListAndDetails']/div/section/section[1]/section/div[2]/dl/dd/span")
            file.write("Done|")
            file.write("Getting Address text...")
            address = address_element.text
            file.write("Done|")
            file.write("Setting outUserAddress...")
            outUserAddress = str(address)
            file.write("Done|")
        except:
            outUserAddress = "Error Occured"
                
            
        try:
            #print(str(address))
            file.write("Getting Meraki Serial Element...")
            wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='NodesListAndDetails']/div/section/section[1]/section/dl[1]/dd/span")))
            file.write("Done|")
            file.write("Meraki Serial Element Visible...")
            meraki_serial_element = driver.find_element_by_xpath("//*[@id='NodesListAndDetails']/div/section/section[1]/section/dl[1]/dd/span")
            file.write("Done|")
            file.write("Getting Meraki Serial Text...")
            meraki_serial = meraki_serial_element.text
            file.write("Done|")
            file.write("Setting outMerakiSerail to " + str(meraki_serial) + "|")
            outMerakiSerial = str(meraki_serial)
            #print(str(meraki_serial))
        except:
            outMerakiSerial = "Error Occured"

        try:
            file.write("Getting //*[@id='NodesListAndDetails']/div/section/section[2]/nav/div/a[3]...")
            element = driver.find_element_by_xpath("//*[@id='NodesListAndDetails']/div/section/section[2]/nav/div/a[3]")
            file.write("Done|")
            file.write("Clicking //*[@id='NodesListAndDetails']/div/section/section[2]/nav/div/a[3]...")
            element.click()
            file.write("Done|")
        except:
            erroroccured = True

        if erroroccured == False:
            try:
                #Implict Wait to load table
                time.sleep(1)
                file.write("Waiting for presense of //*[@id='NodesListAndDetails']/div/section/section[2]/section/div/section/section[2]/div/div/table/tbody...")
                wait.until(EC.presence_of_element_located((By.XPATH, "//*[@id='NodesListAndDetails']/div/section/section[2]/section/div/section/section[2]/div/div/table/tbody")))
                file.write("Done|")
                file.write("Getting element //*[@id='NodesListAndDetails']/div/section/section[2]/section/div/section/section[2]/div/div/table/tbody...")
                table = driver.find_element_by_xpath("//*[@id='NodesListAndDetails']/div/section/section[2]/section/div/section/section[2]/div/div/table/tbody")
                file.write("Done|")
                file.write("Getting elements by tag name 'tr' in element //*[@id='NodesListAndDetails']/div/section/section[2]/section/div/section/section[2]/div/div/table/tbody...")
                items = table.find_elements_by_tag_name("tr")
                file.write("Done|")
                file.write("ComputerFullname = " + str(ComputerFullname) + "|" )
                for idx, item in enumerate(items):
                    try:
                        atag = driver.find_element_by_xpath("//*[@id='NodesListAndDetails']/div/section/section[2]/section/div/section/section[2]/div/div/table/tbody/tr[" + str(idx + 1) + "]//a")
                        text = atag.text
                        file.write("Index = " + str(idx + 1) + " TEXT = " + str(text) + "|" )
                    except:
                        file.write("Index = EXCEPTION PASS TEXT = EXCEPTION PASS|")
                        pass
                    
                    file.write("text = " + str(text) + "|" )
                    if ComputerFullname == text:
                        file.write("ComputerFullName == text!|" )
                        row = item
                        file.write("Getting IP Element...")
                        IP_element = row.find_elements_by_tag_name("td")
                        ip = IP_element[2]
                        file.write("Done|" )
                        IP_Address = ip.text
                        print(IP_Address)
                        outMerakiIP = str(IP_Address)
                        file.write("IP ADDRESS FOUND: " + str(IP_Address) + '|')
                    else:
                        #clear file
                        clear = open(sys.argv[7], 'r+')
                        clear.truncate(0) #r+ requires 0
            except:
                outMerakiIP = "Couldn't Get From Meraki"
                
        file.write('-------- END Getting Info from Meraki ---------| |')
file.write('-------- START Getting Service-Now Info ---------|')
outUserDept = ''
outUserAssigned = ''
outUserLocation = ''
outState = ''
outModel = ''
outSecondaryState = ''
outAssetFunction = ''
outUserReserved = ''
isVDI_Old_PC = False
if "WILG000" in ComputerFullname: pc = ComputerFullname.replace("WILG000","")
elif "WILG00" in ComputerFullname: pc = ComputerFullname.replace("WILG00","")
elif "WIDG000" in ComputerFullname: pc = ComputerFullname.replace("WIDG000","")
elif "WIDG00" in ComputerFullname: pc = ComputerFullname.replace("WIDG00","")
elif "AZLG000" in ComputerFullname: pc = ComputerFullname.replace("AZLG000","")
elif "AZLG00" in ComputerFullname: pc = ComputerFullname.replace("AZLG00","")
elif "AZDG000" in ComputerFullname: pc = ComputerFullname.replace("AZDG000","")
elif "AZDG00" in ComputerFullname: pc = ComputerFullname.replace("AZDG00","")
elif "NVLG000" in ComputerFullname: pc = ComputerFullname.replace("NVLG000","")
elif "NVLG00" in ComputerFullname: pc = ComputerFullname.replace("NVLG00","")
elif "NVDG000" in ComputerFullname: pc = ComputerFullname.replace("NVDG000","")
elif "NVDG00" in ComputerFullname: pc = ComputerFullname.replace("NVDG00","")
elif "MILG000" in ComputerFullname: pc = ComputerFullname.replace("MILG000","")
elif "MILG00" in ComputerFullname: pc = ComputerFullname.replace("MILG00","")
elif "MIDG000" in ComputerFullname: pc = ComputerFullname.replace("MIDG000","")
elif "MNDG00" in ComputerFullname: pc = ComputerFullname.replace("MNDG00","")
elif "MNLG000" in ComputerFullname: pc = ComputerFullname.replace("MNLG000","")
elif "MNLG00" in ComputerFullname: pc = ComputerFullname.replace("MNLG00","")
elif "MNDG000" in ComputerFullname: pc = ComputerFullname.replace("MNDG000","")
elif "MNDG00" in ComputerFullname: pc = ComputerFullname.replace("MNDG00","")
elif "WITGM" in ComputerFullname: pc = ComputerFullname.replace("WITG","")
elif "WIVGP" in ComputerFullname:
    #PC is VDI (different functions required)
    pc = ComputerFullname
    isVDI_Old_PC = True
else:
    #Can't Format to Serial number from full name
    print("NO SERIAL NUMBER COULD BE FOUND FOR: " + ComputerFullname)
    print("Exiting script")
    file2.write('"' + str(outName) +'","' + str(outHasMeraki) + '","' + str(outMerakiIP) + '","' + str(outMerakiSerial) + '","' + str(outUserAddress) + '","' + str(outUserAssigned) + '","' + str(outUserDept) + '","' + str(outState) + '","' + str(outSecondaryState) + '","' + str(outAssetFunction) + '","' + str(outUserLocation)  + '","' + str(outModel) + '"')
    file2.close()
    file.close()
    driver.quit()
    exit()


OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + pc
driver.get(OldPCWebpage)
if driver.title == "Login":
    #login
    userid = driver.find_element_by_id('userID')
    password = driver.find_element_by_id('password')
    btnLogin = driver.find_element_by_id("loginbtn")

    #SEND KEYS TO ELEMENTS IN LOGIN PAGE
    userid.send_keys(SN_Login_Username)
    password.send_keys(SN_Login_Password)
    btnLogin.click()
    if driver.title == "Password is about expire":
        Element = driver.find_element_by_id("proceedWebsite")
        actions = ActionChains(driver)
        actions.move_to_element(Element)
        actions.click(Element)
        actions.perform()
        Element = driver.find_element_by_id("passwordToExpire")
        Element.click()

wait = WebDriverWait(driver, 15)
try:
    file.write("Waiting for visibility of iFrame...")
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    file.write("Done|")
    
except:
    file.write("Iframe Visibility timed out|")

wait = WebDriverWait(driver, 10)

try:
    file.write("Switching to iFrame...")
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    file.write("Done|")
except:
    file.write("Couldn't switch to Iframe!|")

isAssigned = False

try:
    file.write("Getting PC Model Element...")
    Element = driver.find_element_by_id('alm_hardware.model_label')
    file.write("Done|")
    file.write("Getting PC Model 'value' attribute...")
    outModel = Element.get_attribute("value")
    file.write("Done|")
except:
    outModel = "NO MODEL FOUND"
    

try:
    file.write("Getting User Assigned Element...")
    Element = driver.find_element_by_id(userAssignedID)
    file.write("Done|")
    file.write("Getting User Assigned Element 'value' attribute...")
    outUserAssigned = Element.get_attribute("value")
    file.write("Done|")
    #time.sleep(.5)
    #print("User Assigned to Old PC was: " + OldUserAssigned)
    #print(" ")
    if not outUserAssigned:
        #Empty string check for assigned
        outUserAssigned = "NO ASSIGNED USER FOUND"
        isAssigned = False
        file.write("User assigned is an empty string!|")
    else:
        #assigned
        isAssigned = True
        file.write("User assigned is NOT an empty string|")
        file.write("Users assigned value: " + str(outUserAssigned) + "|")
except:
    #no user assigned
    outUserAssigned = "NO ASSIGNED USER FOUND"
    outUserDept = "NO DEPARTMENT FOUND"
    isAssigned = False
    file.write("NO USER ASSIGNED|")

try:
    file.write("Getting ASSET STATE element...")
    Element = driver.find_element_by_id(stateID)
    file.write("Done|")
    #Element.click()
    #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
    file.write("Selecting ASSET STATE element...")
    select = Select(driver.find_element_by_id(stateID))
    file.write("Done|")
    file.write("Selecting ASSET STATE element first option...")
    selected_option = select.first_selected_option
    file.write("Done|")
    outState = selected_option.text
    file.write("ASSET STATE = " + str(outState) + "|")
    try:
        file.write("Waiting for Visibility of ASSET SUBSTATE element...")
        wait.until(EC.visibility_of_element_located((By.ID,SecondaryStateID)))
        file.write("Done|")
        file.write("Getting ASSET SUBSTATE element...")
        Element = driver.find_element_by_id(SecondaryStateID)
        file.write("Done|")
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        file.write("Selecting ASSET SUBSTATE element...")
        select = Select(driver.find_element_by_id(SecondaryStateID))
        file.write("Done|")
        file.write("Selecting ASSET SUBSTATE element first option...")
        selected_option = select.first_selected_option
        file.write("Done|")
        file.write("Setting outSecondaryState based on selected option text...")
        outSecondaryState = selected_option.text
        file.write("Done|")
        file.write("|ASSET SUBSTATE = " + str(outSecondaryState)+ "|")
        if outSecondaryState == 'Reserved':
            #Look for Reserved element
            try:
                file.write("Getting Reserved for Element...")
                Element = driver.find_element_by_id('sys_display.alm_hardware.reserved_for')
                file.write("Done|")
                file.write("Getting Reserved for Element 'value' attribute...")
                outUserReserved = Element.get_attribute("value")
                file.write("Done|")
                if not outUserReserved:
                    #PC has no user reserved for
                    outUserReserved = "NO USER RESERVED FOR"
                else:
                    try:
                        file.write("------- START Getting User Reserved for pc -----------|")
                        file.write("Getting Reserved for Element...")
                        viewuserinfo_element = driver.find_element_by_id("viewr.alm_hardware.reserved_for")
                        file.write("Done|")
                        file.write("Running action chaine for Reserved for Element...")
                        actions = ActionChains(driver)
                        actions.reset_actions()
                        actions.move_to_element(viewuserinfo_element)
                        actions.click(viewuserinfo_element)
                        actions.perform()
                        file.write("Done|")
                        file.write("User Reserved = " + str(outUserReserved) + "|")
                        try:
                            time.sleep(1)
                            file.write("Getting User Space Element...")
                            element = driver.find_element_by_id("sys_user.u_space_id")
                            file.write("location found|")
                            file.write("Getting User Space Element 'value' attribute...")
                            atr = element.get_attribute("value")
                            file.write("Done|")
                            print("Location from user reseverd record: " + str(atr))
                            if atr:
                                outUserLocation = str(atr)
                                stringout = "Setting location to: " + outUserLocation + "|"
                                file.write(stringout)
                            else:
                                outUserLocation = 'NO LOCATION IN RECORD'
                                stringout = "Setting location to: ''|"
                                file.write(stringout)
                        except:
                            outUserLocation = 'NO LOCATION FOUND'
                            
                    except:
                        #No User assigned
                        file.write("Setting user and DEPT to Unassigned (No reseverd users)|")
                        outUserReserved = "NO USER ASSIGNED"
                        outUserDept = "NO DEPARTMENT"

                    file.write("------- END Getting User Reserved for pc -----------| |")
                    if not outUserReserved == "NO USER RESERVED FOR":
                        try:
                            file.write("Waiting for visibility of Department Element...")
                            wait.until(EC.visibility_of_element_located((By.ID, departmentid)))
                            file.write("Done|")
                            file.write("Getting Department Element...")
                            Element = driver.find_element_by_id(departmentid)
                            file.write("Done|")
                            file.write("Getting Department Element 'value' attribute...")
                            outUserDept = Element.get_attribute("value")
                            file.write("Done|")
                            file.write("Department ID =  " + str(outUserDept) + "|")
                        except:
                            #no assigned dept element
                            file.write("No Assigned DEPT Element FOUND|")
                            outUserDept = "NO DEPT FOUND"
                            try:
                                norecord_element = driver.find_element_by_xpath("//*[@id='sys_user.do']/span")
                                file.write("No User Reserved Record Element FOUND|")
                                outUserDept = "NO USER RECORD!"
                            except:
                                file.write("User Reserved Record FOUND but no DEPT|")
                                outUserDept = "NO DEPARTMENT"
            except:
                file.write("No Reserved user element found|")
                outUserReserved = None
    except:
        #No PC SubState found
        outSecondaryState = "STATE NOT FOUND"
        file.write("ASSET SUBSTATE NOT FOUND|")
except:
    #No PC State found
    outState = "STATE NOT FOUND"
    outSecondaryState = "SUBSTATE NOT FOUND"
    file.write("ASSET STATE NOT FOUND|")


try:
    file.write("Getting Asset Function...")
    Element = driver.find_element_by_id(AssetFunctionID)
    file.write("Done|")
    #Element.click()
    #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
    file.write("Selecting Asset Function...")
    select = Select(driver.find_element_by_id(AssetFunctionID))
    file.write("Done|")
    file.write("Selecting Asset Function first selected option...")
    selected_option = select.first_selected_option
    file.write("Done|")
    file.write("Getting Asset Function first selected option text...")
    outAssetFunction = selected_option.text
    file.write("Done|")
    file.write("ASSET FUNCTION = " + str(outAssetFunction) + "|")
except:
    #No PC Asset Function found
    outAssetFunction = "ASSET FUNCTION NOT FOUND"
    file.write("Asset Function not found|")
if isAssigned == True:
    try:
        file.write("Getting User assigned to pc....")
        viewuserinfo_element = driver.find_element_by_id("viewr.alm_hardware.assigned_to")
        file.write("Done|")
        file.write("Running Action Chain for User Assigned Element...")
        actions = ActionChains(driver)
        actions.reset_actions()
        actions.move_to_element(viewuserinfo_element)
        actions.click(viewuserinfo_element)
        actions.perform()
        file.write("Done|")
        #time.sleep(.5)
        #wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
        try:
            time.sleep(.5)
            file.write("Getting User Space Element...")
            element = driver.find_element_by_id("sys_user.u_space_id")
            file.write("Done|")
            file.write("Running Action chain for User Space Element...")
            actions = ActionChains(driver)
            actions.reset_actions()
            actions.move_to_element(element)
            actions.perform()
            file.write("Done|")
            file.write("Getting User Space Element value attribute...")
            atr = element.get_attribute("value")
            file.write("Done|")
            print("Location from user Assigned record: " + str(atr))
            if atr:
                outUserLocation = str(atr)
                stringout = "Setting location to: " + outUserLocation + "|"
                file.write(stringout)
            else:
                outUserLocation = 'NO LOCATION FOUND'
                stringout = "Setting location to: ''|"
                file.write(stringout)
        except:
            outUserLocation = 'NO LOCATION FOUND'
            file.write('NO LOCATION FOUND|')
        file.write("Getting User Assigned Element...")
        Element = driver.find_element_by_id(userAssignedID)
        file.write("Done|")
        file.write("Getting User Assigned Element value attribute...")
        outUserAssigned = Element.get_attribute("value")
        file.write("Done|")
        file.write("User Assigned = " + str(outUserAssigned) + "|")
    except:
        #No User assigned
        file.write("Setting user and DEPT to Unassigned...")
        outUserAssigned = "NO USER ASSIGNED"
        outUserDept = "NO DEPARTMENT"
        file.write("Done|")
    if not outUserAssigned == "NO USER ASSIGNED":
        try:
            file.write("Waiting for visibility of Department ID element...")
            wait.until(EC.visibility_of_element_located((By.ID, departmentid)))
            file.write("Done|")
            file.write("Getting Department ID...")
            Element = driver.find_element_by_id(departmentid)
            file.write("Done|")
            file.write("Getting Department ID value attribute...")
            outUserDept = Element.get_attribute("value")
            file.write("Done|")
            file.write("Department ID =  " + str(outUserDept) + "|")
        except:
            #no assigned dept element
            file.write("No Assigned DEPT Element FOUND|")
            outUserDept = "NO DEPT FOUND"
            try:
                norecord_element = driver.find_element_by_xpath("//*[@id='sys_user.do']/span")
                file.write("No Record Element FOUND|")
                outUserDept = "NO USER RECORD!"
            except:
                file.write("User Record FOUND but no DEPT|")
                outUserDept = "NO DEPARTMENT"
else:
    file.write("User = Not Assigned|")
    if not outUserDept:
        #default user dept
        file.write("No User Dept|")
        outUserDept = "NO USER ASSIGNED"

if outUserAssigned == "NO ASSIGNED USER FOUND" or outUserAssigned == "NO USER ASSIGNED":
    #Try Reserved
    file.write(" User = NO ASSIGNED USER FOUND OR NO USER ASSIGNED...")
    if outUserReserved:
        file.write(" SETTING outUserReserved...")
        outUserAssigned = outUserReserved
        file.write("Done|")
    else:
        file.write(" SETTING outUserAssigned to NO USER ASSIGNED OR RESERVED...")
        outUserAssigned = "NO USER ASSIGNED OR RESERVED"
        outUserDept = "NO USER ASSIGNED OR RESERVED"
        file.write("Done|")
if not outUserLocation:
    outUserLocation = "NO LOCATION FOUND"
file.write('-------- END Getting Service-Now Info ---------| |')
    
file2.write('"' + str(outName) +'","' + str(outHasMeraki) + '","' + str(outMerakiIP) + '","' + str(outMerakiSerial) + '","' + str(outUserAddress) + '","' + str(outUserAssigned) + '","' + str(outUserDept) + '","' + str(outState) + '","' + str(outSecondaryState) + '","' + str(outAssetFunction) + '","' + str(outUserLocation)  + '","' + str(outModel) + '"' )
file2.close()
file.close()
driver.quit()
exit()
