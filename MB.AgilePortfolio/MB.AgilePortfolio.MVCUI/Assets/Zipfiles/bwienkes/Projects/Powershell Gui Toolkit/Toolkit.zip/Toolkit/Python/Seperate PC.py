import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException

#scriptpath = 'C:/Users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver'
scriptpath = os.path.dirname(os.path.realpath(__file__))

OldComputerFullname = ["PF1260JU"]

LoginUsername = sys.argv[1]
LoginUserPassword = sys.argv[2]

StockroomLocation = sys.argv[3]


now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"

#   SETUP CHROME DRIVER
options = Options()
options.add_argument("--disable-logging")
options.add_argument('log-level=3')
options.headless = True
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
#driver = webdriver.Chrome(options=options, executable_path= scriptpath)
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")

wait = WebDriverWait(driver, 5)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

Universal_SN_iframe = "gsft_main"

OldPCiframe = Universal_SN_iframe

stateID = "alm_hardware.install_status"
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"
#<option value="BCP">BCP</option>
#<option value="Call Center">Call Center</option>
#<option value="Disaster Recovery">Disaster Recovery</option>
#<option value="Lab Device">Lab Device</option>
#<option value="Loaner">Loaner</option>
#<option value="Monitoring">Monitoring</option>
#<option value="Primary Device">Primary Device</option>
#<option value="Secondary Device">Secondary Device</option>
#<option value="Security">Security</option>
#<option value="Shared Device">Shared Device</option>
#<option value="Testing">Testing</option>
#<option value="Training">Training</option>
#<option value="Development">Development</option>
#<option value="Spare">Spare</option>
#<option value="Hot-Spare" selected="SELECTED">Hot-Spare</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"

userAssignedID = "sys_display.alm_hardware.assigned_to"
departmentid = "sys_user.department_label"

DateAssignedID = "alm_hardware.assigned"

RequestMembershipPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5e6e207b4f8c0780c8e7e57d0210c75a%26sysparm_link_parent%3Dc3d3e02b0a0a0b12005063c7b2fa4f93%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default"
memberUserID = "sys_display.IO:3cd7f12a903da80087a863f119b63795"
memberModGroupID = "IO:cc7033214fd84f806f4d3e1ca310c75c"
memberTargetGroupID = "IO:94390d824fdc03006f4d3e1ca310c72f"
memberActionID = "IO:1f34c9844fecdb406f4d3e1ca310c7f7"
memberMembershipID = "sys_display.IO:42e078f74f8c0780c8e7e57d0210c77b"
memberPCtbxID = "computer_list_cmdb_ci_computer"
membership_PC_List_Hidden_ID = "cmdb_ci_computer.computer_list"
#memberPCHiddenListID
memberShowAvailablePCEvent = "\"return checkEnter(event, 'cmdb_ci_computer.computer_list')\""
membership_Element_PC_List_select_ID = "computer_list_select_0"
#memberPClistID = "computer_list_select_0"
memberReasonID = "IO:96695c1d311df0404c72ad13d18ba9f0"
memberSubmitBtnCode = "\"if ($$('.order_buttons .disabled_order_button').length == 0) { orderNow(); } else { alert('Please wait - price being updated'); };\""



PCState = None
PCSubState = None
PCAssetFunction = None
viewuserinfo_element = None
outputary = []
#pcary = []
#expectedwindows = 2
print(" ________________________________________________")
print("|        Getting PC Info from Service-now        |")
print("|________________________________________________|")
print(" ")

for pc in OldComputerFullname:
    #Find Old PC Serial
    
    PC = pc
    filename = sys.argv[4] + "/" + PC + ".txt"
    file = codecs.open(filename,"w","utf-8")
    if "WILG000" in PC: pc = PC.replace("WILG000","")
    elif "WILG00" in PC: pc = PC.replace("WILG00","")
    elif "WIDG000" in PC: pc = PC.replace("WIDG000","")
    elif "WIDG00" in PC: pc = PC.replace("WIDG00","")
    elif "AZLG000" in PC: pc = PC.replace("AZLG000","")
    elif "AZLG00" in PC: pc = PC.replace("AZLG00","")
    elif "AZDG000" in PC: pc = PC.replace("AZDG000","")
    elif "AZDG00" in PC: pc = PC.replace("AZDG00","")
    elif "NVLG000" in PC: pc = PC.replace("NVLG000","")
    elif "NVLG00" in PC: pc = PC.replace("NVLG00","")
    elif "NVDG000" in PC: pc = PC.replace("NVDG000","")
    elif "NVDG00" in PC: pc = PC.replace("NVDG00","")
    elif "MILG000" in PC: pc = PC.replace("MILG000","")
    elif "MILG00" in PC: pc = PC.replace("MILG00","")
    elif "MIDG000" in PC: pc = PC.replace("MIDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "MNLG000" in PC: pc = PC.replace("MNLG000","")
    elif "MNLG00" in PC: pc = PC.replace("MNLG00","")
    elif "MNDG000" in PC: pc = PC.replace("MNDG000","")
    elif "MNDG00" in PC: pc = PC.replace("MNDG00","")
    elif "WIVGP" in PC:
        #PC is VDI (different functions required)
        pc = PC
        isVDI_Old_PC = True
    else:
        pc = PC
    
    PCState = None
    PCSubState = None
    PCAssetFunction = None
    viewuserinfo_element = None
    OldUserAssigned = None
    file.write("------- START PYTHON SCRIPT ---------| |")
    file.write ("Computer: " + str(PC) + "|")
    file.write ("Started: " + str(nowoutput) + "| |")
    print("Getting values for " + pc + "...")
    pcary = None
    OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + pc
    #windows_before  = driver.current_window_handle
    #driver.execute_script("window.open('" + OldPCWebpage + "')")
    #WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    #windows_after = driver.window_handles
    #driver.switch_to.window(windows_after[expectedwindows - 1])
    #expectedwindows = expectedwindows + 1
    driver.get(OldPCWebpage)

    if driver.title == "Login":
        file.write("Redirected to Login Page|")
        file.write("|    ------- START LOGIN PAGE ---------|")
        
               
        print("Logging in As User...")

        #USER INPUT TEXTBOX ELEMENT SETUP
        file.write("    Getting UserID element...")
        try:
            wait.until(EC.visibility_of_element_located((By.ID, 'userID')))
            userid = driver.find_element_by_id('userID')
        except NoSuchElementException:
            file.write("FAILED: COULDNT FIND ELEMENT!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        except TimeoutException:
            file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        except:
            file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("SUCCESS|")
    
        #PASSWORD INPUT TEXTBOX ELEMENT SETUP
        file.write("    Getting password element...")
        try:
            wait.until(EC.visibility_of_element_located((By.ID, 'password')))
            password = driver.find_element_by_id('password')
        except NoSuchElementException:
            file.write("FAILED: COULDNT FIND ELEMENT!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        except TimeoutException:
            file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        except:
            file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("SUCCESS|")

        #LOGIN BUTTON ELEMENT SETUP
        file.write("    Getting Login Button element...")
        try:
            wait.until(EC.visibility_of_element_located((By.ID, 'loginbtn')))
            btnLogin = driver.find_element_by_id("loginbtn")
        except NoSuchElementException:
            file.write("FAILED: COULDNT FIND ELEMENT!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        except TimeoutException:
            file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        except:
            file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("SUCCESS|")
    
        #SEND KEYS USER ELEMENT
        file.write("    Entering Username...")
        try:
            userid.send_keys(LoginUsername)
        except:
            file.write("FAILED: ERROR OCCURED DURING Username ENTRY|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("SUCCESS|")
    
        #SEND KEYS PASSWORD ELEMENT
        file.write("    Entering Password...")
        try:
            password.send_keys(LoginUserPassword)
        except:
            file.write("FAILED: ERROR OCCURED DURING password ENTRY|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("SUCCESS|")

        #CLICK LOGIN BUTTON ELEMENT
        file.write("    Clicking Login Button...")
        try:
            btnLogin.click()
        except:
            file.write("FAILED: ERROR OCCURED DURING Login button CLICK|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("SUCCESS|")
        file.write("    ------- END LOGIN PAGE ---------| |")
    
        #   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
        if driver.title == "Password is about expire":
            file.write("Redirected to Password is about to expire Page| |")
            file.write("    ------- START PASSWORD EXPIRED PAGE ---------|")
            file.write("     Selecting Proceed to website radio button element...")
            try:
                
                Element = driver.find_element_by_id("proceedWebsite")
                file.write("SUCCESS|")
            except:
                file.write("FAILED|")
                file.close()
                driver.exit()
                exit()
            try:
                file.write("     Moving to Element and Clicking...")
                actions = ActionChains(driver)
                actions.move_to_element(Element)
                actions.click(Element)
                actions.perform()
            except:
                file.write("FAILED|")
                file.close()
                driver.exit()
                exit()
            try:
                file.write("     Clicking Submit button...")
                Element = driver.find_element_by_id("passwordToExpire")
                Element.click()
                file.write("    ------- END PASSWORD EXPIRED PAGE ---------| |")
            except:
                file.write("FAILED|")
                file.close()
                driver.exit()
                exit()
    print("Logged in Successfully")
    print(" ")
    print("Starting SN Update for: " + str(PC))
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    
    file.write("    -------  START SERVICE NOW RECORD UPDATE ---------|")
    try:
        file.write("     Setting Asset State to: 6 (In Stock)...")
        Element = driver.find_element_by_id(stateID)
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        select = Select(driver.find_element_by_id(stateID))
        select.select_by_value('6')
        file.write("SUCCESS|")
        print("SUCCESS: Set State to: In Stock")
        #PCState = selected_option.text
        try:
            file.write("     Setting StockRoom State to: " + str(StockroomLocation) + "...")
            wait.until(EC.visibility_of_element_located((By.ID, StockRoomID)))
            Element = driver.find_element_by_id(StockRoomID)
            Element.click()
            Element.send_keys(Keys.CONTROL, 'a')
            Element.send_keys(StockroomLocation)
            file.write("SUCCESS|")
            print("SUCCESS: Set Stockroom to to: " + str(StockroomLocation))
            #Element.click()
            try:
                file.write("     Setting SecondaryState State to: Available...")
                try:
                    wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
                    try:
                        Element = driver.find_element_by_id(SecondaryStateID)
                        try:
                            select = Select(driver.find_element_by_id(SecondaryStateID))
                            select.select_by_value('available')
                            file.write("SUCCESS|")
                            print("SUCCESS: Set Secondary State to: Available")
                        except:
                            print("FAILED: Set Secondary State to: Available")
                            file.write("FAILED SELECTING ELEMENT BY ID AND BY VALUE (id: SecondaryStateID: " + str(SecondaryStateID) + ", Value: available)|")
                    except:
                        print("FAILED: Set Secondary State to: Available")
                        file.write("FAILED GETTING ELEMENT BY ID (SecondaryStateID: " + str(SecondaryStateID) + ")|")
                except:
                    print("FAILED: Set Secondary State to: Available")
                    file.write("FAILED WAITING FOR VISIBILITY|")
            except:
                print("FAILED: Set Secondary State to: Available")
                file.write("SECONDARY STATE NOT FOUND|")
                print("SECONDARY STATE  NOT FOUND")

        except:
            #No PC SubState found
            print("FAILED: Set Stockroom to: " + str(StockroomLocation))
            print("FAILED: Set Secondary State to: Available")
            file.write("STOCKROOM NOT FOUND|")
            print("STOCKROOM NOT FOUND")
    except:
        print("FAILED: Set State to: In Stock")
        print("FAILED: Set Stockroom to: " + str(StockroomLocation))
        print("FAILED: Set Secondary State to: Available")
        file.write("FAILED SETTING STATE AND SUBSTATE|")
        #No PC State found
        
    try:
        file.write("     Setting AssetFunction to: Spare...")
        Element = driver.find_element_by_id(AssetFunctionID)
        #Element.click()
        #wait.until(EC.visibility_of_element_located((By.ID, stateID)))
        select = Select(driver.find_element_by_id(AssetFunctionID))
        select.select_by_value('Spare')
        file.write("SUCCESS|")
        print("SUCCESS: Set Asset Function to: Spare")
        #PCAssetFunction = selected_option.text
    except:
        #No PC Asset Function found
        print("FAILED: Set Asset Function to: Spare")
        file.write("FAILED SETTING ASSET FUNCTION|")

    file.write("     Saving Service-Now Record...")
    wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
    driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
    print("Saving Record...")
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()
    print("Record Saved")
    file.write("DONE|")
    file.write("    -------  END OF SERVICE-NOW RECORD UPDATE ---------| |")
    file.write("-------  END OF PYTHON SCRIPT ---------| |")
    file.close()
print("Service Now is complete")

    
driver.quit()
exit()
