import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import TimeoutException

#scriptpath = 'C:/Users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver'
scriptpath = os.path.dirname(os.path.realpath(__file__))

SN_Login_Username = sys.argv[1]
SN_Login_Password = sys.argv[2]

expectedwindows = 2

OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Ftask_list.do%3Fsysparm_offset%3D%26sysparm_list_mode%3Dgrid%26sysparm_query%3Dassignment_group%3Djavascript:getMyGroups()%5Eactive%3Dtrue%5EstateNOT IN-5,3,4,7,8,9,10%5EnumberNOT LIKEGAPRV%5ENQassignment_group%3Djavascript:getMyGroups()%5Eactive%3Dtrue%5Esys_class_name%3Dsn_si_task%5ENQassignment_groupDYNAMICd6435e965f510100a9ad2572f2b47744%5Eactive%3Dtrue%5Esys_class_name%3Dsn_si_incident%5EstateIN10%5EORDERBYassigned_to%5EORDERBYDESCstate%5EORDERBYDESCopened_at%26sysparm_userpref_module%3D2ccb50dfc61122820032728dcea648fe%26sysparm_clear_stack%3Dtrue"
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"

#   SETUP CHROME DRIVER
options = Options()
options.headless = True
options.add_argument('log-level=3')
options.add_argument('--window-size=1920x1080')
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
#driver = webdriver.Chrome(options=options, executable_path= scriptpath)
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")

wait = WebDriverWait(driver, 5)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

Universal_SN_iframe = "gsft_main"

tableid = "//*[@id='task_table']"

try:
    #Try Opening file
    file = codecs.open(sys.argv[3],"w", "utf-8")
except:
    #failed to open file
    file = codecs.open(sys.argv[3] + '(1).txt',"w", "utf-8")
file2 = open(sys.argv[4], "w")
file2.write('"NUMBER","TICKET_NUMBER","TICKET_HREF","TICKET_ASSIGNED","TICKET_CREATED","TICKET_STATE","TICKET_SHORTDESC","TICKET_LONGDESC"\n')

try:
    #Begin Webpage navigation to Old PC record first
    driver.get(OldPCWebpage)
    
    #   INITIAL LOGIN PAGE
    #SET ELEMENTS IN LOGIN PAGE
    if driver.title == "Login":
        print(" ________________________________________________")
        print("|             Logging in As user                 |")
        print("|________________________________________________|")
        print(" ")
        #login
        userid = driver.find_element_by_id('userID')
        password = driver.find_element_by_id('password')
        btnLogin = driver.find_element_by_id("loginbtn")
    
        #SEND KEYS TO ELEMENTS IN LOGIN PAGE
        userid.send_keys(SN_Login_Username)
        password.send_keys(SN_Login_Password)
        btnLogin.click()
    
    #pcary = []
    #expectedwindows = 2
    print(" ________________________________________________")
    print("|        Getting PC Info from Service-now        |")
    print("|________________________________________________|")
    print(" ")
    
    
    try:    
        wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
        time.sleep(2)
        element = driver.find_element(By.ID, 'task_table')
        tbody = element.find_element_by_tag_name("tbody")
        items = tbody.find_elements_by_tag_name("tr")
    except:
        try:
            print("exception finding Iframe")
            time.sleep(2)
            element = driver.find_element(By.ID, 'task_table')
            tbody = element.find_element_by_tag_name("tbody")
            items = tbody.find_elements_by_tag_name("tr")
        except:
            print("exception finding element")
            file2.close()
            file.close()
            quit()
            exit()
    
    #element = driver.find_element(By.XPATH, "//*[@id='alm_hardware_table']/tbody")
    
    Irow = 0
    ticketary = []
    ticketcount = 0
    for row in items:
        print("Row: " + str(Irow))
        Irow = Irow + 1
        cols = row.find_elements_by_tag_name("td")
        #time.sleep(2)
        if not Irow == 0:
            try:
                TicketAssignedElement = cols[4].find_element_by_tag_name("a")
                TicketAssigned = TicketAssignedElement.text
            except:
                TicketAssigned = cols[4].text
                
            if TicketAssigned == "(empty)":
                ticketcount = 1
                TicketNumberElement = cols[2].find_element_by_tag_name("a")
                TicketNumberText = TicketNumberElement.text
                TicketNumberHref = TicketNumberElement.get_attribute("href")
           
        
        
                TicketCreatedElement = cols[5].find_elements_by_tag_name("div")
                TicketCreated = TicketCreatedElement[0].text
                TicketState = cols[6].text
                TicketShortDesc = cols[7].text
                TicketLongDesc = cols[8].get_attribute("data-original-title")
                ticketary += [str(TicketNumberText),str(TicketNumberHref),str(TicketAssigned),str(TicketCreated),str(TicketState),str(TicketShortDesc),str(TicketLongDesc)]
                file2.write('"' + str(Irow) + '","' + str(TicketNumberText) + '","' + str(TicketNumberHref) + '","' + str(TicketAssigned) + '","' + str(TicketCreated) + '","' + str(TicketState) + '","' +str(TicketShortDesc) + '","' +str(TicketLongDesc) + '"\n')
    
                #print(str(TicketNumberText) + ", " + str(TicketNumberHref) + ", " + str(TicketAssigned) + ", " + str(TicketCreated) + ", " + str(TicketState) + ", " + str(TicketShortDesc) + ", " + str(TicketLongDesc))
                #print(" ")
                
    if ticketcount == 0:
        Irow = " "
        TicketNumberText = " "
        TicketNumberHref = " "
        TicketAssigned = " "
        TicketCreated = " "
        TicketState = " "
        TicketShortDesc = " "
        TicketLongDesc = " "
        file2.write('"' + str(Irow) + '","' + str(TicketNumberText) + '","' + str(TicketNumberHref) + '","' + str(TicketAssigned) + '","' + str(TicketCreated) + '","' + str(TicketState) + '","' +str(TicketShortDesc) + '","' +str(TicketLongDesc) + '"\n')
    
    file.close()
    file2.close()
    driver.quit()
    exit()
    #print(ticketary)
except:
    file.close()
    file2.close()
    driver.quit()
    exit()
