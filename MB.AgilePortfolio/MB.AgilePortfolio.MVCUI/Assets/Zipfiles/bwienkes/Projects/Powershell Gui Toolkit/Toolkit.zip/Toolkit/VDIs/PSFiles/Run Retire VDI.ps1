﻿param
(
[Parameter(Mandatory=$false)] $computer
)
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
################## Retire VDI ############################################################################################################################################
    import-module Citrix.xendesktop.admin
    add-pssnapin Citrix.*
    import-module ActiveDirectory
    #$AdminAddress = "GRBAAHVWPXDDC03.i.ameriprise.com:80"
    #$vSphereServer = 'grbaahvlpxdvc02.i.ameriprise.com'

    $ServersPath = (get-item $PSscriptroot).Parent.FullName
    $vSphereServerPath = "$ServersPath\ServerFiles\vSphereServerAddress.txt"
    $CitrixServerPath = "$ServersPath\ServerFiles\CitrixServerAddress.txt"
    if(test-path $vSphereServerPath)
    {
        $vSphereServer = Get-Content -Path $vSphereServerPath
    }
    else
    {
        write-host -ForegroundColor Yellow "vSphere Server file not found, defaulting to hardcoded"
        #default to hardcode
        $vSphereServer = 'grbaahvlpxdvc02.i.ameriprise.com:80'
    }

    if(test-path $CitrixServerPath)
    {
        $AdminAddress = Get-Content -Path $CitrixServerPath
    }
    else
    {
        #default to hardcode
        write-host -ForegroundColor Yellow "Citrix Server file not found, defaulting to hardcoded"
        $AdminAddress = "GRBAAHVWPXDDC03.i.ameriprise.com:80"
    }

    $scriptPath = "$($PSScriptRoot)"
    $Root = (get-item $scriptPath).Parent.Parent.FullName

    ####################################################
    #-------------------LOG SETUP----------------------#
    ####################################################

    $LogRoot = $Root
    $ParentLogContainingFolderName = "VDIs"
    $LogContainingFolderName = "Retire VDI Logs"
    $logpath = "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName\$logfilename"
    if(!(test-path "$LogRoot\Logs"))
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$LogRoot\Logs")
    }

    if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName"))
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName")
    }

    if(!(test-path "$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName"))
    {
        $fso = new-object -ComObject scripting.filesystemobject
        $fso.CreateFolder("$LogRoot\Logs\$ParentLogContainingFolderName\$LogContainingFolderName")
    }
    ####################################################
    #-------------------LOG SETUP----------------------#
    ####################################################

    $continue = $true
    if ($computer)
    {
        $AdapterComputer = $computer
    }

    while($continue)
    {
        $LogDir = "$Root\Logs\VDIs\Retire VDI Logs"
        $computer = $null
        $computer1 = $null
        $vdigone = $false
        if (!($AdapterComputer))
        {
            $VDIEntry = $true
            while($VDIEntry)
            {
                $computer1 = read-host "Enter full VDI name to retire"
                if($computer1 -like "WIVGP*")
                {
                    $VDIEntry = $false
                }
                else
                {
                    cls
                    write-host -ForegroundColor Yellow "VDI Name is Incorrect`n"
                }
            }
        }
        else
        {
            $computer1 = $AdapterComputer
            $AdapterComputer = $null
        }

        $computer = $computer1.trim()
        $computer = $computer.ToUpper()

        if(!(test-path "$LogDir\$computer.txt"))
        {
            Write-Output "---------------------- Started $((Get-Date).ToString()) -------------------------" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii
        }
        else
        {
            Write-Output "---------------------- Started $((Get-Date).ToString()) -------------------------" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        }

        $VM = $null
        $citrix_e = $null
        $VM = Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            write-host -ForegroundColor Cyan "Search for " -NoNewline
            write-host "$($VM.HostedMachineName)" -NoNewline
            write-host -ForegroundColor Cyan " in citrix " -NoNewline
            write-host  "$strE"
            write-output "Search for $($VM.HostedMachineName) in citrix $strE" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        }

        if ($VM.count -gt 1)
        {
            #TODO ADD SELECTION PROCESS ON MULTIPLE VDIs
            write-host -ForegroundColor Red "`nToo many VDI's Returned`n"
            write-output "Too many VDI's Returned, Exiting Script $((Get-Date).ToString())" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            $exit = read-host "Press Enter to Exit"
            exit
        }
        if ($VM.count -lt 1)
        {
            write-host -ForegroundColor Yellow "`nVDI not found in Citrix"
            write-host -ForegroundColor Yellow "skipping to VSphere`n"
            write-output "VDI Not found in Citrix. Skipping to VSphere" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            #$exit = read-host "Press any key to exit"
            $vdigone = $true
        }
        if(!($vdigone))
        {
            write-output "Turning ON MaintenanceMode" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            Set-BrokerMachineMaintenanceMode -InputObject $VM -MaintenanceMode $true -AdminAddress $AdminAddress
            $VM = $null
            $citrix_e = $null
            $VM = Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
            if($citrix_e)
            {
                $strE = $citrix_e[0].ToString()|out-string
                write-host -ForegroundColor Cyan "Search for " -NoNewline
                write-host "$($VM.HostedMachineName)" -NoNewline
                write-host -ForegroundColor Cyan " in citrix " -NoNewline
                write-host "$strE"
                write-output "Search for $($VM.HostedMachineName) in citrix $strE" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            }

            if ($VM.InMaintenanceMode)
            {
                write-host -foregroundcolor Green "SUCCESSFULLY " -NoNewline
                write-host "$($VM.HostedMachineName)" -NoNewline
                write-host -foregroundcolor cyan " set to Maintenance Mode"
                write-output "[SUCCESS] Set $($VM.HostedMachineName) to Maintenance Mode" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            }
            else
            {
                write-host -ForegroundColor Red "FAILED " -NoNewline
                write-host "$($VM.HostedMachineName)" -NoNewline
                write-host -ForegroundColor Cyan " to set to Maintenance Mode"
                write-output "[FAILED] Set $($VM.HostedMachineName) to Maintenance Mode" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                write-output "Exiting Script $((Get-Date).ToString())" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append

                $exit = read-host "Press any key to exit"
                exit
            }
            write-host -ForegroundColor Cyan "`nShutting VDI Down..."
            write-output "Shutting VDI Down..."n | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            New-BrokerHostingPowerAction -MachineName $($VM.HostedMachineName) -Action Shutdown -AdminAddress $AdminAddress
            $poweron = $true

            do
            {
                start-sleep -seconds 5

                $VM = $null
                $citrix_e = $null
                $VM = Get-BrokerMachine  -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
                if($citrix_e)
                {
                    $strE = $citrix_e[0].ToString()|out-string
                    write-output "Search for $($VM.HostedMachineName) in citrix $strE"
                }

                $DesktopGroup = Get-BrokerDesktopGroup -AdminAddress $AdminAddress -Filter "(Name -eq `"$($VM.DesktopGroupName)`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -ev citrix_e -ErrorAction SilentlyContinue
                #write-output "Desktop Group = $DesktopGroup"
                if ($VM.Powerstate -eq "On")
                {
                    write-host "$($VM.HostedMachineName)" -NoNewline
                    write-host -ForegroundColor cyan " is still powered on, waiting 5 more secs..."
                }
                else
                {
                    write-host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                    write-host -ForegroundColor Cyan "Powered off " -NoNewline
                    write-host "$($VM.HostedMachineName)"
                    write-output "[SUCCESS] Powered off $($VM.HostedMachineName)" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                    $poweron = $false
                }
            }
            while ($poweron)

            $vmName = $($VM.HostedMachineName)
            write-host -ForegroundColor Cyan "Removing " -NoNewline
            write-host "$vmName" -NoNewline
            write-host -ForegroundColor Cyan " from Citrix Desktop Group..." -NoNewline
            write-output "Removing $vmName from Citrix Desktop Group" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            Remove-BrokerMachine -InputObject $VM -DesktopGroup $DesktopGroup -AdminAddress $AdminAddress
            write-host "Done"
            write-host -ForegroundColor Cyan "Removing " -nonewline
            write-host "$vmName" -NoNewline
            write-host -ForegroundColor Cyan " from Citrix..." -NoNewline
            write-output "Removing $vmName from Citrix" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            Remove-BrokerMachine -InputObject $VM -AdminAddress $AdminAddress
            write-host "Done"

            $VM = $null
            $citrix_e = $null
            $VM = Get-BrokerMachine -AdminAddress $AdminAddress -Filter "(SessionSupport -eq `"SingleSession`" -and CatalogName -eq `"Win 10 Persistent Desktops`" -and DNSName -eq `"$computer.i.ameriprise.com`")" -MaxRecordCount 1000  -ReturnTotalRecordCount -Skip 0 -SortBy "+DNSName" -ev citrix_e -ErrorAction SilentlyContinue
            if($citrix_e)
            {
                $strE = $citrix_e[0].ToString()|out-string
                write-output "Search for $($vmName) in citrix $strE" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            }

            if ($VM -eq $null -or $VM.count -lt 1)
            {
                write-Host -ForegroundColor Green "SUCCESSFULLY " -NoNewline
                write-host -ForegroundColor Cyan "Removed " -NoNewline
                write-host  "$vmName" -NoNewline
                write-host -ForegroundColor Cyan " from Citrix`n"
                write-output "[SUCCESS] Removed $Vmname from Citrix" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            }
            else
            {
                write-Host -ForegroundColor Red "FAILED " -NoNewline
                write-host -ForegroundColor Cyan "to Remove " -NoNewline
                write-host  "$vmName" -NoNewline
                write-host -ForegroundColor Cyan " from Citrix`n"
                write-output "[FAILED] Removing $Vmname from Citrix" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                write-output "Exiting Script $((Get-Date).ToString())" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                $exit = read-host "Press any key to exit"
                exit
            }
        }


	        ########## VSPHERE #############
        Add-PSSnapin VMware.VimAutomation.Core
        Import-Module -Name VMware.PowerCLI -ErrorAction SilentlyContinue
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

        $vsphere_w = $null
        write-host -ForegroundColor Cyan "Connecting to vSphere`n"
        write-output "Connecting to vSphere"| Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        Set-PowerCLIConfiguration -InvalidCertificateAction ignore -confirm:$false
        $a = $null
        $a = connect-VIServer $vSphereServer -wv vsphere_w -WarningAction SilentlyContinue |Out-String
        if($vsphere_w)
        {
            #$strW = $vsphere_w[0].ToString()|out-string
        }

        $vspheregone = $false
        if ($vdigone)
        {
            if($computer -ne $null -or $computer -ne "")
            {
                $vmName = $computer
            }
        }
        $vsVM = $null

        $citrix_e = $null
        $vsVM = get-vm $vmName -ev citrix_e -ErrorAction SilentlyContinue
        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            #write-output "Search for $($vmName) in vSphere not found"
        }

        if ($vsVM -eq $null)
        {
            write-host "$vmName" -NoNewline
            write-host -ForegroundColor Yellow " is not in vSphere"
            write-host -ForegroundColor Yellow "Skipping to Active Directory`n"
            write-output "$vmName is not in vSphere Skipping to Active Directory" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            $vspheregone = $true
        }
        else
        {
            $VMpower = get-vm $vsVM | select name, PowerState
            write-host "$($VMpower.Name)" -NoNewline
            write-host -ForegroundColor Cyan " is currently " -NoNewline
            write-host "$($VMpower.PowerState)"
            Write-Output "$($VMpower.Name) is currently $($VMpower.PowerState)" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            if ($VMpower.PowerState -eq "PoweredOn")
            {
                get-vm $vsVM| Shutdown-VMGuest -Confirm:0
                $poweredoff = $false
                $BreakTimer = 0
                do
                {
                    $VMpower = get-vm $vsVM | select name, PowerState
                    write-host "$($VMpower.Name)" -NoNewline
                    write-host -ForegroundColor Cyan " is currently " -NoNewline
                    write-host "$($VMpower.PowerState)"
                    if($($VMpower.PowerState) -like "PoweredOff")
                    {
                        $poweredoff = $true
                    }
                    else
                    {
                        $BreakTimer += 1
                        if($BreakTimer -gt 60){write-host -ForegroundColor Red "Shutting down VM Failed`r`n";break}
                        write-Host "Waiting 5 more secs for power to turn off"
                        start-sleep -Seconds 5
                    }
    
                }
                until($poweredoff)
            }
            else
            {
                $poweredoff = $true
            }

            if($poweredoff -eq $false)
            {
                write-host "$($VMpower.Name)" -NoNewline
                write-host -ForegroundColor Cyan " cannot be removed from vSphere because it is " -NoNewline
                write-host -ForegroundColor Yellow "$($VMpower.PowerState)" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                write-output "$($VMpower.Name) cannot be removed from vSphere because it is $($VMpower.PowerState)" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                write-output "Exiting Script $((Get-Date).ToString())" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                write-host -ForegroundColor Red "FAILED TO REMOVE FROM vSPHERE"
                $exit = read-host "`nPress any key to exit" 
                exit
            }
            else
            {
                write-host "$computer" -NoNewline
                write-host -ForegroundColor Cyan "powered off " -NoNewline
                write-host -ForegroundColor Green "SUCCESSFULLY"
                write-host -ForegroundColor Cyan "Removing "-NoNewline
                write-host "$($VMpower.Name)" -NoNewline
                write-host -ForegroundColor Cyan " from vSphere..." -NoNewline
                write-output "Removing $($VMpower.name) from vSphere" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                remove-vm $vsVM -DeletePermanently -Confirm:0
            }
        }

        $citrix_e = $null
        $vsVM = get-vm $vmName -ev citrix_e -ErrorAction SilentlyContinue
        if($citrix_e)
        {
            $strE = $citrix_e[0].ToString()|out-string
            write-host -ForegroundColor Cyan "Verifying Search for " -NoNewline
            write-host "$($vmName)" -NoNewline
            write-host -ForegroundColor Cyan " in vSphere found nothing"
            write-output "Verifying Search for $($vMNAME) in vSphere found nothing" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        }
        if ($vsVM -eq $null -or $vsVM.count -lt 1)
        {
            write-Host -ForegroundColor Green "`nSUCCESSFULLY " -NoNewline
            write-host -ForegroundColor Cyan "removed " -NoNewline
            write-host "$vmName" -NoNewline
            write-host -ForegroundColor Cyan " from vSphere`n"
            write-output "[SUCCESS] Removed $Vmname from vSphere" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        }
        else
        {
            write-host -ForegroundColor Red "`nFAILED " -NoNewline
            write-host -ForegroundColor Cyan " to remove " -NoNewline
            write-host "$vmName" -NoNewline
            write-host -ForegroundColor Cyan " from vSphere`n"
            write-output "[FAILED] Removing $vmName from vSphere" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            write-output "Exiting Script $((Get-Date).Tostring())" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            $exit = read-host "Press any key to exit"
            exit
        }
	
	    ########## VSPHERE #############


	    ####### Active Directory #######
        if ($vmName -eq $null -or $vmName -eq "")
        {
	        if($computer -ne $null -or $computer -ne "")
	        {
	            $vmName = $computer 
	        }
	
        }


        if ($vmName -ne $null -or $vmName -ne "")
        {
            $ADcomputer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$vmName'")
            if ($ADcomputer.count -eq 1)
            {
                write-Host -ForegroundColor Cyan "Removing " -NoNewline
                write-host "$vmName" -NoNewline
                write-host -ForegroundColor Cyan " from Active Directory..."
                write-output "Removing $vmname from Active Directory..." | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$vmName'" | Remove-ADObject -Recursive -Confirm:0
                $ADcomputer = @(Get-ADComputer -Server AFII -SearchBase "OU=Computers,OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$vmName'")
                if ($ADcomputer.count -lt 1)
                {
                    write-Host -ForegroundColor Green "`nSUCCESSFULLY " -NoNewline
                    write-host -ForegroundColor Cyan "removed " -NoNewline
                    write-host  "$vmName" -NoNewline
                    write-host -ForegroundColor Cyan " from Active Directory`n"
                    write-output "[SUCCESS] Removed $VMName From Active Directory" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                }
                else
                {
                    write-Host -ForegroundColor Red "`nFAILED " -NoNewline
                    write-host -ForegroundColor Cyan "to remove " -NoNewline
                    write-host "$vmName" -NoNewline
                    write-host -ForegroundColor Cyan " from Active Directory`n"
                    Write-output "[FAILED] Removing $vmName from Active Directory" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                    write-output "Exiting Script $((Get-Date).ToString())" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                    $exit = read-host "Press any key to exit"
                    exit
                }
            }
            elseif ($ADcomputer.count -lt 1)
            {
                write-host "$vmName" -NoNewline
                write-Host -ForegroundColor Yellow " was not found in Active Directory"
                write-output "[WARNING] $VMName was not found in Active Directory" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            }
        }
	        ####### Active Directory #######
        if ($($vmName))
        {

        #site configuration
$SiteCode = "MSP"
$ProviderMachineName = "mspcsc12sccm01"

#customizations
$initParams = @{}
#$initParams.Add("Verbose", $true) #uncomment to enable verbose logging
#$initParams.Add("ErrorAction", "Stop") # uncomment to stop the script on any errors

# Do not change anything below this line
#import ConfigurationManager.psd1 module
if((Get-Module ConfigurationManager) -eq $null){import-module "$($ENV:SMS_ADMIN_UI_PATH)\..\ConfigurationManager.psd1" @initParams}

#connect to the site's drive if it is not already present
if((Get-PSDrive -Name $SiteCode -PSProvider CMSite -ErrorAction SilentlyContinue) -eq $null){New-PSDrive -name $SiteCode -PSProvider CMSite -Root $ProviderMachineName @initParams}

#set the current location to be the site code
set-Location "$($SiteCode):\" @initParams




$FolderFilePath = "$PSScriptRoot"
$PCList = "$FolderFilePath\pc_list.txt"
$DeleteLogFileName = "$FolderFilePath/DeleteLog - $(((Get-Date).Month).tostring())-$(((Get-Date).Day).tostring())-$(((Get-Date).Year).tostring()).txt"



$pc = $null
$stringout = @()
$sccmpcs = @()
$stringout += " "
write-host -ForegroundColor Cyan "------- START Checking if computers are in AD ------------"
$stringout += "------- START Checking if computers are in AD ------------"
$pc = $vmName

    if($pc)
    {
        if($pc.trim())
        {
            $pc = $pc.trim()
            write-host -ForegroundColor Cyan "Checking: " -NoNewline
            write-host "$pc" -NoNewline
            write-host -ForegroundColor Cyan "..." -NoNewline
            $iPC = $null
            $iPC = Get-ADComputer -Server AFII -SearchBase "OU=AAH,DC=i,DC=ameriprise,DC=com"-Properties * -filter "name -like '$pc'"
            if($iPC)
            {
                write-host "$($iPC.Name)" -nonewline
                write-host -ForegroundColor Yellow " was found in AD!"
                $stringout += "$($iPC.Name) was found in AD!"
                $stringout += "    PROMPT: Remove from SCCM anyways?(y/n)"
                $removestill = read-host "Remove from SCCM anyways?(y/n)"
                $stringout +=  "        USER INPUT: $removestill" 
                if($removestill -like "y")
                {
                    $stringout +=  "           INPUT translated to: Yes" 
                    write-host -ForegroundColor Cyan "Added " -NoNewline
                    write-host "$($IPC.name)" -NoNewline
                    write-host -ForegroundColor Cyan " to the list"
                    $cmdevice = $null
                    $cmdevice = (get-CMDevice -CollectionID "MSP010f6" -name $($pc))
                    if($cmdevice)
                    {
                        write-host "$($IPC.name)" -NoNewline
                        write-host -ForegroundColor Cyan " found in SCCM!"
                        $stringout +=  " $($IPC.name) found in SCCM!"
                        $sccmpcs += $cmdevice
                    }
                    else
                    {
                        write-host "$($IPC.name)" -NoNewline
                        write-host -ForegroundColor Yellow " NOT IN SCCM!"
                        $stringout +=  "[WARNING] $($IPC.name) NOT IN SCCM!"
                    }
                    
                }
                else
                {
                    write-host -ForegroundColor Cyan "Skipping " -NoNewline
                    write-host "$($IPC.name)"
                    $stringout +=  "           INPUT translated to: No" 
                }
            }
            else
            {
                $stringout += "$($pc) was NOT in AD"
                write-host -ForegroundColor Green "Not in AD"
                $cmdevice = $null
                 $cmdevice = (get-CMDevice -CollectionID "MSP010f6" -name $($pc))
                if($cmdevice)
                {
                    write-host "$($pc)" -NoNewline
                    write-host -ForegroundColor Cyan " found in SCCM!"
                    $stringout +=  " $($pc) found in SCCM!"
                    $sccmpcs += $cmdevice
                }
                else
                {
                    write-host "$($IPC.name)" -NoNewline
                    write-host -ForegroundColor Yellow " NOT IN SCCM!"
                    $stringout +=  "[WARNING] $($IPC.name) NOT IN SCCM!"
                }
            }
        }
    }
    $cmdevice = $null

write-host -ForegroundColor Cyan "------- END Checking if computers are in AD ------------"
$stringout += "------- END Checking if computers are in AD ------------"
$stringout += " "


#Set-Location -Path "C:\"
Write-Output "Date: $(get-date)"  | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
Write-Output "Total Computers found in SCCM: $($sccmpcs.Count)" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
Write-Output " "  | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
for($i = 0; $i -lt $stringout.count;$i++)
{
Write-Output "$($stringout[$i])"  | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
}
$stringout = $null
Write-Host -ForegroundColor Cyan "`nTotal Computers found in SCCM: " -NoNewline
write-host "$($sccmpcs.Count)" 
Write-Output " "  | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
write-host -ForegroundColor Cyan "============================================================" 
Write-Output "============================================================" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
write-host -ForegroundColor Cyan "List of computers that will be Deleted:"
Write-Output "List of computers that will be Deleted:"| Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
write-host -ForegroundColor Cyan "------------------------------------"  
Write-Output "------------------------------------"  | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
foreach($p in $sccmpcs)
{
write-host $p.Name
write-output $p.Name | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
}
write-host -ForegroundColor Cyan "------------------------------------`n" 
write-output "------------------------------------`n" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append

write-output "    PROMPT: Are You sure you want to delete these computers?(Y/N)" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
$certainDelete = read-host "Are You sure you want to delete these computers?(Y/N)"
write-output "        USER INPUT: $certainDelete" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
if($certainDelete -like "y")
        {
            write-output  "           INPUT translated to: Yes" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            write-host -ForegroundColor Cyan "`n---------------- START DELETE ----------------------" 
            write-output " " | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            write-output "DELETE LOG" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            write-output "--------------------------------------" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
            foreach($p in $sccmpcs)
            {
                $tempname = $null
                $tempname = $p.Name
                $p | Remove-CMDevice -Force
                write-output "        Deleting: $tempname" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                write-host -ForegroundColor Cyan "Verifying " -NoNewline
                write-host "$tempname" -NoNewline
                write-host -ForegroundColor Cyan " deleted..." -NoNewline
                
                if(get-CMDevice -CollectionID "MSP010f6" -name $($tempname))
                {
                    write-output "[FAILED] Verify $tempname deleted" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                    write-host -ForegroundColor red "FAILED TO DELETE!"
                }
                else
                {
                    write-output "[SUCCESS] Verify $tempname deleted" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                   write-host -ForegroundColor green "SUCCESSFULLY DELETED!"
                }
            }
            write-host -ForegroundColor Cyan "---------------- END DELETE ----------------------`n" 
            write-output "--------------------------------------" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        }
        else
        {
            write-output  "           INPUT translated to: No" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        }

        write-host "=====================================================" 
        write-host "|                  END OF SCCM Delete                |" 
        write-host "=====================================================" 
        write-output "=====================================================" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        write-output "|                  END OF SCCM Delete                |" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
        write-output "=====================================================" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append

        Set-location "C:\" @initParams

            if(test-path 'C:\Program Files (x86)\Python37-32\python.exe')
            {
                #python installed
                if(test-path "$root\Python\Retire VDI.ps1")
                {
                    #retire VDI in Service now script found
                    write-host "Starting Update of Service-Now records"
                    $pslogpath = "$LogDir\$computer.txt"
                    write-host "-------------------------------------------------------"
                    Start-Process Powershell -ArgumentList ("& `'$root\Python\Retire VDI.ps1`' -computer '$($vmName)' -PSLogPath '$($pslogpath)'")
                    write-host "-------------------------------------------------------"
                }
                else
                {
                    write-host -ForegroundColor Cyan "Opening Up VDI in Service Now" -NoNewline
                    write-host -ForegroundColor Yellow " SERVICE-NOW NEEDS TO BE UPDATED MANUALLY!"
                    write-output "Opening Browser to VDI record in Service Now" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                    $url = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware_list.do%3Fsysparm_first_row%3D1%26sysparm_query%3DGOTOci.nameLIKE$($vmName)%26sysparm_query_encoded%3DGOTOci.nameLIKE$($vmName)%26sysparm_view%3D"
                    Start-Process "chrome.exe" $url
                }
            }
            else
            {
                write-host -ForegroundColor Cyan "Opening Up VDI in Service Now" -NoNewline
                write-host -ForegroundColor Yellow " SERVICE-NOW NEEDS TO BE UPDATED MANUALLY!"
                write-output "Opening Browser to VDI record in Service Now" | Out-File -FilePath "$LogDir\$computer.txt" -Encoding ascii -Append
                $url = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware_list.do%3Fsysparm_first_row%3D1%26sysparm_query%3DGOTOci.nameLIKE$($vmName)%26sysparm_query_encoded%3DGOTOci.nameLIKE$($vmName)%26sysparm_view%3D"
                Start-Process "chrome.exe" $url
            }

            write-host -ForegroundColor Cyan "`nFinished Retiring VDI"
            write-output "---------------------- Completed $((Get-Date).ToString()) -------------------------------"
        }

        $conYN = read-host "`nRetire another VDI? (y/n)"
        if ($conYN -like "n")
        {
            $continue = $false
        }
    }
    Disconnect-VIServer -Server $vSphereServer -Force -Confirm:$false
    exit

}
else {
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";



    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}
#TODO: TEST
#TODO: ADD SERVICE-NOW INTEGRATION HERE

################## Retire VDI ############################################################################################################################################