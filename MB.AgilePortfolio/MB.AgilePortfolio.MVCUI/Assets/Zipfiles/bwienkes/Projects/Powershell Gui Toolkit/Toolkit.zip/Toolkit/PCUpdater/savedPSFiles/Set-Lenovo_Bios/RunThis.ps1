﻿cls


###################################
#---------CHANGE SCRIPT-----------#
###################################

$ScriptName = "set-bios"

###################################
#--------END CHANGE SCRIPT--------#
###################################
$scriptPath = "$($PSScriptRoot)"
$Root = (get-item $scriptPath).Parent.Parent.FullName
$ExcelLoginFilePath = "$($Root)\CHANGE-THIS.xlsx"
$xl20 = New-Object -COM "Excel.Application"
$xl20.Visible = $false
$wb20 = $xl20.Workbooks.Open("$($Root)\CHANGE-THIS.xlsx")
$ws20 = $wb20.Sheets.Item(1)
$xlFixedFormat20 = [Microsoft.Office.Interop.Excel.XlFileFormat]::xlWorkbookDefault

$WorksheetRange20 = $ws20.UsedRange
$RowCount20 = $WorksheetRange20.Rows.Count
$ColumnCount20 = $WorksheetRange20.Columns.Count
write-host "Loading Accounts from $($Root)\CHANGE-THIS.xlsx..."
for ($i20 = 2; $i20 -le $RowCount20; $i20++){
for ($cl0 = 1; $cl0 -le $ColumnCount20; $cl0++){



#get data:
$cell = $ws20.Cells.Item($i20, $cl0).Text
if ($i20 -eq 2){
if ($cl0 -eq 1){
write-host "Admin account username Loading"
$Admin_User = "$($cell)"
}
if ($cl0 -eq 2){
write-host "Current account username Loading"
$NonAdmin_User = "$($cell)"
}
if ($cl0 -eq 3){
write-host "H:\ Loading"
$HDrivePath = "$($cell)"
}
else{

}
}
}
}
$wb20.Close()
$xl20.Quit()
[System.Runtime.Interopservices.Marshal]::ReleaseComObject($xl20)

# This is H:\ Drive path DO NOT NEED TO CHANGE UNLESS YOUR H:\ can't be accessed by your nonadmin account
$RootInstallLocation = "$($HDrivePath)"
New-PSDrive -Name "H" -PSProvider FileSystem -Root $RootInstallLocation
$filelist2 = @("H:\ACreds.txt", "H:\Creds.txt")

foreach ($file in $filelist2)
    {
    $newfilepath = "$($file)"
 if (test-path $newfilepath)
                {
                    Write-Host "$newfilepath file exists"
                    try
                    {
                    $test = Get-Content $newfilepath
                    }
                    catch
                    {
                        #Failure
                        Write-host "Error while reading passwords from $newfilepath, make sure you have these text files in your H:\ Drive with your password in them"
                        #skip
                        continue
                    }
                    #On sucess
                    if ($newfilepath -eq "H:\ACreds.txt")
                    {
                    try{
                            (gc H:\ACreds.txt) | ? {$_.trim() -ne "" } | set-content H:\ACreds.txt
                            $ACreds = Get-Content H:\ACreds.txt
                            foreach ($line in $ACreds)
                            {
                            $strPass = $line.Trim()
                                write-output $strPass | Out-File C:\Temp\ACreds.txt
                            }
                        }
                    catch
                        {
                            Write-Host "Admin credentials failed to load, check your H:\ path is correct"
                            $computer2 = Read-Host -Prompt "press enter to exit"
                            exit
                        }
                        write-host "$newfilepath Loaded successfully"
                    }
                    if ($newfilepath -eq "H:\Creds.txt")
                    {
                    try{
                            (gc H:\Creds.txt) | ? {$_.trim() -ne "" } | set-content H:\Creds.txt
                            $Creds = Get-Content H:\Creds.txt
                            foreach ($line in $Creds)
                            {
                                $strPass2 = $line.Trim()
                                write-output $strPass2 | Out-File C:\Temp\Creds.txt
                            }
                        }
                    catch
                        {
                            Write-Host "NonAdmin credentials failed to load, check your H:\ path is correct"
                            $computer2 = Read-Host -Prompt "press enter to exit"
                            exit
                        }
                        write-host "$newfilepath Loaded successfully"
                    }
                    Write-Host  "All Passwords Loaded"
                }
                }







#***************************************************************
#-------------------------Credentials---------------------------
#**************************************************************
$Admin_User1 = "AFII\$($Admin_User)"
$NonAdmin_User1 = "AFII\$($NonAdmin_User)"

<#
$ACreds = Get-Content C:\Temp\ACreds.txt
    foreach ($line in $ACreds)
{
$strPass = $line
}
    $Creds = Get-Content C:\Temp\Creds.txt
foreach ($line in $Creds)
{
$strPass2 = $line
}

#>
$password = convertto-securestring $strPass -AsPlainText -Force
$password2 = convertto-securestring $strPass2 -AsPlainText -Force
write-host "converted passwords"
$credentials = new-object -typename System.Management.Automation.PSCredential -argumentlist "$Admin_User1",$password
$credentials2 = new-object -typename System.Management.Automation.PSCredential -argumentlist "$NonAdmin_User1",$password2
write-host "created credentials"
$powershellArguments = "$($PSScriptroot)\$($ScriptName).ps1" 
$powershellArguments2 = "write-host 'starting $ScriptName'
try{
Start-Process powershell.exe -WorkingDirectory 'C:\Windows\System32\WindowsPowerShell\v1.0\' -verb runas -ArgumentList $powershellArguments
}
catch{
$_
}"
try{
write-host "starting powershell 1"
Start-Process powershell.exe -WorkingDirectory "C:\Windows\System32\WindowsPowerShell\v1.0\" -credential $credentials -NoNewWindow -ArgumentList $powershellArguments2
#Start-Process powershell.exe -verb runas -ArgumentList $powershellArguments
}
catch
{
write-host $_

}
exit



#-----------------------START ADMIN PS-----------------------------------
#************************************************************************

