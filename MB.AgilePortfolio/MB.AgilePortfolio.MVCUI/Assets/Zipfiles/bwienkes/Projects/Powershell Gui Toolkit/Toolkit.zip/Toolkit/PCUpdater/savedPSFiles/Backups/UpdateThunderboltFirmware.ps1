﻿param
(
[Parameter(Mandatory=$false)][string]$Computer,
[Parameter(Mandatory=$false)][string]$Model,
[Parameter(Mandatory=$false)][bool]$CopyFiles
)

###########################################
#   CREATED BY:       Brenton Wienkes     #
#   DATE CREATED:     11-9-2018           #
###########################################

#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------
#**************************************************************

# Get the ID and security principal of the current user account
$myWindowsID = [System.Security.Principal.WindowsIdentity]::GetCurrent();
$myWindowsPrincipal = New-Object System.Security.Principal.WindowsPrincipal($myWindowsID);

# Get the security principal for the administrator role
$adminRole = [System.Security.Principal.WindowsBuiltInRole]::Administrator;

# Check to see if we are currently running as an administrator
if ($myWindowsPrincipal.IsInRole($adminRole))
{
    # We are running as an administrator, so change the title and background colour to indicate this
    $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)";
    $Host.UI.RawUI.BackgroundColor = "DarkBlue";
    Clear-Host;
#***************************************************************
#-------------------------IGNORE THIS ADMIN PROMPTING-----------


    #GET COMPUTER'S MODEL FUNCTION
    Function Get-PC-Model($PCModel)
    {
	    # NOTE LENOVOS DO NOT HAVE "LENOVO" OR "THINKPAD" IN THE MODEL SO THEY NEED TO BE PROCESSED TO DETERMINE WHAT THEY ARE

	    if (($PCModel.Model -like "20JN*") -or ($PCModel.Model -like "20JM*") -or ($PCModel.Model -like "20HE*") -or ($PCModel.Model -like "20HD*"))
	    {
	        #T470
	        $make = "ThinkPad"
	        $Company = "Lenovo"
	        $type = "Laptop"
	        $model = "T470"
	    }
	    elseif (($PCModel.Model -like "20L5*") -or ($PCModel.Model -like "20L6*"))
	    {
	        #T480
	        $make = "ThinkPad"
	        $Company = "Lenovo"
	        $type = "Laptop"
	        $model = "T480"
	    }
	    elseif (($PCModel.Model -like "20K6*") -or ($PCModel.Model -like "20HN*") -or ($PCModel.Model -like "20HM*"))
	    {
	        #X270
	        $make = "ThinkPad"
	        $Company = "Lenovo"
	        $type = "Laptop"
	        $model = "X270"
	    }
	    elseif ($PCModel.Model -like "*OptiPlex*")
	    {
	        # DELL OPTIPLEX DESKTOPS
	        $make = "OptiPlex"
	        $Company = "Dell"
	        $type = "Desktop"
	        if($PCModel.Model -like "*7040*")
	        {
	            # 7040 OPTIPLEX DESKTOP
	            $Model = "7040"
	        }
	        elseif($PCModel.Model -like "*7020*")
	        {
	            # 7020 OPTIPLEX DESKTOP
	            $Model = "7020"
	        }
	        elseif($PCModel.Model -like "*7010*")
	        {
	            # 7010 OPTIPLEX DESKTOP
	            $Model = "7010"
	        }
	        else
	        {
	            # UNKNOWN MODEL OPTIPLEX DESKTOP 
	            $Model = $PCModel.Model
	        }
	    }
	    elseif($PCModel.Model -like "*Latitude*")
	    {
	        # DELL LATITUDE LAPTOPS
	        $make = "Latitude"
	        $Company = "Dell"
	        $type = "Laptop"
	        $Model = $PCModel.Model.Substring($PCModel.Model.Length - 5, 5)
            if ($model -like "E5?[0..5]?")
            {
                #Custom Code for Dell E5X[0-5]X
            }
            else
            {

            }
	    }
	    else
	    {
	        # UNKNOWN MODEL
	        if($PCModel)
	        {
	            $model = $PCModel.Model
	        }
	        else
	        {

	        }
	        if(!($model)){$model = ""}
	        $Make = $null
	        $Company = $null
	        $Type = $null
	    }
	    $properties = @{'Make' = $make;
	                    'Model' = $model;
	                    'Company'= $Company;
	                    'Type' = $type;
        }
	    $object = New-Object –TypeName PSObject –Prop $properties
	    return $object.model
    }

    ##############################################################################################################################
    #         ThunderBoltFirmwareFolder is the Folder that contains folders for different models                                 #
    #              ___________________________________________________________________                                           #
    #             |                                                                   |                                          #
    #             | MODELS THAT CAN BE DETECTED BY THIS SCRIPT:                       |                                          #
    #             |                                                                   |                                          #
    #             |        Laptops:                                                   |                                          #
    #             |                 Lenovo : T470, T480, X270                         |                                          #
    #             |                 Dell: Latitude Laptops (only tested with E5000's) |                                          #
    #             |       Desktops:                                                   |                                          #
    #             |                 Dell: Optiplex 7010, Optiplex 7020, Optiplex 7040 |                                          #
    #             |___________________________________________________________________|                                          #
    #                                                                                                                            #
    #        IE:                                                                                                                 #
    #            IF     you have thunderbolt firmware for a T470 located in C:\Temp\T470\Thunderbolt_FW                          #
    #                                                                                                                            #
    #            THEN                                                                                                            #
    #                  $ThunderBoltFirmwareFolder should be C:\Temp                                                              #
    #                  C:\Temp should contain a folder called T470                                                               #
    #                  C:\Temp should contain a folder called Thunderbolt_FW (this is the folder that is extracted from exe DL)  #
    #                                                                                                                            #
    #                  EXAMPLE:                                                                                                  #
    #                           (firmware for T470 is in C:\Temp\T470\Thunderbolt_FW)                                            #
    #                           $ThunderBoltFirmwareFolder = "C:\Temp"                                                           #
    #                                                                                                                            #
    ##############################################################################################################################


    ###############################################################################################################################################################################
    #      CHANGE THIS VALUE                                                                                                                                                      # 
    #                                                                                                                                                                             #
    #   Default setup is "[Parent folder Path]\ThunderBolt Firmware" Where parent Folder path is the filepath to the Folder containing the Folder that this script is located at  #
        $ThunderBoltFirmwareFolder = "$((Get-Item "$PSScriptRoot").Parent.FullName)\ThunderBolt Firmware"                                                                         #
    ###############################################################################################################################################################################

    $FirmwareFolder = $ThunderBoltFirmwareFolder

    #THERE WAS NO TIME TO ADD A CHECK IF COMPUTER IS OR IS NOT CONNECTED TO DOCK!!!!

    cls
    Write-Warning "Computer MUST BE DOCKED!"
    Write-Host " "
    Write-Warning "THIS WILL RESTART THE COMPUTER!"
    Read-Host "`nPress Enter to Contine"
    cls

    #IF no model parameter is given find model of computer by using WMI query
    if(!($Model))
    {
        #IF no computer parameter was given, prompt from computer then test: input is a string, input is not empty, and input is 14 chars
        while(!($computer))
        {
            $computer = $null
            [string]$computer = Read-Host "Enter Full Computer Name"
            if($computer)
            {
                if($computer -is [string])
                {
                    if($computer.trim())
                    {
                        $computer = $computer.trim()
                        if($computer.Length -ne 14)
                        {
                            $computer = $null
                            Write-Host -ForegroundColor Yellow "Computer Name is not valid!"
                            Read-Host "Press Enter to continue"
                        }
                    }
                    else
                    {
                        $computer = $null
                        Write-Host -ForegroundColor Yellow "Computer Name is not valid!"
                        Read-Host "Press Enter to continue"
                    }
                }
                else
                {
                    $computer = $null
                    Write-Host -ForegroundColor Yellow "Computer Name is not a valid type (string)!"
                    Read-Host "Press Enter to continue"
                }
            }
            else
            {
                $computer = $null
                Write-Host -ForegroundColor Yellow "Computer Name is not valid!"
                Read-Host "Press Enter to continue"
            }
        }
        $objModel = Get-WmiObject -Class Win32_ComputerSystem -ComputerName $computer
        $model = Get-PC-Model($objModel)
        
    }


    if($model -eq "T480")
    {
        #T480

        #HARDCODED FIRMWARE VERSION (as Lenovo's .exe download has different version naming convention than what it is)
	    $FirmwareVersion = "N24TF12W"
    }
    elseif($Model -eq "T470")
    {
        #T470

        #HARDCODED FIRMWARE VERSION (as Lenovo's .exe download has different version naming convention than what it is)
        $FirmwareVersion = "N1QTF15W"
    }
    else
    {
        Write-Host -ForegroundColor Cyan  "Model Detected As: " -NoNewline
        Write-Host $model

        # ONLY T470 AND T480 is supported at time of creation
        Write-Warning "Model $model not supported"
        Read-Host "Press Enter to Exit"
        exit
    }

    Write-Host -ForegroundColor Cyan  "Model Detected As: " -NoNewline
    Write-Host $model
    Write-Host -ForegroundColor Cyan "Firmware Version Set to: " -NoNewline
    Write-Host $FirmwareVersion
    Write-Host -ForegroundColor Yellow " (FIRMWARE MAY NOT READ AS THIS IN THE END)"

    if(!($CopyFiles))
    {
        $CopyFiles = $true
    }

    if($CopyFiles -eq $true)
    {
        $Folder = "$ThunderBoltFirmwareFolder\$model\Thunderbolt_FW"

        Write-Host -ForegroundColor Cyan "`nCopying Thunderbolt Firmware Folder to " -NoNewline
        Write-Host "$computer" -NoNewline
        Write-Host -ForegroundColor Cyan " C:\Temp Folder..." -NoNewline
        Copy-Item -Path "$Folder" -Destination "\\$computer\C$\Temp" -Force -Recurse
        if((Test-Path -Path "\\$computer\C$\Temp\Thunderbolt_FW\FwUpdateCmd.exe" -ErrorAction SilentlyContinue) -eq $true)
        {
            Write-Host -ForegroundColor Green "SUCCESS"
        }
        else
        {
            Write-Host -ForegroundColor Red "FAILED"
            Read-Host "Press Enter to Exit"
            exit
        }
    }
    $cmd = Invoke-Command -ComputerName $computer -ArgumentList $FirmwareVersion -ScriptBlock{
        $FirmwareVersion = $args[0]
        $fwupdatecmdpath = "C:\Temp\Thunderbolt_FW\fwupdatecmd.exe"
        $image = "C:\Temp\Thunderbolt_FW\TBT.bin"
        Write-Host -ForegroundColor Cyan "`nGetting " -NoNewline
        Write-Host "Controller ID" -NoNewline
        Write-Host -ForegroundColor Cyan "..." -NoNewline
        $controllerID = &"$fwupdatecmdpath" enumcontrollers
        Write-Host "Done"

        if($ControllerID)
        {
            Write-Host -ForegroundColor Cyan "Getting " -NoNewline
            Write-Host "Thunderbolt NVM Version" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $NVM_Version = &"$fwupdatecmdpath" getcurrentnvmversion $controllerID
            Write-Host "Done"

            Write-Host -ForegroundColor Cyan "Getting " -NoNewline
            Write-Host "Thunderbolt Patch Version" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $Patch_version = &"$fwupdatecmdpath" getcurrentpatchversion $controllerID
            Write-Host "Done"

            Write-Host -ForegroundColor Cyan "Getting " -NoNewline
            Write-Host "Thunderbolt Power Delivery Firmware Version" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $PD_Version = &"$fwupdatecmdpath" GetCurrentPdVersion $controllerID
            Write-Host "Done"

            Write-Host -ForegroundColor Cyan "Getting " -NoNewline
            Write-Host "Thunderbolt Build Version" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $BuildID = &"$fwupdatecmdpath" GetCurrentBuildId $controllerID
            Write-Host "Done"

            #wake TBT controller (unknown if needed here)
            Write-Host -ForegroundColor Cyan "Waking " -NoNewline
            Write-Host "Thunderbolt Controller" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $WakeTBT = &"$fwupdatecmdpath" WakeTbtController $controllerID
            Write-Host "Done"

            Write-Host -ForegroundColor Cyan "Getting " -NoNewline
            Write-Host "Thunderbolt Enumeration Method" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $TBT = &"$fwupdatecmdpath" GetCurrentTbtEnumMethod $controllerID
            Write-Host "Done"

            #This SHOULD get followed by verification that comparing was successfull (didn't have time to add that)
            Write-Host -ForegroundColor Cyan "Comparing " -NoNewline
            Write-Host "Thunderbolt Enumeration Method" -NoNewline
            Write-Host -ForegroundColor Cyan " To " -NoNewline
            Write-Host "Firmware Update Enumeration Method" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $compareTBT = &"$fwupdatecmdpath" CompareImageTbtEnumMethod $controllerID $image
            Write-Host "Done"

            Write-Host -ForegroundColor Cyan "`nDisplaying Thunderbolt info:"
            $properties = @{'Hardware ID' = $ControllerID;
                            'Thunderbolt_NVM Version Detected' = $NVM_Version;
                            'Thunderbolt Patch Version Detected' = $($Patch_version.trim());
                            'Power Delivery Firmware Version Detected' = $PD_Version;
                            'Thunderbolt Firmware Version Detected' = $BuildID;
                            'Woke Up Thunderbolt' = $WakeTBT;
                            'Thunderbolt Enumeration Method' = $TBT;
                            'Thunderbolt Enumeration Method Compared To Firmware Update' = $compareTBT;}
            $Return_Object = New-Object –TypeName PSObject –Prop $properties
            $PreviousBuildID = $return_object."Thunderbolt Firmware Version Detected"
            $PreviousPatchVersion = $return_object."Power Delivery Firmware Version Detected"
            $PreviousNVMVersion = $return_object."Thunderbolt_NVM Version Detected"
            $PreviousPDVersion = $return_object."Power Delivery Firmware Version Detected"
            $return_object | Out-Host

            #Don't have a great way method for checking if firmware is up to date as the firmware version doesnt change but the patch version and nvm... so not sure what values may change on update for certain
            # So...there is no check for if the firmware is up to date first... sorry

            Write-Host -ForegroundColor Yellow "`nPlease make sure laptop remains docked, is plugged in, and will not be turned off before continuing!`n"
            Read-Host "Press Enter to continue"
            Write-Host -ForegroundColor Cyan "`nUpdating Firmware..."

            #wake TBT controller just in case
            Write-Host -ForegroundColor Cyan "Waking " -NoNewline
            Write-Host "Thunderbolt Controller" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $WakeTBT = &"$fwupdatecmdpath" WakeTbtController $controllerID
            if($WakeTBT -eq $true)
            {
                write-host "Done"
                write-host -ForegroundColor cyan "Starting Firmware Update..."
                &"$fwupdatecmdpath" FWUpdate $controllerID $image
            }
            else
            {
                write-host -ForegroundColor Red "FAILED"
                Write-Warning "`nCouldn't wake Thunderbolt!`n"
                Read-host "Press Enter to exit"
                exit
            }
            Write-Host "Waiting 1 min to be safe..." -NoNewline
            Start-Sleep -Seconds 60
            Write-Host "Done"
            Write-Host "`nBeginning Verification"
            Write-Host -ForegroundColor Cyan "`nGetting " -NoNewline
            Write-Host "Controller ID" -NoNewline
            Write-Host -ForegroundColor Cyan "..." -NoNewline
            $controllerID = &"$fwupdatecmdpath" enumcontrollers
            Write-Host "Done"

            if($ControllerID)
            {
                Write-Host -ForegroundColor Cyan "Getting " -NoNewline
                Write-Host "Thunderbolt NVM Version" -NoNewline
                Write-Host -ForegroundColor Cyan "..." -NoNewline
                $NVM_Version = &"$fwupdatecmdpath" getcurrentnvmversion $controllerID
                Write-Host "Done"

                Write-Host -ForegroundColor Cyan "Getting " -NoNewline
                Write-Host "Thunderbolt Patch Version" -NoNewline
                Write-Host -ForegroundColor Cyan "..." -NoNewline
                $Patch_version = &"$fwupdatecmdpath" getcurrentpatchversion $controllerID
                Write-Host "Done"

                Write-Host -ForegroundColor Cyan "Getting " -NoNewline
                Write-Host "Thunderbolt Power Delivery Firmware Version" -NoNewline
                Write-Host -ForegroundColor Cyan "..." -NoNewline
                $PD_Version = &"$fwupdatecmdpath" GetCurrentPdVersion $controllerID
                Write-Host "Done"

                Write-Host -ForegroundColor Cyan "Getting " -NoNewline
                Write-Host "Thunderbolt Build Version" -NoNewline
                Write-Host -ForegroundColor Cyan "..." -NoNewline
                $BuildID = &"$fwupdatecmdpath" GetCurrentBuildId $controllerID
                Write-Host "Done"
                $changed = $false
                if($PreviousBuildID -ne $BuildID)
                {
                    $changed = $true
                    Write-Host -ForegroundColor Cyan "`nThunderbolt Build Version is now: " -NoNewline
                    Write-Host $BuildID
                }

                if($PreviousPDVersion -ne $PD_Version)
                {
                    $changed = $true
                    Write-Host -ForegroundColor Cyan "`nThunderbolt Power Delivery Firmware Version is now: " -NoNewline
                    Write-Host $PD_Version
                }

                if($PreviousPatchVersion -ne $($Patch_version.trim()))
                {
                    $changed = $true
                    Write-Host -ForegroundColor Cyan "`nThunderbolt Patch Version is now: " -NoNewline
                    Write-Host $Patch_version
                }

                if($PreviousNVMVersion -ne $NVM_Version)
                {
                    $changed = $true
                    Write-Host -ForegroundColor Cyan "`nThunderbolt NVM Version is now: " -NoNewline
                    Write-Host $NVM_Version
                }

                Write-Host -ForegroundColor Cyan "`nUpdate Thunderbolt Firmware result: " -NoNewline
                if($changed -eq $true)
                {
                        
                    Write-Host -ForegroundColor Green "SUCCESS"
                }
                else
                {
                    Write-Host -ForegroundColor Red "FAILED"
                }
                Read-Host "`nPress Enter to Exit"
                exit
            }
            else
            {
                Write-Warning "No Controller ID found, Firmware cannot be updated"
            }
        }
        else
        {
            Write-Warning "No Controller ID found, Firmware cannot be updated"
        }
    }
    Read-Host "`nPress Enter to Exit"
    exit
}
else
{
#************************************************************************
#-----------------------START ADMIN PS-----------------------------------

    # We are not running as an administrator, so relaunch as administrator

    # Create a new process object that starts PowerShell
    $newProcess = New-Object System.Diagnostics.ProcessStartInfo "PowerShell";

    # Specify the current script path and name as a parameter with added scope and support for scripts with spaces in it's path
    $newProcess.Arguments = "& '" + $script:MyInvocation.MyCommand.Path + "'"

    # Indicate that the process should be elevated
    $newProcess.Verb = "runas";

    # Start the new process
    [System.Diagnostics.Process]::Start($newProcess);

    # Exit from the current, unelevated, process
    Exit;
#-----------------------START ADMIN PS-----------------------------------
#************************************************************************
}