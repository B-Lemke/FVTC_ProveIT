import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

scriptpath = os.path.dirname(os.path.realpath(__file__))

VDI = sys.argv[1]
LoginUsername = sys.argv[2]
LoginUserPassword = sys.argv[3]

now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"
file = codecs.open(sys.argv[4],"w","utf-8")
stringout = "VDI set to: " + VDI + "|"
file.write(stringout)
stringout = "Date set to: " + nowoutput + "|"
file.write(stringout)
#   SETUP CHROME DRIVER
options = Options()
#options.headless = True
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")
wait = WebDriverWait(driver, 10)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

OldPCSerial = VDI
Universal_SN_iframe = "gsft_main"
OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=asset_tag=" + OldPCSerial
stringout = "Url set to: " + OldPCWebpage + "|"
file.write(stringout)
stringout = "Date set to: " + nowoutput + "|"
file.write(stringout)
stringout = "iFrame set to: " + Universal_SN_iframe + "|"
file.write(stringout)

OldPCiframe = Universal_SN_iframe

stateID = "alm_hardware.install_status"

stringout = "stateID set to: " + stateID + "|"
file.write(stringout)
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
stringout = "SecondaryStateID set to: " + SecondaryStateID + "|"
file.write(stringout)
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

#<option value="disposed">Disposed</option>

userAssignedID = "sys_display.alm_hardware.assigned_to"
stringout = "userAssignedID set to: " + userAssignedID + "|"
file.write(stringout)
DateAssignedID = "alm_hardware.assigned"
stringout = "DateAssignedID set to: " + DateAssignedID + "|"
file.write(stringout)

#Begin Webpage navigation to Old PC record first

stringout = "Navigating to URL..." 
file.write(stringout)
driver.get(OldPCWebpage)
stringout = "Navigation complete|"
file.write(stringout)

#   INITIAL LOGIN PAGE
#SET ELEMENTS IN LOGIN PAGE
userid = driver.find_element_by_id('userID')
password = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id("loginbtn")

#SEND KEYS TO ELEMENTS IN LOGIN PAGE
stringout = "logging in as user|"
file.write(stringout)
userid.send_keys(LoginUsername)
password.send_keys(LoginUserPassword)
btnLogin.click()

#   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
if driver.title == "Password is about expire":
    #NEEDS RDO BUTTON TO BE SELECTED YET BEFORE CLICKING
    Element = driver.find_element_by_id("proceedWebsite")
    actions = ActionChains(driver)
    actions.move_to_element(Element)
    actions.click(Element)
    actions.perform()
    Element = driver.find_element_by_id("passwordToExpire")
    Element.click()

print("Retiring VDI Update Service-Now Records Started")
file.write("------------------------------------------------------|")
file.write("Retiring VDI Update Service-Now Records Started|")
file.write("------------------------------------------------------|")
#SWITCH IFRAME
file.write("Waiting for iframe...")
wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
file.write("DONE|")
file.write("Switching to iframe...")
driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
file.write("DONE|")
try:
    file.write("Switching to General Tab...")
    acttext = driver.find_element(By.XPATH, '//span[text()="General"]')
    actions = ActionChains(driver)
    actions.reset_actions()
    actions.move_to_element(acttext)
    actions.click(acttext)
    actions.perform()
    file.write("DONE|")
except:
    file.write("ERROR SWITCHING TO GENERAL TAB|")
    file.write("Couldn't find VDI by Asset Tag|")
    file.write("Searching VDI by Configuration Item|")
    OldPCWebpage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=ci.name=" + OldPCSerial
    #Begin Webpage navigation to Old PC record first
    file.write("Navigating to URL...")
    driver.get(OldPCWebpage)
    file.write("Navigation complete|")
    print("Retiring VDI Update Service-Now Records Started")
    file.write("------------------------------------------------------|")
    file.write("Retiring VDI Update Service-Now Records Started|")
    file.write("------------------------------------------------------|")
    #SWITCH IFRAME
    file.write("Waiting for iframe...")
    wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    file.write("DONE|")
    file.write("Switching to iframe...")
    driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    file.write("DONE|")
    try:
        file.write("Switching to General Tab...")
        acttext = driver.find_element(By.XPATH, '//span[text()="General"]')
        actions = ActionChains(driver)
        actions.reset_actions()
        actions.move_to_element(acttext)
        actions.click(acttext)
        actions.perform()
        file.write("DONE|")
    except:
        file.write("ERROR SWITCHING TO GENERAL TAB|")
        file.write("Couldn't Find VDI in Service-Now!|")
        print("Couldn't Find VDI in Service-Now!")
        print("Exiting Python Script...")
        file.write("Exiting script|")
        file.close()
        driver.quit()
        exit()
    
time.sleep(1)
file.write("Deleting Text in Assigned user field...")
element = driver.find_element_by_id(userAssignedID)
actions = ActionChains(driver)
actions.move_to_element(element)
actions.click(element).pause(.5).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).pause(.5).send_keys(Keys.DELETE)
actions.perform()
time.sleep(1)
file.write("DONE|")

#State to Retired
file.write("Setting State to Retired (value: 7)...")
wait.until(EC.visibility_of_element_located((By.ID, stateID)))
select = Select(driver.find_element_by_id(stateID))
select.select_by_value('7')
time.sleep(1)
file.write("DONE|")

#Set Substate Available
file.write("Setting Secondary State to: disposed...")
wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
select = Select(driver.find_element_by_id(SecondaryStateID))
select.select_by_value('disposed')
file.write("DONE|")

#Set Assigned Date
file.write("Setting Assigned Date to: " + nowoutput + "...")
wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
file.write("DONE|")

#WORK NOTES
file.write("Navigating to Activities tab and Adding Work Note: Disposed of VDI...")
try:
    acttext = driver.find_element(By.XPATH, '//span[text()="Activities"]')
    try:
        actions = ActionChains(driver)
        actions.move_to_element(acttext)
        actions.click(acttext)
        actions.perform()
        try:
            Element = driver.find_element_by_id("activity-stream-textarea")
            actions = ActionChains(driver)
            actions.move_to_element(Element).click().send_keys('Disposed of VDI').perform()
            file.write("DONE|")
        except:
            file.write("ERROR Finding element by ID: activity-stream-textarea|")
    except:
        file.write("ERROR performing action chain|")
except:
    file.write("ERROR Finding element by XPATH: '//span[text()=Activities]'|")
    

#SUBMIT CHANGES TO OLD PC

file.write("Saving Changes to Service-Now Record...")
buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
actions = ActionChains(driver)
actions.move_to_element(buttonclick)
actions.click(buttonclick)
actions.perform()
file.write("DONE|")
file.write("Service-Now Record Update Complete|")
file.close()




print("Service Now is complete")
driver.quit()
exit()
