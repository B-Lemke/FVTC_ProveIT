import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

scriptpath = os.path.dirname(os.path.realpath(__file__))

MerakiSerial = sys.argv[1]
AssetConfigItemFieldID = "alm_hardware.ci_label"
AssetConfigItemBtn = "viewr.alm_hardware.ci"

StockroomLocation = sys.argv[2]
TicketNumber = None
LoginUsername = sys.argv[3]
LoginUserPassword = sys.argv[4]
MerakiWebPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Falm_hardware.do?sysparm_query=serial_number=" + MerakiSerial
MerakiCI = None
TicketNotes = []
StockRoomValueGB = 'AAH Green Bay'
StockRoomValueLV = 'AAH LV Site'
StockRoomValuePHX = 'AAH PHX'
Universal_SN_iframe = "gsft_main"
file = codecs.open(sys.argv[5],"w","utf-8")
isVDI_Old_PC = False
isVDI_New_PC = False
file.write("---------- START INPUT VALUES PASSED TO SCRIPT ---------------- |")
stringout = "Meraki Serial set to: " + str(MerakiSerial) + "|"
file.write(stringout)


stringout = "StockroomLocation set to: " + str(StockroomLocation) + "|"
file.write(stringout)

stringout = "TicketNumber set to: " + str(TicketNumber) + "|"
file.write(stringout)
file.write("---------- END INPUT VALUES PASSED TO SCRIPT ---------------- | |")


file.write("---------- START TICKET SETUP ---------------- |")
ticketurl = None
if TicketNumber:
    if TicketNumber.startswith('INC'):
        stringout = str(TicketNumber) + " detected as: INC|"
        file.write(stringout)
        ticketurl = "https://ameriprise.service-now.com/incident.do?uri=&sysparm_query=number=" + TicketNumber
        stringout = "ticketurl set to: " + str(ticketurl) + '|'
        file.write(stringout)
    elif TicketNumber.startswith('TASK'):
        stringout = TicketNumber + " detected as: TASK|"
        file.write(stringout)
        ticketurl = "https://ameriprise.service-now.com/sc_task.do?uri=&sysparm_query=number=" + TicketNumber
        stringout = "ticketurl set to: " + ticketurl + '|'
        file.write(stringout)
    elif TicketNumber.startswith('ITASK'):
        stringout = TicketNumber + " detected as: ITASK|"
        file.write(stringout)
        ticketurl = "https://ameriprise.service-now.com/u_incident_task.do?uri=&sysparm_query=number=" + TicketNumber
        stringout = "ticketurl set to: " + ticketurl + '|'
        file.write(stringout)
    else:
        stringout = TicketNumber + " NOT SUPPORTED|"
        file.write(stringout)
        print("Ticket Type not supported (ONLY ITASK, TASK, and INC are supported at this time")
        TicketNumber = None

#Write ticketnumber and URL set
file.write(" |")
file.write(stringout)
file.write("TicketURL set to: " + str(ticketurl) + "|")
file.write("---------- END TICKET SETUP ---------------- | |")


file.write("---------- START STOCKROOM FILTERING ---------------- |")
#GB
if StockroomLocation == "GB":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "GREEN BAY":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "WI":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "WISCONSIN":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "DEPERE":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "DE PERE":
    StockroomLocation = StockRoomValueGB
if StockroomLocation == "PACKERLAND":
    StockroomLocation = StockRoomValueGB
#NV
if StockroomLocation == "LV":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "NV":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "LASVEGAS":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "LAS VEGAS":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOTRD":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOT RD":
    StockroomLocation = StockRoomValueLV
if StockroomLocation == "PILOT":
    StockroomLocation = StockRoomValueLV
#AZ
if StockroomLocation == "AZ":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "DUNLAP":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "BC":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHOENIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHEONIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHENIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHONIX":
    StockroomLocation = StockRoomValuePHX
if StockroomLocation == "PHX":
    StockroomLocation = StockRoomValuePHX

if StockroomLocation == StockRoomValuePHX:
    StockMerakiCIName = 'AZ-Z3STOCK'
elif StockroomLocation == StockRoomValueLV:
    StockMerakiCIName = 'NV-Z3STOCK'
elif StockroomLocation == StockRoomValueGB:
    StockMerakiCIName = 'GRB-Z3STOCK'
else:
    StockMerakiCIName = None

stringout = "StockroomLocation set to: " + str(StockroomLocation) + "|"
file.write(stringout)
file.write("StockMerakiCIName set to: " + StockMerakiCIName + "|")

file.write("---------- END STOCKROOM FILTERING ---------------- | |")

file.write("---------- START DATETIME SETUP ---------------- |")
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"
stringout = "Date set to: " + str(nowoutput) + "|"
file.write(stringout)
file.write("---------- END DATETIME SETUP ---------------- | |")

file.write("----------- START WEB ELEMENT VARIABLES -------------------|")
file.write("              DEBUGGING PURPOSES ONLY      |")

file.write("Universal_SN_iframe set to: " + str(Universal_SN_iframe) + "|")
#State Element
stateID = "alm_hardware.install_status"
file.write("stateID set to: " + str(stateID) + "|")
file.write("            Option Values of Element:|")
file.write("   --------------------------------------------------|")
file.write('    <option value="1">In use</option>|')
file.write('    <option value="2">On order</option>|')
file.write('    <option value="3">In maintenance</option>|')
file.write('    <option value="6">In stock</option>|')
file.write('    <option value="7">Retired</option>|')
file.write('    <option value="8">Missing</option>|')
file.write('    <option value="9">In transit</option>|')
file.write('    <option value="10">Consumed</option>| |')
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

#Secondary State Element
SecondaryStateID = "alm_hardware.substatus"
file.write("SecondaryStateID set to: " + str(SecondaryStateID) + "|")
file.write("                Option Values of Element:|")
file.write("   --------------------------------------------------|")
file.write('    <option value="available">Available</option>|')
file.write('    <option value="reserved">Reserved</option>|')
file.write('    <option value="defective">Defective</option>|')
file.write('    <option value="pending_repair">Pending repair</option>|')
file.write('    <option value="pending_install">Pending install</option>|')
file.write('    <option value="pending_disposal">Pending disposal</option>|')
file.write('    <option value="pending_transfer">Pending transfer</option>|')
file.write('    <option value="pre_allocated">Pre-allocated</option></select>| |')
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"
file.write("AssetFunctionID set to: " + str(AssetFunctionID) + "|")
file.write("                Option Values of Element:|")
file.write("   --------------------------------------------------|")
file.write('    <option value="BCP">BCP</option>|')
file.write('    <option value="Call Center">Call Center</option>|')
file.write('    <option value="Disaster Recovery">Disaster Recovery</option>|')
file.write('    <option value="Lab Device">Lab Device</option>|')
file.write('    <option value="Loaner">Loaner</option>|')
file.write('    <option value="Monitoring">Monitoring</option>|')
file.write('    <option value="Primary Device">Primary Device</option>|')
file.write('    <option value="Secondary Device">Secondary Device</option>| |')
#<option value="BCP">BCP</option>
#<option value="Call Center">Call Center</option>
#<option value="Disaster Recovery">Disaster Recovery</option>
#<option value="Lab Device">Lab Device</option>
#<option value="Loaner">Loaner</option>
#<option value="Monitoring">Monitoring</option>
#<option value="Primary Device">Primary Device</option>
#<option value="Secondary Device">Secondary Device</option>
#<option value="Security">Security</option>
#<option value="Shared Device">Shared Device</option>
#<option value="Testing">Testing</option>
#<option value="Training">Training</option>
#<option value="Development">Development</option>
#<option value="Spare">Spare</option>
#<option value="Hot-Spare" selected="SELECTED">Hot-Spare</option></select>

StockRoomID = "sys_display.alm_hardware.stockroom"
file.write("StockRoomID set to: " + str(StockRoomID) + "|")

userAssignedID = "sys_display.alm_hardware.assigned_to"
file.write("userAssignedID set to: " + str(userAssignedID) + "|")

DateAssignedID = "alm_hardware.assigned"
file.write("DateAssignedID set to: " + str(DateAssignedID) + "|")

file.write("------- END WEB ELEMENT VARIABLES -------------------| |")


file.write("---------- START CHROMEWEBDRIVER SETUP ---------------- |")
file.write("              FOR DEBUGGING ONLY|")
#   SETUP CHROME DRIVER
options = Options()

# -------- HEADLESS MODE (UNCOMMENT TO TURN ON)

options.headless = True
options.add_argument('log-level=3')
options.add_argument('--window-size=1920x1080')

# -------- HEADLESS MODE (UNCOMMENT TO TURN ON)

waittimeout = 10
chromewebdriverpath = scriptpath + '/ChromeDriver/chromedriver'
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")
wait = WebDriverWait(driver, waittimeout)

file.write("Chrome Web Driver Path set to: " + str(chromewebdriverpath) + "|")
file.write("Chrome Web Driver Options set to: " + str(options) + "|")
file.write("Chrome Web Driver Wait Timeout (in seconds) set to: " + str(waittimeout) + "|")
file.write("---------- END CHROMEWEBDRIVER SETUP ---------------- | |")

file.write("---------- START DEFAULTING BOOLS ---------------- |")
file.write("             FOR DEBUGGING ONLY|")
isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

file.write("isVDI_Old_PC = False|")
file.write("isVDI_New_PC = False|")
file.write("isLaptop = False|")
file.write("---------- END DEFAULTING BOOLS ---------------- | |")


file.write("---------- START OLD PC FILTERING ---------------- |")
#Find Old PC Serial
PC = MerakiSerial
MerakiSerial = PC

stringout = "Meraki Serial set to: " + str(MerakiSerial) + "|"
file.write(stringout)
file.write("---------- END OLD PC FILTERING ---------------- | |")





file.write(" ------- START WEBSITE NAVIGATION  -------------------|")

#Begin Webpage navigation to Old PC record first
file.write("Navigating to Service-Now Meraki Asset WebPage...")
driver.get(MerakiWebPage)
file.write("DONE|")

#   INITIAL LOGIN PAGE REDIRECT
if driver.title == "Login":
    file.write("    ------- START LOGIN PAGE ---------|")
    file.write("   Redirected to Login Page|")
               
    print("Logging in As User...")

    #USER INPUT TEXTBOX ELEMENT SETUP
    file.write("    Getting UserID element...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, 'userID')))
        userid = driver.find_element_by_id('userID')
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #PASSWORD INPUT TEXTBOX ELEMENT SETUP
    file.write("    Getting password element...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, 'password')))
        password = driver.find_element_by_id('password')
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #LOGIN BUTTON ELEMENT SETUP
    file.write("    Getting password element...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, 'loginbtn')))
        btnLogin = driver.find_element_by_id("loginbtn")
    except NoSuchElementException:
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #SEND KEYS USER ELEMENT
    file.write("    Entering Username...")
    try:
        userid.send_keys(LoginUsername)
    except:
        file.write("FAILED: ERROR OCCURED DURING Username ENTRY|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #SEND KEYS PASSWORD ELEMENT
    file.write("    Entering Password...")
    try:
        password.send_keys(LoginUserPassword)
    except:
        file.write("FAILED: ERROR OCCURED DURING password ENTRY|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    #CLICK LOGIN BUTTON ELEMENT
    file.write("    Clicking Login Button...")
    try:
        btnLogin.click()
    except:
        file.write("FAILED: ERROR OCCURED DURING Login button CLICK|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")
    file.write("    ------- END LOGIN PAGE ---------| |")

    #   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
    if driver.title == "Password is about expire":
        Element = driver.find_element_by_id("proceedWebsite")
        actions = ActionChains(driver)
        actions.move_to_element(Element)
        actions.click(Element)
        actions.perform()
        Element = driver.find_element_by_id("passwordToExpire")
        Element.click()
file.write("------------ START MERAKI SERVICE-NOW RECORD GET/SET ----------------------------|")
#MERAKI WEBPAGE
if MerakiSerial in driver.title:
    file.write("Found correct webpage for Meraki by title: " + str(driver.title) + "|")
    file.write("Starting Meraki Service-Now Record Update...|")
    print("Updating Meraki Service-Now Record...")
    
    #SWITCH IFRAME
    file.write("   Switching to iFrame...")
    try:
        wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    except NoSuchElementException:
        print("FAILED: COULDNT FIND ELEMENT!")
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except TimeoutException:
        print("FAILED: TIMED OUT WAITING FOR ELEMENT!")
        file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        print("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!")
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")
    file.write("    Getting Configuration Item Name in record...")
    try:
        Element = driver.find_element(By.ID, 'alm_hardware.ci_label')
        MerakiCI = Element.get_attribute("value")
        time.sleep(.5)
        file.write("SUCCESS|")
    except NoSuchElementException:
        MerakiCI = None
        print("FAILED: COULDNT FIND ELEMENT!")
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        MerakiCI = None
        print("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!")
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")
    
    file.write("    Selecting General tab in record...")
    try:
        acttext = driver.find_element(By.XPATH, '//span[text()="General"]')
        actions = ActionChains(driver)
        actions.reset_actions()
        actions.move_to_element(acttext)
        actions.click(acttext)
        actions.perform()
    except NoSuchElementException:
        print("FAILED: COULDNT FIND ELEMENT!")
        file.write("FAILED: COULDNT FIND ELEMENT!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    except:
        print("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!")
        file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
        file.write("    Exiting Script|")
        file.close()
        driver.quit()
        exit()
    file.write("SUCCESS|")

    if isVDI_Old_PC == False:
        file.write("   Getting Old User Assigned Element...")
        #Open User info panel
        time.sleep(1)
        
        try:
            wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
            Element = driver.find_element_by_id(userAssignedID)
            file.write("SUCCESS|")
            file.write("    Getting Old User Assigned Value...")
            try:
                OldUserAssigned = Element.get_attribute("value")
                time.sleep(.5)
                file.write("SUCCESS|")
                print("User Assigned to Meraki was: " + str(OldUserAssigned))
                file.write("        User Assigned to Meraki was: " + str(OldUserAssigned) + "|")
                print(" ")

                #Get User record show button element
                file.write("   Getting Old User Records Attributes Element...")
                try:
                    element = driver.find_element_by_id("view.alm_hardware.assigned_to")
                    actions = ActionChains(driver)
                    actions.reset_actions()
                    actions.move_to_element(element)
                    actions.click(element)
                    actions.perform()
                    time.sleep(3)
                    file.write("SUCCESS|")
                    #wait.until(EC.visibility_of_element_located((By.ID, "sys_user.u_space_id")))
        
                    #Get User Employee Number from user panel
                    file.write("   Getting Employee Number from User Attributes...")
                    try:
                        EmpNum = None
                        element = driver.find_element_by_id("sys_user.employee_number")
                        atr = element.get_attribute("value")
                        print("Employee number from user: " + str(atr))
                        if atr:
                            EmpNum = str(atr)
                            file.write("SUCCESS|")
                            file.write("        Employee number is: " + str(EmpNum) + "|")
                        else:
                            EmpNum = None
                            file.write("SUCCESS|")
                            file.write("        Employee number was empty|")
                    except:
                        EmpNum = None
                        print("FAILED: ERROR OCCURED getting Employee number from user attributes")
                        file.write("FAILED: ERROR OCCURED getting Employee number from user attributes|")
                except:
                    EmpNum = None
                    print("FAILED: AN ERROR OCCURED Getting User information record (Employee number)")
                    file.write("FAILED: AN ERROR OCCURED Getting User information record (Employee number) |")   
            except:
                print("FAILED: AN ERROR OCCURED getting value from User assigned to Meraki!")
                file.write("FAILED: AN ERROR OCCURED getting value from User assigned to Meraki!|")
                OldUserAssigned = ''
        except NoSuchElementException:
            print("FAILED: COULDNT FIND ELEMENT!")
            file.write("FAILED: COULDNT FIND ELEMENT!|")
        except TimeoutException:
            print("FAILED: TIMED OUT WAITING FOR ELEMENT!")
            file.write("FAILED: TIMED OUT WAITING FOR ELEMENT!|")
        except:
            print("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!")
            file.write("FAILED: UNKNOWN ERROR OCCURED (NO TIMEOUT OR ELEMENT NOT FOUND ERRORS)!|")
            file.write("    Exiting Script|")
            file.close()
            driver.quit()
            exit()
        file.write("    SUCCESSFULLY RETRIEVED USER ELEMENT|")
    
    wait.until(EC.visibility_of_element_located((By.ID, stateID)))
    select = Select(driver.find_element_by_id(stateID))
    if isVDI_Old_PC == True:
        #Set Disposed if VDI
        stringout = "Setting State to Retired (value: 7)|"
        file.write(stringout)
        select.select_by_value('7')
        print("Setting Old PC State to: Retired")
    else:
        stringout = "Setting State to In Stock (value: 6)|"
        file.write(stringout)
        select.select_by_value('6')
        print("Setting Meraki State to: In Stock")

        #Set Stockroom PC is Located
        stringout = "Selecting all text in Stockroom field and overwritting with: " + StockroomLocation + "|"
        file.write(stringout)
        wait.until(EC.visibility_of_element_located((By.ID, StockRoomID)))
        Element = driver.find_element_by_id(StockRoomID)
        Element.click()
        Element.send_keys(Keys.CONTROL, 'a')
        Element.send_keys(StockroomLocation)

        print("Setting Meraki Stockroom to: "+ StockroomLocation)

    #Set Substate Available
    wait.until(EC.visibility_of_element_located((By.ID, SecondaryStateID)))
    select = Select(driver.find_element_by_id(SecondaryStateID))
    stringout = "Setting Secondary State to: available|"
    file.write(stringout)
    select.select_by_value('available')
    print("Setting Meraki SubState to: available")
    
    #Set Asset Function to
    wait.until(EC.visibility_of_element_located((By.ID, AssetFunctionID)))
    select = Select(driver.find_element_by_id(AssetFunctionID))
    stringout = "Setting Asset Function to: Spare|"
    file.write(stringout)
    select.select_by_value('Spare')
    
    #Set Assigned Date
    stringout = "Setting Assigned Date to: " + str(nowoutput) + "|"
    file.write(stringout)
    wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
    driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
    print("Setting Meraki Assigned Date: " + nowoutput)
    
    #WORK NOTES
    #stringout = "Navigating to Activities tab...|"
    #file.write(stringout)
    #acttext = driver.find_element(By.XPATH, '//span[text()="Activities"]')
    #actions = ActionChains(driver)
    #actions.reset_actions()
    #actions.move_to_element(acttext)
    #actions.click(acttext)
    #actions.perform()
    
    
    #if not TicketNumber is None:
        #Add Replacing note
        #stringout = "oldpcoutput added to TicketNotes Array|"
        #file.write(stringout)
        #TicketNotes += [oldpcoutput]
    
    #stringout = "adding oldpcoutput to work notes...|"
    #file.write(stringout)
    #Element = driver.find_element_by_id("activity-stream-textarea")
    #actions = ActionChains(driver)
    #actions.reset_actions()
    #actions.move_to_element(Element).click().send_keys(oldpcoutput).perform()
    #print("________________________________")
    #print("|  Adding Work Note:")
    #print("|  " + str(oldpcoutput))
    #print("________________________________")
    #print("  Searching Work notes for Location and Combo...")

    #SUBMIT CHANGES TO MERAKI
    stringout = "Saving Meraki Service-Now Record...|"
    file.write(stringout)
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()

else:
    #MERAKI WEBPAGE NOT NAVIGATED TO
    print(MerakiSerial + " Not Found in webpage title")
    print("Exiting Script")
    file.close()
    exit()

print("-------------------------------------------------------")
print(" ")
file.write("Meraki Service-Now Record Update Complete|")

#   Change Configuartion Item name
file.write("Starting New PC Service-Now Record Update..." + "|")
print(" _______________________________________________________________________________")
print("|         Submitting Meraki Configuration Item name Change in Service-Now       |")
print("|_______________________________________________________________________________|")
print(" ")
file.write("Opening Meraki Configuration Item Webpage.." + "|")

#Get User record show button element
try:

    MerakiConfigPage = "https://ameriprise.service-now.com/nav_to.do?uri=%2Fcmdb_ci_ip_router.do?sysparm_query=name=" + MerakiCI
    expectedwindows = 2
    windows_before  = driver.current_window_handle
    driver.execute_script("window.open('" + MerakiConfigPage + "')")
    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    windows_after = driver.window_handles
    driver.switch_to.window(windows_after[expectedwindows - 1])
    expectedwindows = expectedwindows + 1 


    #SWITCH IFRAME
    try:
        file.write("Switching to iFrame..." + "|")
        wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
        driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
        time.sleep(2)
        file.write("SUCCESS|")
    except:
        print("FAILED: Switching to iFrame")
        file.write("FAILED|")
        
    file.write("   Clicking Propose changes link...")
    stopconfig = False
    try:
        try:
            wait.until(EC.visibility_of_element_located((By.ID, '620286fb6cccf0006f9847952c7ebd69')))
        except:
            print("WAITING FOR PROPOSE LINK ID TO BE VISIBLE FAILED!")
            file.write("WAITING FOR PROPOSE LINK ID TO BE VISIBLE FAILED!|")
        
        element = driver.find_element_by_id('620286fb6cccf0006f9847952c7ebd69')
        actions = ActionChains(driver)
        actions.move_to_element(element)
        actions.click(element)
        actions.perform()
        file.write("SUCCESS|")
        stopconfig = False
    except:
        print("FAILED: ERROR OCCURED Clicking Propose changes link")
        file.write("FAILED: ERROR OCCURED Clicking Propose changes link|")
        stopconfig = True

    #if not StockMerakiCIName:
        #file.write("MERAKI STOCK NAME WAS NULL|")
        #stopconfig = True

    file.write("   Selecting and Changing Configuration Item name...")
    if stopconfig == False:
        try:
            wait.until(EC.visibility_of_element_located((By.ID, 'cmdb_ci_ip_router.name')))
            element = driver.find_element_by_id('cmdb_ci_ip_router.name')
            actions = ActionChains(driver)
            actions.reset_actions()
            actions.move_to_element(element).click(element).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).pause(1).send_keys(StockMerakiCIName).pause(.5).send_keys(Keys.DOWN).pause(.5).send_keys(Keys.TAB).perform()
            time.sleep(.5)
            file.write("SUCCESS|")
            file.write("   Saving Configuration Item Proposed Changes...")
            element = driver.find_element_by_id('7ff1db77a9fe3dba00f4b327dc2cc731')
            actions = ActionChains(driver)
            actions.reset_actions()
            actions.move_to_element(element)
            actions.click(element)
            actions.perform()
            file.write("SUCCESS|")
            stopconfig = False
        except:
            print("FAILED: ERROR OCCURED Changing Configruation Item Name")
            file.write("FAILED: ERROR OCCURED Changing Configruation Item Name|")
            stopconfig = True
except:
    EmpNum = None
    print("FAILED: AN ERROR OCCURED Getting to Configuration Item Webpage")
    file.write("FAILED: AN ERROR OCCURED Getting to Configuration Item Webpage|")   


if not TicketNumber is None:
    file.write("--------------- START ADDING NOTES TO " + str(TicketNumber) + " ---------------------|")
    file.write("    Adding Additional Notes to Ticket Notes Array: Updated AD, and Service-Now|")
    TicketNotes += ["Meraki Serial: " + str(MerakiSerial) + " returned to stock and Service-Now updated"]
    print("Start: Add note to " + str(TicketNumber))
    print(" ")
    print("----------------------------------------------------------------")
    print("|  WORKS NOTES BEING ADDED:")
    file.write("Adding to Ticket Notes:" + "|")
    file.write("-------------------------------------------------------------------|")
    for note in TicketNotes:
        file.write(note + "|")
        print("|  " + note)
        print("----------------------------------------------------------------")
        print(" ")
    file.write("-------------------------------------------------------------------| |")
    file.write("Saving Ticket..." + "|")
    windows_before  = driver.current_window_handle
    driver.execute_script("window.open('" + ticketurl + "')")
    WebDriverWait(driver, 10).until(EC.number_of_windows_to_be(expectedwindows))
    windows_after = driver.window_handles
    driver.switch_to.window(windows_after[expectedwindows - 1])
    #print("Page Title after Tab Switching is : %s" %driver.title)
    expectedwindows = expectedwindows + 1

    #if TicketNumber.startswith('INC'):
        #Universal_SN_iframe = "https://ameriprise.service-now.com/incident.do?uri=&sysparm_query=number=" + TicketNumber
    #elif TicketNumber.startswith('TASK'):
        #Universal_SN_iframe = "AC.sc_task.request_item.u_requested_for_shim"
    #elif TicketNumber.startswith('ITASK'):
        #Universal_SN_iframe = "https://ameriprise.service-now.com/u_incident_task.do?uri=&sysparm_query=number=" + TicketNumber
        
                              
    #wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
    #driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
    time.sleep(2)
    Element = driver.find_element_by_id("activity-stream-textarea")
    actions = ActionChains(driver)
    actions.move_to_element(Element).click(Element).pause(1).perform()
    for note in TicketNotes:
        actions = ActionChains(driver)
        actions.send_keys(note).pause(.1).send_keys(Keys.ENTER).pause(.1).perform()

        #Post Work note in ticket
    #time.sleep(.5)
    #Postbtn = driver.find_element_by_class_name('btn btn-default pull-right activity-submit')
    #actions = ActionChains(driver)
    #actions.move_to_element(Element).click(Element).pause(1).perform()
    
    #SUBMIT CHANGES TO TICKET
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()
    file.write("--------------- END ADDING NOTES TO " + str(TicketNumber) + " ---------------------| |")
    
file.write("END OF SCRIPT")
file.close()

print("Service Now Script complete")
driver.quit()
