import sys, getopt, re, time, string, datetime, os, codecs
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

scriptpath = os.path.dirname(os.path.realpath(__file__))

VDI = sys.argv[1]
LoginUsername = sys.argv[3]
LoginUserPassword = sys.argv[4]
#UserFullname = sys.argv[3]
UserEmail = sys.argv[2]

file = codecs.open(sys.argv[5],"w","utf-8")
now = datetime.datetime.now()
strnow = now.strftime("%Y-%m-%d %H:%M")
nowoutput = strnow + ":00"

#   SETUP CHROME DRIVER
options = Options()
options.headless = True
options.add_argument('log-level=3')
options.add_argument('--window-size=1920x1080')
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Script Fixes/Python/ChromeDriver/chromedriver')
print(" ")
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
driver = webdriver.Chrome(options=options, executable_path= scriptpath + '/ChromeDriver/chromedriver')
print("------------------- IGNORE THIS (ERRORS HERE DONT AFFECT ANYTHING) ------------------------")
print(" ")
wait = WebDriverWait(driver, 10)
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

isVDI_Old_PC = False
isVDI_New_PC = False
isLaptop = False

#Find Old PC Serial
PC = VDI
if "WILG000" in PC: PC = PC.replace("WILG000","")
elif "WILG00" in PC: PC = PC.replace("WILG00","")
elif "WIDG000" in PC: PC = PC.replace("WIDG000","")
elif "WIDG00" in PC: PC = PC.replace("WIDG00","")
elif "AZLG000" in PC: PC = PC.replace("AZLG000","")
elif "AZLG00" in PC: PC = PC.replace("AZLG00","")
elif "AZDG000" in PC: PC = PC.replace("AZDG000","")
elif "AZDG00" in PC: PC = PC.replace("AZDG00","")
elif "NVLG000" in PC: PC = PC.replace("NVLG000","")
elif "NVLG00" in PC: PC = PC.replace("NVLG00","")
elif "NVDG000" in PC: PC = PC.replace("NVDG000","")
elif "NVDG00" in PC: PC = PC.replace("NVDG00","")
elif "MILG000" in PC: PC = PC.replace("MILG000","")
elif "MILG00" in PC: PC = PC.replace("MILG00","")
elif "MIDG000" in PC: PC = PC.replace("MIDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "MNLG000" in PC: PC = PC.replace("MNLG000","")
elif "MNLG00" in PC: PC = PC.replace("MNLG00","")
elif "MNDG000" in PC: PC = PC.replace("MNDG000","")
elif "MNDG00" in PC: PC = PC.replace("MNDG00","")
elif "WIVGP" in PC:
    #PC is VDI (different functions required)
    PC = PC
    isVDI_Old_PC = True
else:
    #Can't Format to Serial number from full name
    print("NO PC SERIAL COULD BE FOUND FOR: " + PC)
    print("Exiting script")
    file.close()
    exit()
    
OldPCSerial = PC


Universal_SN_iframe = "gsft_main"

OldPCWebpage = "[URL SEARCH]" + OldPCSerial

OldPCiframe = Universal_SN_iframe


stateID = "alm_hardware.install_status"
#<option value="1">In use</option>
#<option value="2">On order</option>
#<option value="6">In stock</option>
#<option value="9">In transit</option>
#<option value="10">Consumed</option>
#<option value="3">In maintenance</option>
#<option value="7">Retired</option>
#<option value="8">Missing</option>

SecondaryStateID = "alm_hardware.substatus"
#<option value="available">Available</option>
#<option value="reserved">Reserved</option>
#<option value="defective">Defective</option>
#<option value="pending_repair">Pending repair</option>
#<option value="pending_install">Pending install</option>
#<option value="pending_disposal">Pending disposal</option>
#<option value="pending_transfer">Pending transfer</option>
#<option value="pre_allocated">Pre-allocated</option></select>

AssetFunctionID = "alm_hardware.u_asset_function"

StockRoomID = "sys_display.alm_hardware.stockroom"

userAssignedID = "sys_display.alm_hardware.assigned_to"

DateAssignedID = "alm_hardware.assigned"

file.write("Navigating to webpage...")
#Begin Webpage navigation to Old PC record first
driver.get(OldPCWebpage)
file.write("DONE|")

file.write("Logging In...")
#   INITIAL LOGIN PAGE
#SET ELEMENTS IN LOGIN PAGE
userid = driver.find_element_by_id('userID')
password = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id("loginbtn")

#SEND KEYS TO ELEMENTS IN LOGIN PAGE
print(userid.get_attribute('id') + " adding text...")
userid.send_keys(LoginUsername)
print(password.get_attribute('id') + " adding text...")
password.send_keys(LoginUserPassword)
print(btnLogin.get_attribute('id') + " clicking button...")
btnLogin.click()

#   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
if driver.title == "Password is about expire":
    file.write("|PASSWORD IS ABOUT TO EXPIRE REDIRECT...")
    Element = driver.find_element_by_id("proceedWebsite")
    actions = ActionChains(driver)
    actions.move_to_element(Element)
    actions.click(Element)
    actions.perform()
    Element = driver.find_element_by_id("passwordToExpire")
    Element.click()
    file.write("Proceed without changing selected|")
else:
    file.write("DONE|")

#   NEW PC
#New Tab, switch tab, and navigate new tab to New PC webpage
print("New PC Service-Now Records Started")


#SWITCH IFRAME
file.write("Waiting for iframe...")
wait.until(EC.visibility_of_element_located((By.ID, Universal_SN_iframe)))
file.write("DONE|")
file.write("Switching to iframe...")
driver.switch_to.frame(driver.find_element_by_id(Universal_SN_iframe))
file.write("DONE|")

file.write("Switching to General tab...")
print("Switching to general tab")
acttext = driver.find_element_by_xpath('//span[text()="General"]')
actions = ActionChains(driver)
actions.reset_actions()
actions.move_to_element(acttext)
actions.click(acttext)
actions.perform()
file.write("DONE|")

file.write("Setting State to In Use...")
try:
    #State to In use
    wait.until(EC.visibility_of_element_located((By.ID, stateID)))
    select = Select(driver.find_element_by_id(stateID))
    select.select_by_value('1')
    time.sleep(1)
    print("Set State to: In Use")
    file.write("DONE|")
except:
    print("[ERROR]Set State to: In Use")
    file.write("ERROR OCCURED|")

file.write("Setting Assigned User to " + str(UserEmail) + "...")
try:
    #Assigned User
    wait.until(EC.visibility_of_element_located((By.ID, userAssignedID)))
    Element = driver.find_element_by_id(userAssignedID)
    actions = ActionChains(driver)
    actions.reset_actions()
    #actions.move_to_element(Element).click(Element).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).pause(1).send_keys(UserFullname).pause(1).send_keys(Keys.TAB).perform()
    actions.move_to_element(Element).click(Element).key_down(Keys.CONTROL).send_keys('a').key_up(Keys.CONTROL).pause(1).send_keys(UserEmail).pause(2).send_keys(Keys.DOWN).pause(.5).send_keys(Keys.TAB).perform()
    file.write("DONE|")
except:
    print("[ERROR] Entering Assigned user")
    file.write("ERROR OCCURED|")
time.sleep(2)

file.write("Verifying Assigned user...|")               
try:
    Element = driver.find_element_by_id(userAssignedID)
    UserSet = Element.get_attribute("value")
    print("Set User Assigned to: " + str(UserSet))
    file.write("Set Assigned User to:" + str(UserSet)) 
except:
    print("Couldn't read value after changing: User Assigned")
    file.write("Couldn't read value after changing: User Assigned|") 

file.write("Setting Asset Function to Primary Device...")
try:
    #Set Asset Function to
    wait.until(EC.visibility_of_element_located((By.ID, AssetFunctionID)))
    select = Select(driver.find_element_by_id(AssetFunctionID))
    select.select_by_value('Primary Device')
    print("Set Asset Function to: Primary Device")
    file.write("DONE|")  
except:
    file.write("ERROR|")
    
file.write("Setting Date Assigned to" + str(nowoutput) + "...")
try:
    #Assigned Dated
    wait.until(EC.visibility_of_element_located((By.ID, DateAssignedID)))
    #Element = driver.find_element_by_id("//input[@id='" + DateAssignedID + "']")
    driver.execute_script("document.getElementById('" + DateAssignedID + "').setAttribute('value', '" + nowoutput + "')")
    print("Set Date to: " + str(nowoutput))
    file.write("DONE|")
except:
    file.write("ERROR|")

file.write("Saving changes...")
try:
    #SUBMIT CHANGES TO OLD PC
    buttonclick = driver.find_element(By.ID, 'sysverb_update_and_stay')
    actions = ActionChains(driver)
    actions.move_to_element(buttonclick)
    actions.click(buttonclick)
    actions.perform()
    file.write("DONE|")
except:
    file.write("ERROR|")



print("Service Now is complete")
file.write("Service-Now Record Update Complete|")
file.close()
driver.quit()
exit()
