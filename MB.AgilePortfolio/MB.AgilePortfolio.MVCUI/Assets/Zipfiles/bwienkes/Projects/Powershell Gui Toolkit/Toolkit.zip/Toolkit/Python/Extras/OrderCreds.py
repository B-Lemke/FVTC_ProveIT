import sys
Arguments: [sys.argv[0], sys.argv[1], sys.argv[2], sys.argv[3]]
print('Filepath:', sys.argv[0])
print('Username:', sys.argv[1])
import time
from selenium.webdriver.chrome.options import Options
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select

userloginname = sys.argv[2]
userloginpass = sys.argv[3]
#   SETUP CHROME DRIVER
options = Options()
#options.headless = True
options.add_argument('disable-infobars')
options.add_argument("--disable-extensions")
options.add_argument('--disable-gpu')
#chrome_path="C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver"

#   CHROMEWEBDRIVER DRIVER INIT
driver = webdriver.Chrome(options=options, executable_path=r'C:/users/bwienk1/Desktop/Powershell Files/selenium-powershell-master/chromedriver')

#   GET WEBPAGE
driver.get('https://ameriprise.service-now.com/ameriprise/catalog.do?sysparm_document_key=sc_cat_item,2b468f379cb941004c7201eb33272b42');

#print("sleep 1")
#time.sleep(1)

#   SET ELEMENTS IN LOGIN PAGE
userid = driver.find_element_by_id('userID')
password = driver.find_element_by_id('password')
btnLogin = driver.find_element_by_id("loginbtn")

#   SEND KEYS TO ELEMENTS IN LOGIN PAGE
print(userid.get_attribute('id') + " adding text...")
userid.send_keys(userloginname)
print(password.get_attribute('id') + " adding text...")
password.send_keys(userloginpass)
print(btnLogin.get_attribute('id') + " clicking button...")
btnLogin.click()

#   IF NEED TO CHANGE PASSWORD PAGE REDIRECT
if driver.title == "Password is about expire":
    #NEEDS RDO BUTTON TO BE SELECTED YET BEFORE CLICKING
    
    #   RADIO BUTTON
    print("finding Radio button")
    rdoProceed = driver.find_element_by_css_selector("input[id='proceedWebsite']")
    print("checking Radio button")
    rdoProceed.checked()
    print("checked Radio button")
    print("sleeping 10")
    time.sleep(10)
    #rdoProceed.click()
    
    #   SUBMIT BUTTON
    print("getting continue button")
    button = driver.find_element_by_xpath("//button[@onclick=\"JavaScript:setValues();\"]")
    print("Clicking continue button")
    #BUTTON COMMENTED OUT AS RDO NEEDS TO BE SELECTED PROPERLY FIRST
    #button.click()

print("switch to iframeresult")
driver.switch_to.frame(driver.find_element_by_id("gsft_main"))
print("searching by input id")
Usersname = sys.argv[1]
#Inputbox = driver.find_element_by_xpath("//input[@id='sys_display.IO:3cd7f12a903da80087a863f119b63795']")
driver.execute_script("document.getElementById('sys_display.IO:3cd7f12a903da80087a863f119b63795').setAttribute('value', '" + Usersname + "')")
select = Select(driver.find_element_by_id('IO:9d76cf379cb941004c7201eb33272b36'))
select.select_by_value('Yes - Employee')

select = Select(driver.find_element_by_id('IO:4b3787779cb941004c7201eb33272bdc'))
select.select_by_value('No')

select = Select(driver.find_element_by_id('IO:4f674b779cb941004c7201eb33272b18'))
select.select_by_value('No')

select = Select(driver.find_element_by_id('IO:1c87cf379cb941004c7201eb33272b56'))
select.select_by_value('Yes')

select = Select(driver.find_element_by_id('IO:dac086244ddf91004c72de7a362d4691'))
select.select_by_value('No')

#driver.execute_script("javascript:\"if ($$('.order_buttons .disabled_order_button').length == 0) { orderNow(); } else { alert('Please wait - price being updated'); };\"")


#CLEAR EXISTING TEXT
#Inputbox.sendKeys(Keys.CONTROL + "a")
#Inputbox.sendKeys(Keys.DELETE)

#INPUT
#print("send keys...")
#Inputbox.send_keys("Test")





#SLEEP END OF SCRIPT DELAY
#print("sleep 10")
#time.sleep(10)






#print("button")
#button = driver.find_element_by_xpath("//button[@onclick=\"myFunction()\"]")
#print("sleep 1")
#time.sleep(1)
#print("execute script")
#driver.execute_script("javascript:myFunction()")

#ActionChains(driver).move_to_element(button).click(button).perform()

#id needed settings_modal
#ids = driver.find_elements_by_xpath('//*[@id]')
#classes = driver.find_elements_by_xpath('//*[@class]')
#names = driver.find_elements_by_xpath('//*[@name]')
#driver.execute_script
#span_element = driver.find_element_by_css_selector(".form-control ")
#print("span E = " + span_element.text)
#html = driver.find_element_by_tag_name('html').get_attribute('innerHTML')
#for ii in ids:
    #print ii.tag_name
#	if ii.get_attribute('id') == "settings_modal":
#		container = ii
#	print('ID = ' + ii.get_attribute('id') + ' Class = ' + ii.get_attribute('class') + ' name = ' + ii.get_attribute('name') + ' HTML = ' +  ii.get_attribute('innerHTML') )
#print('ID = ' + container.get_attribute('id') + ' Class = ' + container.get_attribute('class') + ' name = ' + container.get_attribute('name') + ' HTML = ' +  container.get_attribute('innerHTML') )
#print("CLASSES-------------------")
#for ii in classes:
    #print ii.tag_name
	#print('ID = ' + ii.get_attribute('id') + ' Class = ' + ii.get_attribute('class') )
#print("NAMES-------------------")
#for ii in names:
    #print ii.tag_name
	#print('ID = ' + ii.get_attribute('id') + ' name = ' + ii.get_attribute('name') )
driver.quit()
